const webpack = require("webpack");
const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const GeneratorPlugin = require("./webpack.plugins").GeneratorPlugin;

const contains = (...values) => {
    return (filename) => {
        return values.some(value => {
            return filename.indexOf(value) >= 0;
        });
    }
};

const isNodeModuleFile = contains("node_modules");

const some = (...p) => {
    return (filename) => {
        return p.some(e => e(filename));
    };
};

const every = (...p) => {
    return (filename) => {
        return p.every(e => e(filename));
    };
};

const endsWith = (...extensions) => {
    return (filename) => {
        return extensions.some(ext => {
            return filename.endsWith(ext);
        });
    };
};

const defaultPublicPath = "/analystdesktop/widget/site/";
const defaultFabricFontBasePath = "/analystdesktop/widget/site"; // Fabric appends /fonts/...
const defaultFabricIconBasePath = "/analystdesktop/widget/site/icons/fabric/";

const createConfig = (env) => {
    if(!env) {
        env = {};
    }
    const publicPath = env.publicPath ? env.publicPath : defaultPublicPath;
    const fabricFontBasePath = env.fabricFontBasePath ? env.fabricFontBasePath : defaultFabricFontBasePath;
    const fabricIconBasepath = env.fabricIconBasePath ? env.fabricIconBasePath : defaultFabricIconBasePath;
    const production = env.production ? true : false;
    const configName = !production && env.configName ? env.configName : undefined;
    const buildVersion = env.buildVersion ? env.buildVersion : production ? "Unknown" : "DEV";

    const AppConfig = {
        production: production,
        basePath: publicPath,
        fabricIconBasePath: fabricIconBasepath,
        fabricFontBasePath: fabricFontBasePath,
        buildVersion: buildVersion,
        configName: configName,
        buildDate: new Date(),
        env: env
    };

    const config = {
        mode: AppConfig.production ? "production" : "development",
        entry: {
            index: ["./src/index.tsx"]
        },
        output: {
            filename: AppConfig.production ? "[name].[chunkhash].js" : "[name].js",
            path: path.join(__dirname, "dist"),
            publicPath: publicPath
        },
        externals: [
            {'./node_modules/jszip': 'jszip'}
        ],
        module: {
            rules: [
                {
                    enforce: "pre",
                    test: endsWith(".ts", ".tsx", ".js"),
                    loader: "source-map-loader",
                    exclude: some(isNodeModuleFile, endsWith(".html.ts"))
                },
                {
                    test: endsWith(".ts", ".tsx"),
                    loader: "ts-loader",
                    exclude: isNodeModuleFile
                },
                {
                    test: endsWith(".css"),
                    use: [
                        { loader: "@microsoft/loader-load-themed-styles" },
                        { loader: "css-loader" }
                    ]
                },
                {
                    test: endsWith(".scss"),
                    use: [
                        { loader: "@microsoft/loader-load-themed-styles" },
                        { loader: "css-loader" },
                        { 
                            loader: "sass-loader",
                            options: {
                                data: `$ms-font-cdn-path: "${AppConfig.fabricFontBasePath}";`
                            }
                        }
                    ]
                },
                {
                    test: endsWith(".woff", ".woff2", ".font.svg", ".ttf", ".eot"),
                    use: [
                        { loader: "file-loader" }
                    ]
                },
                {
                    test: endsWith(".png", ".jpg", ".gif"),
                    use: [
                        { loader: "file-loader" }
                    ]
                }
            ]
        },
        resolve: {
            extensions: [".js", ".tsx", ".ts"],
            modules: [
                path.resolve(__dirname, "src"), "node_modules"
            ],
            alias: {
                "package.json$": path.resolve(__dirname, "package.json")
            }
        },
        devtool: "source-map",
        plugins: [
            new HtmlWebpackPlugin({
                title: "Analyst Desktop",
                template: "src/index.html.ts",
                AppConfig: AppConfig,
                chunks: ["index"],
                chunksSortMode: "none"
            }),
            new CopyWebpackPlugin([
                { from: 'report_templates', to: 'report_templates' },
                { from: "fonts", to: "fonts" },
                { from: 'ideas', to: 'ideas' },
                { from: `${path.dirname(require.resolve('@uifabric/icons'))}/../fonts`, to: "icons/fabric" }
            ]),
            new GeneratorPlugin({
                generator: () => {
                    return `window.AppConfig = ${JSON.stringify(AppConfig, null, "\t")};`
                },
                filename: "AppConfig.js"
            })
        ]
    };
    
    return config;
};

module.exports = createConfig;