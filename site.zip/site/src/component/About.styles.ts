import { IStyle, getTheme, concatStyleSets, ITheme, FontSizes, FontWeights } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface IAboutStyles {
    root?: IStyle;
    section?: IStyle;
    sectionTitle?: IStyle;
    sectionBody?: IStyle;
    config?: IStyle;
}

const defaultStyles = (theme : ITheme) : IAboutStyles => {
    return {
        root: {},
        section: {},
        sectionTitle: {
            margin: 0,
            paddingTop: 16,
            paddingBottom: 8,
            fontSize: FontSizes.medium
        },
        sectionBody: {},
        config: {
            fontSize: FontSizes.small,
            fontWeight: FontWeights.semilight
        }
    };
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles : IAboutStyles) : IAboutStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export { IAboutStyles, getStyles }