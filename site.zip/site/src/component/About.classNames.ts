import { memoizeFunction } from "@uifabric/utilities";
import { mergeStyles } from "@uifabric/styling";
import { IAboutStyles } from "./About.styles";

interface IAboutClassNames {
    root?: string;
    section?: string;
    sectionTitle?: string;
    sectionBody?: string;
    config?: string;
}

const getClassNames = memoizeFunction((styles : IAboutStyles, className?: string) : IAboutClassNames => {
    return {
        root: mergeStyles("about", className, styles.root),
        section: mergeStyles("about-section", styles.section),
        sectionTitle: mergeStyles("about-section-title", styles.sectionTitle),
        sectionBody: mergeStyles("about-section-body", styles.sectionBody),
        config: mergeStyles("about-config", styles.config)
    };
});

export { IAboutClassNames, getClassNames }