import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { DashboardListStore } from "../model/DashboardListStore";
import { createUserProfileMenu } from "@twii/ozone/lib/user/component/UserProfileMenuHelper";
import { DashboardListAppView } from "@twii/dashboard/lib/component/DashboardListAppView";
import { AppPanelContainer } from "@twii/common/lib/component/AppPanel";
import { IRequest } from "@twii/common/lib/IRequest";
import { BrandButton } from "./Brand";
import { IMutableSupplier } from "@twii/common/lib/IMutableSupplier";
import { PathsContext } from "@twii/ozone/lib/PathsContext";
import { PanelType } from "office-ui-fabric-react/lib/Panel";
import { getRequestSupplier } from "@twii/common/lib/AppPanelUtils";
import { OzoneAppBase } from "@twii/ozone/lib/common/component/OzoneAppBase";
import { ListingViewConfig } from "@twii/ozone/lib/listing/component/ListingViewConfig";

class DashboardsApp extends OzoneAppBase {
    get panelAppRequestSupplier() : IMutableSupplier<IRequest> {
        return getRequestSupplier(this.host);
    }
    private _onClickHelp = () => {
        this.panelAppRequestSupplier.value = { path: "/help", panelProps: { type: PanelType.medium } };
    }
    private _onClickAbout = () => {
        this.panelAppRequestSupplier.value = { path: "/about", panelProps: { type: PanelType.medium } };
    }
    private _onClickAccessibility = () => {
        this.panelAppRequestSupplier.value = { path: "/accessibility", panelProps: { type: PanelType.medium } };
    }
    private _onClickBrand = () => {
        this.host.load({ path: "/index" });
    }
    private _onClickShop = () => {
        this.panelAppRequestSupplier.value = { path: PathsContext.value.store() };
    }
    private _launchPanelApp = (request : IRequest) => {
        return this.host.open(request);
    }
    componentWillMount() {
        this.host.setTitle("Dashboards");
    }
    private _onRenderBrand = () => {
        return <BrandButton onClick={this._onClickBrand} />;
    }
    /*private _onRenderProtectedBanner = () => {
        return (
            <div style={{
                position: "absolute",
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
                background: "transparent",
                letterSpacing: 3,
                color:"red",
                fontWeight: "bold",
                zIndex: 1 }}>
                PROTECTED
            </div>
        );
    }*/
    render() {
        const items : IContextualMenuItem[] = [
            {
                key: "brand",
                name: "Analyst Desktop",
                title: "Analyst Desktop",
                onRender: this._onRenderBrand
            }
        ];
        const farItems : IContextualMenuItem[] = [];
        // shop/store
        const storeMenu : IContextualMenuItem = {
            key: "store",
            title: ListingViewConfig.storeLabel,
            iconProps: {
                iconName: "Shop"
            },
            onClick: this._onClickShop
        };
        farItems.push(storeMenu);

        // help
        const helpMenu : IContextualMenuItem = {
            key: "helpMenu",
            iconProps: {
                iconName: "Help"
            },
            subMenuProps: {
                items: [
                    {
                        key: "help",
                        name: "AppsMart Help",
                        iconProps: {
                            iconName: "Help"
                        },
                        onClick: this._onClickHelp
                    },
                    {
                        key: "about",
                        name: "About AppsMart",
                        iconProps: {
                            iconName: "Info"
                        },
                        onClick: this._onClickAbout
                    },
                    {
                        key: "accessibility",
                        name: "Accessibility",
                        iconProps: {
                            iconName: "Devices4"
                        },
                        onClick: this._onClickAccessibility
                    }
                ]
            }
        };
        farItems.push(helpMenu);

        // user profile
        if(this.userProfile) {
            farItems.push(createUserProfileMenu(this.userProfile));
        }
        return (
            <DashboardListAppView dashboardList={DashboardListStore}
                                host={this.host}
                                commandBarProps={{ items: items, farItems: farItems }}
                                //onRenderMenuOther={this._onRenderProtectedBanner}
                                hideTitle>
                <AppPanelContainer requestSupplier={this.panelAppRequestSupplier}
                                launcher={this._launchPanelApp}
                                router={this.host.router}
                                panelProps={{ type: PanelType.large }} />
            </DashboardListAppView>
        );
    }
}

export { DashboardsApp, DashboardsApp as default }