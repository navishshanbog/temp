import { memoizeFunction } from "@uifabric/utilities";
import { IBrandStyles } from "./Brand.styles";
import { mergeStyles } from "@uifabric/styling";

interface IBrandClassNames {
    root?: string;
    logo?: string;
    title?: string;
}

const getClassNames = memoizeFunction((styles : IBrandStyles, className?: string) : IBrandClassNames => {
    return {
        root: mergeStyles("brand", className, styles.root),
        logo: mergeStyles("brand-logo", styles.logo),
        title: mergeStyles("brand-title", styles.title)
    };
});

export { IBrandClassNames, getClassNames }