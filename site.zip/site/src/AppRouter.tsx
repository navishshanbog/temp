import { Router } from "@twii/common/lib/Router";
import EntityRouter from "@twii/entity/lib/EntityRouter";
import MERouter from "@twii/matcheval/lib/me/MERouter";
import IconRouter from "icon/IconRouter";
import RiskResumeRouter from "@twii/riskresume/lib/RiskResumeRouter";
import PNRSearchRouter from "@twii/pnrsearch/lib/PNRSearchRouter";
import CargoSearchRouter from "@twii/cargosearch/lib/CargoSearchRouter";
import UserGroup from "user/UserGroup";
import { requiresGroupRouter, injectUserProfile } from "@twii/ozone/lib/user/UserAuthRouters";
import { Router as OzoneRouter } from "@twii/ozone/lib/Router";
import { PathsContext as OzonePathsContext } from "@twii/ozone/lib/PathsContext";
import { Paths as OzonePaths } from "@twii/ozone/lib/Paths";
import { Paths as CargoSearthPaths } from "@twii/cargosearch/lib/Paths";
import { PathsContext as EntityPathsContext } from "@twii/entity/lib/PathsContext";
import { PathsContext as CargoSearchPathContext } from "@twii/cargosearch/lib/PathsContext";
import { PathsContext as ReferralPathsContext } from "@twii/irc/lib/ref/PathsContext";
import { Paths as EntityPaths } from "@twii/entity/lib/Paths";
import { Paths as ReferralPaths } from "@twii/irc/lib/ref/Paths";
import IRPRouter from "@twii/irp/lib/IRPRouter";
import { ConfigRouter } from "@twii/common/lib/ConfigRouter";
import * as configMap from "./config/map";
import {IRCRouter} from "@twii/irc/lib/IRCRouter";
import {ImagesRouter} from "@twii/gateimages/lib/ImagesRouter";
import { reactRouter } from "@twii/common/lib/Routers";
import {CIERouter} from "@twii/kitchensink/lib/cie/CIERouter";

const r = new Router();

// these are our 'interceptors'
// config
r.use(new ConfigRouter({
    env: AppConfig.env,
    configMap: configMap
}));
// ozone config
r.use(injectUserProfile());

OzonePathsContext.value = new OzonePaths("/appsmart");
r.use("/appsmart", OzoneRouter);

// application mappings
r.use("/icon", IconRouter);
r.use("/about", reactRouter(() => import("./component/About")));
r.use("/help", reactRouter(() => import("./component/Help")));
r.use("/accessibility", reactRouter(() => import("./component/Accessibility")));
r.use("/user/menuitem", reactRouter(() => import("@twii/ozone/lib/user/component/UserProfileMenuItemApp")));

EntityPathsContext.value = new EntityPaths("/entity");
r.use("/entity", requiresGroupRouter(UserGroup.ENTITY_SEARCH, EntityRouter));
r.use("/me", requiresGroupRouter(UserGroup.MATCH_EVALUATION, MERouter));
r.use("/vra", requiresGroupRouter(UserGroup.RISK_RESUME, RiskResumeRouter));
r.use("/pnrsearch", requiresGroupRouter(UserGroup.PNR_SEARCH, PNRSearchRouter));

r.use("/irc", requiresGroupRouter(UserGroup.IDENTITY_RESOLUTION, IRCRouter));

ReferralPathsContext.value = new ReferralPaths("/referral");
r.use("/referral", requiresGroupRouter(UserGroup.IDENTITY_RESOLUTION, IRCRouter));

CargoSearchPathContext.value = new CargoSearthPaths("/cargosearch");
r.use("/cargosearch", requiresGroupRouter(UserGroup.CARGO_SEARCH, CargoSearchRouter));

r.use("/gateimages", requiresGroupRouter(UserGroup.IMAGE_SEARCH, ImagesRouter));
r.use("/irp", requiresGroupRouter(UserGroup.RISK_RESUME,  IRPRouter));
r.use("/cie", CIERouter);

r.use("/app/selector", reactRouter(() => import("./component/AppSelector")));

r.use("/blank", req => {
    return null;
});

const dashboardsAppRouter = reactRouter(() => import("./component/DashboardsApp"), { exact: false });

r.use((req, next) => {
    if (req.path === "/" || req.path === "/index" || req.path === "/dashboard") {
        return dashboardsAppRouter(req, next);
    }
    return next(req);
});

export { r as default, r as AppRouter }