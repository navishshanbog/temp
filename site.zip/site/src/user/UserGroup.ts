enum UserGroup {
    ADMIN = "APPS_MALL_STEWARD",
    ENTITY_SEARCH = "analyst_desktop_entity_search",
    MATCH_EVALUATION = "analyst_desktop_match_evaluation",
    RISK_RESUME = "analyst_desktop_risk_resume",
    CARGO_SEARCH = "analyst_desktop_cargo_search",
    PNR_SEARCH = "analyst_desktop_pnr_search",
    IDENTITY_RESOLUTION = "analyst_desktop_identity_resolution", 
    IMAGE_SEARCH = "analyst_desktop_image_search"
}

export { UserGroup as default, UserGroup }