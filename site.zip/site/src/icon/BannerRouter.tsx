import * as React from "react";
import { Router } from "roota/lib/Router";

const BannerRouter = new Router();
BannerRouter.use("/entity/search/banner", req => {
    return import("@twii/entity/lib/entity/component/EntitySearchLogo").then(m => {
        return <m.EntitySearchLogo width={req.params.width} height={req.params.height} />;
    })
});
BannerRouter.use("/entity/search/new/banner", req => {
    return import("@twii/entity/lib/entity/component/EntitySearchLogo").then(m => {
        return <m.EntitySearchLogo width={req.params.width} height={req.params.height} />;
    })
});

BannerRouter.use("/entity/profile/banner", req => {
    return import("@twii/entity/lib/entity/profile/component/EntityProfileBanner").then(m => {
        return <m.EntityProfileBanner />;
    });
});

export { BannerRouter }