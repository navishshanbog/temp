import { DashboardList } from "@twii/dashboard/lib/model/DashboardList";
import { DashboardStorageServiceContext } from "../service/DashboardStorageServiceContext";
import { ComponentFactory } from "@twii/dashboard/lib/model/ComponentFactory";
import { AppRouter } from "../AppRouter";

const storageKey = "analyst-desktop-dashboard-list";

const DashboardListStore = new DashboardList();
DashboardListStore.componentFactory = ComponentFactory;
DashboardListStore.setRouter(AppRouter);
DashboardListStore.loader = () => {
    return DashboardStorageServiceContext.value.getItem(storageKey);
};
DashboardListStore.saver = (data) => {
    return DashboardStorageServiceContext.value.setItem(storageKey, data);
};
DashboardListStore.addApp = { title: "Add App", path: "/app/selector" };

export { DashboardListStore }