import { ListingListModel } from "@twii/ozone/lib/listing/model/ListingListModel";

const ListingListStore = new ListingListModel();

export { ListingListStore }