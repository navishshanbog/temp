"use strict";
const express = require("express");
const path = require("path");
const morgan = require("morgan");
const analystDesktopRoute = require("./route/analystdesktop");
const intelTravellerRoute = require("./route/inteltraveller");
const solrRoute = require("./route/solr");
const dataServicesRouter = require("./route/dataServices");
const pnrDataServicesRouter = require("./route/pnrDataServices");
const riskResultsRouter = require("./route/riskresults");
const prwebRouter = require("./route/prweb");
const newIdeaRouter = require("./route/newIdea");

const yargs = require("yargs");
const directsolr = require("./route/directsolr");
const cors = require("cors");

const app = express();
app.use(morgan("tiny"));
app.options('*', cors());
app.use(cors());

// For any other than local - ME Only
//app.use("/IntelTraveller", dataServicesRouter);
app.use("/IntelTraveller", intelTravellerRoute);
app.use("/directsolr", directsolr);

app.use("/analystdesktop", analystDesktopRoute);
app.use("/solr", solrRoute);
app.use("/prweb", prwebRouter);
app.use("/newIdea", newIdeaRouter);
const contentDir = path.join(__dirname, "..", "dist");

// switch depending upon the backend argument
app.use("/DataServices", dataServicesRouter);
//app.use("/DataServicesPNR", pnrDataServicesRouter);
app.use("/riskresults", riskResultsRouter);
app.use("/cragoServices", dataServicesRouter);
app.use("/DataServicesIdentity", dataServicesRouter);

app.use(function(req, res, next) {
    var ext = path.extname(req.path);
    if(!ext || ext === ".html") {
        res.sendFile("index.html", { root: contentDir });
    } else {
        next();
    }
});

app.use(express.static(contentDir));

module.exports = app;