const rp = require("request-promise-native");
const url = require("url");

const login = async (opts) => {
    const loginOpts = Object.assign({}, opts, {
        method: "POST",
        uri: `${opts.websealLoginUri}`,
        resolveWithFullResponse: true,
        form: {
            "login-form-type": "pwd",
            username: opts.websealUsername,
            password: opts.websealPassword
        }
    });
    // now we can perform the actual login
    const response = await rp(loginOpts);
};

const DEFAULT_WEBSEAL_SESSION_ID = "PD-S-SESSION-ID";

const proxied = (proxyOpts) => {
    const websealSessionId = proxyOpts.websealSessionId || DEFAULT_WEBSEAL_SESSION_ID;
    const cookieJar = rp.jar();

    const containsWebsealSessionId = (opts) => {
        const cookies = cookieJar.getCookies(opts.uri);
        return cookies && cookies.length > 0 && cookies.some(c => c.key === websealSessionId);
    };

    const doLogin = async (opts) => {
        let websealLoginUri = proxyOpts.websealLoginUri;
        if(!websealLoginUri) {
            const pu = url.parse(opts.uri);
            websealLoginUri = url.format({
                protocol: pu.protocol,
                hostname: pu.hostname,
                port: pu.port,
                pathname: "/pkmslogin.form"
            });
        }
        const loginOpts = Object.assign({}, proxyOpts, { websealLoginUri: websealLoginUri, jar: cookieJar });
        await login(loginOpts);
        if(!containsWebsealSessionId(opts)) {
            throw {
                statusCode: 401,
                code: "LOGIN_FAILED",
                message: "Login Failed"
            };
        }
    };

    return async (opts) => {
        if(!containsWebsealSessionId(opts)) {
            await doLogin(opts);
        }
        const requestOpts = Object.assign({}, opts, { jar: cookieJar });
        try {
            const r = await rp(requestOpts);
            return r;
        } catch(err) {
            if(err.statusCode === 401) {
                await doLogin(opts);
                return rp(requestOpts)
            }
            throw err;
        }
    };
};

module.exports.proxied = proxied;