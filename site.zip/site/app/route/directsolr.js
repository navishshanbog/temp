const axios = require("axios");
const express = require('express');
const bodyParser = require('body-parser');

const r = express.Router();
r.use(bodyParser.urlencoded({ extended: false }));
r.use(bodyParser.json());

const solrDirectBaseUrl = "https://Solr_DEV_Select_User:SelectRocks@dhd1e1:9031/solr/svoe_addr/query";
const solrNameDirectBaseUrl = "https://Solr_DEV_Select_User:SelectRocks@dhd1e1:9031/solr/svoe_nm/query";

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

r.post('/address', function(req, res) {
    console.log("Request: ", req.body.params);
    axios.post(solrDirectBaseUrl, {params: req.body.params}).then((result) => {
        res.json(result.data).end();
    }).catch((error) => {
        handleApiError(res, error);
    });
});

r.post('/name', function(req, res) {
    console.log("Request: ", req.body.params);
    axios.post(solrNameDirectBaseUrl, {params: req.body.params}).then((result) => {
        res.json(result.data).end();
    }).catch((error) => {
        handleApiError(res, error);
    });
});

function handleApiError (res, error) {
    console.error("API Error: ", error);
    if (error.response) {
        res.status(error.response.status);
        res.send(error.response.data);
    } else {
        console.log(error)
        res.status(500).send(JSON.stringify(error));
    }
}

module.exports = r;



