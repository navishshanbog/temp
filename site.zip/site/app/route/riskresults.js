const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const rpn = require("request-promise-native");
const request = require("request");
const proxied = require("../webseal-request-proxy").proxied;

const timeout = "0";

//const apiBaseUrl = "https://e4-portals.immi.gov.au";
const apiBaseUrl = "http://localhost:3310";
const dsRouter = express.Router();
dsRouter.use(bodyParser.json());
dsRouter.use(bodyParser.text());

const apiUsername = "ADPTA0";
const apiPassword = "P@ssw0rd!0";

// yay - hacky
const rp = proxied({
    websealUsername: apiUsername,
    websealPassword: apiPassword,
    strictSSL: false
});

dsRouter.all("/*", (req, res, next) => {
    let headers = {
        "Content-Type": "application/json; charset=utf-8",
        "Accept-Encoding": "application/json; charset=utf-8"
    };

    if (req.headers["content-type"] === "text/plain") {
        headers["Content-Type"] = "text/plain";
    }

    const uri = apiBaseUrl + req.originalUrl;

    rp({
        uri: uri,
        method: req.method,
        headers: headers,
        body: req.method === "POST" ? JSON.stringify(req.body) : undefined,
        resolveWithFullResponse: true,
        strictSSL: false
    }).then(response => {
        // console.log(response);
        if (response.headers) {
            Object.keys(response.headers).forEach(key => {
                res.set(key, response.headers[key]);
            });
        }
        // console.log(response.body);
        setTimeout(() => {
            res.status(200);
            res.send(response.body);
        }, timeout)
    }).catch(err => {
        res.status(err.statusCode || 500);
        if (err.response) {
            res.send(JSON.parse(err.response.body));
        } else {
            res.send(err);
        }
        console.log(err);
    });
});

module.exports = dsRouter;