const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");
const rpn = require("request-promise-native");
const proxied = require("../webseal-request-proxy").proxied;

//const apiBaseUrl = "http://localhost:3310";
//const apiBaseUrl = "http://e1-analyst04:3010";
//const apiBaseUrl = "http://localhost:3001";
//const apiBaseUrl = "https://e1-portals.immi.gov.au";
const apiBaseUrl = "http://e4-analyst02.immi.gov.au:3010";
//const apiBaseUrl = "https://e4-portals.immi.gov.au";

const apiUsername = "ADPTA0";
const apiPassword = "Password101";

// yay - hacky
const rp = apiBaseUrl.indexOf("portal") ? proxied({
    websealUsername: apiUsername,
    websealPassword: apiPassword,
    strictSSL: false
}) : rpn;

//https.globalAgent.options.ca = fs.readFileSync('dibpca.cer');
const dsRouter = express.Router();
dsRouter.use(bodyParser.raw({ type: '*/*' }));

dsRouter.all("/*", (req, res, next) => {
    // nice and hacky
    rp({
        uri: apiBaseUrl + req.originalUrl,
        qs: req.query,
        method: req.method,
        body: req.method === "POST" ? req.body : undefined,
        resolveWithFullResponse: true,
        strictSSL: false
    }).then(response => {
        if(response.headers) {
            Object.keys(response.headers).forEach(key => {
                res.set(key, response.headers[key]);
            });
        }
        res.status(response.statusCode);
        res.send(response.body);
    }).catch(err => {
        console.error(err);
        res.status(500).send(JSON.stringify(err));
    });
});

module.exports = dsRouter;