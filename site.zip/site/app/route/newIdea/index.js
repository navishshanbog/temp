const express = require("express");
const path = require("path");

const route = express.Router();

route.use("/register.html", (req, res) => {
    res.sendFile("/register.html", { root: __dirname });
});
route.use("/background.png", (req, res) => {
    res.sendFile("/background.png", { root: __dirname });
});


module.exports = route;