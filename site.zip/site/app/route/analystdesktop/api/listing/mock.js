const express = require("express");
const route = express.Router();
const mockListings = require("../listings/mockListings");

const allGetHandler = (req, res) => {
    res.json([].concat(mockListings).concat({ total: mockListings.length })).end();
};

const idGetHandler = (req, res) => {
    const l = mockListings.find(l => String(l.id) === req.params.listingId);
    if(l) {
        res.json(l).end();
    } else {
        res.status(404).json({ code: "NOT_FOUND", message: `Unable to find listing by id ${req.params.listingId}`}).end();
    }
};

route.get("/listing/:listingId", idGetHandler);
route.get("/listing/:listingId/", idGetHandler);
route.get("/listing", allGetHandler);
route.get("/listing/", allGetHandler);

module.exports = route;