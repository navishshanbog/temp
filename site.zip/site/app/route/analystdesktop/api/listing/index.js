const target = require("./mock");

module.exports = target;