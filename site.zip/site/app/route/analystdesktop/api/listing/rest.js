const request = require("request");
const express = require("express");
const route = express.Router();

const allGetHandler = (req, res) => {
    req.pipe(request("http://localhost:8000/api/listing/")).pipe(res);
};

const idGetHandler = (req, res) => {
    res.pipe(request(`http://localhost:8000/api/listing/${req.params.listingId}`)).pipe(res);
}

route.get("/listing/:listingId", idGetHandler);
route.get("/listing/:listingId/", idGetHandler);
route.get("/listing", allGetHandler);
route.get("/listing/", allGetHandler);

module.exports = route;