const express = require("express");
const route = express.Router();
const mockListings = require("./mockListings");

const searchGetHandler = (req, res) => {
    res.json(mockListings).end();
};

const allGetHandler = (req, res) => {
    res.json({
        listings: mockListings,
        count: { total: mockListings.length }
    }).end();
};

route.get("/search", searchGetHandler);
route.get("/search/", searchGetHandler);
route.get("/", allGetHandler);
route.get(allGetHandler);

module.exports = route;