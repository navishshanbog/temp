const mockListings = [{
    id: 1,
    is_enabled: true,
    title: "Entity Search",
    launch_url: "/entity/search",
    security_marking: "analyst_desktop_entity_search",
    approval_status: "APPROVED"
}, {
    id: 2,
    is_enabled: true,
    title: "Clipboard",
    launch_url: "/entity/profile",
    security_marking: "analyst_desktop_entity_search",
    approval_status: "APPROVED"
}, {
    id: 3,
    is_enabled: true,
    title: "ME Case Management",
    launch_url: "/me/portal",
    security_marking: "analyst_desktop_match_evaluation",
    approval_status: "APPROVED"
}, {
    id: 4,
    is_enabled: true,
    title: "Risk Resume Search",
    launch_url: "/vra/search",
    security_marking: "analyst_desktop_risk_resume",
    approval_status: "APPROVED"
}, {
    id: 5,
    is_enabled: true,
    title: "PNR Search",
    launch_url: "/pnrsearch/search",
    security_marking: "analyst_desktop_pnr_search",
    approval_status: "APPROVED"
}, {
    id: 6,
    is_enabled: true,
    title: "Master Watchlist",
    launch_url: "/cie",
    security_marking: "analyst_desktop_pnr_search",
    approval_status: "APPROVED"
}, {
    id: 7,
    is_enabled: true,
    title: "ITM Portal",
    launch_url: "https://portalsstage.immi.gov.au/protectedportal",
    security_marking: "analyst_desktop_task_management",
    approval_status: "APPROVED"
}, {
    id: 8,
    is_enabled: true,
    title: "ITM Reporting",
    launch_url: "http://birs-stg/BOE/BI",
    security_marking: "analyst_desktop_task_management",
    approval_status: "APPROVED"
}, {
    id: 9,
    is_enabled: true,
    title: "Solr Search",
    launch_url: "/directSearch",
    security_marking: "analyst_desktop_task_management",
    approval_status: "APPROVED"
}, {
    id: 10,
    is_enabled: true,
    title: "Match Eval Search",
    launch_url: "/me/search",
    security_marking: "analyst_desktop_match_evaluation",
    approval_status: "APPROVED"
}, {
    id: 11,
    is_enabled: true,
    title: "Integrated Risk Portal",
    launch_url: "/irp/search",
    security_marking: "analyst_desktop_match_evaluation",
    approval_status: "APPROVED"
}, {
    id: 12,
    is_enabled: true,
    title: "Entity Search (NEW)",
    launch_url: "/entity/search/new",
    security_marking: "analyst_desktop_entity_search",
    approval_status: "APPROVED"
}, {
    id: 13,
    is_enabled: true,
    title: "Watchlist",
    launch_url: "/cie",
    security_marking: "analyst_desktop_entity_search",
    approval_status: "APPROVED"
}, {
    id: 14,
    is_enabled: true,
    title: "Images Search",
    launch_url: "/gateimages/search",
    security_marking: "analyst_desktop_image_search",
    approval_status: "APPROVED"
}, {
    id: 15,
    is_enabled: true,
    title: "Cargo Search",
    launch_url: "/cargosearch/search",
    security_marking: "analyst_desktop_cargo_search",
    approval_status: "APPROVED"
}, {
    id: 16,
    is_enabled: true,
    title: "Identity Resolution",
    launch_url: "/irc/referrals/summaries",
    security_marking: "analyst_desktop_match_evaluation",
    approval_status: "APPROVED"
}, {
    id: 17,
    is_enabled: true,
    title: "PNR Clipboard",
    launch_url: "/pnrsearch/pnrBoard",
    security_marking: "analyst_desktop_pnr_search",
    approval_status: "APPROVED"
}
];

module.exports = mockListings;