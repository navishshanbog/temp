const express = require("express");
const route = express.Router();
const mockListings = require("../listings/mockListings");

const storeFrontGetHandler = (req, res) => {
    res.json({
        featured: mockListings,
        most_popular: mockListings,
        recent: mockListings,
        recommended: mockListings
    }).end();
};

route.get("/storefront", storeFrontGetHandler);
route.get("/storefront/", storeFrontGetHandler);

module.exports = route;