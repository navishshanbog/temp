const request = require("request");
const express = require("express");
const targetUrl = "http://localhost:8000/api/listings/storefront/";

const route = express.Router();

const storeFrontGetHandler = (req, res) => {
    req.pipe(request(targetUrl)).pipe(res);
};

route.get("/storefront", searchGetHandler);
route.get("/storefront/", searchGetHandler);

module.exports = route;