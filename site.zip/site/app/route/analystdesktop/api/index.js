const express = require("express");
const selfRoute = require("./self/index");
const listingRoute = require("./listing");
const listingsRoute = require("./listings");
const storeFrontRoute = require("./storefront");

const route = express.Router();
route.use("/self", selfRoute);
route.use(listingRoute);
route.use(storeFrontRoute);
route.use("/listings", listingsRoute);

module.exports = route;