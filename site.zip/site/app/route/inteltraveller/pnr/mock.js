const express = require("express");

const route = express.Router();

const GetCurrentBookingDataSoapAction = "http://border.gov.au/risk/traveller/pnr/v1/GetCurrentBookingData";
const GetHistoricalBookingDataSoapAction = "http://border.gov.au/risk/traveller/pnr/v1/GetHistoricalBookingData";

const GetCurrentBookingDataFault =
    `<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:com="http://border.gov.au/service/risk/traveller/common/v1" xmlns:exe="http://border.gov.au/service/risk/traveller/pnr/exception/v1">
   <soap:Body>
      <soap:Fault>
         <faultcode>soap:Client</faultcode>
         <faultstring>TME103-Invalid Service Request Input</faultstring>
         <detail>
            <exe:GetCurrentBookingData>
               <exe:exception>
                  <com:status>ERROR</com:status>
                  <com:errorCode>TME103</com:errorCode>
                  <com:errorDescription>Invalid Service Request Input: A schema validation error has occurred while parsing the XML document**/XMLNSC/http://schemas.xmlsoap.org/soap/envelope/:Envelope/http://schemas.xmlsoap.org/soap/envelope/:Body/http://border.gov.au/service/risk/traveller/pnr/request/v1:GetCurrentBookingDataRequest/BookingCreationTimeStamp**cvc-datatype-valid.1.2: The value "?" is not a valid value for the "dateTime" datatype.**XML Parsing Errors have occurred**problem creating SOAP tree from bitstream**3c736f6170656e763a456e76656c6f706520786d6c6e733a736f6170656e763d22687474703a2f2f736368656d61732e786d6c736f61702e6f72672f736f61702f656e76656c6f70652f2220786d6c6e733a76313d22687474703a2f2f626f726465722e676f762e61752f736572766963652f7269736b2f74726176656c6c65722f706e722f726571756573742f76312220786d6c6e733a7631313d22687474703a2f2f626f726465722e676f762e61752f736572766963652f7269736b2f74726176656c6c65722f636f6d6d6f6e2f7631223e0a2020203c736f6170656e763a4865616465722f3e0a2020203c736f6170656e763a426f64793e0a2020202020203c76313a47657443757272656e74426f6f6b696e6744617461526571756573743e0a2020202020202020203c526571756573744865616465723e0a2020202020202020202020203c7631313a636f7272656c6174696f6e5265717565737449643e3f3c2f7631313a636f7272656c6174696f6e5265717565737449643e0a2020202020202020202020203c7631313a7573657249643e3f3c2f7631313a7573657249643e0a2020202020202020202020203c7631313a7265717565737454696d655374616d703e3f3c2f7631313a7265717565737454696d655374616d703e0a2020202020202020203c2f526571756573744865616465723e0a2020202020202020203c426f6f6b696e6753797374656d436f64653e3f3c2f426f6f6b696e6753797374656d436f64653e0a2020202020202020203c426f6f6b696e674372656174696f6e54696d655374616d703e3f3c2f426f6f6b696e674372656174696f6e54696d655374616d703e0a2020202020202020203c5265636f72644c6f6361746f723e3f3c2f5265636f72644c6f6361746f723e0a2020202020203c2f76313a47657443757272656e74426f6f6b696e6744617461526571756573743e0a2020203c2f736f6170656e763a426f64793e0a3c2f736f6170656e763a456e76656c6f70653e**Root**Error occurred in ImbSOAPInputHelper::validateSOAPInput()**Node throwing exception**</com:errorDescription>
                  <com:sourceSystem>IIB</com:sourceSystem>
               </exe:exception>
            </exe:GetCurrentBookingData>
         </detail>
      </soap:Fault>
   </soap:Body>
</soap:Envelope>`;

const GetCurrentBookingDataResponse =
    `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
   <soapenv:Body>
      <GetCurrentBookingDataResponse xmlns="http://border.gov.au/service/risk/traveller/pnr/response/v1" xmlns:com="http://border.gov.au/service/risk/traveller/pnr/common/v1" xmlns:iat="http://border.gov.au/service/risk/traveller/iat/common/v1" xmlns:pnr="http://border.gov.au/service/risk/traveller/pnr/v1">
         <CurrentBookingData>
            <pnr:BookingRecordInfo>
               <pnr:BookingSystemCode>EK</pnr:BookingSystemCode>
               <pnr:RecordLocator>BS2D6J</pnr:RecordLocator>
               <pnr:PNRCreationTimeStamp>2019-05-29T04:55:00</pnr:PNRCreationTimeStamp>
               <pnr:PNRSource>Non-EU PNR</pnr:PNRSource>
            </pnr:BookingRecordInfo>
            <pnr:BookingSummaryInfo>
               <pnr:PNRTravelType>Travel From AUS - Round Trip</pnr:PNRTravelType>
               <pnr:BookingDate>2019-05-29</pnr:BookingDate>
               <pnr:BookingCity>SYD</pnr:BookingCity>
               <pnr:IntentToTravelDate>2019-10-25</pnr:IntentToTravelDate>
               <pnr:TravelGroupName />
               <pnr:OriginalBookingDBT>148</pnr:OriginalBookingDBT>
               <pnr:CurrentBookingDBT>148</pnr:CurrentBookingDBT>
               <pnr:MostTimeSpentDays>27</pnr:MostTimeSpentDays>
               <pnr:MostTimeSpentCountry>IND</pnr:MostTimeSpentCountry>
               <pnr:MostTimeSpentPort>BLR</pnr:MostTimeSpentPort>
               <pnr:TotalLengthOfStay>99999</pnr:TotalLengthOfStay>
               <pnr:IntendLengthOfStay>99999</pnr:IntendLengthOfStay>
               <pnr:TotalLengthOfTrip>32</pnr:TotalLengthOfTrip>
               <pnr:TotalIntendedLengthOfTrip>34</pnr:TotalIntendedLengthOfTrip>
               <pnr:TotalLengthOfTravel>34</pnr:TotalLengthOfTravel>
               <pnr:ActiveSegmentCount>4</pnr:ActiveSegmentCount>
               <pnr:CancelledSegmentCount>0</pnr:CancelledSegmentCount>
               <pnr:TravellerCount>4</pnr:TravellerCount>
               <pnr:DepartureCanberraTimeStamp>2019-10-25T06:00:00</pnr:DepartureCanberraTimeStamp>
               <pnr:OriginalPortCode>SYD</pnr:OriginalPortCode>
               <pnr:OriginalCountryCode>AUS</pnr:OriginalCountryCode>
               <pnr:OriginalCountryName>AUSTRALIA</pnr:OriginalCountryName>
               <pnr:DestinationPortCode>SYD</pnr:DestinationPortCode>
               <pnr:DestinationCountryCode>AUS</pnr:DestinationCountryCode>
               <pnr:DestinationCountryName>AUSTRALIA</pnr:DestinationCountryName>
            </pnr:BookingSummaryInfo>
            <pnr:LinkedPNRInfo>
               <pnr:PNRRecordKey>
                  <pnr:RecordLocator>BS2D6J</pnr:RecordLocator>
                  <pnr:BookingSystemCode>EK</pnr:BookingSystemCode>
               </pnr:PNRRecordKey>
            </pnr:LinkedPNRInfo>
            <pnr:SplitPNRInfo />
            <pnr:TravellerInfo>
               <pnr:TravellerSummary>
                  <pnr:PNRTraveller>
                     <com:PassengerTattoo>1</com:PassengerTattoo>
                     <com:Biographic>
                        <iat:birthCountryCode>IND</iat:birthCountryCode>
                     </com:Biographic>
                     <com:ReservationName>
                        <com:familyName>AJEESH</com:familyName>
                        <com:givenName>Mamatha</com:givenName>
                     </com:ReservationName>
                  </pnr:PNRTraveller>
                  <pnr:IATTraveller>
                     <com:IATTravellerId>0083375385</com:IATTravellerId>
                  </pnr:IATTraveller>
                  <pnr:PreviousTripCount>12</pnr:PreviousTripCount>
                  <pnr:TravelDocDeptCntyCodeInd />
                  <pnr:CntyOfOrgDeptInd>y</pnr:CntyOfOrgDeptInd>
               </pnr:TravellerSummary>
               <pnr:TravellerSummary>
                  <pnr:PNRTraveller>
                     <com:PassengerTattoo>2</com:PassengerTattoo>
                     <com:Biographic>
                        <iat:birthCountryCode>AUS</iat:birthCountryCode>
                     </com:Biographic>
                     <com:ReservationName>
                        <com:familyName>AJEESH</com:familyName>
                        <com:givenName>Rian</com:givenName>
                     </com:ReservationName>
                  </pnr:PNRTraveller>
                  <pnr:IATTraveller>
                     <com:IATTravellerId>0099096065</com:IATTravellerId>
                  </pnr:IATTraveller>
                  <pnr:PreviousTripCount>7</pnr:PreviousTripCount>
                  <pnr:TravelDocDeptCntyCodeInd />
                  <pnr:CntyOfOrgDeptInd>y</pnr:CntyOfOrgDeptInd>
               </pnr:TravellerSummary>
               <pnr:TravellerSummary>
                  <pnr:PNRTraveller>
                     <com:PassengerTattoo>3</com:PassengerTattoo>
                     <com:Biographic>
                        <iat:birthCountryCode>IND</iat:birthCountryCode>
                     </com:Biographic>
                     <com:ReservationName>
                        <com:familyName>AJEESH</com:familyName>
                        <com:givenName>Ridhwan</com:givenName>
                     </com:ReservationName>
                  </pnr:PNRTraveller>
                  <pnr:IATTraveller>
                     <com:IATTravellerId>0085107258</com:IATTravellerId>
                  </pnr:IATTraveller>
                  <pnr:PreviousTripCount>12</pnr:PreviousTripCount>
                  <pnr:TravelDocDeptCntyCodeInd />
                  <pnr:CntyOfOrgDeptInd>y</pnr:CntyOfOrgDeptInd>
               </pnr:TravellerSummary>
               <pnr:TravellerSummary>
                  <pnr:PNRTraveller>
                     <com:PassengerTattoo>4</com:PassengerTattoo>
                     <com:Biographic>
                        <iat:birthCountryCode>IND</iat:birthCountryCode>
                     </com:Biographic>
                     <com:ReservationName>
                        <com:familyName>JOSEPH</com:familyName>
                        <com:givenName>Ajeesh</com:givenName>
                     </com:ReservationName>
                  </pnr:PNRTraveller>
                  <pnr:IATTraveller>
                     <com:IATTravellerId>0083375379</com:IATTravellerId>
                  </pnr:IATTraveller>
                  <pnr:PreviousTripCount>12</pnr:PreviousTripCount>
                  <pnr:TravelDocDeptCntyCodeInd />
                  <pnr:CntyOfOrgDeptInd>y</pnr:CntyOfOrgDeptInd>
               </pnr:TravellerSummary>
            </pnr:TravellerInfo>
            <pnr:ItineraryInfo>
               <pnr:Itinerary>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:CancellationInd />
                  <pnr:TransportType>AIR</pnr:TransportType>
                  <pnr:CraftId>EK0415</pnr:CraftId>
                  <pnr:CabinClass>L</pnr:CabinClass>
                  <pnr:FareClass>Economy</pnr:FareClass>
                  <pnr:Route>SYD DXB</pnr:Route>
                  <pnr:DepartureDate>2019-10-25</pnr:DepartureDate>
                  <pnr:DepartureTime>06:00:00</pnr:DepartureTime>
                  <pnr:ArrivalDate>2019-10-25</pnr:ArrivalDate>
                  <pnr:ArrivalTime>13:20:00</pnr:ArrivalTime>
                  <pnr:DepatureDay>Fri</pnr:DepatureDay>
                  <pnr:Status>HK</pnr:Status>
                  <pnr:DaysAtArrivalPort>5</pnr:DaysAtArrivalPort>
                  <pnr:ContactInfo>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                  </pnr:ContactInfo>
               </pnr:Itinerary>
               <pnr:Itinerary>
                  <pnr:SegmentTattoo>2</pnr:SegmentTattoo>
                  <pnr:CancellationInd />
                  <pnr:TransportType>AIR</pnr:TransportType>
                  <pnr:CraftId>EK0566</pnr:CraftId>
                  <pnr:CabinClass>L</pnr:CabinClass>
                  <pnr:FareClass>Economy</pnr:FareClass>
                  <pnr:Route>DXB BLR</pnr:Route>
                  <pnr:DepartureDate>2019-10-30</pnr:DepartureDate>
                  <pnr:DepartureTime>13:35:00</pnr:DepartureTime>
                  <pnr:ArrivalDate>2019-10-30</pnr:ArrivalDate>
                  <pnr:ArrivalTime>18:35:00</pnr:ArrivalTime>
                  <pnr:DepatureDay>Wed</pnr:DepatureDay>
                  <pnr:Status>HK</pnr:Status>
                  <pnr:DaysAtArrivalPort>27</pnr:DaysAtArrivalPort>
                  <pnr:ContactInfo>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                  </pnr:ContactInfo>
               </pnr:Itinerary>
               <pnr:Itinerary>
                  <pnr:SegmentTattoo>3</pnr:SegmentTattoo>
                  <pnr:CancellationInd />
                  <pnr:TransportType>AIR</pnr:TransportType>
                  <pnr:CraftId>EK0569</pnr:CraftId>
                  <pnr:CabinClass>T</pnr:CabinClass>
                  <pnr:FareClass>Economy</pnr:FareClass>
                  <pnr:Route>BLR DXB</pnr:Route>
                  <pnr:DepartureDate>2019-11-27</pnr:DepartureDate>
                  <pnr:DepartureTime>04:20:00</pnr:DepartureTime>
                  <pnr:ArrivalDate>2019-11-27</pnr:ArrivalDate>
                  <pnr:ArrivalTime>06:50:00</pnr:ArrivalTime>
                  <pnr:DepatureDay>Wed</pnr:DepatureDay>
                  <pnr:Status>HK</pnr:Status>
                  <pnr:DaysAtArrivalPort>0</pnr:DaysAtArrivalPort>
                  <pnr:ContactInfo>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                  </pnr:ContactInfo>
               </pnr:Itinerary>
               <pnr:Itinerary>
                  <pnr:SegmentTattoo>4</pnr:SegmentTattoo>
                  <pnr:CancellationInd />
                  <pnr:TransportType>AIR</pnr:TransportType>
                  <pnr:CraftId>EK0412</pnr:CraftId>
                  <pnr:CabinClass>T</pnr:CabinClass>
                  <pnr:FareClass>Economy</pnr:FareClass>
                  <pnr:Route>DXB SYD</pnr:Route>
                  <pnr:DepartureDate>2019-11-27</pnr:DepartureDate>
                  <pnr:DepartureTime>10:15:00</pnr:DepartureTime>
                  <pnr:ArrivalDate>2019-11-28</pnr:ArrivalDate>
                  <pnr:ArrivalTime>07:00:00</pnr:ArrivalTime>
                  <pnr:DepatureDay>Wed</pnr:DepatureDay>
                  <pnr:Status>HK</pnr:Status>
                  <pnr:ContactInfo>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
                     </pnr:Contact>
                     <pnr:Contact>
                        <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                        <pnr:Type>Address (home or hotel)</pnr:Type>
                        <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
                     </pnr:Contact>
                  </pnr:ContactInfo>
               </pnr:Itinerary>
            </pnr:ItineraryInfo>
            <pnr:TicketingInfo>
               <pnr:Ticketing>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:TicketType>3</pnr:TicketType>
                  <pnr:TicketNumber>1763657218306</pnr:TicketNumber>
               </pnr:Ticketing>
               <pnr:Ticketing>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:TicketType>3</pnr:TicketType>
                  <pnr:TicketNumber>1763657218308</pnr:TicketNumber>
               </pnr:Ticketing>
               <pnr:Ticketing>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:TicketType>3</pnr:TicketType>
                  <pnr:TicketNumber>1763657218309</pnr:TicketNumber>
               </pnr:Ticketing>
               <pnr:Ticketing>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:TicketType>3</pnr:TicketType>
                  <pnr:TicketNumber>1763657218307</pnr:TicketNumber>
               </pnr:Ticketing>
            </pnr:TicketingInfo>
            <pnr:PNRPushHistoryInfo>
               <pnr:PNRPushHistory>
                  <pnr:DirectionCode>O</pnr:DirectionCode>
                  <pnr:RouteId>EK415</pnr:RouteId>
                  <pnr:LocalPort>SYD</pnr:LocalPort>
                  <pnr:ScheduledDate>2019-10-25</pnr:ScheduledDate>
                  <pnr:PushTypeCode>POC</pnr:PushTypeCode>
                  <pnr:PushNumber>4</pnr:PushNumber>
                  <pnr:PNRReceivedTimeStamp>2019-10-25T05:02:04.780</pnr:PNRReceivedTimeStamp>
               </pnr:PNRPushHistory>
               <pnr:PNRPushHistory>
                  <pnr:DirectionCode>O</pnr:DirectionCode>
                  <pnr:RouteId>EK415</pnr:RouteId>
                  <pnr:LocalPort>SYD</pnr:LocalPort>
                  <pnr:ScheduledDate>2019-10-25</pnr:ScheduledDate>
                  <pnr:PushTypeCode>POC</pnr:PushTypeCode>
                  <pnr:PushNumber>3</pnr:PushNumber>
                  <pnr:PNRReceivedTimeStamp>2019-10-25T04:03:03.400</pnr:PNRReceivedTimeStamp>
               </pnr:PNRPushHistory>
               <pnr:PNRPushHistory>
                  <pnr:DirectionCode>O</pnr:DirectionCode>
                  <pnr:RouteId>EK415</pnr:RouteId>
                  <pnr:LocalPort>SYD</pnr:LocalPort>
                  <pnr:ScheduledDate>2019-10-25</pnr:ScheduledDate>
                  <pnr:PushTypeCode>POC</pnr:PushTypeCode>
                  <pnr:PushNumber>2</pnr:PushNumber>
                  <pnr:PNRReceivedTimeStamp>2019-10-24T06:02:37.280</pnr:PNRReceivedTimeStamp>
               </pnr:PNRPushHistory>
               <pnr:PNRPushHistory>
                  <pnr:DirectionCode>O</pnr:DirectionCode>
                  <pnr:RouteId>EK415</pnr:RouteId>
                  <pnr:LocalPort>SYD</pnr:LocalPort>
                  <pnr:ScheduledDate>2019-10-25</pnr:ScheduledDate>
                  <pnr:PushTypeCode>POC</pnr:PushTypeCode>
                  <pnr:PushNumber>1</pnr:PushNumber>
                  <pnr:PNRReceivedTimeStamp>2019-10-22T06:04:06.080</pnr:PNRReceivedTimeStamp>
               </pnr:PNRPushHistory>
            </pnr:PNRPushHistoryInfo>
            <pnr:TravelAgentInfo>
               <pnr:TravelAgent>
                  <pnr:AgentName>No IATA Global Source Match</pnr:AgentName>
                  <pnr:AgentContactName />
                  <pnr:IATAAgentCode>9999999</pnr:IATAAgentCode>
                  <pnr:RoleTypeCode>CREATOR</pnr:RoleTypeCode>
               </pnr:TravelAgent>
               <pnr:TravelAgent>
                  <pnr:AgentName>No IATA Global Source Match</pnr:AgentName>
                  <pnr:Location>MUC DE</pnr:Location>
                  <pnr:AgentContactName>RM</pnr:AgentContactName>
                  <pnr:IATAAgentCode>00235849</pnr:IATAAgentCode>
                  <pnr:RoleTypeCode>History</pnr:RoleTypeCode>
               </pnr:TravelAgent>
               <pnr:TravelAgent>
                  <pnr:AgentName>No IATA Global Source Match</pnr:AgentName>
                  <pnr:Location>BOM IN</pnr:Location>
                  <pnr:AgentContactName>SU</pnr:AgentContactName>
                  <pnr:IATAAgentCode>09999999</pnr:IATAAgentCode>
                  <pnr:RoleTypeCode>History</pnr:RoleTypeCode>
               </pnr:TravelAgent>
            </pnr:TravelAgentInfo>
            <pnr:PaymentInfo>
               <pnr:Payment>
                  <pnr:FreeTextValue>LFT-15  -4####</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Base Fare</pnr:Type>
                  <pnr:Amount>818</pnr:Amount>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>MON</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Base Fare</pnr:Type>
                  <pnr:Amount>1091</pnr:Amount>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>MON</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>2</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#2##AUD#TP######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>28</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#27.6##AUD#F6######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>30</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#29.5##AUD#AE######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>30</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#30.1##AUD#IN######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>6</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#5.5##AUD#WO######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>6</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#6##AUD#ZR######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>60</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#60##AUD#AU######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Tax Amount</pnr:Type>
                  <pnr:Tax>63</pnr:Tax>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>700#62.96##AUD#WY######</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Total Fare</pnr:Type>
                  <pnr:Amount>982</pnr:Amount>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>MON</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:Type>Total Fare</pnr:Type>
                  <pnr:Amount>1315</pnr:Amount>
                  <pnr:Currency>AUD</pnr:Currency>
                  <pnr:FreeTextValue>MON</pnr:FreeTextValue>
               </pnr:Payment>
               <pnr:Payment>
                  <pnr:FormOfPayment>MS</pnr:FormOfPayment>
                  <pnr:CreditCardNumber />
                  <pnr:CreditCardName />
               </pnr:Payment>
            </pnr:PaymentInfo>
            <pnr:ContactInfo>
               <pnr:Contact>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 0061433513456/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######EK CTCM 00919845263280/VALID#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:FreeTextValue>
               </pnr:Contact>
               <pnr:Contact>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:Type>Address (home or hotel)</pnr:Type>
                  <pnr:FreeTextValue>700#######YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:FreeTextValue>
               </pnr:Contact>
            </pnr:ContactInfo>
            <pnr:SpecialServiceRequestInfo>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:SSRCode>CTCE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#YY###MAMATHA.HARIKRISHNA//GMAIL.COM####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:SSRCode>CTCM</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#YY###0061433513456####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:SSRCode>CTCM</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#YY###00919845263280####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>NSST</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415#046A###</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415++1763657218306C1####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>2</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#BLR#EK 0566++1763657218306C2####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>3</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#BLR#DXB#EK 0569++1763657218306C3####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>1</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>4</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#SYD#EK 0412++1763657218306C4####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:SSRCode>CHLD</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK###05MAY13####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>NSST</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415#046B###</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415++1763657218308C1####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>2</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#BLR#EK 0566++1763657218308C2####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>3</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#BLR#DXB#EK 0569++1763657218308C3####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>2</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>4</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#SYD#EK 0412++1763657218308C4####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>0</pnr:SegmentTattoo>
                  <pnr:SSRCode>CHLD</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK###24FEB09####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>NSST</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415#045B###</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415++1763657218309C1####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>2</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#BLR#EK 0566++1763657218309C2####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>3</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#BLR#DXB#EK 0569++1763657218309C3####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>3</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>4</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#SYD#EK 0412++1763657218309C4####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>NSST</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415#046C###</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>1</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#SYD#DXB#EK 0415++1763657218307C1####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>2</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#BLR#EK 0566++1763657218307C2####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>3</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#BLR#DXB#EK 0569++1763657218307C3####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
               <pnr:SpecialServiceRequest>
                  <pnr:PassengerTattoo>4</pnr:PassengerTattoo>
                  <pnr:SegmentTattoo>4</pnr:SegmentTattoo>
                  <pnr:SSRCode>TKNE</pnr:SSRCode>
                  <pnr:FreeTextValue>HK#1#EK#DXB#SYD#EK 0412++1763657218307C4####</pnr:FreeTextValue>
               </pnr:SpecialServiceRequest>
            </pnr:SpecialServiceRequestInfo>
            <pnr:PNRHistoryInfo>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SS</pnr:Element>
                  <pnr:HistoryData>EK#0412###T#SYD#28-11-2019#07:00:00#DXB#27-11-2019#10:15:00#4#SN#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SS</pnr:Element>
                  <pnr:HistoryData>EK#0415###L#DXB#25-10-2019#13:20:00#SYD#25-10-2019#06:00:00#4#SN#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SS</pnr:Element>
                  <pnr:HistoryData>EK#0566###L#BLR#30-10-2019#18:35:00#DXB#30-10-2019#13:35:00#4#SN#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SS</pnr:Element>
                  <pnr:HistoryData>EK#0569###T#DXB#27-11-2019#06:50:00#BLR#27-11-2019#04:20:00#4#SN#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>NM</pnr:Element>
                  <pnr:HistoryData>AJEESH##JOSEPH#A#004#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>NM</pnr:Element>
                  <pnr:HistoryData>MAMATHA##AJEESH#A#001#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>NM</pnr:Element>
                  <pnr:HistoryData>RIAN##AJEESH#C#002#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>NM</pnr:Element>
                  <pnr:HistoryData>RIDHWAN##AJEESH#C#003#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>28</pnr:Element>
                  <pnr:HistoryData>4#28###YY CTCP SYD 61 2 8206 9142 - PRICE BEAT TRAVEL - A#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>28</pnr:Element>
                  <pnr:HistoryData>4#28###YY CTCT SYD 61 2 8206 9142 PRICE BEAT TRAVEL#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHLD#HK##EK###05MAY13###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHLD#HK##EK###24FEB09###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:55:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#BLR#DXB#EK 0569###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#BLR#DXB#EK 0569###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#DXB#BLR#EK 0566###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#DXB#BLR#EK 0566###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#DXB#SYD#EK 0412###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#DXB#SYD#EK 0412###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#SYD#DXB#EK 0415###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#SYD#DXB#EK 0415###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>FQE</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-29T04:57:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#BLR#DXB#EK 0569++1763657218306C3###001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#BLR#DXB#EK 0569++1763657218307C3###004##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#BLR#DXB#EK 0569++1763657218308C3###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#BLR#DXB#EK 0569++1763657218309C3###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#BLR#EK 0566++1763657218306C2###001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#BLR#EK 0566++1763657218307C2###004##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#BLR#EK 0566++1763657218308C2###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#BLR#EK 0566++1763657218309C2###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#SYD#EK 0412++1763657218306C4###001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#SYD#EK 0412++1763657218307C4###004##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#SYD#EK 0412++1763657218308C4###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#DXB#SYD#EK 0412++1763657218309C4###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#SYD#DXB#EK 0415++1763657218306C1###001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#SYD#DXB#EK 0415++1763657218307C1###004##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#SYD#DXB#EK 0415++1763657218308C1###002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>TKNE#HK#1#EK#SYD#DXB#EK 0415++1763657218309C1###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>0235849</pnr:CreatorIATACode>
                  <pnr:CreatorId>RM</pnr:CreatorId>
                  <pnr:CreatorCityCode>MUC</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>1A</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-30T11:33:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>28</pnr:Element>
                  <pnr:HistoryData>4#28###EK CTCE MAMATHA.HARIKRISHNA//GMAIL.COM#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>DXB</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-31T13:21:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>28</pnr:Element>
                  <pnr:HistoryData>4#28###EK CTCM 0061433513456/VALID#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>DXB</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-31T13:21:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CTCE#HK##YY###MAMATHA.HARIKRISHNA//GMAIL.COM###001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>DXB</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-31T13:21:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CTCM#HK##YY###0061433513456###001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>DXB</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-05-31T13:21:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#PN#1#EK#BLR#DXB#EK 0569++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#PN#1#EK#DXB#BLR#EK 0566++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#PN#1#EK#DXB#SYD#EK 0412++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#PN#1#EK#SYD#DXB#EK 0415++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#XX#1#EK#BLR#DXB#EK 0569###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#XX#1#EK#DXB#BLR#EK 0566###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#XX#1#EK#DXB#SYD#EK 0412###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#XX#1#EK#SYD#DXB#EK 0415###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T10:58:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>28</pnr:Element>
                  <pnr:HistoryData>4#28###EK CTCM 00919845263280/VALID#</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:02:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CTCM#HK##YY###00919845263280###001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:02:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#BLR#DXB#EK 0569###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#DXB#BLR#EK 0566###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#DXB#SYD#EK 0412###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>CHML#HK#1#EK#SYD#DXB#EK 0415###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#XK#1#EK#BLR#DXB#EK 0569++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#XK#1#EK#DXB#BLR#EK 0566++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#XK#1#EK#DXB#SYD#EK 0412++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>SPML#XK#1#EK#SYD#DXB#EK 0415++CHML REFUSED###003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>BOM</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T11:17:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#056D##002##</pnr:HistoryData>
                  <pnr:CreatorIATACode />
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>QRS</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T20:15:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#056E##003##</pnr:HistoryData>
                  <pnr:CreatorIATACode />
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>QRS</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T20:15:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#056F##001##</pnr:HistoryData>
                  <pnr:CreatorIATACode />
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>QRS</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T20:15:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#056G##004##</pnr:HistoryData>
                  <pnr:CreatorIATACode />
                  <pnr:CreatorId>RC</pnr:CreatorId>
                  <pnr:CreatorCityCode>QRS</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-21T20:15:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#046A##001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:38:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#046B##002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:38:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#XB#1#EK#SYD#DXB#EK 0415#056D##002##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:38:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#XB#1#EK#SYD#DXB#EK 0415#056F##001##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:38:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#045B##003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:39:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>A</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#HK#1#EK#SYD#DXB#EK 0415#046C##004##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:39:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#XB#1#EK#SYD#DXB#EK 0415#056E##003##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:39:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
               <pnr:PNRHistory>
                  <pnr:Action>X</pnr:Action>
                  <pnr:Element>SR</pnr:Element>
                  <pnr:HistoryData>NSST#XB#1#EK#SYD#DXB#EK 0415#056G##004##</pnr:HistoryData>
                  <pnr:CreatorIATACode>9999999</pnr:CreatorIATACode>
                  <pnr:CreatorId>SU</pnr:CreatorId>
                  <pnr:CreatorCityCode>WWW</pnr:CreatorCityCode>
                  <pnr:CreatorCompanyId>EK</pnr:CreatorCompanyId>
                  <pnr:CreationTimeStamp>2019-10-22T19:39:00</pnr:CreationTimeStamp>
               </pnr:PNRHistory>
            </pnr:PNRHistoryInfo>
         </CurrentBookingData>
      </GetCurrentBookingDataResponse>
   </soapenv:Body>
</soapenv:Envelope>`;

const GetHistoricalBookingDataResponse =
    `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"><soapenv:Body><GetHistoricalBookingDataResponse xmlns="http://border.gov.au/service/risk/traveller/pnr/response/v1" xmlns:com="http://border.gov.au/service/risk/traveller/pnr/common/v1" xmlns:pnr="http://border.gov.au/service/risk/traveller/pnr/v1" xmlns:iat="http://border.gov.au/service/risk/traveller/iat/common/v1"><ListOfHistoricalPNRRecord><PNRRecord><pnr:RecordLocator>MHC8WE</pnr:RecordLocator><pnr:CreationTimeStamp>2017-10-04T23:09:00</pnr:CreationTimeStamp><pnr:LocalScheduledDate>2018-03-16</pnr:LocalScheduledDate><pnr:LocalPortCode>SYD </pnr:LocalPortCode><pnr:DirectionCode>O</pnr:DirectionCode><pnr:RouteId>QR908</pnr:RouteId><pnr:LastReceivedTimeStamp>2018-03-16T03:30:56.440</pnr:LastReceivedTimeStamp><pnr:PNRPushCount>8</pnr:PNRPushCount><pnr:Carrier>1A</pnr:Carrier><pnr:PNRTraveller><com:PassengerTattoo>1</com:PassengerTattoo><com:Biographic><iat:familyName>AVARD</iat:familyName><iat:givenName>SHAREN ELIZABETH </iat:givenName></com:Biographic><com:ReservationName><com:familyName>AVARD</com:familyName><com:givenName>SHAREN ELIZABETH </com:givenName></com:ReservationName></pnr:PNRTraveller></PNRRecord></ListOfHistoricalPNRRecord><ListOfMatchedIATTraveller><MatchedIATTraveller><pnr:PNRTraveller><com:PassengerTattoo>1</com:PassengerTattoo><com:Biographic/><com:ReservationName><com:familyName>AVARD</com:familyName><com:givenName>SHAREN ELIZABETH </com:givenName></com:ReservationName></pnr:PNRTraveller><pnr:IATTraveller><com:IATTravellerId>0118198112</com:IATTravellerId><com:Biographic><iat:familyName>AVARD</iat:familyName><iat:givenName>SHAREN ELIZABETH</iat:givenName><iat:sexCode>F</iat:sexCode></com:Biographic></pnr:IATTraveller></MatchedIATTraveller><MatchedIATTraveller><pnr:PNRTraveller><com:PassengerTattoo>1</com:PassengerTattoo><com:Biographic/><com:ReservationName><com:familyName>AVARD</com:familyName><com:givenName>SHAREN ELIZABETH </com:givenName></com:ReservationName></pnr:PNRTraveller><pnr:IATTraveller><com:IATTravellerId>0118198112</com:IATTravellerId><com:Biographic><iat:familyName>BOARDMAN</iat:familyName><iat:givenName>SHAREN ELIZABETH</iat:givenName><iat:sexCode>F</iat:sexCode></com:Biographic></pnr:IATTraveller></MatchedIATTraveller></ListOfMatchedIATTraveller></GetHistoricalBookingDataResponse></soapenv:Body></soapenv:Envelope>`;

const GetHistoricalBookingDataFault =
    `<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:com="http://border.gov.au/service/risk/traveller/common/v1" xmlns:exe="http://border.gov.au/service/risk/traveller/pnr/exception/v1">
   <soap:Body>
      <soap:Fault>
         <faultcode>soap:Client</faultcode>
         <faultstring>TME103-Invalid Service Request Input</faultstring>
         <detail>
            <exe:GetHistoricalBookingData>
               <exe:exception>
                  <com:status>ERROR</com:status>
                  <com:errorCode>TME103</com:errorCode>
                  <com:errorDescription>Invalid Service Request Input: A schema validation error has occurred while parsing the XML document**/XMLNSC/http://schemas.xmlsoap.org/soap/envelope/:Envelope/http://schemas.xmlsoap.org/soap/envelope/:Body/http://border.gov.au/service/risk/traveller/pnr/request/v1:GetHistoricalBookingDataRequest**cvc-complex-type.2.4.a: Expecting element with local name "BookingSystemCode" but saw "ListOfIATTravellerId".**XML Parsing Errors have occurred**problem creating SOAP tree from bitstream**3c736f6170656e763a456e76656c6f706520786d6c6e733a736f6170656e763d22687474703a2f2f736368656d61732e786d6c736f61702e6f72672f736f61702f656e76656c6f70652f2220786d6c6e733a76313d22687474703a2f2f626f726465722e676f762e61752f736572766963652f7269736b2f74726176656c6c65722f706e722f726571756573742f76312220786d6c6e733a7631313d22687474703a2f2f626f726465722e676f762e61752f736572766963652f7269736b2f74726176656c6c65722f636f6d6d6f6e2f7631223e0a2020203c736f6170656e763a4865616465722f3e0a2020203c736f6170656e763a426f64793e0a2020202020203c76313a476574486973746f726963616c426f6f6b696e6744617461526571756573743e0a2020202020202020203c526571756573744865616465723e0a2020202020202020202020203c7631313a636f7272656c6174696f6e5265717565737449643e3f3c2f7631313a636f7272656c6174696f6e5265717565737449643e0a2020202020202020202020203c7631313a7573657249643e3f3c2f7631313a7573657249643e0a2020202020202020202020203c7631313a7265717565737454696d655374616d703e3f3c2f7631313a7265717565737454696d655374616d703e0a2020202020202020203c2f526571756573744865616465723e0a2020202020202020203c4c6973744f6649415454726176656c6c657249643e0a2020202020202020202020203c2f4c6973744f6649415454726176656c6c657249643e0a2020202020203c2f76313a476574486973746f726963616c426f6f6b696e6744617461526571756573743e0a2020203c2f736f6170656e763a426f64793e0a3c2f736f6170656e763a456e76656c6f70653e**Root**Error occurred in ImbSOAPInputHelper::validateSOAPInput()**Node throwing exception**</com:errorDescription>
                  <com:sourceSystem>IIB</com:sourceSystem>
               </exe:exception>
            </exe:GetHistoricalBookingData>
         </detail>
      </soap:Fault>
   </soap:Body>
</soap:Envelope>`;

const NoSoapActionFault =
    `<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
   <soap:Body>
      <soap:Fault>
         <faultcode>soap:Client</faultcode>
         <faultstring>No SOAP Action specified</faultstring>
      </soap:Fault>
   </soap:Body>
</soap:Envelope>`;

route.post("/PNRDataService", (req, res) => {

    console.log("=============================================================================");
    console.log("mock /PNRDataService called");
    console.log("=============================================================================");

    const timestamp = new Date().getTime();
    const faultItUp = false;  //timestamp % 2 === 0;
    const soapAction = req.get("SOAPAction");
    res.set("Content-Type", "text/xml");

    if(soapAction === GetCurrentBookingDataSoapAction) {
        if(faultItUp) {
            res.status(500).send(GetCurrentBookingDataFault);
        } else {
            res.send(GetCurrentBookingDataResponse);
        }
    } else if(soapAction === GetHistoricalBookingDataSoapAction) {
        if(faultItUp) {
            res.status(500).send(GetHistoricalBookingDataFault);
        } else {
            res.send(GetHistoricalBookingDataResponse);
        }
    } else {
        res.status(500).send(NoSoapActionFault);
    }
});

module.exports = route;
