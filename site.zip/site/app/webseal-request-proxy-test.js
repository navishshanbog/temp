const proxied = require("./webseal-request-proxy").proxied;

const test = async () => {
    const rp = proxied({
        /*websealUri: "https://e1-portals.immi.gov.au",*/
        websealUsername: "ADPTA7",
        websealPassword: "P@ssw0rd!7",
        strictSSL: false
    });
    const r = await rp({
        uri: "https://e1-portals.immi.gov.au/DataServices/solr/resources/v1/svoe/entitySearch/entities",
        qs: {
            searchString: "STNDRDSD_FL_NM:john"
        },
        strictSSL: false
    });
    console.log("-- Result: " + r);
};

test().catch(err => {
    console.error(err);
    process.exit(1);
});