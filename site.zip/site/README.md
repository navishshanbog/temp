# Analyst Desktop
Analyst Desktop Application

# node sass environment variable
set SASS_BINARY_SITE=http://nexus.bcz.gov.au/repository/cloud-mirror/node-sass
# Cloud mirror repo
# http://nexus.bcz.gov.au/#browse/browse:cloud-mirror 
or

export SASS_BINARY_SITE=http://nexus.bcz.gov.au/repository/cloud-mirror/node-sass

## Installing Dependencies
npm install

## Starting the server
npm run start

## Building with the default config
npm run build-watch

## Building with the mock config
npm run build-watch-mock


