import { Sequence } from "@twii/common/lib/Id";

const ComponentIdSequence = new Sequence("db-comp-");

export { ComponentIdSequence }