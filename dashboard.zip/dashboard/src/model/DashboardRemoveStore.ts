import { Supplier } from "@twii/common/lib/model/Supplier";
import { IDashboard } from "./IDashboard";

const DashboardRemoveStore = new Supplier<IDashboard>();

export { DashboardRemoveStore }