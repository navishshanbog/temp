import { DashboardAdd } from "./DashboardAdd";

const DashboardAddStore = new DashboardAdd();

export { DashboardAddStore }