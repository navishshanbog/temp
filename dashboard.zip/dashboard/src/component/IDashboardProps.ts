import { IDashboard } from "../model/IDashboard";

interface IDashboardProps {
    dashboard: IDashboard;
}

export { IDashboardProps as default, IDashboardProps }