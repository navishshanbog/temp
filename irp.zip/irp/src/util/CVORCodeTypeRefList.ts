import RefListModel from "@twii/common/lib/RefListModel";

const CVORCodeTypeRefList = new RefListModel([
    { key: "STR", text: "Streamlined"},
    { key: "STD", text: "Standard"},
    { key: "HGH", text: "High"},
    { key: "TBD", text: "Undetermined"}
]);

export { CVORCodeTypeRefList as default, CVORCodeTypeRefList };