import * as DefaultHttpErrorHandler from '@twii/common/lib/HttpErrorHandler';
import axios, {AxiosRequestConfig, AxiosResponse} from 'axios';

import AbstractRestDataService from '../shared/AbstractRestDataService';
import {IAddTreatmentNoteService, IAddTreatmentNoteServiceParams} from "../irp/model/IAddTreatmentNoteService";
import IRRClientRiskChecksServiceResponseItem from "../irp/model/IRRClientRiskChecksService";
import IRRClientRiskChecksService from "../irp/model/IRRClientRiskChecksService";
import {IRRClientRiskChecksServiceRequest, GetRRClientRiskCheckServiceRestResponse} from "../irp/model/IRRClientRiskChecksService";
import {
    IUpdateTreatmentService,
    IUpdateTreatmentServiceParams, IUpdateTreatmentServiceRes
} from "../irp/model/IUptateTreatmentService";
import {
    IGetTreatmentNotesService,
    IGetTreatmentNotesServiceReq, IGetTreatmentNotesServiceRes,
    IGetTreatmentNotesServiceResItem
} from "../irp/model/IGetTreatmentNotesService";
import {IIRPRiskSearchRequest} from "../search/model/IIRPRiskSearchRequest";
import {IIRPSearchService} from "../search/model/IIRPSearchService";
import {
    IClientSummaryService,
    IClientSummaryServiceReq,
    IClientSummaryServiceRes
} from "../irp/model/IClientSummaryService";
import {
    ICmalService,
    ICmalServiceReq,
    ICmalServiceRes
} from "../irp/model/ICmalService";
import {
    IClientBiographicsService,
    IClientBiographicsServiceReq,
    IClientBiographicsServiceRes
} from "../irp/model/IClientBiographicsService";
import {
    IClientApplicationDealingsService,
    IClientApplicationDealingsServiceReq, IClientApplicationDealingsServiceRes
} from "../irp/model/IClientApplicationDealingsService";
import {IRRClientRiskMatchesServiceResponseItem} from "../irp/model/IRRClientRiskMatchesServiceResponseItem";
import {
    IRRClientRiskMatchesService,
    IRRClientRiskMatchesServiceRequest, 
    GetRRClientRiskMatchesServiceRestResponse
} from "../irp/model/IRRClientRiskMatchesService";
import {
    IGetTreatmentAdvicesService,
    IGetTreatmentAdvicesServiceReq,
    IGetTreatmentAdvicesServiceRes, IGetTreatmentAdvicesServiceResItem
} from "../irp/model/IGetTreatmentAdvicesService";
import {
    IGetMatchEvalCaseDetailsService,
    IGetMatchEvalCaseDetailsServiceReq, IGetMatchEvalCaseDetailsServiceRes, IGetMatchEvalCaseDetailsServiceResItem
} from "../irp/model/IGetMatchEvalCaseDetailsService";
import {
    IGetTreatmentHistoryService,
    IGetTreatmentHistoryServiceReq, IGetTreatmentHistoryServiceRes,
    IGetTreatmentHistoryServiceResItem
} from "../irp/model/IGetTreatmentHistoryService";
import {
    IGetCodeSetService,
    IGetCodeSetServiceReq,
    IGetCodeSetServiceRes,
    IGetCodeSetServiceResItem
} from "../irp/model/IGetCodeSetService";
import {ValidRiskMatchStatus} from "../shared/RiskMatchValidValues";
import {
    IIRPRiskSearchResultItem,
    IIRPRiskSearchResultModel,
    IRPRiskSearchResultDataModel
} from "../search/model/IRPRiskSearchResultModel";
import {
    IRRCvorHistoryClientRiskMatchesService,
    IRRCvorHistoryClientRiskMatchesServiceRequest, 
    GetRRCvorHistoryClientRiskMatchesServiceRestResponse
} from "../irp/model/IRRCvorHistoryClientRiskMatchesService";
import { reject } from '@twii/common/lib/util/String';

const DEFAULT_MAX_RECORDS = 2000;

const CIEServicesHeaders = {
    "X-Clientapp-Id": "AnalystDesktop-IRPPortal"
};

// Add Treatment note
interface IAddTreatmentNoteServiceRes {
    errors?: any;
}

interface IAddTreatmentNoteServiceReq extends AxiosRequestConfig {
}

class RestAddTreatmentNoteService extends AbstractRestDataService implements IAddTreatmentNoteService {
    addTreatmentNote(params: IAddTreatmentNoteServiceParams): Promise<any> {
        const url = `${this.config.baseUrl.rrs}/api/results/${params.resultId}/notes`;
        return axios({
            method: "post",
            url: url,
            headers: {
                "Content-Type": "text/plain"
            },
            data: params.note
        } as IAddTreatmentNoteServiceReq).then((value) => {
            const response = this.assertObject(value.data) as IAddTreatmentNoteServiceRes;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            return response;
        }).catch(e => {
            DefaultHttpErrorHandler.handleAxiosError(e);
        });
    }
}

// Update treatment
class RestUpdateTreatmentService extends AbstractRestDataService implements IUpdateTreatmentService {
    updateTreatment(params: IUpdateTreatmentServiceParams): Promise<IUpdateTreatmentServiceRes> {
        const config: AxiosRequestConfig = {
            url: `${this.config.baseUrl.rrs}/api/results/${params.resultId}/status`,
            method: "post",
            data: {
                status: params.status,
                outcome: params.outcome,
                dismissalReasonCode: params.dismissalReasonCode,
                applicationRiskCheckVersion: params.applicationRiskCheckVersion,
                clientRiskCheckVersion: params.clientRiskCheckVersion
            }
        };

        return axios(config).then((value: AxiosResponse<IUpdateTreatmentServiceRes>) => {
            return this.assertObject(value.data) as IUpdateTreatmentServiceRes;
        })
    }
}

// Get Client Summary
class RestClientSummaryService extends AbstractRestDataService implements IClientSummaryService {
    getClientSummaryService(req: IClientSummaryServiceReq): Promise<IClientSummaryServiceRes> {
        const config: AxiosRequestConfig = {
            params: req
        };

        return axios({
            url: `${this.config.baseUrl.rrs}/api/client/summary`,
            headers: CIEServicesHeaders,
            params: config.params
        }).then((value) => {
            const response = this.assertObject(value.data) as IClientSummaryServiceRes;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            if (response && response.ClientSummary) {
                return response;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Get Cmal
class RestCmalService extends AbstractRestDataService implements ICmalService {
    getCmalService(req: ICmalServiceReq): Promise<ICmalServiceRes> {
        const config: AxiosRequestConfig = {
            params: req
        };

        return axios({
            url: `${this.config.baseUrl.rrs}/api/client/cmalstatus`,
            headers: CIEServicesHeaders,
            params: config.params
        }).then((value) => {
            const response = this.assertObject(value.data) as ICmalServiceRes;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            if (response && response.CmalStatus) {
                return response;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Get Client Biographics
class RestClientBiographicsService extends AbstractRestDataService implements IClientBiographicsService {
    getClientBiographics(req: IClientBiographicsServiceReq): Promise<IClientBiographicsServiceRes> {
        const config: AxiosRequestConfig = {
            params: req
        };

        return axios({
            url: `${this.config.baseUrl.rrs}/api/client/biographics`,
            headers: CIEServicesHeaders,
            params: config.params
        }).then((value) => {
            const response = this.assertObject(value.data) as IClientBiographicsServiceRes;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            if (response && response.ClientBiographics) {
                return response;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Get Client Application Dealings
class RestClientApplicationDealingsService extends AbstractRestDataService implements IClientApplicationDealingsService {
    getClientApplicationDealings(req: IClientApplicationDealingsServiceReq): Promise<IClientApplicationDealingsServiceRes> {
        const config: AxiosRequestConfig = {
            params: req
        };

        return axios({
            url: `${this.config.baseUrl.rrs}/api/client/applicationdealings`,
            headers: CIEServicesHeaders,
            params: config.params
        }).then((value) => {
            const response = this.assertObject(value.data) as IClientApplicationDealingsServiceRes;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            if (response && response.ClientApplicationDealings) {
                return response;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Get RR Risk Client Checks
class RestRRClientRiskCheckService extends AbstractRestDataService implements IRRClientRiskChecksService {
    getRRClientRiskChecks(params: IRRClientRiskChecksServiceRequest): Promise<GetRRClientRiskCheckServiceRestResponse> {
        const config: AxiosRequestConfig = {
            url: `${this.config.baseUrl.rrs}/api/applications/searches`,
            method: "post",
            data: params
        };

        return axios(config).then((value) => {
            const response = this.assertObject(value.data) as GetRRClientRiskCheckServiceRestResponse;
            if (response && response.applications) {
                return response;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Get RR Client Risk Matches
class RestRRClientRiskMatchesService extends AbstractRestDataService implements IRRClientRiskMatchesService {
    getRRClientRiskMatches(params: IRRClientRiskMatchesServiceRequest): Promise<GetRRClientRiskMatchesServiceRestResponse> {
        const config: AxiosRequestConfig = {
            params: params
        };

        return axios({
            url: `${this.config.baseUrl.rrs}/api/results/searches`,
            method: "post",
            data: config.params
        }).then((value) => {
            const response = this.assertObject(value.data) as GetRRClientRiskMatchesServiceRestResponse;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            if (response && response.filterResults) {
                return response;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Get RR CVOR History Client Risk Matches
class RestRRCvorHistoryClientRiskMatchesService extends AbstractRestDataService implements IRRCvorHistoryClientRiskMatchesService {
    getRRCvorHistoryClientRiskMatches(params: IRRCvorHistoryClientRiskMatchesServiceRequest): Promise<GetRRCvorHistoryClientRiskMatchesServiceRestResponse> {
        const config: AxiosRequestConfig = {
            params: params
        };
        return axios({
            url: `${this.config.baseUrl.rrs}/api/client/cvorhistory`,
            method: "get",
            params: config.params
        }).then((value) => {
            const response = this.assertObject(value.data) as GetRRCvorHistoryClientRiskMatchesServiceRestResponse;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            if (response && response.CvorHistories) {
                return response;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
        
}

class RestGetTreatmentAdvicesService extends AbstractRestDataService implements IGetTreatmentAdvicesService {
    getTreatmentAdvices(req: IGetTreatmentAdvicesServiceReq): Promise<IGetTreatmentAdvicesServiceResItem[]> {
        return axios({
            url: `${this.config.baseUrl.rrs}/api/results/${req.resultId}/advices`,
            method: "get"
        }).then((value) => {
            const response = this.assertObject(value.data) as IGetTreatmentAdvicesServiceRes;
            if (response && response.treatmentAdvices) {
                return response.treatmentAdvices;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Get RR Risk Match's Match Eval case
class RestGetMatchEvalCaseDetailsService extends AbstractRestDataService implements IGetMatchEvalCaseDetailsService {
    getMatchEvalCaseDetails(req: IGetMatchEvalCaseDetailsServiceReq): Promise<IGetMatchEvalCaseDetailsServiceResItem> {
        return axios({
            url: `${this.config.baseUrl.rrs}/api/results/${req.resultId}/matcheval/case`,
            method: "get"
        }).then((value) => {
            const response = this.assertObject(value.data) as IGetMatchEvalCaseDetailsServiceRes;
            if (response && response.case) {
                return response.case;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

//Get risk match notes
class RestGetTreatmentNotesService extends AbstractRestDataService implements IGetTreatmentNotesService {
    getTreatmentNotes(req: IGetTreatmentNotesServiceReq): Promise<IGetTreatmentNotesServiceResItem[]> {
        const url = `${this.config.baseUrl.rrs}/api/results/${req.resultId}/notes/`;

        return axios({
            method: "get",
            url: url,
        }).then((value) => {
            const response = this.assertObject(value.data) as IGetTreatmentNotesServiceRes;
            return response.notes;
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

//Get risk match history
class RestGetTreatmentHistoryService extends AbstractRestDataService implements IGetTreatmentHistoryService {
    getTreatmentHistory(req: IGetTreatmentHistoryServiceReq): Promise<IGetTreatmentHistoryServiceResItem[]> {
        const url = `${this.config.baseUrl.rrs}/api/results/${req.resultId}/history/`;

        return axios({
            method: "get",
            url: url,
        }).then((value) => {
            const response = this.assertObject(value.data) as IGetTreatmentHistoryServiceRes;
            return response.revisions;
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// Risk Search Service
interface IRestSearchResponse {
    totalResults: number;
    filterResults: IIRPRiskSearchResultItem;
    filtered?: boolean;
}

class RestIRPRiskSearchDataService extends AbstractRestDataService implements IIRPSearchService {
    search(request: IIRPRiskSearchRequest): Promise<IRPRiskSearchResultDataModel> {
        const reqInternal = Object.assign({}, request);

        return axios.post(`${this.config.baseUrl.rrs}/api/results/extsearches`, reqInternal).then((value: AxiosResponse<IRestSearchResponse>) => {
            return {
                total: value.data.totalResults,
                items: value.data.filterResults,
                filtered: value.data.filtered
            };
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

// RRS Code set service (Ref data)
class RestGetCodeSetService extends AbstractRestDataService implements IGetCodeSetService {
    getCodeSet(req: IGetCodeSetServiceReq): Promise<IGetCodeSetServiceResItem[]> {
        return axios({
            url: `${this.config.baseUrl.rrs}/api/codesets/${req.codeSetName}`,
            method: "get",
            timeout: 10000
        }).then((value) => {
            const response = this.assertObject(value.data) as IGetCodeSetServiceRes;
            if (response && response.entries) {
                return response.entries;
            }
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

export {
    RestAddTreatmentNoteService,
    IAddTreatmentNoteServiceReq,
    RestGetTreatmentNotesService,
    RestGetTreatmentHistoryService,
    RestUpdateTreatmentService,
    RestRRClientRiskCheckService,
    RestIRPRiskSearchDataService,
    RestClientSummaryService,
    RestCmalService,
    RestClientBiographicsService,
    RestClientApplicationDealingsService,
    RestRRClientRiskMatchesService,
    RestGetTreatmentAdvicesService,
    RestGetMatchEvalCaseDetailsService,
    RestGetCodeSetService, 
    RestRRCvorHistoryClientRiskMatchesService
};