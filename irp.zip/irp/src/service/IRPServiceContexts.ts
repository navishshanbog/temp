import Context from "@twii/common/lib/Context";
import {IRRClientRiskChecksService} from "../irp/model/IRRClientRiskChecksService";
import {
    RestAddTreatmentNoteService,
    RestGetTreatmentNotesService,
    RestRRClientRiskCheckService,
    RestUpdateTreatmentService,
    RestIRPRiskSearchDataService,
    RestClientSummaryService,
    RestCmalService,
    RestClientBiographicsService,
    RestClientApplicationDealingsService,
    RestRRClientRiskMatchesService,
    RestRRCvorHistoryClientRiskMatchesService,
    RestGetTreatmentAdvicesService,
    RestGetMatchEvalCaseDetailsService, RestGetTreatmentHistoryService, RestGetCodeSetService
} from "./IRPRestServices";
import {IAddTreatmentNoteService} from "../irp/model/IAddTreatmentNoteService";
import {IUpdateTreatmentService} from "../irp/model/IUptateTreatmentService";
import {IGetTreatmentNotesService} from "../irp/model/IGetTreatmentNotesService";
import {IIRPSearchService} from "../search/model/IIRPSearchService";
import {IClientSummaryService} from "../irp/model/IClientSummaryService";
import {ICmalService} from "../irp/model/ICmalService";
import {IClientBiographicsService} from "../irp/model/IClientBiographicsService";
import {IClientApplicationDealingsService} from "../irp/model/IClientApplicationDealingsService";
import {IRRClientRiskMatchesService} from "../irp/model/IRRClientRiskMatchesService";
import {IGetTreatmentAdvicesService} from "../irp/model/IGetTreatmentAdvicesService";
import {IGetMatchEvalCaseDetailsService} from "../irp/model/IGetMatchEvalCaseDetailsService";
import {IGetTreatmentHistoryService} from "../irp/model/IGetTreatmentHistoryService";
import {IGetCodeSetService} from "../irp/model/IGetCodeSetService";
import {IRRCvorHistoryClientRiskMatchesService} from "../irp/model/IRRCvorHistoryClientRiskMatchesService";

const GetCodeSetServiceContext = new Context<IGetCodeSetService>({
    id: "GetCodeSet",
    factory() {
        return new RestGetCodeSetService();
    }
});

const RRClientApplicationOverviewServiceContext = new Context<IRRClientRiskChecksService>({
    id: "RRClientApplicationOverview",
    factory() {
        return new RestRRClientRiskCheckService();
    }
});

const RRClientRiskMatchesServiceContext = new Context<IRRClientRiskMatchesService>({
    id: "RRClientRiskMatches",
    factory() {
        return new RestRRClientRiskMatchesService();
    }
});

const RRCvorHistoryClientRiskMatchesServiceContext = new Context<IRRCvorHistoryClientRiskMatchesService>({
    id: "RRCvorHistoryClientRiskMatches",
    factory() {
        return new RestRRCvorHistoryClientRiskMatchesService();
    }
});

const AddTreatmentNoteServiceContext = new Context<IAddTreatmentNoteService>({
    id: "AddTreatmentNote",
    factory() {
        return new RestAddTreatmentNoteService();
    }
});

const GetTreatmentAdvicesServiceContext = new Context<IGetTreatmentAdvicesService>({
    id: "GetTreatmentAdvices",
    factory() {
        return new RestGetTreatmentAdvicesService();
    }
});

const GetMatchEvalCaseDetailsServiceContext = new Context<IGetMatchEvalCaseDetailsService>({
    id: "GetMatchEvalCaseDetails",
    factory() {
        return new RestGetMatchEvalCaseDetailsService();
    }
});

const GetTreatmentNotesServiceContext = new Context<IGetTreatmentNotesService>({
    id: "GetTreatmentNotes",
    factory() {
        return new RestGetTreatmentNotesService();
    }
});

const GetTreatmentHistoryServiceContext = new Context<IGetTreatmentHistoryService>({
    id: "GetTreatmentHistory",
    factory() {
        return new RestGetTreatmentHistoryService();
    }
});

const UpdateTreatmentServiceContext = new Context<IUpdateTreatmentService>({
    id: "UpdateTreatment",
    factory() {
        return new RestUpdateTreatmentService();
    }
});

const IRPSearchServiceContext = new Context<IIRPSearchService>({
    id: "IRPSearchService",
    factory() {
        return new RestIRPRiskSearchDataService()
    }
});

const IRPClientSummaryServiceContext = new Context<IClientSummaryService>({
    id: "ClientSummaryService",
    factory: () => new RestClientSummaryService()
});

const IRPCmalServiceContext = new Context<ICmalService>({
    id: "CmalService",
    factory: () => new RestCmalService()
});

const IRPClientBiographicsServiceContext = new Context<IClientBiographicsService>({
    id: "ClientBiographicsService",
    factory: () => new RestClientBiographicsService()
});

const IRPClientApplicationDealingsServiceContext = new Context<IClientApplicationDealingsService>({
    id: "ClientApplicationDealingsService",
    factory: () => new RestClientApplicationDealingsService()
});

export {
    RRClientApplicationOverviewServiceContext,
    AddTreatmentNoteServiceContext,
    GetTreatmentNotesServiceContext,
    GetTreatmentHistoryServiceContext,
    UpdateTreatmentServiceContext,
    IRPSearchServiceContext,
    IRPClientSummaryServiceContext,
    IRPCmalServiceContext,
    IRPClientBiographicsServiceContext,
    IRPClientApplicationDealingsServiceContext,
    RRClientRiskMatchesServiceContext,
    RRCvorHistoryClientRiskMatchesServiceContext,
    GetTreatmentAdvicesServiceContext,
    GetMatchEvalCaseDetailsServiceContext,
    GetCodeSetServiceContext
};