import {observable} from "mobx";
import {KeyCodes} from "@uifabric/utilities";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {Observable, Subscription} from "rxjs/Rx";
import {fromEvent} from "rxjs/index";

enum ShortcutType {
    ActiveToggle = "activeToggle"
}

interface IKeyboardShortcutsService {
    registerShortcut: (shortcutObject: IRegisteredShortcuts) => void;
    unRegisterShortcut: (shortcutObject: IRegisteredShortcuts) => void;
    isKeyRegistered?: (shortcutObject: IRegisteredShortcuts) => void;
    getKeyIndex?: (shortcutObject: IRegisteredShortcuts) => number;
    passKeyCode: (e?: KeyboardEvent, keycode?: KeyCodes) => void;
    simulateKeyCode: (keycode: KeyCodes) => void;
}

interface IRegisteredShortcuts {
    keyCode: KeyCodes;
    shortcutType?: ShortcutType;
    shortcutFunction?: (e: KeyboardEvent) => any;
    preventDefault?: boolean;
}

enum ValidEventTypes {
    keydown = "keydown",
    keyup = "keyup"
}

enum ValidActivationKeys {
    alt = "alt",
    ctrl = "ctrl",
    shift = "shift"
}

class KeyboardShortcutsService implements IKeyboardShortcutsService {
    private readonly _rootElement: HTMLElement;
    private readonly _activationKeys: ValidActivationKeys[];
    private _keyDownHandlerObservable: Observable<KeyboardEvent>;
    private _keyDownHandlerSubscription: Subscription;
    private _keyUpHandlerObservable: Observable<KeyboardEvent>;
    private _keyUpHandlerSubscription: Subscription;

    @observable private _active: boolean;
    @observable private _registeredShortcuts: IRegisteredShortcuts[] = [];

    constructor(host: IAppHost, activationKeys: ValidActivationKeys[]) {
        this._rootElement = document.querySelector(`#${host.id}`) || document.documentElement;
        this._activationKeys = activationKeys;
        this._initiate();
    };

    private _checkActivationKeysPressed = (e: KeyboardEvent) => {
        const c1 = this._activationKeys.indexOf(ValidActivationKeys.alt) > -1 && !e.altKey;
        const c2 = this._activationKeys.indexOf(ValidActivationKeys.ctrl) > -1 && !e.ctrlKey;
        const c3 = this._activationKeys.indexOf(ValidActivationKeys.shift) > -1 && !e.shiftKey;
        return !c1 && !c2 && !c3;
    };

    private _initiate = () => {
        // this._keyDownHandlerObservable = fromEvent<KeyboardEvent>(this._rootElement, ValidEventTypes.keydown);
        // if (this._keyDownHandlerSubscription) this._keyDownHandlerSubscription.unsubscribe();
        // this._keyDownHandlerSubscription = this._keyDownHandlerObservable.subscribe((e: KeyboardEvent) => {
        //     if (this._checkActivationKeysPressed(e)) {
        //         this.passKeyCode(e);
        //     }
        // });

        this._keyUpHandlerObservable = fromEvent<KeyboardEvent>(this._rootElement, ValidEventTypes.keyup);
        if (this._keyUpHandlerSubscription) this._keyUpHandlerSubscription.unsubscribe();
        this._keyUpHandlerSubscription = this._keyUpHandlerObservable.subscribe((e: KeyboardEvent) => {
            if (this._checkActivationKeysPressed(e)) {
                this.passKeyCode(e);
            }
        });
    };

    passKeyCode = (e?: KeyboardEvent, keyCode?: KeyCodes) => {
        if (!keyCode && e) {
            keyCode = e.keyCode;
        }
        if (keyCode) {
            this._registeredShortcuts.forEach(shortcut => {
                if (keyCode === shortcut.keyCode) {
                    if (e && shortcut.preventDefault) {
                        e.preventDefault();
                    }
                    if (shortcut.shortcutFunction) {
                        shortcut.shortcutFunction(e);
                    }
                }
            });
        }
    };

    simulateKeyCode = (keyCode: KeyCodes) => {
        this._registeredShortcuts.forEach(shortcut => {
            if (keyCode === shortcut.keyCode && shortcut.shortcutFunction) {
                shortcut.shortcutFunction(null);
            }
        });
    };

    public registerShortcut(shortcutObject: IRegisteredShortcuts) {
        if (this.isKeyRegistered(shortcutObject)) {
            this._registeredShortcuts.splice(this.getKeyIndex(shortcutObject), 1, shortcutObject);
        } else {
            this._registeredShortcuts.push(shortcutObject);
        }
    }

    public unRegisterShortcut(shortcutObject: IRegisteredShortcuts) {
        if (this.isKeyRegistered(shortcutObject)) {
            this._registeredShortcuts.splice(this.getKeyIndex(shortcutObject), 1);
        }
    }

    public isKeyRegistered(shortcutObject: IRegisteredShortcuts) {
        return this.getKeyIndex(shortcutObject) > -1;
    }

    public getKeyIndex(shortcutObject: IRegisteredShortcuts): number {
        return this._registeredShortcuts.findIndex(rs => rs.keyCode === shortcutObject.keyCode);
    }
}

export {
    KeyboardShortcutsService as default,
    KeyboardShortcutsService,
    IKeyboardShortcutsService,
    ShortcutType,
    IRegisteredShortcuts,
    ValidActivationKeys
}