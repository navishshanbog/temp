import {observable, computed, reaction} from 'mobx';
import {IIRPStoreModel, IIRPStoreViewModel, ILoadPreSelectIds, ValidSearchTypes} from "./IIRPStoreModel";

import {
    GetCodeSetServiceContext,
    GetMatchEvalCaseDetailsServiceContext,
    GetTreatmentAdvicesServiceContext, GetTreatmentHistoryServiceContext,
    GetTreatmentNotesServiceContext,
    IRPClientApplicationDealingsServiceContext,
    IRPClientBiographicsServiceContext,
    IRPClientSummaryServiceContext, IRPCmalServiceContext, IRPSearchServiceContext, 
    RRClientRiskMatchesServiceContext, RRCvorHistoryClientRiskMatchesServiceContext,
    UpdateTreatmentServiceContext
} from "./IRPServiceContexts";
import {Dealing, DealingsModel, IDealing} from "../irp/model/IDealings";
import {
    IRRClientRiskChecks,
    IRRClientRiskChecksServiceResponseItem,
    RRClientRiskChecks,
    RRClientRiskChecksServiceRequest
} from "../irp/model/IRRClientRiskChecksService";
import {
    IClientIds,
    IRRClientRiskChecksServiceRequest,
    IApplication,
    IApps,
    ValidRRIdTypes
} from "../irp/model/IRRClientRiskChecksService";
import {RRClientApplicationOverviewServiceContext} from "./IRPServiceContexts";
import {SyncModel} from "@twii/common/lib/SyncModel";
import {TreatmentNotesServiceModel} from "../irp/model/TreatmentNotesServiceModel";
import {ISearchHistoryModel, searchHistoryMethodTypes, SearchHistoryModel} from "../irp/model/SearchHistoryModel";
import {IRPRiskSearchRequestModel} from "../search/model/IRPRiskSearchRequestModel";
import {IIRPRiskSearchResultViewItem, IRPRiskSearchResultModel} from "../search/model/IRPRiskSearchResultModel";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {AddTreatmentNoteServiceContext} from "./IRPServiceContexts";
import {IUpdateTreatmentServiceParams, IUpdateTreatmentServiceRes} from "../irp/model/IUptateTreatmentService";
import {IRPUpdateTreatmentRequestModel} from "../irp/model/IRPUpdateTreatmentRequestModel";
import {IGetTreatmentNotesServiceReq, TreatmentNotes} from "../irp/model/IGetTreatmentNotesService";
import {
    ClientSummary,
    IClientSummaryItem,
    IClientSummaryServiceReq, 
    IClientSummaryService,
    IClientSummaryServiceRes
} from "../irp/model/IClientSummaryService";
import {
    Cmal,
    ICmalItem,
    ICmalServiceReq
} from "../irp/model/ICmalService";
import {
    ClientBiographics,
    IClientBiographicsServiceReq
} from "../irp/model/IClientBiographicsService";
import {
    ClientApplicationDealings,
    IClientApplicationDealings,
    IClientApplicationDealingsServiceReq,
} from "../irp/model/IClientApplicationDealingsService";
import {IAddTreatmentNoteServiceParams} from "../irp/model/IAddTreatmentNoteService";
import {SystemIdTypeRefList, validIdSourceENUM, validIdTypeENUM} from "../shared/SystemIdTypeRefList";
import {
    ClientRiskMatches,
    IClientRiskMatch, ClientRiskMatch
} from "../irp/model/IRRClientRiskMatchesServiceResponseItem";
import {
    IClientRiskOverview,
    ClientRiskOverviewModel
} from "../irp/model/ClientRiskOverviewModel";
import {
    IGetTreatmentAdvicesServiceReq,
    IGetTreatmentAdvicesServiceResItem, TreatmentAdvices
} from "../irp/model/IGetTreatmentAdvicesService";
import {
    IGetMatchEvalCaseDetailsServiceReq,
    IGetMatchEvalCaseDetailsServiceResItem,
    MatchEvalCaseDetails
} from "../irp/model/IGetMatchEvalCaseDetailsService";
import {TreatmentHistory} from "../irp/model/IGetTreatmentHistoryService";
import {UserProfileStore} from "@twii/ozone/lib/user/model/UserProfileStore";
import {
    CodeSet,
    ICodeSet,
    IGetCodeSetServiceReq,
    IGetCodeSetServiceResItem,
    ValidCodeSetNames
} from "../irp/model/IGetCodeSetService";
import {IUserProfile} from "@twii/ozone/lib/user/IUserProfile";
import {IRRClientRiskMatchesServiceRequest} from "../irp/model/IRRClientRiskMatchesService";
import {IRRCvorHistoryClientRiskMatchesServiceRequest} from "../irp/model/IRRCvorHistoryClientRiskMatchesService";
import {IRPSimpleSearchRequestModel} from "../search/model/IRPSimpleSearchRequestModel";
import {IIRPRiskSearchRequest} from "../search/model/IIRPRiskSearchRequest";
import {fromEvent} from "rxjs/index";
import {debounceTime} from "rxjs/internal/operators";
import {Observable, BehaviorSubject} from "rxjs/Rx";
import {IIRPRouterUrlParams} from "../IRPRouter";
import {KeyboardShortcutsService, ShortcutType, ValidActivationKeys} from "./KeyboardShortcuts.service";
import AppContext from "@twii/common/lib/AppContext";
import {IIRPSimpleSearchRequest} from "../search/model/IIRPSimpleSearchRequest";

class IRPStoreViewModel implements IIRPStoreViewModel {
    @observable isSimpleSearchOpen = true;
    @observable isRiskSearchOpen = false;
    @observable rootElementSelector = undefined;
    @observable stickyClientSummary = false;
    @observable noClientRiskMatchesDataReFetch = false;
    @observable isLeftPanelOpen = true;
    toggleLeftPanel = () => {
        this.isLeftPanelOpen = !this.isLeftPanelOpen
    };
    @observable selectedSearch = ValidSearchTypes.simpleSearch;
    windowResizeObservable = new Observable<Event>();
    setSelectedSearch = (selectedSearch: ValidSearchTypes) => {
        this.selectedSearch = selectedSearch;
    };
    keyboardShortcutsService = undefined;
}

class IRPStoreModel implements IIRPStoreModel {
    private _servicesSyncId: string;
    userProfile: IUserProfile = UserProfileStore.value;

    @observable private clientSummary = new ClientSummary();
    @observable private cmal = new Cmal();
    @observable private clientBiographics = new ClientBiographics();
    @observable private clientApplicationDealings: IClientApplicationDealings = new ClientApplicationDealings();

    @observable private rrClientRiskChecks: IRRClientRiskChecks = new RRClientRiskChecks();

    @observable dealings = new DealingsModel();
    @observable _selectedDealing: IDealing;
    @observable clientRiskMatches = new ClientRiskMatches();
    @observable selectedRiskMatch: IClientRiskMatch = null;

    @observable private _viewModel: IIRPStoreViewModel = new IRPStoreViewModel();

    @observable simpleSearchRequest = new IRPSimpleSearchRequestModel();
    @observable riskSearchRequest = new IRPRiskSearchRequestModel();
    @observable riskSearchResults = new IRPRiskSearchResultModel();

    @observable treatmentNotes = new TreatmentNotes();
    @observable treatmentsNotes = new TreatmentNotesServiceModel();
    @observable updatedNotes = {};

    @observable treatmentHistory = new TreatmentHistory();

    @observable treatmentAdvices = new TreatmentAdvices();
    @observable matchEvalCaseDetails = new MatchEvalCaseDetails();

    @observable updateTreatmentRequest = new IRPUpdateTreatmentRequestModel();

    @observable visitedItems: ISearchHistoryModel = new SearchHistoryModel();

    dismissalReasonsSubject = new BehaviorSubject(null);
    dismissalReasons: ICodeSet = new CodeSet();
    @observable attachmentsCodeSet: ICodeSet = new CodeSet();
    @observable matchTriggersCodeSet: ICodeSet = new CodeSet();
    @observable threatTypesCodeSet: ICodeSet = new CodeSet();

    constructor() {
        // Subscribing to search history Subject
        this.visitedItems.funcExecuteSub.subscribe(res => {
                if (res && res.method === searchHistoryMethodTypes.get) {
                    this.visitedItems.setItems(res.value);
                }
                if (res && res.method === searchHistoryMethodTypes.error) {
                    console.log(res.value);
                }
            }
        );

        const resizeEvent = fromEvent(window, "resize");
        this.setViewModel({
            windowResizeObservable: resizeEvent.pipe(debounceTime(50))
        });

        //Pre loading ref data code sets
        this.dismissalReasonsSubject.subscribe((res: IGetCodeSetServiceResItem[]) => {
            if (res) {
                this.dismissalReasons.setItems(res);
            }
        });
        this._getDismissalReasons();
        this._getAttachmentsCodeSet();
        this._getTriggersCodeSet();
        this._getThreatTypes();
    }

    /*------- START - All code sets from Ref data DB -------*/
    private _getThreatTypes = () => {
        if (!this.threatTypesCodeSet.sync.hasSynced && !this.threatTypesCodeSet.sync.syncing) {
            this.threatTypesCodeSet.sync.syncStart();
            const req: IGetCodeSetServiceReq = {codeSetName: ValidCodeSetNames.threattypes};
            GetCodeSetServiceContext.value.getCodeSet(req).then(res => {
                this.threatTypesCodeSet.setItems(res);
                this.threatTypesCodeSet.sync.syncEnd();
            }).catch(e => {
                this.threatTypesCodeSet.sync.syncError(e);
            })
        }
    };

    private _getDismissalReasons = () => {
        if (!this.dismissalReasons.sync.hasSynced && !this.dismissalReasons.sync.syncing) {
            this.dismissalReasons.sync.syncStart();
            const req: IGetCodeSetServiceReq = {codeSetName: ValidCodeSetNames.dismissalreasons};
            GetCodeSetServiceContext.value.getCodeSet(req).then(res => {
                // this.dismissalReasons.setItems(res);
                this.dismissalReasonsSubject.next(res);
                this.dismissalReasons.sync.syncEnd();
            }).catch(e => {
                this.dismissalReasons.sync.syncError(e);
            })
        }
    };

    private _getAttachmentsCodeSet = () => {
        if (!this.attachmentsCodeSet.sync.hasSynced && !this.attachmentsCodeSet.sync.syncing)
            this.attachmentsCodeSet.sync.syncStart();
        const req: IGetCodeSetServiceReq = {codeSetName: ValidCodeSetNames.attachments};
        GetCodeSetServiceContext.value.getCodeSet(req).then(res => {
            this.attachmentsCodeSet.setItems(res);
            this.attachmentsCodeSet.sync.syncEnd();
        }).catch(e => {
            this.attachmentsCodeSet.sync.syncError(e);
        })
    };

    private _getTriggersCodeSet = () => {
        if (!this.matchTriggersCodeSet.sync.hasSynced && !this.matchTriggersCodeSet.sync.syncing)
            this.matchTriggersCodeSet.sync.syncStart();
        const req: IGetCodeSetServiceReq = {codeSetName: ValidCodeSetNames.triggers};
        GetCodeSetServiceContext.value.getCodeSet(req).then(res => {
            this.matchTriggersCodeSet.setItems(res);
            this.matchTriggersCodeSet.sync.syncEnd();
        }).catch(e => {
            this.matchTriggersCodeSet.sync.syncError(e);
        })
    };
    /*------- END - All code sets from Ref data DB -------*/

    /*------- START - IRP ViewModel functions --------*/
    setViewModel = (props: IIRPStoreViewModel) => {
        Object.keys(props).forEach(key => {
            if (this._viewModel.hasOwnProperty(key)) {
                this._viewModel[key] = props[key];
            }
        });
    };

    getViewModel = () => this._viewModel;

    activateKeyboardShortcutsService = (host: IAppHost) => {
        const keyboardShortcutService = new KeyboardShortcutsService(host, [ValidActivationKeys.alt]);
        this.setViewModel({
            keyboardShortcutsService: keyboardShortcutService
        });
    };
    /*------- END - IRP ViewModel functions --------*/

    private getCmal = (req: ICmalServiceReq) => {
        this._servicesSyncId = req.searchIdType + req.searchId;
        this.cmal.sync.syncStart({id: this._servicesSyncId});
        return IRPCmalServiceContext.value.getCmalService(req).then(res => {
            if (this.cmal.sync.id === this._servicesSyncId) {
                this.cmal.setData(res.CmalStatus);
                this.cmal.sync.syncEnd();
                return this.cmal;
            }
        }).catch(e => {
            if (this.cmal.sync.id === this._servicesSyncId) {
                this.cmal.setServiceStatus("Status unavailable");
                this.cmal.sync.syncError(e);
            }
        });
    };

    private clearCmal = () => {
        this.cmal = new Cmal();
        this.cmal.sync = new SyncModel();
        return Promise.resolve(this.cmal);
    };


    /*------ START - CIE Services functions ------*/
    // CIE data - Client Summary
    //private getClientSummary = (req: IClientSummaryServiceReq) : Promise<IClientSummaryServiceRes>  => {
    private getClientSummary = (req: IClientSummaryServiceReq) => {
        this._servicesSyncId = req.searchIdType + req.searchId;
        this.clientSummary.sync.syncStart({id: this._servicesSyncId});
        return IRPClientSummaryServiceContext.value.getClientSummaryService(req).then(res => {
            if (this.clientSummary.sync.id === this._servicesSyncId) {
                this.clientSummary.setData(res.ClientSummary);
                this.clientSummary.setFiltered(res.filtered);
                this.clientSummary.sync.syncEnd();
                return this.clientSummary;
            }
        }).catch(e => {
            if (this.clientSummary.sync.id === this._servicesSyncId) {
                this.clientSummary.sync.syncError(e);
            }
        });
    };

    private clearClientSummary = () => {
        this.clientSummary = new ClientSummary();
        this.clientSummary.sync = new SyncModel();
        return Promise.resolve(this.clientSummary);
    };

    // CIE data - Client Biography
    private getClientBiographics = (req: IClientBiographicsServiceReq) => {
        this.clientBiographics.sync.syncStart({id: this._servicesSyncId});
        return IRPClientBiographicsServiceContext.value.getClientBiographics(req).then(res => {
            if (this.clientBiographics.sync.id === this._servicesSyncId) {
                this.clientBiographics.setData(res.ClientBiographics);
                this.clientBiographics.sync.syncEnd();
                return this.clientBiographics;
            }
        }).catch(e => {
            if (this.clientBiographics.sync.id === this._servicesSyncId) {
                this.clientBiographics.sync.syncError(e);
            }
        });
    };

    private clearClientBiographics = () => {
        this.clientBiographics = new ClientBiographics();
        this.clientBiographics.sync = new SyncModel();
        return Promise.resolve(this.clientBiographics);
    };

    // Client Overview data derived from Client Summary, Client Biography, and CMAL
    @computed
    get clientRiskOverview() {
        const clientSummary = this.clientSummary;
        const clientBiographics = this.clientBiographics;
        const cmal = this.cmal;
        const clientBiographicsData = clientBiographics.data ? clientBiographics.data : null;
        const cmalData = cmal.data ? cmal.data : null;
        const cmalServiceStatus = cmal.serviceStatus ? cmal.serviceStatus : null;
        let clientRiskOverview = new ClientRiskOverviewModel();
        clientRiskOverview.setData(clientSummary, clientBiographicsData);
        clientRiskOverview.setCmalData(cmalData);
        clientRiskOverview.setCmalServiceStatus(cmalServiceStatus);
        if(cmalData) {
            clientRiskOverview.sync.hasSynced = clientSummary.sync.hasSynced && clientBiographics.sync.hasSynced && cmal.sync.hasSynced;
        } else {
            clientRiskOverview.sync.hasSynced = clientSummary.sync.hasSynced && clientBiographics.sync.hasSynced
        }
        clientRiskOverview.sync.syncing = clientSummary.sync.syncing || clientBiographics.sync.syncing || cmal.sync.syncing;
        clientRiskOverview.sync.error = clientSummary.sync.error || clientBiographics.sync.error;

        return clientRiskOverview;
    }

    // CIE data - Client application dealings
    private getClientApplicationDealings = (req: IClientApplicationDealingsServiceReq) => {
        // const req: IClientApplicationDealingsServiceReq = new ClientApplicationDealingsServiceReq();
        // req.setRequest(icseid, tripsId);
        this.clientApplicationDealings.sync.syncStart({id: this._servicesSyncId});
        return IRPClientApplicationDealingsServiceContext.value.getClientApplicationDealings(req).then(res => {
            if (this.clientApplicationDealings.sync.id === this._servicesSyncId) {
                if (res.ClientApplicationDealings) {
                    this.clientApplicationDealings.setClientDealings(res.filtered, res.ClientApplicationDealings)
                    /*this.clientApplicationDealings.setItems(res.ClientApplicationDealings);
                    this.clientApplicationDealings.setFiltered(res.filtered);*/
                    this.clientApplicationDealings.sync.syncEnd();
                }
            }
        }).catch(e => {
            if (this.clientApplicationDealings.sync.id === this._servicesSyncId) {
                this.clientApplicationDealings.sync.syncError(e);
                //throw(e);
            }
        });
    };

    private clearClientApplicationDealings = () => {
        this.clientApplicationDealings = new ClientApplicationDealings();
        this.clientApplicationDealings.sync = new SyncModel();
        return Promise.resolve(this.clientApplicationDealings);
    };
    /*------ END - CIE Services functions ------*/

    private updateRRClientRiskChecks = (res: any) => {
        this.rrClientRiskChecks.filtered = res.filtered;
    }


    
    /*------ START - RRS Services functions ------*/
    // RRS data - Application risk checks
    private getRRClientRiskChecks = (applications: IApplication[]) => {
        const req: IRRClientRiskChecksServiceRequest = new RRClientRiskChecksServiceRequest();
        req.setRequest(applications);

        const id = req.applications.map(i => i.sourceSystemId).join("");
        this.rrClientRiskChecks.sync.hasSynced = false;
        //this.rrClientRiskChecks.setRiskChecksRetrieved(false);
        this.rrClientRiskChecks.sync.syncStart({id: this._servicesSyncId});
        return RRClientApplicationOverviewServiceContext.value.getRRClientRiskChecks(req).then(res => {
            if (this.rrClientRiskChecks.sync.id === this._servicesSyncId) {
                if(res.applications) {
                    res.applications.forEach(app => {
                        app.fetchVRAMatches = true;
                    })
                    this.updateRRClientRiskChecks(res);
                    this.rrClientRiskChecks.setItems(res.applications);
                    //this.rrClientRiskChecks.setRiskChecksRetrieved(true);
                    this.rrClientRiskChecks.sync.syncEnd();
                }
                return this.rrClientRiskChecks;
            }
        }).catch(e => {
            if (this.rrClientRiskChecks.sync.id === this._servicesSyncId) {
                this.clientApplicationDealings.sync.syncError(e);
            }
        });
    };

    // RRS Data - To update application risk check data - When a risk match status updates
    updateApplicationRiskCheckClient = (clientIds: IClientIds[], applicationRiskCheck: IUpdateTreatmentServiceRes) => {
        this.rrClientRiskChecks.updateApplicationRiskCheckClientSubject.next({
            clientIds: clientIds,
            updateTreatmentRes: applicationRiskCheck
        });
    };

    private clearRRApplicationClientRiskOverview = () => {
        this.rrClientRiskChecks.clear();
        this.rrClientRiskChecks.sync = new SyncModel();
        return Promise.resolve(this.rrClientRiskChecks);
    };

    //RRS data - get treatment advices
    private _getTreatmentAdvices = (req: IGetTreatmentAdvicesServiceReq) => {
        this.treatmentAdvices.sync.syncStart({id: this._servicesSyncId});
        return GetTreatmentAdvicesServiceContext.value.getTreatmentAdvices(req)
            .then((treatmentAdvices: IGetTreatmentAdvicesServiceResItem[]) => {
                if (this.treatmentAdvices.sync.id === this._servicesSyncId) {
                    this.treatmentAdvices.setItems(treatmentAdvices);
                    this.treatmentAdvices.sync.syncEnd();
                }
            });
    };

    private clearTreatmentAdvices = () => {
        this.treatmentAdvices.clear();
        this.treatmentAdvices.sync = new SyncModel();
    };

    //RRS data - get match eval case details
    private _getMatchEvalCaseDetails = (req: IGetMatchEvalCaseDetailsServiceReq) => {
        this.matchEvalCaseDetails.sync.syncStart({id: this._servicesSyncId});
        return GetMatchEvalCaseDetailsServiceContext.value.getMatchEvalCaseDetails(req)
            .then((matchEvalCase: IGetMatchEvalCaseDetailsServiceResItem) => {
                if (this.matchEvalCaseDetails.sync.id === this._servicesSyncId) {
                    this.matchEvalCaseDetails.setData(matchEvalCase);
                    this.matchEvalCaseDetails.sync.syncEnd();
                }
            });
    };

    private clearMatchEvalCaseDetails = () => {
        this.matchEvalCaseDetails = new MatchEvalCaseDetails();
    };

    skipNote = () => {
        const riskMatchIdx = this.clientRiskMatches.items.findIndex(r => r.resultId === this.selectedRiskMatch.resultId);
        const riskMatch = this.clientRiskMatches.items[riskMatchIdx];

        if (riskMatch) {
            riskMatch.showNotesForUserIp = false;
            riskMatch.actionedByUser = false;
        }
        // not a good way.. hacky for now
        this.clientRiskMatches.items[riskMatchIdx] = riskMatch;
        this.selectedRiskMatch = riskMatch;
    }

    // RRS data - saving risk match note
    saveNote = (treatmentNote: IAddTreatmentNoteServiceParams) => {
        const syncId = treatmentNote.resultId;
        const riskMatchIdx = this.clientRiskMatches.items.findIndex(r => r.resultId === syncId);
        const riskMatch = this.clientRiskMatches.items[riskMatchIdx];
        this.clientRiskMatches.items[riskMatchIdx] = riskMatch;
        this.selectedRiskMatch = riskMatch;
        if (riskMatch) {
            riskMatch.showNoteIcon = true;
        }
       
        this.treatmentsNotes.notes.sync.syncStart({id: syncId});
        return AddTreatmentNoteServiceContext.value.addTreatmentNote(treatmentNote)
            .then(() => {
                this.treatmentsNotes.removeTreatmentNote(treatmentNote.resultId);
                this.treatmentsNotes.notes.sync.syncEnd();
                return this._getTreatmentNotes({resultId: treatmentNote.resultId});
            }).catch(e => {
                this.treatmentsNotes.notes.sync.syncError(e);
            });
    };

    // RRS data - Retrieving a particular risk match notes
    private _getTreatmentNotes = (req: IGetTreatmentNotesServiceReq) => {
        const resultId = req.resultId;
        this.treatmentNotes.sync.syncStart({id: resultId});
        return GetTreatmentNotesServiceContext.value.getTreatmentNotes(req).then(res => {
            this.treatmentNotes.setItems(res);
        }).catch(e => {
            this.treatmentNotes.sync.syncError(e);
        });
    };

    private clearTreatmentNotes = () => {
        this.treatmentNotes = new TreatmentNotes();
    };

    // RRS data - Retrieving a particular risk match history
    private _getTreatmentHistory = (req: IGetTreatmentNotesServiceReq) => {
        const resultId = req.resultId;
        this.treatmentHistory.sync.syncStart({id: resultId});
        return GetTreatmentHistoryServiceContext.value.getTreatmentHistory(req).then(res => {
            this.treatmentHistory.setItems(res);
        }).catch(e => {
            this.treatmentHistory.sync.syncError(e);
        });
    };

    private clearTreatmentHistory = () => {
        this.treatmentHistory = new TreatmentHistory();
    };

    // RRS data - Updating Risk match status
    updateTreatment = (params: IUpdateTreatmentServiceParams): Promise<IUpdateTreatmentServiceRes | void> => {
        this.updateTreatmentRequest.setRequest(params);
        const syncId = params.resultId;
        const sync = this.updateTreatmentRequest.syncList.syncStart(syncId);

        return UpdateTreatmentServiceContext.value
            .updateTreatment(this.updateTreatmentRequest.request)
            .then(res => {
                this.updateTreatmentRequest.clear();
                sync.syncEnd();
                return res;
            }).catch(e => {
                sync.syncError(e);
                throw(e);
            });
    };
    /*------ END - RRS Services functions ------*/

    ///*------ START - Automated data retrieval by Mobx-------*///
    /*------ START - Client dealings functions ----------*/
    // Matching "Risk Results data" with "CIE data" and producing "Client Dealings"
    private _getClientDealings = reaction(
        () => {
            const clientSummary: IClientSummaryItem = this.clientSummary && this.clientSummary.data ? this.clientSummary.data : null;
            const clientBio = this.clientBiographics && this.clientBiographics.data ? this.clientBiographics.data : null;
            const cmal = this.cmal && this.cmal.data ? this.cmal.data : null;
            const cieClientApplicationOverview = this.clientApplicationDealings && this.clientApplicationDealings.items && this.clientApplicationDealings.items.length > 0 ? 
            this.clientApplicationDealings.items : [];
            const rrApplicationClientRiskOverview = this.rrClientRiskChecks && this.rrClientRiskChecks.items && this.rrClientRiskChecks.items.length > 0 ?
            this.rrClientRiskChecks.items : [];

            const iCSEClientId = clientSummary && clientSummary.identifiers && clientSummary.identifiers.ICSEClientId && clientSummary.identifiers.ICSEClientId.length > 0 ? 
            clientSummary.identifiers.ICSEClientId[0] : "";
            const tRIPSPersonId = clientSummary && clientSummary.identifiers && clientSummary.identifiers.TRIPSPersonId && clientSummary.identifiers.TRIPSPersonId.length > 0 ? 
            clientSummary.identifiers.TRIPSPersonId[0] : "";
            const iRISClientId = clientSummary && clientSummary.identifiers && clientSummary.identifiers.IRISClientId && clientSummary.identifiers.IRISClientId.length > 0 ? 
            clientSummary.identifiers.IRISClientId[0] : "";

            let syncId;
            if (this.rrClientRiskChecks.sync.error || this.clientApplicationDealings.sync.error) {
                this.dealings.sync = this.rrClientRiskChecks.sync.error ? this.rrClientRiskChecks.sync : this.clientApplicationDealings.sync;
                syncId = null;
            } else if (this.rrClientRiskChecks.sync.syncing || this.clientApplicationDealings.sync.syncing) {
                this.dealings.sync = this.rrClientRiskChecks.sync.syncing ? this.rrClientRiskChecks.sync : this.clientApplicationDealings.sync;
                syncId = null;
            } else if (this.rrClientRiskChecks.sync.hasSynced && this.clientApplicationDealings.sync.hasSynced && clientSummary && clientSummary.identifiers) {
                syncId = iCSEClientId + tRIPSPersonId + iRISClientId + Math.random();
            } else {
                syncId = null;
            }
            return syncId;
        }, (syncId: string) => {
            if (!syncId) {
                return;
            }
            this.dealings.sync = new SyncModel();
            this.dealings.sync.syncStart({id: syncId});
            const clientSummary: IClientSummaryItem = this.clientSummary && this.clientSummary.data ? this.clientSummary.data : null;
            const clientBio = this.clientBiographics && this.clientBiographics.data ? this.clientBiographics.data : null;
            const cmal = this.cmal && this.cmal.data ? this.cmal.data : null;
            const cieClientApplicationOverview = this.clientApplicationDealings && this.clientApplicationDealings.items && this.clientApplicationDealings.items.length > 0 ?
            this.clientApplicationDealings.items : [];
            const rrApplicationClientRiskOverview = this.rrClientRiskChecks && this.rrClientRiskChecks.items && this.rrClientRiskChecks.items.length > 0 ? 
            this.rrClientRiskChecks.items : [];

            //if (cieClientApplicationOverview.length > 0 && rrApplicationClientRiskOverview.length > 0) {
            if (cieClientApplicationOverview && rrApplicationClientRiskOverview) {
                const dealings = this.dealings.matchApplicationDealings(cieClientApplicationOverview, rrApplicationClientRiskOverview, clientSummary.identifiers);

                this.dealings.setItems(dealings);
                this.dealings.setRRApplicationClientRiskFilteredStatus(this.rrClientRiskChecks.filtered);
                this.dealings.sync.syncEnd();

                if (this.simpleSearchRequest.request.idType && this.simpleSearchRequest.request.idType.toLowerCase() === "prid") {
                    const selectedDealing = this.dealings.items.find(d => d.applicationId === this.simpleSearchRequest.request.referenceNumber);
                    this.selectDealing(selectedDealing)
                } else if (this.getSelectedDealing()) {
                    this.updateSelectedDealing();
                }
            }
        }, {
            name: "Dealings Reaction", onError: e => {
                this.dealings.sync.syncError(e);
                //throw(e);
            }
        });

    selectDealing(dealing: IDealing) {
        if (!dealing) {
            return false;
        }
        if (!this._selectedDealing) {
            this._selectedDealing = observable(new Dealing());
        }
        const dealingPrcid = dealing.permissionReqId;
        const dealingVGN = dealing.vgn;
        const dealingIid = dealing && dealing.iid && dealing.iid.length > 0 ? dealing.iid[0] : "";
        const selectedDealing = this.dealings.items.find(d => {
            return (dealingPrcid && d.permissionReqId === dealingPrcid)
                || (dealingVGN && d.vgn === dealingVGN) || (dealingIid && d.iid[0] === dealingIid)
        });
        if (selectedDealing) {
            this._selectedDealing = selectedDealing;
        }
    }

    clearSelectedDealing = () => {
        this._selectedDealing = null;
    };

    @computed
    get selectedDealing() {
        return this._selectedDealing;
    };

    getSelectedDealing() {
        return this._selectedDealing;
    };

    updateSelectedDealing = () => {
        const currentlySelectedDealing = this.getSelectedDealing();
        if (currentlySelectedDealing) {
            const prcId = currentlySelectedDealing.permissionReqId;
            const vgn = currentlySelectedDealing.vgn;
            const updatedSelectedDealing = this.dealings.items.find(d => {
                return (prcId && prcId === d.permissionReqId)
                    || (vgn && vgn === d.vgn);
            });
            if (updatedSelectedDealing) {
                this.getSelectedDealing().setDealing(updatedSelectedDealing);
            }
        }
    };
    /*--------- END- Client dealings functions--------*/

    /*--------- START - Risk Matches functions---------*/
    // Producing client Risk Matches by changing of selected dealing
    private _getClientRiskMatchesBySelectedDealing = (selectedDealing: IDealing) => {
        let serviceReq: IRRClientRiskMatchesServiceRequest;
        if (selectedDealing.riskResultsMathedId === ValidRRIdTypes.CLIENT_ROLE_ID) {
            serviceReq = {
                identifier: {
                    type: ValidRRIdTypes.CLIENT_ROLE_ID,
                    value: selectedDealing.permissionReqId
                }
            }
        } else if (selectedDealing.riskResultsMathedId === ValidRRIdTypes.VISA_GRANT_NUMBER) {
        //} else if (selectedDealing.selectedVgn) {
            serviceReq = {
                identifier: {
                    type: ValidRRIdTypes.VISA_GRANT_NUMBER,
                    value: selectedDealing.vgn
                }
            }
        }
        return RRClientRiskMatchesServiceContext.value.getRRClientRiskMatches(serviceReq);
    };

    // Producing CVOR History client Risk Matches by changing of selected dealing
    private _getCvorHistoryClientRiskMatchesBySelectedDealing = (selectedDealing: IDealing) => {
        let serviceReq: IRRCvorHistoryClientRiskMatchesServiceRequest;
        if( selectedDealing.permissionReqId){
            serviceReq = {
                ids: selectedDealing.permissionReqId, 
                type: "permissionRequestClientId"
            }
        }
        else {
            serviceReq = {
                ids: selectedDealing.iid && selectedDealing.iid.length > 0 ? selectedDealing.iid[0] : "", 
                type:  "irisClientId"
            }
        }
        return RRCvorHistoryClientRiskMatchesServiceContext.value.getRRCvorHistoryClientRiskMatches(serviceReq);
    };



    private _getClientRiskMatchesReaction = reaction(() => {
        const selectedDealing = this.getSelectedDealing();
        let out = null;
        if(this.rrClientRiskChecks.sync.hasSynced) {
            out = selectedDealing
                ? selectedDealing : null;
        }
        return out;
    }, (selectedDealing: IDealing) => {

        const riskChecksRetrieved: boolean = true;
        const rrClientRiskChecksItemsLength = this.rrClientRiskChecks && this.rrClientRiskChecks.items 
        && this.rrClientRiskChecks.items.length > 0 ? this.rrClientRiskChecks.items.length : 0;
        console.log("riskChecksRetrieved: " + riskChecksRetrieved);
        console.log("riskChecksRetrieved: " + this.rrClientRiskChecks.items.length);
        //if (!this._viewModel.noClientRiskMatchesDataReFetch && selectedDealing && selectedDealing.isSelectedClient && riskChecksRetrieved) {
        //if (!this._viewModel.noClientRiskMatchesDataReFetch && selectedDealing && selectedDealing.isSelectedClient && rrClientRiskChecksItemsLength > 0) {
        if (!this._viewModel.noClientRiskMatchesDataReFetch && selectedDealing && selectedDealing.isSelectedClient) {
            const selectedRiskMatchId = this.selectedRiskMatch ? this.selectedRiskMatch.resultId : null;
            this.selectedRiskMatch = null;
            this.clientRiskMatches.setMatchesFetched(false);

            //Get RRS risk matches
            if(selectedDealing.isInRiskResults  && riskChecksRetrieved) {//When VRA client exists
                const syncId = selectedDealing.permissionReqId || (selectedDealing.iid && selectedDealing.iid[0]) || (selectedDealing.pid && selectedDealing.pid[0]) ?
                selectedDealing.permissionReqId || selectedDealing.iid[0] || selectedDealing.pid[0] : null;
                //selectedDealing.permissionReqId || selectedDealing.iid[0] || selectedDealing.vg

                if(syncId) {
                    this.clientRiskMatches.sync.syncStart({id: syncId});
                    this._getClientRiskMatchesBySelectedDealing(selectedDealing).then(res => {
                        if (this.clientRiskMatches.sync.id === syncId) {
                            const itemsToSet = this.clientRiskMatches.initialSortRiskMatches(res.filterResults.map(item => new ClientRiskMatch(item, this._selectedDealing)));
                            this.clientRiskMatches.setFiltered(null);
                            this.clientRiskMatches.setFiltered(res.filtered);
                            this.clientRiskMatches.setMatchesFetched(true);
                            this.clientRiskMatches.setItems(itemsToSet);
                            const selectedRiskMatch = this.clientRiskMatches.items.find(i => i.resultId === selectedRiskMatchId);
                            if (selectedRiskMatch) {
                                this.selectedRiskMatch = selectedRiskMatch;
                            } else if (this.clientRiskMatches.total > 0) {
                                this.selectedRiskMatch = this.clientRiskMatches.items[0];
                            }
                            this.clientRiskMatches.sync.syncEnd();
                        }
                    }).catch(e => {
                        if (this.clientRiskMatches.sync.id === syncId) {
                            //this.clientRiskMatches.setServiceErrored(true);
                            this.clientRiskMatches.sync.syncError(e);
                        }
                    })
                }
                this.clientRiskMatches.setItems([]);
                this.clientRiskMatches.setFiltered(null);
                
            } else {

                    let syncID = null;

                    if (selectedDealing.permissionReqId) {
                        syncID = selectedDealing.permissionReqId;
                    } else if (selectedDealing.iid && selectedDealing.iid[0]) {
                        syncID = selectedDealing.iid[0];
                    }

                    const randomId = (Math.random() * 10).toString();
                    const syncIdCvor = syncID ? syncID + randomId : null;
                    this.clientRiskMatches.setMatchesFetched(false);

                    if (syncIdCvor) {
                        this.clientRiskMatches.sync.syncStart({ id: syncIdCvor });
                        //Get CVOR History risk matches
                        this._getCvorHistoryClientRiskMatchesBySelectedDealing(selectedDealing).then(res => {
                            if (this.clientRiskMatches.sync.id === syncIdCvor) {
                                const cvorHistoryitems = this.clientRiskMatches.initialSortRiskMatches(res.CvorHistories[0].CvorHistory
                                    .map(item => {
                                        item.status = null;
                                        item.riskActionable = false;
                                        item.cvorMatch = true;
                                        return new ClientRiskMatch(item, this._selectedDealing)
                                    })
                                );
                                let itemsToSet = this.clientRiskMatches.items;
                                this.clientRiskMatches.setFiltered(null);
                                this.clientRiskMatches.setFiltered(res.CvorHistories[0].filtered);
                                this.clientRiskMatches.setMatchesFetched(true);
                                if (cvorHistoryitems && cvorHistoryitems.length > 0) {
                                    this.clientRiskMatches.setItems([]);
                                    this.clientRiskMatches.setItems(cvorHistoryitems);
                                }
                                else {
                                    this.clientRiskMatches.setItems([]);
                                    this.clientRiskMatches.setItems(itemsToSet);
                                }

                                const selectedRiskMatch = this.clientRiskMatches.items.find(i => i.resultId === selectedRiskMatchId);
                                if (selectedRiskMatch) {
                                    this.selectedRiskMatch = selectedRiskMatch;
                                } else if (this.clientRiskMatches.total > 0) {
                                    this.selectedRiskMatch = this.clientRiskMatches.items[0];
                                    selectedDealing.cvorMatchesRetrieved = true;
                                    selectedDealing.cvorMatches = cvorHistoryitems;
                                }
                                this.clientRiskMatches.sync.syncEnd();
                            }
                        }).catch(e => {
                            if (this.clientRiskMatches.sync.id === syncIdCvor) {
                                //this.clientRiskMatches.setServiceErrored(true);
                                this.clientRiskMatches.sync.syncError(e);
                            }
                        })
                    }
                    this.clientRiskMatches.setItems([]);
                    this.clientRiskMatches.setFiltered(null);

            }
                
            
        } else if (!selectedDealing || !selectedDealing.isInRiskResults) {
            return this.clearClientRiskMatches();
        } else {
            return;
        }
    }, {
        name: "Risk Matches Reaction", onError: (e => {
            this.dealings.sync.syncError(e);
        })
    });

    clearClientRiskMatches = () => {
        this.clientRiskMatches = new ClientRiskMatches();
        this.selectedRiskMatch = null;
        this.clientRiskMatches.setFiltered(null);
        this.clientRiskMatches.setMatchesFetched(false);
        return Promise.resolve(this.clientRiskMatches.items);
    };
    /*-------- END - Risk Matches functions---------*/

    /*-------- START - Treatment details functions-------*/
    // Getting treatment details when selected risk match changes
    private _getSelectedRiskMatchDetails = reaction(() => {
        const selectedRiskMatch = this.selectedRiskMatch;
        return selectedRiskMatch ? selectedRiskMatch.resultId : null;
    }, (resultId) => {
        this.clearTreatmentAdvices();
        // this.clearMatchEvalCaseDetails();
        this.clearTreatmentNotes();
        if (resultId && !this.selectedRiskMatch.cvorMatch) {
            return Promise.all([this._getTreatmentAdvices({resultId: resultId}),
                this._getTreatmentNotes({resultId: resultId}),
                this._getTreatmentHistory({resultId: resultId})]
            );
        }
    }, {
        name: "Treatment advices", onError: e => {
            this.dealings.sync.syncError(e);
        }
    });

    reFetchTreatmentDetails = (resultId: string) => {
        return Promise.all([this._getTreatmentNotes({resultId: resultId}),
            this._getTreatmentHistory({resultId: resultId})]);
    };
    /*-------- END - Treatment details functions-------*/
    /*------- END - Risk Matches functions--------*/
    ///*------ END - Automated data retrieval by Mobx-------*///

    /*------ START - Clear and refresh store functions ------*/
    // Clear store function
    private clearStore = () => {
        const p1 = this.clearTreatmentAdvices();
        const p2 = this.clearClientRiskMatches();
        const p3 = this.clearClientBiographics();
        const p4 = this.clearClientSummary();
        const p5 = this.clearClientApplicationDealings();
        const p6 = this.clearTreatmentNotes();
        const p7 = this.clearClientApplicationDealings();
        const p8 = this.clearCmal();

        this.dealings = new DealingsModel();
        this.clientRiskMatches = new ClientRiskMatches();
        this.clearSelectedDealing();
        this.selectedRiskMatch = null;
        return Promise.all([p1, p2, p3, p4, p5, p6, p7, p8]);
    };

    // Clear and refresh store
    refreshStore = (preSelect: ILoadPreSelectIds) => {
        return this.clearStore().then(() => {
            return this.applySearch(preSelect);
        });
    };
    /*------ END - Clear and refresh store functions ------*/

    /*------ START - Search functions ------*/
    // Simple search validation and execution
    applySearch = (preSelect?: ILoadPreSelectIds) => {
        const req = this.simpleSearchRequest.request;
        this.simpleSearchRequest.validate();

        if (this.simpleSearchRequest.isValid) {
            return this.clearStore().then(() => {


                const reqIdType = this.simpleSearchRequest.request.idType;
                const serviceReqForBio = {
                    searchId: this.simpleSearchRequest.request.clientId ? this.simpleSearchRequest.request.clientId :
                        this.simpleSearchRequest.request.referenceNumber,
                    searchIdType: this.simpleSearchRequest.request.clientId ? SystemIdTypeRefList.getSystemItemByKey("icseId").text as validIdTypeENUM:
                        SystemIdTypeRefList.getSystemItemByKey(reqIdType).text as validIdTypeENUM,

                    searchIdSource: SystemIdTypeRefList.getSystemItemByKey(reqIdType).systemName
                };
                const serviceReq = {
                    searchId: this.simpleSearchRequest.request.referenceNumber,
                    searchIdType: SystemIdTypeRefList.getSystemItemByKey(reqIdType).text as validIdTypeENUM,
                    searchIdSource: SystemIdTypeRefList.getSystemItemByKey(reqIdType).systemName
                };

                const p1 = this.getClientSummary(serviceReqForBio);
                const p3 = this.getCmal(serviceReqForBio);
                const p2 = this.getClientBiographics(serviceReqForBio);
                const p4 = this.getClientApplicationDealings(serviceReq);

                return Promise.all([p1, p2, p3, p4]).then(() => {
                    if (this.clientApplicationDealings.total > 0) {
                        if (preSelect && preSelect.applicationId) {
                            const selectedDealing = this.dealings.items.find(d => d.applicationId === preSelect.applicationId);
                            if (selectedDealing) {
                                this.selectDealing(selectedDealing);
                            }
                        }

                        let applications : IApplication[] = [];
                        applications = this.clientApplicationDealings.items.map(d => {
                            return {
                                sourceSystemId: d.applicationId,
                                sourceSystemCode: d.sourceSystem
                            }
                        });

                        if(applications && applications.length > 0) {
                            return this.getRRClientRiskChecks(applications).then(() => {
                                if (preSelect && preSelect.filterId) {
                                    const selectedRiskMatch = this.clientRiskMatches.items.find(r => r.resultId === preSelect.filterId);
                                    if (selectedRiskMatch) {
                                        this.selectedRiskMatch = selectedRiskMatch;
                                    }
                                }
                            });
                        }
                    } else {
                        return Promise.resolve();
                    }
                })
            }).then(() => {
                this.visitedItems.funcExecuteSub.next({method: searchHistoryMethodTypes.add, value: [req]});
            });
        } else {
            return Promise.reject(null);
        }
    };

    // Risk check validation and execution
    applyRiskSearch = () => {
        if (this.riskSearchRequest.request && this.riskSearchRequest.isValueSpecified) {
            return this.riskSearchRequest.submit(this.riskSearch)
        }
    };

    riskSearch = (req: IIRPRiskSearchRequest) => {
        const syncId = Math.random();
        this.riskSearchResults.sync.syncStart({id: syncId});

        IRPSearchServiceContext.value.search(req).then((res) => {
            if (this.riskSearchResults.sync.id === syncId) {
                this.riskSearchResults.clearSelectedItems();
                this.riskSearchResults.request = Object.assign({}, this.riskSearchRequest);
                this.riskSearchResults.setData(res);
                this.riskSearchResults.data.items.forEach((item: IIRPRiskSearchResultViewItem) => {
                    item.matchTriggerName = this.matchTriggersCodeSet.items.length > 0 ? this.matchTriggersCodeSet.getDescByCd(item.trigger) : ""
                });
                this.riskSearchResults.sync.syncEnd();
                this.visitedItems.funcExecuteSub.next({
                    method: searchHistoryMethodTypes.add,
                    value: [this.riskSearchRequest.request]
                });
                return res;
            }
        }).catch(e => {
            if (this.riskSearchResults.sync.id === syncId) {
                this.riskSearchResults.sync.syncError(e);
            }
        });
    };
    /*------ END - Search functions functions ------*/

    /*------ START - Navigation functions between IRP search and main screens ------*/
    // Navigating to IRP main screen
    routeToIRPApplet = (host: IAppHost, openInNewWidget?: boolean, query?: IIRPRouterUrlParams | IIRPSimpleSearchRequest) => {
        const windowFeatures = `menubar=no,location=no,resizable=yes,scrollbars=yes,status=yes,channelmode=yes`;
        if (!query) {
            if (host.path && host.path.toLowerCase().indexOf("search") === -1) {
                host.title = "Integrated Risk Portal";
                this.applySearch().then(() => {
                    host.title = `IRP - ${this.clientRiskOverview.data.fullName}`;
                });
            } else if (host.path && host.path.toLowerCase().indexOf("search") > -1) {
                query = this.simpleSearchRequest.request;
            }
        }

        return openInNewWidget
            ? window.open(AppContext.value.rootAppHost.getUrl({
                    path: "/irp",
                    query: query
                }),
                query.windowId, windowFeatures)
            : host.load({path: "/irp", query: query})
    };

    // Navigating to IRP search screen
    routeToIRPSearchApplet = (host: IAppHost) => {
        if (host.path && host.path.toLowerCase().indexOf("search") > -1) {
            return this.riskSearchRequest.submit(this.applyRiskSearch);
        } else {
            return host.load({path: "/irp/search", query: this.simpleSearchRequest});
        }
    };
    /*------ END - Navigation functions between IRP search and main screens ------*/
}

export {IRPStoreModel, IClientRiskOverview}