import {IDealing, IDealingsModel} from "../irp/model/IDealings";
import {
    IClientIds
} from "../irp/model/IRRClientRiskChecksService";
import {ITreatmentNotesServiceModel} from "../irp/model/TreatmentNotesServiceModel";
import {ISearchHistoryModel} from "../irp/model/SearchHistoryModel";
import {IIRPRiskSearchRequestModel} from "../search/model/IIRPRiskSearchRequestModel";
import {IIRPRiskSearchResultModel} from "../search/model/IRPRiskSearchResultModel";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {IIRPSimpleSearchRequestModel} from "../search/model/IIRPSimpleSearchRequestModel";
import {IListModel} from "@twii/common/lib/IListModel";
import {IUpdateTreatmentServiceParams, IUpdateTreatmentServiceRes} from "../irp/model/IUptateTreatmentService";
import {IIRPUpdateTreatmentRequestModel} from "../irp/model/IRPUpdateTreatmentRequestModel";
import {
    IGetTreatmentNotesServiceResItem,
    ITreatmentNotes
} from "../irp/model/IGetTreatmentNotesService";
import {IClientSummary} from "../irp/model/IClientSummaryService";
import {IClientBiographics} from "../irp/model/IClientBiographicsService";
import {IAddTreatmentNoteServiceParams} from "../irp/model/IAddTreatmentNoteService";
import {
    IClientRiskMatches,
    IClientRiskMatch,
} from "../irp/model/IRRClientRiskMatchesServiceResponseItem";
import {IClientRiskOverview} from "../irp/model/ClientRiskOverviewModel";
import {ITreatmentAdvices} from "../irp/model/IGetTreatmentAdvicesService";
import {IMatchEvalCaseDetails} from "../irp/model/IGetMatchEvalCaseDetailsService";
import {IUserProfile} from "@twii/ozone/lib/user/IUserProfile";
import {ICodeSet, IGetCodeSetServiceResItem} from "../irp/model/IGetCodeSetService";
import {Observable,BehaviorSubject} from "rxjs/Rx";
import {IIRPRouterUrlParams} from "../IRPRouter";
import {IKeyboardShortcutsService} from "./KeyboardShortcuts.service";

interface ILoadPreSelectIds {
    applicationId: string;
    filterId: string;
}

interface IUpdatedNotes {
    [key: string]: IListModel<IGetTreatmentNotesServiceResItem>
}

enum ValidSearchTypes {
    simpleSearch ="simpleSearch",
    riskSearch = "riskSearch"
}

interface IIRPStoreViewModel {
    rootElementSelector?: string;
    stickyClientSummary?: boolean;
    noClientRiskMatchesDataReFetch?: boolean;
    isLeftPanelOpen?: boolean;
    toggleLeftPanel?: () => void;
    selectedSearch?: ValidSearchTypes;
    setSelectedSearch?: (selectedSearch: ValidSearchTypes) => void;
    windowResizeObservable?: Observable<Event>;
    keyboardShortcutsService?: IKeyboardShortcutsService
}

interface IIRPStoreModel {

    clientRiskOverview: IClientRiskOverview;
    dealings: IDealingsModel;

    selectDealing: (dealing: IDealing) => void;
    getSelectedDealing: () => IDealing;
    clearSelectedDealing: () => void;
    updateSelectedDealing: () => void;
    clientRiskMatches: IClientRiskMatches;
    selectedRiskMatch: IClientRiskMatch;
    setViewModel: (props: IIRPStoreViewModel) => void;
    getViewModel: () => IIRPStoreViewModel;
    activateKeyboardShortcutsService: (host: IAppHost) => void;

    // Simple search
    simpleSearchRequest: IIRPSimpleSearchRequestModel;
    applySearch: (preSelect?: ILoadPreSelectIds) => Promise<[IClientSummary, IClientBiographics] | void>;
    routeToIRPApplet: (host: IAppHost, openInNewWindow?: boolean, urlParams?: IIRPRouterUrlParams) => void;
    refreshStore: (preSelectIds: ILoadPreSelectIds) => void;

    // Risk search
    riskSearchRequest: IIRPRiskSearchRequestModel;
    riskSearchResults: IIRPRiskSearchResultModel;
    applyRiskSearch: () => void;
    routeToIRPSearchApplet: (host: IAppHost) => void;

    //Treatment Notes
    treatmentNotes: ITreatmentNotes;

    //Update treatment notes
    treatmentsNotes: ITreatmentNotesServiceModel;
    saveNote: (treatmentNote: IAddTreatmentNoteServiceParams) => Promise<any>;
    updatedNotes: IUpdatedNotes;

    //Update treatment status
    updateTreatmentRequest: IIRPUpdateTreatmentRequestModel;
    updateTreatment: (request: IUpdateTreatmentServiceParams) => Promise<any>;
    updateApplicationRiskCheckClient: (clientIds: IClientIds[], applicationRiskCheck: IUpdateTreatmentServiceRes) => void;

    //Selected risk match's Treatment advices
    treatmentAdvices: ITreatmentAdvices;

    reFetchTreatmentDetails: (resultId: string) => void;

    //Selected risk match's Treatment MatchEval case details
    matchEvalCaseDetails: IMatchEvalCaseDetails;

    visitedItems: ISearchHistoryModel;
    userProfile: IUserProfile;

    //Get Dismissal reasons
    dismissalReasonsSubject: BehaviorSubject<IGetCodeSetServiceResItem[]>;
    dismissalReasons: ICodeSet;
    attachmentsCodeSet: ICodeSet;
    matchTriggersCodeSet: ICodeSet;
    threatTypesCodeSet: ICodeSet;
}

export {IIRPStoreModel, IUpdatedNotes, ILoadPreSelectIds, IIRPStoreViewModel, ValidSearchTypes}