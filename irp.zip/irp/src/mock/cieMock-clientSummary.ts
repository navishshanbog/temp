const clientSummary = [{
    "ClientSummary": {
        "identifiers": {
            "ICSEClientId": ["77930006176",
                "10000008183",
                "10000000065"],
            "TRIPSPersonId": ["0005555555",
                "0006666666"],
            "travelDocs": [],
            "nationalIds": []
        },
        "alerts": {
            "malAlertStatus": "Amber",
            "cmalId": "314235",
            "ccmdAlert": {
                "openCasesCount": 2,
                "closedCasesCount": 1
            },
            "clientOfInterestAlert": true
        },
        "statuses": {
            "currentLocation": "Offshore",
            "lawfulStatus": null,
            "currentVisas": [{
                "subClassCode": "602",
                "subClassDesc": "Transit",
                "expiryDate": "2019-11-12",
                "currentVisaStatusCode": "E"
            }],
            "lastVisa": {
                "subClassCode": "602",
                "subClassDesc": "Transit",
                "expiryDate": "2019-11-12",
                "currentVisaStatusCode": "E"
            }
        }
    }
}, {
    "ClientSummary": {
        "identifiers": {
            "ICSEClientId": ["7568585222"],
            "TRIPSPersonId": ["56858542222"],
            "travelDocs": [],
            "nationalIds": []
        },
        "alerts": {
            "malAlertStatus": "Amber",
            "cmalId": "322235",
            "ccmdAlert": {
                "openCasesCount": 1,
                "closedCasesCount": 1
            },
            "clientOfInterestAlert": true
        },
        "statuses": {
            "currentLocation": "Offshore",
            "lawfulStatus": null,
            "currentVisas": [{
                "subClassCode": "602",
                "subClassDesc": "Transit",
                "expiryDate": "2019-11-12",
                "currentVisaStatusCode": "E"
            }],
            "lastVisa": {
                "subClassCode": "602",
                "subClassDesc": "Transit",
                "expiryDate": "2017-11-12",
                "currentVisaStatusCode": "E"
            }
        }
    }
}, {
    "ClientSummary": {
        "identifiers": {
            "ICSEClientId": ["7568585333"],
            "TRIPSPersonId": ["56858542333"],
            "travelDocs": [],
            "nationalIds": []
        },
        "alerts": {
            "malAlertStatus": "Amber",
            "cmalId": "311135",
            "ccmdAlert": {
                "openCasesCount": 0,
                "closedCasesCount": 0
            },
            "clientOfInterestAlert": false
        },
        "statuses": {
            "currentLocation": "Offshore",
            "lawfulStatus": null,
            "currentVisas": [{
                "subClassCode": "602",
                "subClassDesc": "Transit",
                "expiryDate": "2019-11-12",
                "currentVisaStatusCode": "E"
            }],
            "lastVisa": {
                "subClassCode": "602",
                "subClassDesc": "Transit",
                "expiryDate": "2017-11-12",
                "currentVisaStatusCode": "S"
            }
        }
    }
}, {
    "ClientSummary": {
        "identifiers": {
            "ICSEClientId": ["779300061760",
                "100000081830",
                "100000000650"],
            "TRIPSPersonId": ["00055555550",
                "00066666660"],
            "travelDocs": [{
                "documentId": "900123456",
                "documentName": "Passport",
                "issuingCountry": "Pakistan"
            }],
            "nationalIds": []
        },
        "alerts": {
            "malAlertStatus": "Amber",
            "cmalId": "314235",
            "ccmdAlert": {
                "openCasesCount": 1,
                "closedCasesCount": 1
            },
            "clientOfInterestAlert": true
        },
        "statuses": {
            "currentLocation": "Offshore",
            "lawfulStatus": null,
            "currentVisas": [{
                "subClassCode": "988",
                "subClassDesc": "Maritime Crew (Temp)- Crew(Web)",
                "expiryDate": "2021-01-22",
                "currentVisaStatusCode": "E"
            }],
            "lastVisa": {
                "subClassCode": "771",
                "subClassDesc": "Transit",
                "expiryDate": "2018-09-17",
                "currentVisaStatusCode": "S"
            }
        }
    }
}, {
    "ClientSummary": {
        "identifiers": {
            "ICSEClientId": ["75685852220"],
            "TRIPSPersonId": ["568585422220"],
            "travelDocs": [],
            "nationalIds": []
        },
        "alerts": {
            "malAlertStatus": "Green",
            "cmalId": null,
            "ccmdAlert": {
                "openCasesCount": 0,
                "closedCasesCount": 0
            },
            "clientOfInterestAlert": false
        },
        "statuses": {
            "currentLocation": "Offshore",
            "lawfulStatus": null,
            "currentVisas": [{
                "subClassCode": "988",
                "subClassDesc": "Maritime Crew (Temp) - Partner/Dep(Web)",
                "expiryDate": "2021-04-03",
                "currentVisaStatusCode": "E"
            }],
            "lastVisa": {
                "subClassCode": null,
                "subClassDesc": null,
                "expiryDate": null,
                "currentVisaStatusCode": null
            }
        }
    }
}];

export {clientSummary}