import {
    IRPClientSummaryServiceContext,
    IRPClientBiographicsServiceContext,
    IRPClientApplicationDealingsServiceContext
} from "../service/IRPServiceContexts";
import {IClientSummaryServiceReq} from "../irp/model/IClientSummaryService";
import {IClientBiographicsServiceReq} from "../irp/model/IClientBiographicsService";
import {IClientApplicationDealingsServiceReq} from "../irp/model/IClientApplicationDealingsService";

import {cieMockClientApplicationDealings} from "./cieMock-clientApplicationDealings";
import {clientSummary} from "./cieMock-clientSummary";
import {clientBiographics} from "./cieMock-clientBiographics";
import {validIdTypeENUM} from "../shared/SystemIdTypeRefList";

class clientSummaryService {
    getClientSummaryService = (req: IClientSummaryServiceReq) => {
        let out;
        if (req.searchIdType === validIdTypeENUM.PRID) {
            let cid;
            Object.keys(cieMockClientApplicationDealings).forEach(d => {
                (cieMockClientApplicationDealings[d]).ClientApplicationDealings.forEach(dealing => {
                    if (dealing.applicationId === req.searchId) {
                        cid = dealing.clients[0].ICSEClientId[0];
                    }
                })
            });
            out = clientSummary.find(c => c.ClientSummary.identifiers.ICSEClientId.indexOf(cid) > -1);
        } else {
            out = clientSummary.find(c => c.ClientSummary.identifiers.ICSEClientId.indexOf(req.searchId) > -1);
        }
        return Promise.resolve(out)
    };
}

class clientiographicsService {
    getClientBiographics = (req: IClientBiographicsServiceReq) => {
        return Promise.resolve(clientBiographics[req.searchId]);
    }
}

class clientApplicationDealingsService {
    getClientApplicationDealings = (req: IClientApplicationDealingsServiceReq) => {
        return Promise.resolve(cieMockClientApplicationDealings[req.searchId]);
    }
}

const initiateMock = () => {
    IRPClientSummaryServiceContext.value = new clientSummaryService();
    IRPClientBiographicsServiceContext.value = new clientiographicsService();
    IRPClientApplicationDealingsServiceContext.value = new clientApplicationDealingsService();
};

export {
    cieMockClientApplicationDealings,
    initiateMock
}
