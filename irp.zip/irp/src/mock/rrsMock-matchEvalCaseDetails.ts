const matchEvalCaseDetails = {
    "case": {                                         // optional, null if case is not created
        "caseId": "IAirCR51742-1",                     // mandatory
        "createdTs": "2018-08-09T03:32:22.467+0000",   // mandatory, ISO-8601 format
        "userId": "xaqkvd",                            // optional
        "userName": "John SMith",                      // optional
        "allocatedTs": "2018-08-09T03:32:22.467+0000", // optional, ISO-8601 format
        "dueDate": "2018-08-11T03:32:22.467+0000",     // mandatory, ISO-8601 format
        "status": "ALLOCATED",                         // mandatory, CREATED/ALLOCATED/CLOSED
        "updatedTs": "2018-08-09T03:32:22.468+0000",   // optional, ISO-8601 format
    }
};

export {matchEvalCaseDetails}