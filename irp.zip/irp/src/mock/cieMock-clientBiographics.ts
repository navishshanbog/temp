const clientBiographics = {
    "77930006176": {
        ClientBiographics: {
            "firstName": "Senthil",
            "lastName": "Khan",
            "fullName": "Khan, Senthil",
            "dateOfBirth": "1978-02-12",
            "gender": "Male",
            "countryOfBirth": "Pakistan",
            "countryOfResidences": ["Pakistan",
                "Australia"],
            "citizenships": ["Pakistan",
                "Australia"]
        }
    },
    "7568585222": {
        ClientBiographics: {
            "firstName": "Rahani",
            "lastName": "Khan",
            "fullName": "Khan, Rahani",
            "dateOfBirth": "1980-04-12",
            "gender": "Female",
            "countryOfBirth": "Pakistan",
            "countryOfResidences": ["Pakistan",
                "Australia"],
            "citizenships": ["Pakistan",
                "Australia"]
        }
    },
    "7568585333": {
        ClientBiographics: {
            "firstName": "Geetha",
            "lastName": "Khan",
            "fullName": "Khan, Geetha",
            "dateOfBirth": "2010-06-22",
            "gender": "Female",
            "countryOfBirth": "Pakistan",
            "countryOfResidences": ["Pakistan",
                "Australia"],
            "citizenships": ["Pakistan",
                "Australia"]
        }
    },
    "779300061760": {
        ClientBiographics: {
            "firstName": "Muhammad",
            "lastName": "Khan",
            "fullName": "Khan, Muhammad",
            "dateOfBirth": "1978-02-12",
            "gender": "Male",
            "countryOfBirth": "Pakistan",
            "countryOfResidences": ["Pakistan",
                "Australia"],
            "citizenships": ["Pakistan",
                "Australia"]
        }
    },
    "75685852220": {
        ClientBiographics: {
            "firstName": "Inaya",
            "lastName": "Khan",
            "fullName": "Khan, Inaya",
            "dateOfBirth": "1980-04-12",
            "gender": "Female",
            "countryOfBirth": "Pakistan",
            "countryOfResidences": ["Pakistan",
                "Australia"],
            "citizenships": ["Pakistan",
                "Australia"]
        }
    }
};

export {clientBiographics}