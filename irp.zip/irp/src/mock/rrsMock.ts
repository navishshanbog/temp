import {IRRClientRiskChecksServiceRequest,
    ValidRRIdTypes
} from "../irp/model/IRRClientRiskChecksService";
import {ValidRiskMatchAssessmentOutcome, ValidRiskMatchStatus} from "../shared/RiskMatchValidValues";
import {IUpdateTreatmentServiceParams} from "../irp/model/IUptateTreatmentService";
import {
    GetMatchEvalCaseDetailsServiceContext,
    GetTreatmentAdvicesServiceContext,
    RRClientApplicationOverviewServiceContext,
    RRClientRiskMatchesServiceContext,
    UpdateTreatmentServiceContext
} from "../service/IRPServiceContexts";

import {rrsMockApplicationSearch} from "./rrsMock-applicationSearch";
import {IGetTreatmentAdvicesServiceReq} from "../irp/model/IGetTreatmentAdvicesService";
import {IGetMatchEvalCaseDetailsServiceReq} from "../irp/model/IGetMatchEvalCaseDetailsService";
import {updateTreatmentRes} from "./rrsMock-updateTreatments";
import {treatmentAdvices} from "./rrsMock-treatmentAdvices";
import {matchEvalCaseDetails} from "./rrsMock-matchEvalCaseDetails";
import {rrsMock} from "./rrsMock-rrsMock";
import {IRRClientRiskMatchesServiceRequest} from "../irp/model/IRRClientRiskMatchesService";

const applicationSearchRes = rrsMockApplicationSearch.applications;

class UpdateTreatmentMockService {
    updateTreatment = (req: IUpdateTreatmentServiceParams) => {
        const riskMatch = rrsMock.find(r => r.resultId === req.resultId);
        switch (req.status) {
            case ValidRiskMatchStatus.RISK_ASSESSMENT_UNTREATED:
            case ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS:
                if (riskMatch.riskAssessmentOutcome === ValidRiskMatchAssessmentOutcome.CONFIRMED) updateTreatmentRes.client.confirmedResultCount -= 1;
                if (riskMatch.riskAssessmentOutcome === ValidRiskMatchAssessmentOutcome.DISMISSED) updateTreatmentRes.client.dismissedResultCount -= 1;
                updateTreatmentRes.client.untreatedResultCount += 1;
                riskMatch.riskAssessmentOutcome = null;
                riskMatch.status = req.status;
                riskMatch.dismissalReasonCode = null;
                break;
            case ValidRiskMatchStatus.COMPLETED:
                if (req.outcome === ValidRiskMatchAssessmentOutcome.DISMISSED) {
                    updateTreatmentRes.client.dismissedResultCount += 1;
                    if (riskMatch.riskAssessmentOutcome === ValidRiskMatchAssessmentOutcome.CONFIRMED) updateTreatmentRes.client.confirmedResultCount -= 1;
                    if (riskMatch.riskAssessmentOutcome === ValidRiskMatchAssessmentOutcome.DISMISSED) updateTreatmentRes.client.dismissedResultCount -= 1;
                    riskMatch.riskAssessmentOutcome = ValidRiskMatchAssessmentOutcome.DISMISSED;
                    riskMatch.status = ValidRiskMatchStatus.COMPLETED;
                    riskMatch.dismissalReasonCode = req.dismissalReasonCode;
                    break;
                } else if (req.outcome === ValidRiskMatchAssessmentOutcome.CONFIRMED) {
                    if (riskMatch.status === ValidRiskMatchStatus.RISK_ASSESSMENT_UNTREATED || ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS) updateTreatmentRes.client.untreatedResultCount -= 1;
                    if (riskMatch.riskAssessmentOutcome === ValidRiskMatchAssessmentOutcome.DISMISSED) updateTreatmentRes.client.dismissedResultCount -= 1;
                    updateTreatmentRes.client.confirmedResultCount += 1;
                    riskMatch.riskAssessmentOutcome = ValidRiskMatchAssessmentOutcome.CONFIRMED;
                    riskMatch.status = ValidRiskMatchStatus.COMPLETED;
                    riskMatch.dismissalReasonCode = null;
                    break;
                }
        }
        return Promise.resolve(updateTreatmentRes)
    }
}

class RRClientRiskMatchesMockService {
    getRRClientRiskMatches = (req: IRRClientRiskMatchesServiceRequest) => {
        const temp = [].concat(...applicationSearchRes.map(rc => rc.clients.filter(c => {
            return c.identifiers.findIndex(i => i.value === req.identifier.value) > -1;
        })));
        const out = temp.length > 0 ? rrsMock : [];
        return Promise.resolve(out);
    }
}

class RRClientApplicationOverviewMockService {
    getRRClientRiskChecks = (req: IRRClientRiskChecksServiceRequest) => Promise.resolve(applicationSearchRes);
}

class GetTreatmentAdvicesMockService {
    getTreatmentAdvices = (req: IGetTreatmentAdvicesServiceReq) => Promise.resolve(treatmentAdvices.treatmentAdvices);
}

class GetMatchEvalCaseDetailsMockService {
    getMatchEvalCaseDetails = (req: IGetMatchEvalCaseDetailsServiceReq) => Promise.resolve(matchEvalCaseDetails.case);
}

const initiateMock = () => {
    UpdateTreatmentServiceContext.value = new UpdateTreatmentMockService();
    //RRClientApplicationOverviewServiceContext.value = new RRClientApplicationOverviewMockService();
    //RRClientRiskMatchesServiceContext.value = new RRClientRiskMatchesMockService();
    GetTreatmentAdvicesServiceContext.value = new GetTreatmentAdvicesMockService();
    GetMatchEvalCaseDetailsServiceContext.value = new GetMatchEvalCaseDetailsMockService();
};

export {
    UpdateTreatmentMockService,
    RRClientRiskMatchesMockService,
    RRClientApplicationOverviewMockService,
    initiateMock
}
