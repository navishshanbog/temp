import {ValidRRIdTypes} from "../irp/model/IRRClientRiskChecksService";
import {ValidRiskMatchStatus} from "../shared/RiskMatchValidValues";

const updateTreatmentRes = {
    "status": ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS,              // mandatory, RISK_ASSESSMENT_UNTREATED/RISK_ASSESSMENT_IN_PROGRESS/COMPLETED
    "outcome": null,                                    // CONFIRMED/DISMISSED. Mandatory when status is COMPLETED, must be null otherwise
    "riskRating": "HIGH",                               // mandatory, HIGH/LOW/NO_RATING
    "application": {                                    // mandatory
        "sourceSystemId": "546546456456",               // mandatory
        "sourceSystemCode": "ICSE",                     // mandatory
        "riskRating": "HIGH",                           // optional, HIGH/LOW/NO_RATING
        "riskCheckStatus": "IN_RISK_ASSESSMENT",        // optional, CHECKING/UNDER_THREAT_EVAL/IN_RISK_ASSESSMENT/COMPLETED
        "updatedTs": "2018-08-13T10:03:40.022+0000",    // mandatory, ISO-8601 format
    },
    "client": {                                         // mandatory
        "identifiers": [{                               // mandatory, not empty
            "type": ValidRRIdTypes.CLIENT_ROLE_ID,                    // mandatory, CLIENT_ROLE_ID/VISA_GRANT_NUMBER
            "value": "43826843754543251"                 // mandatory
        }, {
            "type": ValidRRIdTypes.VISA_GRANT_NUMBER,
            "value": "68568753847581"
        }],
        "riskRating": "HIGH",                           // mandatory, HIGH/LOW/NO_RATING
        "riskCheckStatus": "IN_RISK_ASSESSMENT",        // mandatory, UNDER_THREAT_EVAL/IN_RISK_ASSESSMENT/COMPLETED
        "lastRiskCheckTs": "2018-07-26T14:42:24.660+0000", // mandatory, ISO-8601 format
        "updatedTs": "2018-08-13T10:03:40.007+0000",    // mandatory, ISO-8601 format
        "untreatedResultCount": 0,                      // mandatory
        "dismissedResultCount": 0,                      // mandatory
        "confirmedResultCount": 1                       // mandatory
    }
};

export {updateTreatmentRes}