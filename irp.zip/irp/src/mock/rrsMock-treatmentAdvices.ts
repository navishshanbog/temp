const treatmentAdvices = {
    "treatmentAdvices": [
        {
            "treatmentId": "34649",                         // optional
            "treatmentVersion": "1.0",                      // optional
            "adviceType": "FILTER_ENGINE",                  // mandatory, FILTER_ENGINE/MATCH_EVAL_ADDL
            "adviceText": "Assess client intentions to..",  // mandatory
            "createdTs": "2018-08-24T06:17:42.479Z"         // mandatory, ISO-8601 format
        }
    ]
};

export {treatmentAdvices}