const cieMockClientApplicationDealings = {
        "77930006176": {
            "ClientApplicationDealings": [{
                "applicationId": "1111111111",
                "sourceSystem": "ICSE",
                "applicationType": {
                    "subClassCode": "988",
                    "subClassDesc": "Temporary - Maritime Crew Visa-Crew(Web)"
                },
                "milestone": {
                    "milestone": "Commenced",
                    "milestoneDate": "2018-05-18"
                },
                "clients": [{
                    "ICSEClientId": ["77930006176",
                        "10000008183",
                        "10000000065"],
                    "TRIPSPersonId": ["0005555555",
                        "0006666666"],
                    "lastName": "KHAN",
                    "firstName": "SENTHIL",
                    "fullName": "KHAN,SENTHIL",
                    "VRAClientRole": "Primary Visa Applicant",
                    "visaGrantNumber": "bf965d9e-35c2-4846-8336-0b15294b9f88",
                    "currentVisaStatusCode": null,
                    "finalisedFlag": "N",
                    "prmsnRqstClientId": "c65a916c-9b7f-4df9-a05f-ccac16d7d29b",
                    "TRIPSApplnId": null
                }, {
                    "ICSEClientId": ["723657826578"],
                    "TRIPSPersonId": ["634845374"],
                    "lastName": "KHAN",
                    "firstName": "SENTHIL",
                    "fullName": "KHAN,SENTHIL",
                    "VRAClientRole": "Primary Visa Applicant",
                    "visaGrantNumber": null,
                    "currentVisaStatusCode": null,
                    "finalisedFlag": "N",
                    "prmsnRqstClientId": "966662991101",
                    "TRIPSApplnId": null
                }, {
                    "ICSEClientId": ["098934758934"],
                    "TRIPSPersonId": [],
                    "lastName": "KHAN",
                    "firstName": "SENTHIL",
                    "fullName": "KHAN,SENTHIL",
                    "VRAClientRole": "Primary Visa Applicant",
                    "visaGrantNumber": null,
                    "currentVisaStatusCode": null,
                    "finalisedFlag": "N",
                    "prmsnRqstClientId": "966662991102",
                    "TRIPSApplnId": null
                }]
            },
                {
                    "applicationId": "2222222222",
                    "sourceSystem": "ICSE",
                    "applicationType": {
                        "subClassCode": "417",
                        "subClassDesc": "Working Holiday (Temporary)"
                    },
                    "milestone": {
                        "milestone": "Commenced",
                        "milestoneDate": "2018-08-29"
                    },
                    "clients": [{
                        "ICSEClientId": ["77930006176",
                            "10000000065",
                            "10000008183"],
                        "TRIPSPersonId": ["0006666666",
                            "0005555555"],
                        "lastName": "KHAN",
                        "firstName": "SENTHIL",
                        "fullName": "KHAN,SENTHIL",
                        "VRAClientRole": "Primary Visa Applicant",
                        "visaGrantNumber": null,
                        "currentVisaStatusCode": null,
                        "finalisedFlag": "N",
                        "prmsnRqstClientId": "22576105831",
                        "TRIPSApplnId": null
                    },
                        {
                            "ICSEClientId": ["7568585222"],
                            "TRIPSPersonId": ["56858542222"],
                            "lastName": "KHAN",
                            "firstName": "RAHANI",
                            "fullName": "KHAN, RAHANI",
                            "VRAClientRole": "Secondary Visa Applicant",
                            "visaGrantNumber": null,
                            "currentVisaStatusCode": null,
                            "finalisedFlag": "N",
                            "prmsnRqstClientId": "684087740250",
                            "TRIPSApplnId": null
                        },
                        {
                            "ICSEClientId": ["7568585333"],
                            "TRIPSPersonId": ["56858542333"],
                            "lastName": "KHAN",
                            "firstName": "GEETHA",
                            "fullName": "KHAN, GEETHA",
                            "VRAClientRole": "Secondary Visa Applicant",
                            "visaGrantNumber": null,
                            "currentVisaStatusCode": null,
                            "finalisedFlag": "N",
                            "prmsnRqstClientId": "762018119591",
                            "TRIPSApplnId": null
                        }],
                },
                {
                    "applicationId": "3333333333",
                    "sourceSystem": "ICSE",
                    "applicationType": {
                        "subClassCode": "417",
                        "subClassDesc": "Working Holiday (Temporary)"
                    },
                    "milestone": {
                        "milestone": "Granted",
                        "milestoneDate": "2008-08-29"
                    },
                    "clients": [{
                        "ICSEClientId": ["77930006176",
                            "10000000065",
                            "10000008183"],
                        "TRIPSPersonId": ["0006666666",
                            "0005555555"],
                        "lastName": "KHAN",
                        "firstName": "SENTHIL",
                        "fullName": "KHAN,SENTHIL",
                        "VRAClientRole": "Primary Visa holder",
                        "visaGrantNumber": "329504123777",
                        "currentVisaStatusCode": "S",
                        "finalisedFlag": "Y",
                        "prmsnRqstClientId": null,
                        "TRIPSApplnId": "CO9582069764244  "
                    }]
                },
                {
                    "applicationId": "4444444444",
                    "sourceSystem": "ICSE",
                    "applicationType": {
                        "subClassCode": "417",
                        "subClassDesc": "Working Holiday (Temporary)"
                    },
                    "milestone": {
                        "milestone": "Granted",
                        "milestoneDate": "2008-08-29"
                    },
                    "clients": [{
                        "ICSEClientId": ["77930006176",
                            "10000000065",
                            "10000008183"],
                        "TRIPSPersonId": ["0006666666",
                            "0005555555"],
                        "lastName": "KHAN",
                        "firstName": "SENTHIL",
                        "fullName": "KHAN,SENTHIL",
                        "VRAClientRole": "Primary Visa holder",
                        "visaGrantNumber": "329504123568",
                        "currentVisaStatusCode": "S",
                        "finalisedFlag": "Y",
                        "prmsnRqstClientId": "22576105555",
                        "TRIPSApplnId": "CO9582069766566  "
                    }]
                },
                {
                    "applicationId": "555555555",
                    "sourceSystem": "ICSE",
                    "applicationType": {
                        "subClassCode": "417",
                        "subClassDesc": "Working Holiday (Temporary)"
                    },
                    "milestone": {
                        "milestone": "Granted",
                        "milestoneDate": "2008-08-29"
                    },
                    "clients": [{
                        "ICSEClientId": ["77930006176",
                            "10000000065",
                            "10000008183"],
                        "TRIPSPersonId": ["0006666666",
                            "0005555555"],
                        "lastName": "KHAN",
                        "firstName": "SENTHIL",
                        "fullName": "KHAN,SENTHIL",
                        "VRAClientRole": "Primary Visa holder",
                        "visaGrantNumber": "555555555",
                        "currentVisaStatusCode": "S",
                        "finalisedFlag": "Y",
                        "prmsnRqstClientId": "555555555",
                        "TRIPSApplnId": "555555555  "
                    }]
                },
                // {
                //     "applicationId": "123456789",
                //     "sourceSystem": "ICSE",
                //     "applicationType": {
                //         "subClassCode": "417",
                //         "subClassDesc": "Working Holiday (Temporary)"
                //     },
                //     "milestone": {
                //         "milestone": "Granted",
                //         "milestoneDate": "2008-08-29"
                //     },
                //     "clients": [{
                //         "ICSEClientId": ["77930006176",
                //             "10000000065",
                //             "10000008183"],
                //         "TRIPSPersonId": ["0006666666",
                //             "0005555555"],
                //         "lastName": "KHAN",
                //         "firstName": "SENTHIL",
                //         "fullName": "KHAN,SENTHIL",
                //         "VRAClientRole": "Primary Visa holder",
                //         "visaGrantNumber": "329504123568",
                //         "currentVisaStatusCode": "S",
                //         "finalisedFlag": "Y",
                //         "prmsnRqstClientId": "123456789",
                //         "TRIPSApplnId": "123456789"
                //     }]
                // }
            ]
        }
        ,
        "7568585222":
            {
                "ClientApplicationDealings":
                    [{
                        "applicationId": "2222222222",
                        "sourceSystem": "ICSE",
                        "applicationType": {
                            "subClassCode": "417",
                            "subClassDesc": "Working Holiday (Temporary)"
                        },
                        "milestone": {
                            "milestone": "Commenced",
                            "milestoneDate": "2018-08-29"
                        },
                        "clients": [{
                            "ICSEClientId": ["77930006176",
                                "10000000065",
                                "10000008183"],
                            "TRIPSPersonId": ["0006666666",
                                "0005555555"],
                            "lastName": "KHAN",
                            "firstName": "SENTHIL",
                            "fullName": "KHAN,SENTHIL",
                            "VRAClientRole": "Primary Visa Applicant",
                            "visaGrantNumber": null,
                            "currentVisaStatusCode": null,
                            "finalisedFlag": "N",
                            "prmsnRqstClientId": "22576105831",
                            "TRIPSApplnId": null
                        },
                            {
                                "ICSEClientId": ["7568585222"],
                                "TRIPSPersonId": ["56858542222"],
                                "lastName": "KHAN",
                                "firstName": "RAHANI",
                                "fullName": "KHAN, RAHANI",
                                "VRAClientRole": "Secondary Visa Applicant",
                                "visaGrantNumber": null,
                                "currentVisaStatusCode": null,
                                "finalisedFlag": "N",
                                "prmsnRqstClientId": "684087740250",
                                "TRIPSApplnId": null
                            },
                            {
                                "ICSEClientId": ["7568585333"],
                                "TRIPSPersonId": ["56858542333"],
                                "lastName": "KHAN",
                                "firstName": "GEETHA",
                                "fullName": "KHAN, GEETHA",
                                "VRAClientRole": "Secondary Visa Applicant",
                                "visaGrantNumber": null,
                                "currentVisaStatusCode": null,
                                "finalisedFlag": "N",
                                "prmsnRqstClientId": "762018119591",
                                "TRIPSApplnId": null
                            }]
                    }]
            }
        ,
        "7568585333":
            {
                "ClientApplicationDealings":
                    [{
                        "applicationId": "2222222222",
                        "sourceSystem": "ICSE",
                        "applicationType": {
                            "subClassCode": "417",
                            "subClassDesc": "Working Holiday (Temporary)"
                        },
                        "milestone": {
                            "milestone": "Commenced",
                            "milestoneDate": "2018-08-29"
                        },
                        "clients": [{
                            "ICSEClientId": ["77930006176",
                                "10000000065",
                                "10000008183"],
                            "TRIPSPersonId": ["0006666666",
                                "0005555555"],
                            "lastName": "KHAN",
                            "firstName": "SENTHIL",
                            "fullName": "KHAN,SENTHIL",
                            "VRAClientRole": "Primary Visa Applicant",
                            "visaGrantNumber": null,
                            "currentVisaStatusCode": null,
                            "finalisedFlag": "N",
                            "prmsnRqstClientId": "22576105831",
                            "TRIPSApplnId": null
                        },
                            {
                                "ICSEClientId": ["7568585222"],
                                "TRIPSPersonId": ["56858542222"],
                                "lastName": "KHAN",
                                "firstName": "RAHANI",
                                "fullName": "KHAN, RAHANI",
                                "VRAClientRole": "Secondary Visa Applicant",
                                "visaGrantNumber": null,
                                "currentVisaStatusCode": null,
                                "finalisedFlag": "N",
                                "prmsnRqstClientId": "684087740250",
                                "TRIPSApplnId": null
                            },
                            {
                                "ICSEClientId": ["7568585333"],
                                "TRIPSPersonId": ["56858542333"],
                                "lastName": "KHAN",
                                "firstName": "GEETHA",
                                "fullName": "KHAN, GEETHA",
                                "VRAClientRole": "Secondary Visa Applicant",
                                "visaGrantNumber": null,
                                "currentVisaStatusCode": null,
                                "finalisedFlag": "N",
                                "prmsnRqstClientId": "762018119591",
                                "TRIPSApplnId": null
                            }]
                    }]
            }
        ,
        "779300061760":
            {
                "ClientApplicationDealings":
                    [{
                        "applicationId": "1111111111",
                        "sourceSystem": "ICSE",
                        "applicationType": {
                            "subClassCode": "988",
                            "subClassDesc": "Maritime Crew (Temp)- Crew(Web)"
                        },
                        "milestone": {
                            "milestone": "Granted",
                            "milestoneDate": "2017-06-19"
                        },
                        "clients": [{
                            "ICSEClientId": ["779300061760",
                                "100000081830",
                                "100000000650"],
                            "TRIPSPersonId": ["00055555550",
                                "00066666660"],
                            "lastName": "KHAN",
                            "firstName": "MUHAMMAD",
                            "fullName": "KHAN,MUHAMMAD",
                            "VRAClientRole": "Primary Visa Holder",
                            "visaGrantNumber": "1159521352392",
                            "currentVisaStatusCode": "S",
                            "finalisedFlag": "Y",
                            "prmsnRqstClientId": "966662991100",
                            "TRIPSApplnId": "1119521352392"
                        }]
                    },
                        {
                            "applicationId": "2222222222",
                            "sourceSystem": "ICSE",
                            "applicationType": {
                                "subClassCode": "988",
                                "subClassDesc": "Maritime Crew (Temp) - Partner/Dep(Web)"
                            },
                            "milestone": {
                                "milestone": "Commenced",
                                "milestoneDate": "2018-03-27"
                            },
                            "clients": [{
                                "ICSEClientId": ["779300061760",
                                    "100000000650",
                                    "100000081830"],
                                "TRIPSPersonId": ["00066666660",
                                    "00055555550"],
                                "lastName": "KHAN",
                                "firstName": "MUHAMMAD",
                                "fullName": "KHAN,MUHAMMAD",
                                "VRAClientRole": "Assoc Visaed Principal Applicant",
                                "visaGrantNumber": null,
                                "currentVisaStatusCode": null,
                                "finalisedFlag": "N",
                                "prmsnRqstClientId": "22576105831",
                                "TRIPSApplnId": null
                            },
                                {
                                    "ICSEClientId": ["7568585222"],
                                    "TRIPSPersonId": ["56858542222"],
                                    "lastName": "KHAN",
                                    "firstName": "INAYA",
                                    "fullName": "KHAN, INAYA",
                                    "VRAClientRole": "Primary Visa Holder",
                                    "visaGrantNumber": "2259521352392",
                                    "currentVisaStatusCode": "E",
                                    "finalisedFlag": "Y",
                                    "prmsnRqstClientId": "684087740250",
                                    "TRIPSApplnId": "2229521352392"
                                }],

                        },
                        {
                            "applicationId": "3333333333",
                            "sourceSystem": "ICSE",
                            "applicationType": {
                                "subClassCode": "771",
                                "subClassDesc": "Transit (Temp) (Ship's Crew)"
                            },
                            "milestone": {
                                "milestone": "Granted",
                                "milestoneDate": "2018-08-17"
                            },
                            "clients": [{
                                "ICSEClientId": ["779300061760",
                                    "100000000650",
                                    "100000081830"],
                                "TRIPSPersonId": ["00066666660",
                                    "00055555550"],
                                "lastName": "KHAN",
                                "firstName": "MUHAMMAD",
                                "fullName": "KHAN,MUHAMMAD",
                                "VRAClientRole": "Primary Visa holder",
                                "visaGrantNumber": "3295041237776",
                                "currentVisaStatusCode": "S",
                                "finalisedFlag": "Y",
                                "prmsnRqstClientId": "9666629911001",
                                "TRIPSApplnId": "CO9582069764244  "
                            }]
                        },
                        {
                            "applicationId": "4444444444",
                            "sourceSystem": "ICSE",
                            "applicationType": {
                                "subClassCode": "866",
                                "subClassDesc": "Permanent Protection (XA 866)"
                            },
                            "milestone": {
                                "milestone": "Commenced",
                                "milestoneDate": "2018-09-20"
                            },
                            "clients": [{
                                "ICSEClientId": ["779300061760",
                                    "100000000650",
                                    "100000081830"],
                                "TRIPSPersonId": ["00066666660",
                                    "00055555550"],
                                "lastName": "KHAN",
                                "firstName": "MUHAMMAD",
                                "fullName": "KHAN,MUHAMMAD",
                                "VRAClientRole": "Primary Visa Applicant",
                                "visaGrantNumber": null,
                                "currentVisaStatusCode": null,
                                "finalisedFlag": "N",
                                "prmsnRqstClientId": "22576105555",
                                "TRIPSApplnId": null
                            }]
                        }]
            }
        ,
        "75685852220":
            {
                "ClientApplicationDealings":
                    [{
                        "applicationId": "2222222222",
                        "sourceSystem": "ICSE",
                        "applicationType": {
                            "subClassCode": "988",
                            "subClassDesc": "Maritime Crew (Temp) - Partner/Dep(Web)"
                        },
                        "milestone": {
                            "milestone": "Granted",
                            "milestoneDate": "2018-04-03"
                        },
                        "clients": [{
                            "ICSEClientId": ["779300061760",
                                "100000000650",
                                "100000081830"],
                            "TRIPSPersonId": ["00066666660",
                                "00055555550"],
                            "lastName": "KHAN",
                            "firstName": "MUHAMMAD",
                            "fullName": "KHAN,MUHAMMAD",
                            "VRAClientRole": "Assoc Visaed Principal Applicant",
                            "visaGrantNumber": null,
                            "currentVisaStatusCode": null,
                            "finalisedFlag": "N",
                            "prmsnRqstClientId": "22576105831",
                            "TRIPSApplnId": null
                        },
                            {
                                "ICSEClientId": ["75685852220"],
                                "TRIPSPersonId": ["568585422220"],
                                "lastName": "KHAN",
                                "firstName": "INAYA",
                                "fullName": "KHAN, INAYA",
                                "VRAClientRole": "Primary Visa Holder",
                                "visaGrantNumber": "2259521352392",
                                "currentVisaStatusCode": "E",
                                "finalisedFlag": "Y",
                                "prmsnRqstClientId": "684087740250",
                                "TRIPSApplnId": "2229521352392"
                            }]
                    }]
            }
    }
;

export {cieMockClientApplicationDealings};