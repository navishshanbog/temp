const rrsMockApplicationSearch = {
    "applications": [{
        "sourceSystemId": "915502743",
        "sourceSystemCode": "ICSE",
        "riskRating": "No Rating",
        "riskCheckStatus": "Completed",
        "updatedTs": "2018-10-06T00:06:42.916Z",
        "version": 4,
        "clients": [{
            "identifiers": [{
                "type": "CLIENT_ROLE_ID",
                "value": "935503406"
            },
                {
                    "type": "VISA_GRANT_NUMBER",
                    "value": "0069553529618"
                }],
            "riskRating": "High",
            "riskCheckStatus": "In Risk Assessment",
            "lastRiskCheckTs": "2018-10-06T00:12:51.930Z",
            "updatedTs": "2018-10-22T05:47:45.210Z",
            "incompleteResultCount": 1,
            "untreatedResultCount": 1,
            "dismissedResultCount": 0,
            "confirmedResultCount": 0,
            "version": 12
        }]
    },
        {
            "sourceSystemId": "925502619",
            "sourceSystemCode": "ICSE",
            "riskRating": "No Rating",
            "riskCheckStatus": "Completed",
            "updatedTs": "2018-10-06T00:27:21.427Z",
            "version": 5,
            "clients": [{
                "identifiers": [{
                    "type": "CLIENT_ROLE_ID",
                    "value": "975503309"
                }],
                "riskRating": "No Rating",
                "riskCheckStatus": "Completed",
                "lastRiskCheckTs": "2018-10-06T00:15:59.120Z",
                "updatedTs": "2018-10-06T00:27:21.422Z",
                "incompleteResultCount": 0,
                "untreatedResultCount": 0,
                "dismissedResultCount": 1,
                "confirmedResultCount": 0,
                "version": 5
            }]
        },
        {
            "sourceSystemId": "970502703",
            "sourceSystemCode": "ICSE",
            "riskRating": "No Rating",
            "riskCheckStatus": "Completed",
            "updatedTs": "2018-10-10T04:53:44.012Z",
            "version": 3,
            "clients": [{
                "identifiers": [{
                    "type": "CLIENT_ROLE_ID",
                    "value": "1180503396"
                }],
                "riskRating": "No Rating",
                "riskCheckStatus": "Completed",
                "lastRiskCheckTs": "2018-10-10T04:47:16.320Z",
                "updatedTs": "2018-10-10T04:53:44.004Z",
                "incompleteResultCount": 0,
                "untreatedResultCount": 0,
                "dismissedResultCount": 1,
                "confirmedResultCount": 0,
                "version": 3
            }]
        }]
    //     }][
    //     {
    //         "sourceSystemId": "0ec29fd0-7b46-425c-8d70-43d156a24d8b",
    //         "sourceSystemCode": "ICSE",
    //         "riskRating": "HIGH",
    //         "riskCheckStatus": "COMPLETED",
    //         "updatedTs": "2018-08-24T01:29:23.598Z",
    //         "clients": [
    //             {
    //                 "identifiers": [
    //                     {
    //                         "type": "CLIENT_ROLE_ID",
    //                         "value": "c65a916c-9b7f-4df9-a05f-ccac16d7d29b"
    //                     },
    //                     {
    //                         "type": "VISA_GRANT_NUMBER",
    //                         "value": "bf965d9e-35c2-4846-8336-0b15294b9f88"
    //                     }
    //                 ],
    //                 "riskRating": "HIGH",
    //                 "riskCheckStatus": "IN_RISK_ASSESSMENT",
    //                 "lastRiskCheckTs": "2018-08-24T01:29:23.365Z",
    //                 "updatedTs": "2018-08-24T01:29:23.604Z",
    //                 "untreatedResultCount": 1,
    //                 "dismissedResultCount": 0,
    //                 "confirmedResultCount": 1
    //             }
    //         ]
    //     },
    //     {
    //         "sourceSystemId": "ed6adeba-bbed-4b2a-a2bf-a3e2012d80a8",
    //         "sourceSystemCode": "ICSE",
    //         "riskRating": "NO_RATING",
    //         "riskCheckStatus": "COMPLETED",
    //         "updatedTs": "2018-08-24T01:29:20.499Z",
    //         "clients": [
    //             {
    //                 "identifiers": [
    //                     {
    //                         "type": "CLIENT_ROLE_ID",
    //                         "value": "2854462d-32b3-45a5-ae67-cf1b83badc0f"
    //                     }
    //                 ],
    //                 "riskRating": "NO_RATING",
    //                 "riskCheckStatus": "COMPLETED",
    //                 "lastRiskCheckTs": "2018-08-24T01:29:18.313Z",
    //                 "updatedTs": "2018-08-24T01:29:20.300Z",
    //                 "untreatedResultCount": 0,
    //                 "dismissedResultCount": 1,
    //                 "confirmedResultCount": 0
    //             }
    //         ]
    //     },
    //     {
    //         "sourceSystemId": "7ced04fa-9b0e-4b79-b49a-7f3ddc130e0a",
    //         "sourceSystemCode": "ICSE",
    //         "riskRating": null,
    //         "riskCheckStatus": null,
    //         "updatedTs": "2018-08-24T01:29:22.659Z",
    //         "clients": [
    //             {
    //                 "identifiers": [
    //                     {
    //                         "type": "CLIENT_ROLE_ID",
    //                         "value": "e52459a8-5e53-4732-959b-7bf29c1d1422"
    //                     }
    //                 ],
    //                 "riskRating": "HIGH",
    //                 "riskCheckStatus": "UNDER_THREAT_EVAL",
    //                 "lastRiskCheckTs": "2018-08-24T01:29:22.553Z",
    //                 "updatedTs": "2018-08-24T01:29:22.747Z",
    //                 "untreatedResultCount": 0,
    //                 "dismissedResultCount": 0,
    //                 "confirmedResultCount": 0
    //             }
    //         ]
    //     },
    //     {
    //         "sourceSystemId": "4605cd97-6a3b-4263-b560-d0f395ee0f01",
    //         "sourceSystemCode": "ICSE",
    //         "riskRating": "HIGH",
    //         "riskCheckStatus": "UNDER_THREAT_EVAL",
    //         "updatedTs": "2018-08-24T01:29:21.777Z",
    //         "clients": [
    //             {
    //                 "identifiers": [
    //                     {
    //                         "type": "CLIENT_ROLE_ID",
    //                         "value": "0a31a616-ef59-4936-bbf9-84cd0b164ed6"
    //                     }
    //                 ],
    //                 "riskRating": "HIGH",
    //                 "riskCheckStatus": "UNDER_THREAT_EVAL",
    //                 "lastRiskCheckTs": "2018-08-24T01:29:21.782Z",
    //                 "updatedTs": "2018-08-24T01:29:22.046Z",
    //                 "untreatedResultCount": 5,
    //                 "dismissedResultCount": 0,
    //                 "confirmedResultCount": 0
    //             },
    //             {
    //                 "identifiers": [
    //                     {
    //                         "type": "CLIENT_ROLE_ID",
    //                         "value": "5d871528-f237-4d94-ac45-00bb4b6f31f9"
    //                     }
    //                 ],
    //                 "riskRating": "NO_RATING",
    //                 "riskCheckStatus": "COMPLETED",
    //                 "lastRiskCheckTs": "2018-08-24T01:29:21.516Z",
    //                 "updatedTs": "2018-08-24T01:29:21.661Z",
    //                 "untreatedResultCount": 0,
    //                 "dismissedResultCount": 0,
    //                 "confirmedResultCount": 0
    //             },
    //             {
    //                 "identifiers": [
    //                     {
    //                         "type": "CLIENT_ROLE_ID",
    //                         "value": "9647d116-ab6b-449e-bb51-a58631dec10f"
    //                     }
    //                 ],
    //                 "riskRating": "HIGH",
    //                 "riskCheckStatus": "UNDER_THREAT_EVAL",
    //                 "lastRiskCheckTs": "2018-08-24T01:29:21.032Z",
    //                 "updatedTs": "2018-08-24T01:29:21.292Z",
    //                 "untreatedResultCount": 0,
    //                 "dismissedResultCount": 0,
    //                 "confirmedResultCount": 0
    //             }
    //         ]
    //     }
    // ]
};

export {rrsMockApplicationSearch};