import * as React from "react";
import {
    ISyncContainerProps as ICommonSyncContainerProps,
    SyncContainer as CommonSyncContainer
} from "@twii/common/lib/component/SyncContainer";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";
import {MessageBarType, MessageBar} from "office-ui-fabric-react/lib/MessageBar";
import {Link} from "office-ui-fabric-react/lib/Link";
import {observer} from "mobx-react";
import {observable} from "mobx";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {IIRPStoreModel, ILoadPreSelectIds} from "../service/IIRPStoreModel";
import {isObject, isString} from "@twii/common/lib/util/Lang";
import {ServiceErrorMessages} from "./ServiceErrorMessages";

interface ISyncContainerProps extends ICommonSyncContainerProps {
    elementBefore?: () => JSX.Element | HTMLElement;
    host?: IAppHost;
}

@observer
class SyncContainer extends React.Component<ISyncContainerProps, any> {
    @observable private _stackOpen: boolean = false;
    @observable private _detailsOpen: boolean = false;
    private _IRPStore: IIRPStoreModel = this.props.host ? this.props.host.state.irpState : null;

    private get refreshButton() {
        if (this.props.host && this._IRPStore) {
            const selectedDealing = this._IRPStore.getSelectedDealing();
            const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
            const preSelectIds: ILoadPreSelectIds = {
                applicationId: selectedDealing && selectedDealing.applicationId ? selectedDealing.applicationId : null,
                filterId: selectedRiskMatch && selectedRiskMatch ? selectedRiskMatch.resultId : null
            };
            const onClick = (e: React.MouseEvent<HTMLElement>) => {
                e.preventDefault();
                this._IRPStore.refreshStore(preSelectIds)
            };
            return <Link href="#" title="Refresh link" onClick={onClick}>Refresh</Link>
        } else {
            return "Refresh";
        }
    }

    private _toggleStack = () => this._stackOpen = !(this._stackOpen);
    private _toggleDetails = () => this._detailsOpen = !(this._detailsOpen);

    private _onRenderError = (error) => {
        const _renderDetails = () => {
            const defaultMsg = "No details found.";
            if (isObject(error)) {
                const keys = Object.keys(error);
                return keys.length > 0
                    ? keys.map((errorSec, i) => <p
                        key={i}>{errorSec}<br/>{JSON.stringify(error[errorSec])}</p>)
                    : defaultMsg;
            } else if (isString(error)) {
                return error;
            } else {
                return defaultMsg;
            }
        };

        const _stackLink = error.stack
            ? <Link href="#" onClick={this._toggleStack}>{this._stackOpen ? "Close " : "Open "} stack</Link>
            : null;

        const _detailsLink = <Link href="#"
                                   onClick={this._toggleDetails}>{this._detailsOpen ? "Close " : "Open "} details</Link>;

        const defaultContent = <Spinner className="sync-spinner" label="Loading..."/>;
        //const defaultErrorContent = <MessageBar messageBarType={MessageBarType.error} title={error.message}><span style={{color: "red"}}>An error occurred</span></MessageBar>;
        const status = error && error.response && error.response.status ? error.response.status : null;
        const errorContent = 
            <MessageBar messageBarType={MessageBarType.error} title={error.message}>
                <ServiceErrorMessages host={this.props.host} status={status ? status : null}/>
                    {/*<p>{_stackLink} {_detailsLink}</p>
                    <div>
                        {this._stackOpen ? <p>{error.stack}</p> : null}
                        {this._detailsOpen ? _renderDetails() : null}
                    </div>*/}
            </MessageBar>
        return <div className="ande-irp-sync-container-error">
            {this.props.elementBefore ? this.props.elementBefore() : null}
            {status ? errorContent : null}
        </div>
        
        
    };

    render() {
        return <CommonSyncContainer onRenderError={this._onRenderError} {...this.props} />
    }
}

export {
    SyncContainer as default,
    SyncContainer,
    ISyncContainerProps
}