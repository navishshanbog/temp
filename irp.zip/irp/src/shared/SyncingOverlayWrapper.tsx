import * as React from "react";
import "./SyncingOverlay.scss";




interface ISyncingOverlayWrapperProps {
    syncedBckGrnd?: any;
}

class SyncingOverlayWrapper extends React.Component<any, any> {
    render() {
        return <div className="ande-overlay-container" key="ande-overlay-container">
            <div className="ande-overlay-surface"></div>
            <div className="ande-overlay-content" style={this.props.syncedBckGrnd}
                 key="ande-overlay-content">{this.props.children}</div>
        </div>;

    }
}

export {
    SyncingOverlayWrapper as default,
    SyncingOverlayWrapper
}