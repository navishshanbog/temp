enum ValidRiskMatchStatus {
    CHECKING = "CHECKING",
    UNDER_THREAT_EVAL = "UNDER_THREAT_EVAL",
    RISK_ASSESSMENT_UNTREATED = "RISK_ASSESSMENT_UNTREATED",
    RISK_ASSESSMENT_IN_PROGRESS = "RISK_ASSESSMENT_IN_PROGRESS",
    COMPLETED = "COMPLETED"
}

enum ValidRiskMatchAssessmentOutcome {
    CONFIRMED = "CONFIRMED",
    DISMISSED = "DISMISSED"
}

enum ValidRiskMatchViewStatus {
    untreated = "Untreated",
    inProgress = "In Progress",
    confirmed = "Confirmed",
    dismissed = "Dismissed",
    matchEvalDismissed = "Dismissed - Threat Evaluation",
    positiveProfile = "Completed",
    underThreatEval = "Under Threat Evaluation",
    historicalCVOR = "CVOR COMPLETED"
    //historicalCVOR = "Completed"
}

enum ViewMovement {
    U = "UP",
    D = "Down"
}

export {
    ValidRiskMatchStatus,
    ValidRiskMatchAssessmentOutcome,
    ValidRiskMatchViewStatus,
    ViewMovement
};