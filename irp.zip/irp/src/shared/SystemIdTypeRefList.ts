import RefListModel from "@twii/common/lib/RefListModel";
import {IRefListItem} from "@twii/common/lib/IRefListItem";

enum validIdSourceENUM {
    ICSE = "ICSE",
    TRIPS = "TRIPS",
    ETAS = "ETAS"
}

enum validIdTypeENUM {
    CID = "CID",
    PID = "PID",
    PRID = "PRID",
    VGN = "VGN"
}

enum validUrlParamsENUM {
    cid = "cid",
    pid = "pid",
    prid = "prid",
    vgn = "vgn", 
    iid = "iid"
}

interface ISystemIdTypeRefListItem extends IRefListItem {
    text: validIdTypeENUM | string;
    subPath?: string;
    systemName?: validIdSourceENUM;
}

interface ISystemIdTypeRefList<T extends IRefListItem> extends RefListModel {
    items: ISystemIdTypeRefListItem[];
    getItemByKey(key: string, defaultItem?: T): T;
}

class SystemIdTypeRefListClass extends RefListModel implements ISystemIdTypeRefList<ISystemIdTypeRefListItem> {
    getSystemItemByKey(key: string, defaultItem?: ISystemIdTypeRefListItem): ISystemIdTypeRefListItem {
        return this.getItemByKey(key, defaultItem);
    }
}

const SystemIdTypeRefList = new SystemIdTypeRefListClass([
    {key: "icseId", subPath: "icseId", text: "CID", systemName: "ICSE", urlParam:validUrlParamsENUM.cid},
    {key: "tripsId", subPath: "tripsId", text: "PID", systemName: "TRIPS", urlParam:validUrlParamsENUM.pid},
    {key: "prId", subPath: "prId", text: "PRID", systemName: "ICSE", urlParam: validUrlParamsENUM.prid},
    {key: "vgn", subPath: "vgn", text: "VGN", systemName: "TRIPS", urlParam: validUrlParamsENUM.vgn}
]);

export {
    SystemIdTypeRefList as default,
    SystemIdTypeRefList,
    SystemIdTypeRefListClass,
    ISystemIdTypeRefListItem,
    ISystemIdTypeRefList,
    validIdSourceENUM,
    validIdTypeENUM
};