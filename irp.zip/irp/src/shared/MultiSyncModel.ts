import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {SyncModel} from "@twii/common/lib/SyncModel";
import {observable} from "mobx";


interface IMultiSyncModel {
    syncList: {
        [key: string]: ISyncModel;
    };
    addSync: (id: string) => ISyncModel;
    findSync: (id: string) => ISyncModel;
    getSync: (id: string) => ISyncModel;
    removeSync: (id: string) => boolean;
    resetSync: (id: string) => ISyncModel;
    syncStart: (id: string) => ISyncModel;
}

class MultiSyncModel implements IMultiSyncModel {
    @observable syncList = {};

    findSync = (id: string): ISyncModel => {
        return this.syncList[id];
    };

    getSync = (id: string) => {
        return this.syncList[id] || this.addSync(id);
    };

    addSync = (id: string) => {
        const syncInTheList = this.findSync(id);
        if (syncInTheList) {
            return syncInTheList;
        } else {
            const sync = observable(new SyncModel());
            sync.id = id;
            this.syncList[id] = sync;
            return this.findSync(id);
        }
    };

    removeSync = (id: string) => {
        const syncInTheList = this.findSync(id);
        if (syncInTheList) {
            delete this.syncList[id];
        }
        return false;
    };

    resetSync = (id: string) => {
        this.removeSync(id);
        return this.addSync(id);
    };

    syncStart = (id: string) => {
        const sync = this.addSync(id);
        sync.syncStart();
        return sync;
    };

    syncEnd = (id: string) => {
        const sync = this.findSync(id);
        if (sync) {
            sync.syncEnd();
        }
        return sync;
    };

}

export {
    MultiSyncModel as default,
    MultiSyncModel,
    IMultiSyncModel
};