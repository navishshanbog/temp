import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Link } from "office-ui-fabric-react/lib/Link";
import "./QuickLinks.scss";

interface IQuickLinksProps {
}

class QuickLinks extends React.Component<IQuickLinksProps, any> {
    render() {
        const farItems: IContextualMenuItem[] = [];
        const quickLinksMenu: IContextualMenuItem = {
            key: "quicklinks",
            name: "Quick Links",
            iconProps: {
                iconName: "Link12"
            },
            subMenuProps: {
                items: [
                    {
                        key: 'canx',
                        text: 'CANX',
                        href: 'https://portals.immi.gov.au/cancellations/app',
                        target: '_blank'
                    },
                    {
                        key: 'ccmd',
                        text: 'CCMD',
                        href: 'https://portals.immi.gov.au/ecm/app/epublicsector/enu',
                        target: '_blank'
                    },
                    {
                        key: 'cmal',
                        text: 'CMAL',
                        href: 'https://portals.immi.gov.au/cmal/crif',
                        target: '_blank'
                    },
                    {
                        key: 'intel',
                        text: 'IMTEL',
                        href: 'http://immbelpd1:7778/pls/imtel/interquest',
                        target: '_blank'
                    }
                ]
            }
        };
        farItems.push(quickLinksMenu);
        return (
            <div className="ande-irp-quicklinks">
                <CommandBar items={[]} farItems={farItems} className="ande-irp-quick-link-command-bar" />
            </div>
        )
    }
}

export { QuickLinks, QuickLinks as default }