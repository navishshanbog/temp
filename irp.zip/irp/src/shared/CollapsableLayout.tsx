import * as React from "react";
import {css} from "@uifabric/utilities";
import "./CollapsableLayout.scss";
import {CollapsableLayoutService, ICollapsableLayoutService} from "./CollapsableLayout.service";
import {observable} from "mobx";
import {ReactElement} from "react";
import {CollapsableLayoutLeft} from "./CollapsableLayout--left";
import {observer} from "mobx-react";

interface ICollapsableLayoutProps {
    leftWidthPercent?: number;
    collapseButtonWidthPixel?: number;
    isLeftPanelOpen?: boolean;
    toggleLeftPanelCallback?: (isExpanded: boolean) => any;
}

const CollapsableLayoutClassNames = {
    wrapper: "irp-applets-layout",
    header: "irp-applets-header",
    left: "irp-applets-layout--left-panel",
    toggleBtn: "irp-applets-layout--toggle-button",
    toggleBtnIcon: "irp-applets-layout--toggle-button-icon",
    main: "irp-applets-layout--main-panel",
    collapsed: "is-collapsed"
};

@observer
class CollapsableLayout extends React.Component<ICollapsableLayoutProps, any> {
    @observable layoutService: ICollapsableLayoutService;

    constructor(props) {
        super(props);
        this.state = {
            dimensions: undefined
        }
    }

    private _initiateLayoutService = ref => {
        this.layoutService = new CollapsableLayoutService(ref, this.props);
    };

    private _toggleLeftPanel = () => {
        this.layoutService.isExpanded = !this.layoutService.isExpanded;
        if(this.props.toggleLeftPanelCallback) {
            this.props.toggleLeftPanelCallback(this.layoutService.isExpanded);
        }
    };

    componentWillReceiveProps(newProps: ICollapsableLayoutProps) {
        this.layoutService.isExpanded = newProps.isLeftPanelOpen;
        this.layoutService.leftWidthPercent = newProps.leftWidthPercent;
        this.layoutService.toggleButtonPixel = newProps.collapseButtonWidthPixel;
        this.setState({
            dimentions: this.layoutService.dimensions
        })
    }

    render() {
        return <div ref={this._initiateLayoutService}
                    className={css(CollapsableLayoutClassNames.wrapper, this.layoutService && !this.layoutService.isExpanded ? CollapsableLayoutClassNames.collapsed : "")}>
            {this.layoutService ? React.Children.map(this.props.children, (child: ReactElement<any>) => {
                if (child.type === CollapsableLayoutLeft) {
                    return React.cloneElement(child, {
                        width: this.layoutService.dimensions.leftPanelWidth,
                        offset: this.layoutService.dimensions.leftPanelOffset
                    })
                } else {
                    return React.cloneElement(child, {
                        leftOffset: this.layoutService.dimensions.rightPanelLeftOffset,
                        rightOffset: this.layoutService.dimensions.rightPanelRightOffset,
                        isExpanded: this.layoutService.isExpanded,
                        toggleButtonWidth: this.layoutService.toggleButtonPixel,
                        toggleButtonOffset: this.layoutService.dimensions.toggleButtonOffset,
                        toggleLeftPanel: this._toggleLeftPanel
                    });
                }

            }) : null}
        </div>
    }
}

export {
    CollapsableLayout as default,
    CollapsableLayout,
    ICollapsableLayoutProps,
    CollapsableLayoutClassNames
}