import * as React from "react";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";
import "./SyncingOverlay.scss";
import {ReactNode, ReactText} from "react";
import {SyncContainer} from "./SyncContainer";
import {ISync} from "@twii/common/lib/ISync";
import {SyncingOverlayWrapper} from "./SyncingOverlayWrapper";

interface ISyncingOverlayProps {
    sync?: ISync;
    onRenderContent?: () => ReactNode | ReactText;
    onRenderError?: {overlay: boolean, function: (e) => ReactNode | ReactText;}
    onRenderSync?: () => ReactNode | ReactText;
    showSpinner?: boolean;
    syncedBckGrnd?: any;
}

class SyncingOverlay extends React.Component<ISyncingOverlayProps, any> {
    private _showSpinner = this.props.showSpinner;

    private _ref;

    private _setRef = ref => {
        if (ref && !this._ref) {
            this._ref = ref;
        }
    };

    private _onRenderSync = () => {
        return <SyncingOverlayWrapper>
            {this._showSpinner ? <Spinner className="ande-overlay-spinner"/> : null}
            {/*this.props.onRenderSync ? this.props.onRenderSync() : <Spinner className="ande-overlay-spinner"/>*/}
        </SyncingOverlayWrapper>
    };

    private _onRenderError = (e: Error) => {
        if (this.props.onRenderError) {
            return this.props.onRenderError.overlay
                ? <SyncingOverlayWrapper>{this.props.onRenderError.function(e)}</SyncingOverlayWrapper>
                : this.props.onRenderError.function(e);
        } else if (this._ref && this._ref._onRenderError) {
            return <div className="ande-overlay--error-message-bar">{this._ref._onRenderError(e)}</div>;
        } else {
            return <SyncingOverlayWrapper>{"An error occurred..."}</SyncingOverlayWrapper>
        }
    };

    render() {
        return this.props.sync
            ? <SyncContainer sync={this.props.sync}
                             ref={this._setRef}
                             onRenderDone={() => this.props.onRenderContent ? this.props.onRenderContent() : null}
                             onRenderSync={this._onRenderSync}
                             onRenderError={this._onRenderError}/>
            : this.props.onRenderContent
                ? <SyncingOverlayWrapper syncedBckGrnd={this.props.syncedBckGrnd}>{this.props.onRenderContent()}</SyncingOverlayWrapper>
                : null
    }
}

export {
    SyncingOverlay as default,
    SyncingOverlay,
    ISyncingOverlayProps
}