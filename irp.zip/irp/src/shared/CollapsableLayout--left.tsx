import * as React from "react";
import {CollapsableLayoutClassNames, ICollapsableLayoutProps} from "./CollapsableLayout";
import {css} from "@uifabric/utilities";

interface ICollapsableLayoutLeftProps {
    width?: number;
    offset?: number;
}
class CollapsableLayoutLeft extends React.Component<ICollapsableLayoutLeftProps, any> {
    render() {
        return <div className={css(CollapsableLayoutClassNames.left)} style={{width: this.props.width, left: this.props.offset}}>{this.props.children}</div>
    }
}

export {CollapsableLayoutLeft as default, CollapsableLayoutLeft, ICollapsableLayoutLeftProps}