const Defaults = {
    baseUrl: {
        cie: "/DataServices",
        rrs: "/riskresults",
    },
    NoResultErrorCode: "0101"
};

abstract class AbstractRestDataService {
    private _baseUrl: any;

    get config() {
        return {
            baseUrl: this._baseUrl || Defaults.baseUrl
        };
    }

    protected assertObject(data: any): any {
        if (data && typeof (data) !== 'object') {
            throw new Error(`UNEXPECTED_RESPONSE_TYPE: Expected response to be an object, but got ${typeof (data)}. Data - ${data}`);
        }
        return data;
    }

    protected handleError(errors: any): any {
        if (errors.code !== Defaults.NoResultErrorCode) {
            throw errors;
        }
        return [];
    }
}

export {AbstractRestDataService as default, AbstractRestDataService, Defaults};