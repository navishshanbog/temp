import * as React from "react";
import {IContextualMenuItem} from "office-ui-fabric-react/lib/ContextualMenu";
import {observer} from "mobx-react";
import {computed} from "mobx";
import "./SectionTitleBar.scss";
import {ContextualMenuItemType} from "office-ui-fabric-react/lib/components/ContextualMenu";
import {css} from "@uifabric/utilities";
import {Icon} from "office-ui-fabric-react/lib/Icon";
import * as StringUtils from "@twii/common/lib/util/String";
import _ from "lodash";
import {ValidRiskMatchViewStatus} from "./RiskMatchValidValues";

interface BreadCrumbItem {
    label?: string | number;
    value?: string | number;
    identifirer?: string | number;
}

interface ISectionTitleBarProps {
    title: string;
    items?: IContextualMenuItem[];
    farItems?: IContextualMenuItem[];
    breadcrumbItems?: BreadCrumbItem[];
    iconName?: string;
    className?: string;
    dismissedMatch?: number;
    confirmedMatch?: number;
}

const componentClassNamePrefix = "ande-section-title-bar";

@observer
class SectionTitleBar extends React.Component<ISectionTitleBarProps, any> {
    @computed
    private get _internalItems(): IContextualMenuItem[] {
        let items: IContextualMenuItem[] = [{
            key: "title",
            title: this.props.title,
            name: this.props.title,
            className: `${componentClassNamePrefix}--title`
        }];

        if (this.props.breadcrumbItems) {
            items.push({
                itemType: ContextualMenuItemType.Section,
                key: "breadcrumb",
                name: this.props.breadcrumbItems.join(" "),
                className: `${componentClassNamePrefix}--breadcrumb`
            })
        }

        if (this.props.items) {
            items = items.concat(this.props.items)
        }

        return items;
    }

    private _renderBreadcrumbItems = () => {
        const breadcrumbItems = this.props.breadcrumbItems && this.props.breadcrumbItems.length > 0 ? this.props.breadcrumbItems : [];
        if (breadcrumbItems && breadcrumbItems.length > 0) {
            const className = css(`${componentClassNamePrefix}--item`);
            return this.props.breadcrumbItems.map((br, i) => {
                const brLabel = br.label ? br.label.toString() : "";
                const brValue = br.value ? br.value.toString() : "";
                const brIdentifier = br.identifirer ? br.identifirer.toString() : "";
                const bri = brIdentifier + `-${i}-` + (brValue ? brLabel + brValue.split(' ').join('').split(',').join('') : "");
                return <div key={`${bri}-1`}>
                    <span className={`${className}`} id={`${bri}-2`} key={i}>{brLabel + ":" }</span>
                    <div className={`${className}`} aria-labelledby={`${bri}-2`} key={`${bri}-3`}>{`${br.value}`}</div>
                    <div key={`${bri}-4`}>{`    `}</div>
                </div>
            })
        } else {
            return null;
        }
    };

    private _renderItems = () => {
        if (this.props.items) {
            return this.props.items.map((item, i) => {
                let content;
                const itemsClassNames = css(`${componentClassNamePrefix}--item`, item.className);
                const secondaryText = item.secondaryText ? item.secondaryText : null;
                const spanElement = <span className={itemsClassNames} id={item.key}>{secondaryText}</span>;
                return <div key={i}>
                    { spanElement }
                    <div key={i} className={itemsClassNames} aria-labelledby={item.key} >
                        {item.onClick ? <a href="#" onClick={item.onClick} title={item.title ? item.title : null}>{item.name}</a> : item.name}
                    </div>
                </div>
                
            })
        } else {
            return null;
        }
    };

    private _renderFarItems = () => {
        if (this.props.farItems) {
            return this.props.farItems.reverse().map((fi, i) => {
                const farItemsClassNames = css(`${componentClassNamePrefix}--item`, fi.className);
                return <div key={i} className={farItemsClassNames}>
                    {fi.onRender ? fi.onRender(fi, () => null) : fi.name}
                </div>
            })
        } else {
            return null;
        }
    };

    render() {
        const warningAriaLabel = this.props.iconName && this.props.iconName === "IncidentTriangle" ? "Limited access" : "";
        const renderIcon = (StringUtils.isNotBlank(this.props.iconName) && this.props.className ) ? 
            <div title={`${warningAriaLabel}`}>
                <Icon iconName={this.props.iconName} className={this.props.className} ariaLabel={`${warningAriaLabel}`} />
            </div>
        : null;


        const dismissed = this.props.dismissedMatch && this.props.dismissedMatch !=0 ?
            <div><span>{this.props.dismissedMatch}</span><span className="tooltiptext">{`${this.props.dismissedMatch} Dismissed Risks`}</span></div> : null;
        const confirmed = this.props.confirmedMatch && this.props.confirmedMatch !=0 ?
            <div><span>{this.props.confirmedMatch}</span><span className="tooltiptext">{`${this.props.confirmedMatch} Confirmed Risks`}</span></div> : null;

        const titleClassNames = css(`${componentClassNamePrefix}--item`, `${componentClassNamePrefix}--title`);
        const itemsClassNames = css(`${componentClassNamePrefix}--item`, `${componentClassNamePrefix}--items`)
        const breadcrumbClassNames = css(`${componentClassNamePrefix}--item`, `${componentClassNamePrefix}--breadcrumb`)
        const farItemsClassNames = css(`${componentClassNamePrefix}--item`, `${componentClassNamePrefix}--far-item`);
        const riskCirclesClassNames = css(`${componentClassNamePrefix}--item`, `${componentClassNamePrefix}--circles`);

        return (
            <div className={componentClassNamePrefix}>
                <div className = {titleClassNames} style={{marginRight: "1%", color: "orange"}}>{renderIcon}</div>
                <div className={titleClassNames}>{this.props.title}</div>
                {dismissed != null ? <div className={`${riskCirclesClassNames} dismissed-circle`}>{dismissed}</div> : null}
                {confirmed != null ? <div className={`${riskCirclesClassNames} confirmed-circle`}>{confirmed}</div> : null}

                <div className={breadcrumbClassNames}>{this._renderBreadcrumbItems()}</div>
                <div className={itemsClassNames}>{this._renderItems()}</div>
                <div className={farItemsClassNames}>{this._renderFarItems()}</div>
            </div>
        )
    }
}

export {
    SectionTitleBar as default,
    SectionTitleBar,
    ISectionTitleBarProps, 
    BreadCrumbItem
}