import * as React from "react";
import {Link} from "office-ui-fabric-react/lib/Link";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {IIRPStoreModel, ILoadPreSelectIds} from "../service/IIRPStoreModel";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";

interface IServiceErrorMessagesProps {
    status: number;
    host?: IAppHost;
}

class ServiceErrorMessages extends React.Component<IServiceErrorMessagesProps, any> {
    private _IRPStore: IIRPStoreModel = this.props.host? this.props.host.state.irpState : null;

    private get refreshButton() {
        if (this.props.host && this._IRPStore) {
            const selectedDealing = this._IRPStore.getSelectedDealing();
            const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
            const preSelectIds: ILoadPreSelectIds = {
                applicationId: selectedDealing && selectedDealing.applicationId ? selectedDealing.applicationId : null,
                filterId: selectedRiskMatch && selectedRiskMatch ? selectedRiskMatch.resultId : null
            };
            const onClick = (e:React.MouseEvent<HTMLElement>) => {
                e.preventDefault();
                this._IRPStore.refreshStore(preSelectIds)
            };
            return <Link href="#" title="Refresh link" onClick={onClick}>Refresh</Link>
        } else {
            return "Refresh";
        }
    }

    private _validErrorMessages = {
        _403: "You are not authorized to access this resource",
        _404: "No record found",
        _500: <span>A system error has occurred. {this.refreshButton} the screen to try again and contact IT Support if the problem persists.</span>,
        _409: <span>Your change could not be saved because the record has been updated by another user since you last opened it. {this.refreshButton} the screen to try again.</span>,
        _defaullt: "A error has occurred..."
    };

    render() {
        const status = this.props.status ? this.props.status : null;
        if(status) {
            switch (status) {
                case 403:
                    return this._validErrorMessages._403;
                case 404:
                    return this._validErrorMessages._404;
                case 409:
                    return this._validErrorMessages._409;
                case 500:
                    return this._validErrorMessages._500;
                default:
                    return this._validErrorMessages._defaullt;
            }
        }
        else {
            //return <span>"An error has occurred"</span>
            //return <Spinner className="sync-spinner" label="Loading..."/>;
            return <div></div>;
        }
    }
}

export {
    ServiceErrorMessages as default,
    ServiceErrorMessages,
    IServiceErrorMessagesProps
}