import "./CollapsableLayout.scss";
import {ICollapsableLayoutProps} from "./CollapsableLayout";
import {computed, observable} from "mobx";

interface ICollapsableLayoutDimensions {
    leftPanelWidth: number;
    leftPanelOffset: number;
    rightPanelRightOffset: number;
    rightPanelLeftOffset: number;
    toggleButtonWidth: number;
    toggleButtonOffset: number;
}

interface ICollapsableLayoutService {
    leftWidthPercent: number;
    toggleButtonPixel: number;
    toggleButtonCallback: (isExpanded: boolean) => any;
    isExpanded: boolean;

    dimensions: ICollapsableLayoutDimensions;
}

class CollapsableLayoutService implements ICollapsableLayoutService {
    @observable leftWidthPercent: number = 30;
    @observable toggleButtonPixel: number = 15;
    @observable isExpanded: boolean = true;
    toggleButtonCallback: (isExpanded: boolean) => any;

    private _layoutElementRef: HTMLElement;

    constructor(layoutElementRef: HTMLElement, props: ICollapsableLayoutProps) {
        this._layoutElementRef = layoutElementRef;
        this.leftWidthPercent = props.leftWidthPercent;
        this.toggleButtonPixel = props.collapseButtonWidthPixel;
        this.toggleButtonCallback = props.toggleLeftPanelCallback;
        this.isExpanded = props.isLeftPanelOpen;
    }

    @computed
    get dimensions() {
        const layoutWidth = this._layoutElementRef.getBoundingClientRect().width;
        const leftWidth = layoutWidth * (this.leftWidthPercent / 100) - this.toggleButtonPixel;
        const leftPanelOffset = this.isExpanded ? 0 : -1 * leftWidth;
        const rightPanelLeftOffset = this.isExpanded ? leftWidth + this.toggleButtonPixel : this.toggleButtonPixel;
        return {
            leftPanelWidth: leftWidth,
            leftPanelOffset: leftPanelOffset,
            rightPanelRightOffset: 0,
            rightPanelLeftOffset: rightPanelLeftOffset,
            toggleButtonWidth: this.toggleButtonPixel,
            toggleButtonOffset: leftWidth + leftPanelOffset
        }
    };
}

export {
    CollapsableLayoutService as default,
    CollapsableLayoutService,
    ICollapsableLayoutService,
    ICollapsableLayoutDimensions
}