import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { Link } from "office-ui-fabric-react/lib/components/Link";

class Accessibility extends React.Component<any, any> {
    render() {
        return (
            <div>
                <div className="default-accessibility">
                    <p>
                        The Department of Home Affairs is committed to ensuring that our online digital services are inclusive for all users regardless of ability. <br /><br />
                        The design of the Integrated Risk Portal (IRP) aims to meet the Australian Government standard for web accessibility mandated by the Digital Transformation Agency (DTA) in their <Link href="https://www.dta.gov.au/help-and-advice/digital-service-standard/digital-service-standard-criteria/9-make-it-accessible" target="_blank">Digital Service Standard (DSS), Article 9 – Make it Accessible</Link>.<br /><br />
                        We continue to improve the user experience of these applications for everyone and welcome your feedback.  If you encounter any barriers in the use of our services that limit your access to information please let us know by email at <Link href="mailto:webaccessibility@homeaffairs.gov.au" target="_blank">webaccessibility@homeaffairs.gov.au</Link>.
                    </p>
                </div>
            </div>
        );
    }
}

class AccessibilityApp extends React.Component<IAppProps, any> {
    componentWillMount() {
        this.props.match.host.setTitle("Accessibility");
    }
    render() {
        return <Accessibility />;
    }
}

export { AccessibilityApp, AccessibilityApp as default, Accessibility }