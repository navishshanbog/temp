import * as React from "react";
import {observer} from "mobx-react";
import {Label} from "office-ui-fabric-react/lib/Label";
import {DatePicker, IDatePickerProps} from "office-ui-fabric-react/lib/DatePicker";
import {PrimaryButton, IconButton} from "office-ui-fabric-react/lib/Button";
import {Subject} from "rxjs/Subject";
import {debounceTime} from "rxjs/operators/debounceTime";
import {map} from "rxjs/operators/map";
import "./DateRangeFilter.scss"
import * as moment from "moment";
import {observable} from "mobx";

interface IDateRangeFilterModel {
    from: moment.Moment;
    to: moment.Moment;
}

interface IDateRangeFilterProps {
    label?: string;
    dateRange: IDateRangeFilterModel;
    className?: string;
    onChanged?: (dateRange: IDateRangeFilterModel) => any;
}

const filterPaneClassNamePrefix = "ande-date-range-filter";

@observer
class DateRangeFilter extends React.Component<IDateRangeFilterProps, any> {
    private _dateRangeFilterSubject = new Subject();
    @observable private _matchDateFilter: IDateRangeFilterModel = {
        from: null,
        to: null
    };

    componentDidMount() {
        this._dateRangeFilterSubject
            .pipe(debounceTime(250), map(() => {
                return (!this._matchDateFilter.from && !this._matchDateFilter.to)
                    ? {
                        from: null,
                        to: null
                    }
                    : {
                        from: moment(this._matchDateFilter.from).isValid() ? moment(this._matchDateFilter.from) : moment(),
                        to: moment(this._matchDateFilter.to).isValid() ? moment(this._matchDateFilter.to) : moment()
                    };
            }))
            .subscribe((matchDateFilter) => {
                this.props.onChanged(matchDateFilter);
            });
    };

    componentWillReceiveProps(props: IDateRangeFilterProps) {
        if(props.dateRange && props.dateRange.from !== this._matchDateFilter.from || this._matchDateFilter.to !== this._matchDateFilter.to) {
            this._matchDateFilter = props.dateRange;
            this._dateRangeFilterSubject.next();
        }
    }

    private _onSelectDateFrom = val => {
        this._matchDateFilter.from = moment(val).isValid() ? moment(val) : null;
        this._dateRangeFilterSubject.next();
    };

    private _onSelectDateTo = val => {
        this._matchDateFilter.to = moment(val).isValid() ? moment(val) : null;
        this._dateRangeFilterSubject.next();
    };

    private _clearDateFilter = () => {
        this._matchDateFilter = {from: null, to: null};
        this._dateRangeFilterSubject.next();
    };

    private _toDateFormat(date: moment.Moment) {
        return date.toDate();
    }

    render() {
        const dateRangeFilterProps: IDatePickerProps = {
            allowTextInput: true,
            isMonthPickerVisible: true,
            showGoToToday: true
        };
        return <div className={`${filterPaneClassNamePrefix} ${this.props.className ? this.props.className : ""}`}>
            {this.props.label ? <Label className={`${filterPaneClassNamePrefix}--match-date-filter-label`}>{this.props.label}</Label> : null}
            <DatePicker
                value={this._matchDateFilter.from ? this._toDateFormat(this._matchDateFilter.from) : null}
                className={`${filterPaneClassNamePrefix}--match-date-filter-from`} {...dateRangeFilterProps}
                placeholder="From"
                onSelectDate={this._onSelectDateFrom}/>
            <DatePicker
                value={this._matchDateFilter.to ? this._toDateFormat(this._matchDateFilter.to) : null}
                className={`${filterPaneClassNamePrefix}--match-date-filter-to`} {...dateRangeFilterProps}
                placeholder="To"
                onSelectDate={this._onSelectDateTo}/>
            <PrimaryButton className={`${filterPaneClassNamePrefix}--clear-button`} text="Clear"
                           iconProps={{iconName: "Clear"}} onClick={this._clearDateFilter}/>
        </div>
    }
}

export {
    DateRangeFilter as default,
    DateRangeFilter,
    IDateRangeFilterProps,
    IDateRangeFilterModel
}
