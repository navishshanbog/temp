import * as React from "react";
import {CollapsableLayoutClassNames, ICollapsableLayoutProps} from "./CollapsableLayout";
import {css} from "@uifabric/utilities";

class CollapsableLayoutHeader extends React.Component<ICollapsableLayoutProps, any> {
    render() {
        return <div className={css(CollapsableLayoutClassNames.header)}>{this.props.children}</div>
    }
}

export {CollapsableLayoutHeader as default, CollapsableLayoutHeader}