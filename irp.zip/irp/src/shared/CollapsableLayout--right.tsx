import * as React from "react";
import {CollapsableLayoutClassNames} from "./CollapsableLayout";
import {css} from "@uifabric/utilities";
import {IconButton} from "office-ui-fabric-react/lib/Button"

interface ICollapsableLayoutRightProps {
    rightOffset?: number;
    leftOffset?: number;
    toggleButtonWidth?: number;
    toggleButtonOffset?: number;
    isExpanded?: boolean;
    toggleLeftPanel?: () => void;
}

class CollapsableLayoutRight extends React.Component<ICollapsableLayoutRightProps, any> {
    render() {
        return <>
            <div className={css(CollapsableLayoutClassNames.toggleBtn)}
                 style={{
                     width: this.props.toggleButtonWidth,
                     left: this.props.toggleButtonOffset
                 }}>
                <IconButton className={css(CollapsableLayoutClassNames.toggleBtnIcon)}
                            ariaLabel="toggle client summary panel"
                            iconProps={{iconName: this.props.isExpanded ? "CaretSolidLeft" : "CaretSolidRight"}}
                            onClick={this.props.toggleLeftPanel}/>
            </div>
            <div className={css(CollapsableLayoutClassNames.main)}
                 style={{
                     right: this.props.rightOffset,
                     left: this.props.leftOffset
                 }}>{this.props.children}</div>
        </>
    }
}

export {CollapsableLayoutRight as default, CollapsableLayoutRight, ICollapsableLayoutRightProps}