import * as React from "react";

import {observer} from "mobx-react";
import {ITreatmentNotesServiceModel} from "../model/TreatmentNotesServiceModel";
import "./ClientRiskCheckDetails--alert.scss";
import {IDetailsRowProps} from "office-ui-fabric-react/lib/DetailsList";
import {IRRClientRiskMatchesServiceResponseItem} from "../model/IRRClientRiskMatchesServiceResponseItem";
import {Icon} from "office-ui-fabric-react/lib/Icon";

interface IClientRiskCheckDetailsAlert {
    notesModel: ITreatmentNotesServiceModel,
    rowProps: IDetailsRowProps,
    rowDefaultRenderer: (props: IDetailsRowProps) => JSX.Element
}

@observer
class ClientRiskCheckDetailsAlert extends React.Component<IClientRiskCheckDetailsAlert, any> {
    render() {
        const rowProps = this.props.rowProps;
        const item: IRRClientRiskMatchesServiceResponseItem = rowProps.item;
        let className: string = "";
        let notesServiceModel = this.props.notesModel;

        const hasNotes = notesServiceModel.isDirtyTreatmentNote(item.resultId);
        rowProps.className = hasNotes ? "has-notes" : "";

        return <div className="client-risk-check-details--row-has-notes">
            {this.props.rowDefaultRenderer(rowProps)}
            {hasNotes ? <div className="warning-floating-box">
                <Icon iconName="Warning"/>
                <span>  Unsaved note.</span>
            </div> : null}
        </div>;
    }
}

export {
    ClientRiskCheckDetailsAlert as default,
    ClientRiskCheckDetailsAlert,
    IClientRiskCheckDetailsAlert
}
