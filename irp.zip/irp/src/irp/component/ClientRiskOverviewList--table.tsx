import * as React from "react";
import {action, computed, observable, reaction} from "mobx";
import {observer} from "mobx-react";
import {IDealing} from "../model/IDealings";
import {Subject} from "rxjs/Rx";

import "./ClientRiskOverviewList.scss";
//import {CustomDetailsList, ICustomDetailsListProps} from "@twii/common/lib/component/CustomDetailsList";
import {CustomDetailsList, ICustomDetailsListProps} from "../../irpcommon/CustomDetailsList";
import {
    CheckboxVisibility,
    ConstrainMode,
    css, DetailsListBase,
    DetailsListLayoutMode,
    IDetailsRowProps,
    SelectionMode
} from "office-ui-fabric-react/lib";
import {ScrollablePaneBase} from "office-ui-fabric-react/lib/ScrollablePane";
import {CheckboxType} from "@twii/common/lib/component/CustomDetailsList";
import {IDetailsHeaderProps, DetailsHeader} from 'office-ui-fabric-react/lib/components/DetailsList/DetailsHeader';
import {delay} from "rxjs/internal/operators";
import {ISelection} from "office-ui-fabric-react/lib/Selection";
import {IKeyboardShortcutsService, IRegisteredShortcuts} from "../../service/KeyboardShortcuts.service";
import {KeyCodes} from "@uifabric/utilities";

interface ClientRiskOverviewListTableProps extends ICustomDetailsListProps<IDealing> {
    autoScroll;
    selectedDealing: IDealing;
    groupByApplicationId: (dealings: IDealing[]) => IDealing[];
    keyboardShortcutKeysService: IKeyboardShortcutsService;
}

@observer
class ClientRiskOverviewListTable extends React.Component<ClientRiskOverviewListTableProps, any> {
    @observable private _tableRef: CustomDetailsList<IDealing>;
    @observable private _currentTableScrollPosition: number;
    private _detailsListComponentRef: DetailsListBase;

    @computed
    private get _selectedRowId() {
        const selectedDealing = this.props.selectedDealing;
        if (selectedDealing) {
            return `irp-interaction-${selectedDealing.applicationId}`
        }
    };

    componentWillReceiveProps(props: ClientRiskOverviewListTableProps) {
        if (props.autoScroll && props.autoScroll !== this.props.autoScroll) {
            const tableSelectionObj = this._tableRef["_selection"] as ISelection;
            if (this._tableRef) {
                this._scrollToSelectedRow(tableSelectionObj.getSelection()[0] as IDealing, tableSelectionObj.getSelectedIndices()[0]);
            }
        }
        if (this.props.keyboardShortcutKeysService) {
            if (props.selectedDealing && this.props.selectedDealing && props.selectedDealing.key !== this.props.selectedDealing.key
                || (this.props.selectedDealing && !this.props.keyboardShortcutKeysService.isKeyRegistered({keyCode: KeyCodes.i}))) {
                this.registerHotKey(props.selectedDealing);
            }
        }
    }

    resetSort = () => {
        if (this._tableRef) {
            this._tableRef.setState({
                sortKey: null
            }, () => {
                this._tableRef._sortItems();
            });
            this.registerHotKey(this.props.selectedDealing)
        }
    };

    private _replaceSortFuncs = (ref: CustomDetailsList<IDealing>) => {
        if (!this._tableRef && ref && ref.textSort && ref.numberSort && ref.dateSort) {
            this._tableRef = ref;
            const textSortFunc = ref.textSort;
            const numberSortFunc = ref.numberSort;
            const dateSortFunc = ref.dateSort;
            ref.textSort = () => {
                return this.props.groupByApplicationId(textSortFunc());
            };
            ref.numberSort = () => {
                return this.props.groupByApplicationId(numberSortFunc());
            };
            ref.dateSort = () => {
                return this.props.groupByApplicationId(dateSortFunc());
            };
        }
        if (this._tableRef && !this._detailsListComponentRef) {
            this._detailsListComponentRef = this._tableRef.detailsListComponentRef;
        }
    };

    private registerHotKey = (selectedDealing: IDealing) => {
        if (selectedDealing && this._detailsListComponentRef) {
            const items = this._tableRef.getViewItems();
            const index = items.findIndex((i: IDealing) => i.key === selectedDealing.key);
            const keyboardShortcutKeysRef = this.props.keyboardShortcutKeysService;
            if (keyboardShortcutKeysRef) {
                const shortcutObject: IRegisteredShortcuts = {
                    keyCode: KeyCodes.i,
                    shortcutFunction: () => {
                        this._detailsListComponentRef.focusIndex(index);
                    }
                };
                keyboardShortcutKeysRef.registerShortcut(shortcutObject);
            }
        }
    };

    private _onRenderHeader = (headerProps: IDetailsHeaderProps) => {
        let appWidth = 0;
        let clientWidth = 0;
        let matchWidth = 0;
        headerProps.columns.forEach((col, index) => {
            if (col.className && col.className.indexOf("ande-irp-dealings-list--application-section") !== -1)
                appWidth += col.calculatedWidth + 20; //16px padding
            if (col.className && col.className.indexOf("ande-irp-dealings-list--client-section") !== -1)
                clientWidth += col.calculatedWidth + 20; //16px padding
            if (col.className && col.className.indexOf("ande-irp-dealings-list--matchSummary-section") !== -1)
                matchWidth += col.calculatedWidth + 20; //16px padding
        });

        return (
            <div>
                <div className="header-title">
                    <div className={css("ande-irp-dealings-list--application")} style={{width: appWidth}}>
                        <h3>Applications</h3>
                    </div>
                    <div className={css("ande-irp-dealings-list--client")} style={{width: clientWidth}}>
                        <h3>Clients</h3>
                    </div>
                    <div className={css("ande-irp-dealings-list--matchSummary")} style={{width: matchWidth}}>
                        <h3>Match Status Summaries</h3>
                    </div>
                </div>
                <DetailsHeader {...headerProps} />
            </div>
        )
    };

    private _onRenderRow = (props: IDetailsRowProps, defaultRenderer) => {
        const selectedDealing: IDealing = this.props.selectedDealing;
        const isSelectedClient = props.item.isSelectedClient;
        const isSelectedDealing = selectedDealing && props.item.applicationId === selectedDealing.applicationId;
        const c1 = isSelectedClient ? css("ande-irp-dealings-list--primary") : css("ande-irp-dealings-list--secondary");
        const c2 = isSelectedDealing ? "is-selected" : "not-selected";
        const selectedRowId = this._selectedRowId;
        const selectedRowIdNoDot = selectedRowId.replace(/\./g, "");
        const c3 = isSelectedClient && isSelectedDealing ? selectedRowIdNoDot : "";
        const c4 = props.itemIndex === 0 ? "scrollRef" : "";
        props.className = css(props.className, c1, c2, c3, c4);

        return defaultRenderer(props);
    };

    private _scrollToSelectedRow = (item: IDealing, index: number) => {
        if (this._selectedRowId && this._tableRef && this._tableRef.scrollablePaneRef) {
            const selectedRowId = this._selectedRowId;
            const selectedRowIdNoDot = selectedRowId.replace(/\./g, "");
            const selectedRow: HTMLElement = document.querySelector(`.client-risk-overview-list .${selectedRowIdNoDot}`);
            const scrollRefRow: HTMLElement = (this._tableRef.scrollablePaneRef as ScrollablePaneBase).root;
            if (selectedRow && scrollRefRow) {
                const scrollPosition = selectedRow.offsetTop - scrollRefRow.offsetTop;
                this._scrollTo(scrollRefRow, scrollPosition, 100);
                this._scrollTo(scrollRefRow, scrollPosition, 500);
            }
        }
    };

    private _autoScroll = (item: IDealing, index: number) => {
        // checking if the last row is mounted
        if (index === this.props.items.length - 1) {
            this._scrollToSelectedRow(item, index)
        }
    };

    private _scrollTo = (c: HTMLElement, amount: number, delayMS) => {
        const s = new Subject();
        s.pipe(delay(delayMS)).subscribe(() => {
            c.scrollTop = amount;
            this._tableRef.scrollablePaneRef.forceLayoutUpdate();
        });
        s.next();
    };

    render() {
        const items = this.props.groupByApplicationId(this.props.items);
        const selectedDealing = this.props.selectedDealing;
        const selectedItems = [selectedDealing];

        return <CustomDetailsList
            {...this.props}
            items={items}
            selectedItems={selectedItems}
            layoutMode={DetailsListLayoutMode.justified}
            constrainMode={ConstrainMode.unconstrained}
            compact={true}
            checkboxVisibility={CheckboxVisibility.hidden}
            selectionMode={SelectionMode.single}
            checkboxType={CheckboxType.square}
            stickyHeader={true}
            selectionPreservedOnEmptyClick={true}
            ref={ref => this._replaceSortFuncs(ref)}
            onRenderDetailsHeader={this._onRenderHeader}
            onRenderRow={this._onRenderRow}
            onRowDidMount={this._autoScroll}
            ariaLabelForGrid="Client interactions"
            sortTriggered={() => {
                this.registerHotKey(this.props.selectedDealing)
            }}/>
    }
}

export {
    ClientRiskOverviewListTable as default,
    ClientRiskOverviewListTable,
    ClientRiskOverviewListTableProps
}