import * as React from "react";
import {observer} from "mobx-react";
import {Label} from "office-ui-fabric-react/lib/Label";
import "./ClientRiskCheckTreatments--advice.scss";
import {ITreatmentAdvices} from "../model/IGetTreatmentAdvicesService";
import {SyncContainer} from "../../shared/SyncContainer";
import {ICodeSet} from "../model/IGetCodeSetService";
import {Link} from "office-ui-fabric-react/lib/Link"
import {Icon} from "office-ui-fabric-react/lib/Icon";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {saveAs} from "file-saver";
import * as StringUtils from "@twii/common/lib/util/String";
import "./ClientRiskCheckTreatments--advice-attachments.scss";

interface IClientRiskCheckTreatmentsAdviceProps {
    data: ITreatmentAdvices;
    attachmentsCodeSet: ICodeSet;
    host: IAppHost
}

@observer
class ClientRiskCheckTreatmentsAdviceAttachments extends React.Component<IClientRiskCheckTreatmentsAdviceProps, any> {
    private _onClickAttachment = (e: React.MouseEvent<HTMLElement>, content: string, downloadFileName: string) => {
        e.preventDefault();
        const blob = new Blob([content], {type: "text/plain;charset=utf-8"});
        saveAs(blob, downloadFileName, true);
    };

    private _onRenderDoneAttachments = () => {
        const attachmentsCodeSet = this.props.attachmentsCodeSet;
        let attachments: JSX.Element[] = [];

        this.props.data.items.map((treatmentAdvice, i) => {
            const attachmentData = attachmentsCodeSet.getDescByCd(treatmentAdvice.treatmentId);

            if (attachmentData) {
                const attachmentDataSplit = attachmentData.split("\n");
                const detailsItem = attachmentDataSplit && attachmentDataSplit.length > 0 ? attachmentDataSplit.find(i => i.startsWith("Details=")) : "";
                const detailsArr = detailsItem ? detailsItem.split("=") : [];
                const detail = detailsArr && detailsArr.length > 0 ? detailsArr[1] : "";

                const extraItem = attachmentDataSplit && attachmentDataSplit.length > 0 ? attachmentDataSplit.find(i => i.startsWith("Extra=")) : "";
                const extraArr = extraItem ? extraItem.split("=") : [];
                const extra = extraArr && extraArr.length > 0 ? extraArr[1] : "";

                const trimDocname = detail || extra ? detail + " - " + extra : "";
                const downloadFileName = StringUtils.isNotBlank(detail) ? detail + ".tr5" : "";
                const attachmentLink = <div key={i}><Link href="#" onClick={(e) => {
                    this._onClickAttachment(e as React.MouseEvent<HTMLElement>, attachmentData, downloadFileName)
                }} download={downloadFileName}>{StringUtils.isNotBlank(trimDocname) ? trimDocname : ""}</Link></div>;
                attachments.push(attachmentLink);
            }
        });
        return <div className="ande-client-risk-check-treatments--advices-attachments-wrapper">
            <Label><Icon iconName="Attach"/><b>Treatment attachments</b></Label>
            <div className="ande-client-risk-check-treatments--advices-attachments">
                {attachments}
            </div>
        </div>
    };

    render() {
        return <SyncContainer host={this.props.host}
                              sync={this.props.attachmentsCodeSet.sync}
                              onRenderDone={this._onRenderDoneAttachments}/>
    }
}

export {
    ClientRiskCheckTreatmentsAdviceAttachments as default,
    ClientRiskCheckTreatmentsAdviceAttachments,
    IClientRiskCheckTreatmentsAdviceProps
}
