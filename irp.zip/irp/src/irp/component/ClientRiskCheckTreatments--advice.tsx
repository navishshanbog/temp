import * as React from "react";
import {observer} from "mobx-react";
import {Label} from "office-ui-fabric-react/lib/Label";
import "./ClientRiskCheckTreatments--advice.scss";
import {ITreatmentAdvices} from "../model/IGetTreatmentAdvicesService";
import {ICodeSet} from "../model/IGetCodeSetService";
import {Icon} from "office-ui-fabric-react/lib/Icon";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {ClientRiskCheckTreatmentsAdviceAttachments} from "./ClientRiskCheckTreatments--advice-attachments";
import {SyncContainer} from "../../shared/SyncContainer";
import {IRPExternalLinksModel, ValidIRPLinksSystemCodes} from "../model/IRPExternalLinksModel";

interface IClientRiskCheckTreatmentsAdviceProps {
    data: ITreatmentAdvices;
    attachmentsCodeSet: ICodeSet;
    host: IAppHost;
    irpState?: any;
}


/*

<div className="ms-Grid">
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-md8">


 */
@observer
class ClientRiskCheckTreatmentsAdvice extends React.Component<IClientRiskCheckTreatmentsAdviceProps, any> {
    private _onClickAttachment = (e: React.MouseEvent<HTMLElement>, content: string) => {
        e.preventDefault();
        const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
        saveAs(blob, "Attachment.tr5", true);
    };
    private _onRenderDoneAdvices = () => {
        const linkGenerator = new IRPExternalLinksModel(ValidIRPLinksSystemCodes.gois);
        const linkContent = linkGenerator.generateLink({
            applicationId: this.props.irpState._selectedDealing.applicationId,
            idType: this.props.irpState._selectedDealing.sourceSystemCode,
            linkText: "Entity Match Summary"});

        return (
            <div className="ms-Grid">
                <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-md8 ande-client-risk-check-treatments--advices" style={{borderWidth: "0px 1px 0px 0px", borderStyle: "solid", color: "black'"}}>
                        <Label><Icon iconName="Info" /><b> Treatment advice</b></Label>
                        <div className="ande-client-risk-check-treatments--advices-advice">
                            {this.props.irpState.selectedRiskMatch && this.props.irpState.selectedRiskMatch.goisResult ?
                                <p>{linkContent}</p> : null}
                            {this.props.data.items.map((advice, i) => <p
                                key={i}>{advice.adviceText}</p>)}
                        </div>
                    </div>
                    <div className="ms-Grid-col ms-md4">
                        <ClientRiskCheckTreatmentsAdviceAttachments {...this.props} />
                    </div>
                </div>
            </div>
        )
/*        return (
            <div className="ande-client-risk-check-treatments--advices">
                <Label><Icon iconName="Info" /> Treatment Advice</Label>
                <div className="ande-client-risk-check-treatments--advices-advice">
                    {this.props.data.items.map((advice, i) => <p
                        key={i}>{advice.adviceText}</p>)}
                </div>
                <ClientRiskCheckTreatmentsAdviceAttachments {...this.props} />
            </div>
        )*/
    };

    render() {
        return <SyncContainer host={this.props.host}
                              sync={this.props.data.sync}
                              onRenderDone={this._onRenderDoneAdvices}/>
    }
}

export {
    ClientRiskCheckTreatmentsAdvice as default,
    ClientRiskCheckTreatmentsAdvice,
    IClientRiskCheckTreatmentsAdviceProps
}
