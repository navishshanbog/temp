import * as React from "react";
import {observer} from "mobx-react";
import {PrimaryButton, DefaultButton, IconButton} from "office-ui-fabric-react/lib/Button";
import {TextField} from "office-ui-fabric-react/lib/TextField";
import * as StringUtils from "@twii/common/lib/util/String";
import {Subject} from "rxjs";
import {debounceTime, map} from "rxjs/internal/operators";
import {observable} from "mobx";
import {css} from "@uifabric/utilities";
import "./ClientRiskCheckTreatments--actionButtons.scss";
import "./ClientRiskCheckTreatments--actionButtons-other-text-field.scss";


interface IClientRiskCheckTreatmentsActionButtonsOtherTextFieldProps {
    onSave: (readon: string) => void;
    onCancel: () => void;
    dismissalValueWarning?: boolean;
}

@observer
class ClientRiskCheckTreatmentsActionButtonsOtherTextField extends React.Component<IClientRiskCheckTreatmentsActionButtonsOtherTextFieldProps, any> {
    @observable private _dismissalReason = "";
    @observable private _textTypeSubj: Subject<string> = new Subject();
    @observable private _errorMsg = "";

    private _onchange = (val: string) => {
        this._textTypeSubj.next(val);
    };

    componentDidMount() {
        this._textTypeSubj.pipe(debounceTime(250), map(x => x));
        this._textTypeSubj.subscribe((txt: string) => {
            if (txt.length > 50) {
                this._errorMsg = "Maximum character allowed is 50";
                this.forceUpdate();
            } else {
                this._errorMsg = "";
                this._dismissalReason = txt;
            }
        });
    }

    render() {
        let textStyle = this.props.dismissalValueWarning ? "dismissal-reason--other-text-warning" : "";
        return <div className="dismissal-reason--other">
            <div className="dismissal-reason--other-actions">
                <TextField value={this._dismissalReason}
                           onChanged={this._onchange}
                           placeholder={"Dismissal Reason"}
                           className={css(`dismissal-reason--other-text-field ${textStyle}`)}
                           maxLength={50}/>
                <PrimaryButton className="dismissal-reason--other-btn"
                               ariaDescription="save"
                               iconProps={{iconName: "Accept"}}
                               disabled={this._dismissalReason.length > 50 || StringUtils.isBlank(this._dismissalReason)}
                               onClick={() => {
                                   this.props.onSave(this._dismissalReason)
                               }}/>
                <DefaultButton className="dismissal-reason--other-btn"
                               ariaDescription="cancel"
                               iconProps={{iconName: "Cancel"}}
                               onClick={this.props.onCancel}/>
            </div>
            <div className={css("dismissal-reason--other-msg", this._errorMsg ? "error" : "")}>
                {`${this._dismissalReason.length} of 50 characters`}
                {this._errorMsg && ` - ${this._errorMsg}`}
            </div>
        </div>
    }
}

export {
    ClientRiskCheckTreatmentsActionButtonsOtherTextField as default,
    ClientRiskCheckTreatmentsActionButtonsOtherTextField,
    IClientRiskCheckTreatmentsActionButtonsOtherTextFieldProps
}
