/*
import * as React from "react";
import {css, KeyCodes} from "@uifabric/utilities";
import {observer} from "mobx-react";
import {ClientRiskCheckTreatmentsAdvice} from "./ClientRiskCheckTreatments--advice";
import {ClientRiskCheckTreatmentsNotes} from "./ClientRiskCheckTreatments--notes";
import {ClientRiskCheckTreatmentsActions} from "./ClientRiskCheckTreatments--actions";
import {SectionTitleBar} from "../../shared/SectionTitleBar";
import {IGetTreatmentNotesServiceResItem} from "../model/IGetTreatmentNotesService";
import {IGetTreatmentHistoryServiceResItem} from "../model/IGetTreatmentHistoryService";
import * as moment from "moment";
import {ISyncModel} from "@twii/common/lib/ISyncModel"
import {
    IClientRiskMatch
} from "../model/IRRClientRiskMatchesServiceResponseItem";
import "./ClientRiskCheckTreatments.scss"
import {IButtonProps} from "office-ui-fabric-react";
import {observable} from "mobx";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import * as StringUtils from "@twii/common/lib/util/String";
import {ValidRiskMatchViewStatus} from "../../shared/RiskMatchValidValues";
import { ClientRiskCheckDetailsDetailedView } from "./ClientRiskCheckDetails--DetailedView";
import {ClientRiskItem} from "./ClientRiskCheckDetails--table";

const sectionTitle = "Actioned Risks";

interface IMatchLogItem {
    userId: string;
    text: string;
    timestamp: string;
}

interface IClientRiskTreatmentsActionedProps extends IAppletProps {
    hotKeysService ?: any;
}



@observer
class ClientRiskTreatmentsActioned extends React.Component<IClientRiskTreatmentsActionedProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    @observable _filters: ("notes" | "logs")[] = ["notes", "logs"];
    @observable _showDetails: boolean = false;
    private showClientDetails: IClientRiskMatch;

    private _onClosePanel = (e : React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();
        e.preventDefault();
        this._showDetails = false;
        this._IRPStore.selectedRiskMatch = null;
        this.showClientDetails = null;

    }

    private showSelectedClientItemDetails = (clientItem?: IClientRiskMatch, visible?: boolean) => {
        this._showDetails = visible;
        this._IRPStore.selectedRiskMatch = clientItem;
        this.showClientDetails = clientItem;
    }


    render() {
        const attachmentsCodeSet = this._IRPStore.attachmentsCodeSet;
        const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
        const treatmentAdvices = this._IRPStore.treatmentAdvices;
        const treatmentNotes: IMatchLogItem[] = this._IRPStore.treatmentNotes.items.map((note: IGetTreatmentNotesServiceResItem) => {
            return {
                userId: note.userId,
                text: note.text,
                timestamp: note.noteTs
            }
        });
        const treatmentHistory: IMatchLogItem[] = this._IRPStore.treatmentHistory.items.map((revision: IGetTreatmentHistoryServiceResItem) => {
            return {
                userId: revision.revisionUser,
                text: revision.action,
                timestamp: revision.revisionTs
            }
        });
        const treatmentMatchEvalCaseDetails = this._IRPStore.matchEvalCaseDetails;
        const selectedDealing = this._IRPStore.getSelectedDealing();

        let matchLog = this._filters.indexOf("notes") > -1 ? treatmentNotes : [];
        matchLog = this._filters.indexOf("logs") > -1 ? matchLog.concat(treatmentHistory) : matchLog;
        matchLog = matchLog.sort((a, b) => {
            const momentA = moment(a.timestamp).unix();
            const momentB = moment(b.timestamp).unix();
            return momentB > momentA ? 1 : -1;
        });

        const matchLogSync: ISyncModel = this._IRPStore.treatmentNotes.sync.syncing || this._IRPStore.treatmentHistory.sync.error ? this._IRPStore.treatmentNotes.sync : this._IRPStore.treatmentHistory.sync;

        const breadcrumbItems = [];
        if (selectedDealing) breadcrumbItems.push(`Client: ${this._IRPStore.clientRiskOverview.data.lastName}, ${this._IRPStore.clientRiskOverview.data.firstName}`, `Interaction: ${selectedDealing.applicationId} (${selectedDealing.sourceSystemCode})`);
        if (selectedRiskMatch) breadcrumbItems.push(`Risk Match: ${selectedRiskMatch.riskNumber} - ${selectedRiskMatch.riskName}`);
        //let actionedRiskItems = this._IRPStore.clientRiskMatches.items.filter(item => !((item.riskAssessmentOutcome == null &&
        //    item.riskActionable) || StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.underThreatEval)))

        let actionedRiskItems = this._IRPStore.clientRiskMatches.items.filter(item => (
            ((item.riskAssessmentOutcome != null  || !item.riskActionable) &&
                !(StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.underThreatEval) ||
                    StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.untreated) ||
                    StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.inProgress)))
        ));

        
        const riskMatchList =<div className="risk-match-container">
            {this._IRPStore.clientRiskMatches.items.map((item, i) => {
                return ((item.riskAssessmentOutcome != null  || !item.riskActionable) &&
                (!(StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.untreated) ||
                    StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.underThreatEval) ||
                    StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.inProgress) )))  ? <ClientRiskItem
                    key={i} clientItem ={item} 
                    irpState={this._IRPStore}
                    showNotes={true}
                    showSelectedClientItemDetails = {this.showSelectedClientItemDetails}
                    host={this.props.host}/> : null;
            })
            } </div>

        const iconName = this._IRPStore.clientRiskMatches.getFiltered() ? "IncidentTriangle" : "Completed";
        const iconColorClass = this._IRPStore.clientRiskMatches.getFiltered() ? "icon-color-class-orange" : "icon-color-class-blue";

        return selectedRiskMatch ? (
            <div className="ande-treatments">
                <SectionTitleBar title={sectionTitle +` (${actionedRiskItems.length})`}  iconName={iconName} className={iconColorClass} />
                {riskMatchList}
                <ClientRiskCheckDetailsDetailedView showDetails={this._showDetails} irpState={this._IRPStore}
                                                    hotKeysService={this.props.hotKeysService} host={this.props.host} onClose={() => this._onClosePanel}/>

            </div>
        ) : null;
    }
}

export {
    ClientRiskTreatmentsActioned as default,
    ClientRiskTreatmentsActioned,
    IMatchLogItem,
    IClientRiskTreatmentsActionedProps
}
*/