import * as React from "react";
import {observer} from "mobx-react";
import {ProgressIndicator} from "office-ui-fabric-react/lib/ProgressIndicator";
import "./ClientRiskCheckTreatments--actionButtons.scss";
import {IClientRiskCheckTreatmentsHotKeysService} from "./ClientRiskCheckTreatments--hotKeys.service";
import {SyncContainer} from "../../shared/SyncContainer";
import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {computed, observable} from "mobx";
import {Icon} from "office-ui-fabric-react/lib/Icon";
import {ServiceErrorMessages} from "../../shared/ServiceErrorMessages";
import {css} from "@uifabric/utilities";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import {ClientRiskMatch} from "../model/IRRClientRiskMatchesServiceResponseItem";


interface ClientRiskCheckTreatmentsActionButtonsMessagesProps extends IAppletProps {
    resultId?: string;
    hotKeysService?: IClientRiskCheckTreatmentsHotKeysService
}

enum messages {
    default = "Select risk match status.",
    sync = "Updating please wait...",
    done = "Risk match status updated.",
    error = "Error updating.",
    reaction = "Risk match status needs to be reactioned",
    empty = "Select risk match status"
}

@observer
class ClientRiskCheckTreatmentsActionButtonsMessages extends React.Component<ClientRiskCheckTreatmentsActionButtonsMessagesProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    @observable private _sync: ISyncModel;
    private _classNamePrefix = "ande-client-risk-check-treatments";
    private resultIDD = this.props.resultId;

    @computed
    private get _item(): ClientRiskMatch {
        const riskMatches = this._IRPStore.clientRiskMatches;
        return riskMatches.items.find(i => i.resultId === this.props.resultId);
    }

    componentWillMount() {
        this._sync = this._IRPStore.updateTreatmentRequest.syncList.addSync(this.props.resultId);
    };

    componentWillUnmount() {
        this._IRPStore.updateTreatmentRequest.syncList.removeSync(this.props.resultId);
    }

    private _onSyncDefault = () => {
        let wrapperClassName = `${this._classNamePrefix}--action-buttons-messages`;
        let msg = null;
        if (this._item) {
            if (this._item.reassessmentWarning) {
                wrapperClassName = `${this._classNamePrefix}--action-buttons-messages-reaction`;
                msg = (
                    <>
                        <div className={css(`${this._classNamePrefix}--action-buttons-messages-icon`)}>
                            <Icon iconName="Info" className={`${this._classNamePrefix}--action-buttons-messages-icon`}/>
                        </div>
                        <div className={css(`${this._classNamePrefix}--action-buttons-messages-text`)}>
                            <span>{messages.reaction}</span>
                        </div>
                    </>
                )
            } /*else {
                msg = messages.default;
            }*/
        }

        return <span className={css(wrapperClassName)}>{msg}</span>;
    };

    private _onSyncSync = () => {
        return <div className={`${this._classNamePrefix}--action-buttons-messages`}>
            <span>{messages.sync}</span>
            <ProgressIndicator/>
        </div>;
    };
    private _onSyncDone = () => {
        return <div className={`${this._classNamePrefix}--action-buttons-messages-done`}>
            <div className={css(`${this._classNamePrefix}--action-buttons-messages-icon`)}>
                <Icon iconName="Completed" className={`${this._classNamePrefix}--action-buttons-messages-icon`}/>
            </div>
            <div className={css(`${this._classNamePrefix}--action-buttons-messages-text`)}>
                <span className="client-risk-check-treatment-status-changed">{messages.done}</span>
            </div>
        </div>;
    };

    private _onSyncError = (e) => {
        return <div className={`${this._classNamePrefix}--action-buttons-messages-error`}>
            <div className={css(`${this._classNamePrefix}--action-buttons-messages-icon`)}>
                <Icon iconName="Error"/>
            </div>
            <div className={css(`${this._classNamePrefix}--action-buttons-messages-text`)}>
                <ServiceErrorMessages status={e.response.status} host={this.props.host}/>
            </div>
        </div>;
    };

    render() {
        return <div className={`${this._classNamePrefix}--action-buttons-messages`}>
            <SyncContainer host={this.props.host}
                           sync={this._sync}
                           onRenderError={this._onSyncError}
                           onRenderDefault={this._onSyncDefault}
                           onRenderSync={this._onSyncSync}
                           onRenderDone={this._onSyncDone}/>
        </div>
    }
}

export {
    ClientRiskCheckTreatmentsActionButtonsMessages as default,
    ClientRiskCheckTreatmentsActionButtonsMessages
}
