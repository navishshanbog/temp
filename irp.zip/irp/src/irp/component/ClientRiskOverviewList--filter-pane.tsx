import * as React from "react";

import {observer} from "mobx-react";
import {TextField} from "office-ui-fabric-react/lib/TextField";
import {IconButton} from "office-ui-fabric-react/lib/Button";
import {css} from "office-ui-fabric-react/lib/";
import {Subject} from "rxjs/Subject";
import {debounceTime} from "rxjs/operators/debounceTime";
import {map} from "rxjs/operators/map";
import * as moment from "moment";
import {observable} from "mobx";
import {IDateRangeFilterModel} from "../../shared/DateRangeFilter";

import "./ClientRiskOverviewList--filter-pane.scss"

interface IClientRiskOverviewListFilterPaneProps {
    freeTextFilter: (filterText: string) => void;
    milestoneDateFilter: (matchDateFilter: IDateRangeFilterModel) => void;
}

const filterPaneClassNamePrefix = "ande-irp-risk-overview-list-filter-pane";

@observer
class ClientRiskOverviewListFilterPane extends React.Component<IClientRiskOverviewListFilterPaneProps, any> {
    private _filterSubject = new Subject();
    private _matchDateSubject = new Subject();
    @observable private _matchDateFilter: IDateRangeFilterModel = {
        from: null,
        to: null
    };
    @observable private _filterText = "";

    componentDidMount() {
        this._filterSubject
            .pipe(debounceTime(250), map(value => value.toString()))
            .subscribe((filterText: string) => {
                this.props.freeTextFilter(filterText);
            });
        this._matchDateSubject
            .pipe(debounceTime(250), map(() => {
                return (!this._matchDateFilter.from && !this._matchDateFilter.to)
                    ? {
                        from: null,
                        to: null
                    }
                    : {
                        from: moment(this._matchDateFilter.from).isValid() ? moment(this._matchDateFilter.from) : moment(),
                        to: moment(this._matchDateFilter.to).isValid() ? moment(this._matchDateFilter.to) : moment()
                    };
            }))
            .subscribe((matchDateFilter) => {
                this.props.milestoneDateFilter(matchDateFilter);
            });
    };

    reset(props: IClientRiskOverviewListFilterPaneProps) {
        this._matchDateFilter = {
            from: null,
            to: null
        };
        this._filterText = "";
        this._matchDateSubject.next(this._matchDateFilter);
        this._filterSubject.next(this._filterText);
        this.forceUpdate();
    }

    private _onChanged = val => {
        this._filterSubject.next(val);
    };

    private _clearTxtFilter = e => {
        e.preventDefault();
        this._filterText = "";
        this._filterSubject.next("");
        this.forceUpdate();
    };

    render() {
        return <div className={css("ms-Grid-row", `${filterPaneClassNamePrefix}`)}>
            <div className={`ms-Grid-col ms-md12 ${filterPaneClassNamePrefix}--free-text-filter`}>
                <TextField className={`${filterPaneClassNamePrefix}--textField`} onChanged={this._onChanged}
                           label="Filter:" placeholder="Filter interactions" value={this._filterText}/>
                <IconButton iconProps={{iconName: "Cancel"}}
                            ariaLabel="filter interactions"
                            className={`${filterPaneClassNamePrefix}--free-text-filter-button`}
                            onClick={this._clearTxtFilter}/>
            </div>
        </div>
    }
}

export {
    ClientRiskOverviewListFilterPane as default,
    ClientRiskOverviewListFilterPane,
    IClientRiskOverviewListFilterPaneProps
}
