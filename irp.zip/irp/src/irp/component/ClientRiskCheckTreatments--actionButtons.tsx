import * as React from "react";
import {observer} from "mobx-react";
import {IButtonProps} from "office-ui-fabric-react/lib/Button";
import { ValidRiskMatchViewStatus} from "../../shared/RiskMatchValidValues";
import {computed, observable, reaction} from "mobx";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import "./ClientRiskCheckTreatments--actionButtons.scss";
import {ClientRiskCheckTreatmentsActionButtonsMessages} from "./ClientRiskCheckTreatments--actionButtons-messages";
import * as StringUtils from "@twii/common/lib/util/String";
import {ClientRiskCheckTreatmentsActionButtonsOtherTextField} from "./ClientRiskCheckTreatments--actionButtons-other-text-field";
import {ClientRiskCheckTreatmentsActionButtonsService} from "./ClientRiskCheckTreatments--actionButtons.service";
import {ClientRiskCheckTreatmentsActionButtonsOverlay} from "./ClientRiskCheckTreatments--actionButtons-overlay";
import {ClientRiskCheckTreatmentsActionButtonsActions} from "./ClientRiskCheckTreatments--actionButtons-actions";
import {IClientRiskMatch} from "../model/IRRClientRiskMatchesServiceResponseItem";
import {isArray} from "@twii/common/lib/util/Lang";
import {IClientRiskCheckTreatmentsHotKeysService} from "./ClientRiskCheckTreatments--hotKeys.service";
import {KeyCodes} from "@uifabric/utilities";

interface IClientRiskCheckTreatmentsActionButtonsProps extends IAppletProps {
    resultId: string;
    hotKeysService: IClientRiskCheckTreatmentsHotKeysService;
    enableIfActionable?: boolean;
    userToIPNotes?: boolean;
    updateClientRisks?:(canAddNote?: boolean)=> void;
    overlayMsgFlag?: boolean;
    setDimissalEntry?:(isDismissalValueRequired?: boolean) => void;
    dismissalValueWarning?: boolean;
}

@observer
class ClientRiskCheckTreatmentsActionButtons extends React.Component<IClientRiskCheckTreatmentsActionButtonsProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    private _actionBtnsService = new ClientRiskCheckTreatmentsActionButtonsService();
    @observable _itemViewStatus: ValidRiskMatchViewStatus;
    @observable private _dismissalReason: string = "";
    @observable _isDismissalReasonEntryRequired = false;
    private resultID = this.props.resultId;

    constructor(props) {
        super(props);
        reaction(() => {
            const riskMatches = this._IRPStore.clientRiskMatches;
            const riskMatch = riskMatches.items.find(i => i.resultId === this.props.resultId);
            const viewStatus = riskMatch ? riskMatch.viewStatus : undefined;
            return viewStatus;
        }, (viewStatus) => {
            this._getItemViewStatus()
        });
        this._getItemViewStatus();
        const _keyboardShortcutsService = this._IRPStore.getViewModel().keyboardShortcutsService;
        _keyboardShortcutsService.registerShortcut({
            keyCode: KeyCodes.p,
            preventDefault: true,
            shortcutFunction: (e) => {
                const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
                if (selectedRiskMatch && selectedRiskMatch.riskActionable) {
                    _keyboardShortcutsService.simulateKeyCode(KeyCodes.m);
                    this._actionBtnsService.updateRRS(ValidRiskMatchViewStatus.inProgress, undefined, this._IRPStore, selectedRiskMatch).catch(e => {
                        this._getItemViewStatus();
                    });
                }
            }
        });
        _keyboardShortcutsService.registerShortcut({
            keyCode: KeyCodes.openBracket,
            preventDefault: true,
            shortcutFunction: (e) => {
                const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
                if (selectedRiskMatch && selectedRiskMatch.riskActionable) {
                    _keyboardShortcutsService.simulateKeyCode(KeyCodes.m);
                    this._actionBtnsService.updateRRS(ValidRiskMatchViewStatus.confirmed, undefined, this._IRPStore, selectedRiskMatch).catch(e => {
                        this._getItemViewStatus();
                    });
                }
            }
        });
    }

    @computed
    private get _item(): IClientRiskMatch {
        const riskMatches = this._IRPStore.clientRiskMatches;
        return riskMatches.items.find(i => i.resultId === this.props.resultId);
    }

    private _getItemViewStatus() {
        this._itemViewStatus = null;
        const riskMatches = this._IRPStore.clientRiskMatches;
        const riskMatch = riskMatches.items.find(i => i.resultId === this.props.resultId);
        this._itemViewStatus = riskMatch ? riskMatch.viewStatus : undefined;
    }

    private _cancelDismissalReason = () => {
        this._isDismissalReasonEntryRequired = false;
        this.props.setDimissalEntry(false);
    };

    private _saveDismissalReason = (reason: string) => {
        this._actionBtnsService.saveOtherReasonAsNote(reason, this._item, this._IRPStore).then(() => {
            this._actionBtnsService.updateRRS(ValidRiskMatchViewStatus.dismissed, reason, this._IRPStore, this._item).then(() => {
                this._isDismissalReasonEntryRequired = false;
                this.props.setDimissalEntry(false);
                this.props.updateClientRisks(true);
            }).catch(e => {
                this._isDismissalReasonEntryRequired = false;
                this.props.setDimissalEntry(false);
            })
        });
    };

    private _onChanged = (selectedItems: IButtonProps[]) => {
        const selectedItem = isArray(selectedItems) ? selectedItems[0] : null;
        if (selectedItem && selectedItem.uniqueId) {
            const isOtherReasonSelected = StringUtils.equalsIgnoreCase("other", selectedItem.data || "");
            if (!isOtherReasonSelected) {
                const riskMatches = this._IRPStore.clientRiskMatches;
                const riskMatch = riskMatches.items.find(i => i.resultId === this.props.resultId);
                //const riskMatchIndex = riskMatches.items.findIndex(i => i.resultId === this.props.resultId);
                this._IRPStore.selectedRiskMatch = riskMatch;
                //const newCode = getCdByDesc
                this._actionBtnsService.updateRRS(selectedItem.uniqueId as ValidRiskMatchViewStatus, selectedItem.data, this._IRPStore, this._item, this.props.userToIPNotes)
                    .catch(e => {
                        this._getItemViewStatus();
                    })
                .then(res => {
                    this.resultID = riskMatch.resultId;
                    this.props.updateClientRisks(true);
                })
            } else if (isOtherReasonSelected) {
                this.props.setDimissalEntry(true);
                this._isDismissalReasonEntryRequired = true;

            }
        }
    };

    private _setActionButtonRefs = (refs) => {
        if(this.props.hotKeysService) {
            this.props.hotKeysService.addBtnRefs({
                resultId: this.props.resultId,
                defaultDismissBtnRef: refs.defaultBtnRef,
                primaryDismissBtnRef: refs.primaryBtnRef
            })
        }
    };

    shouldComponentUpdate(nextProps) {
        return true;
    }

    render() {
        const _dismissBtnProps = this._actionBtnsService.getDismissButtonProps(this._item, this._IRPStore.dismissalReasons, this._onChanged);
        const itemViewStatus = this._itemViewStatus;
        const actionButtons = !this._isDismissalReasonEntryRequired
            ? <ClientRiskCheckTreatmentsActionButtonsActions {...this.props}
                                                             dismissButtonProps={_dismissBtnProps}
                                                             buttonGroupItems={this._actionBtnsService.getButtonGroupItems(this._item)}
                                                             selectedKey={itemViewStatus}
                                                             onChanged={this._onChanged}
                                                             setRefs={this._setActionButtonRefs}/>
            : <ClientRiskCheckTreatmentsActionButtonsOtherTextField onSave={this._saveDismissalReason}
                                                                    dismissalValueWarning = {this.props.dismissalValueWarning}
                                                                    onCancel={this._cancelDismissalReason}/>
        return (
            <div className="ande-client-risk-check-treatments--action-buttons">
                <div className="ande-client-risk-check-treatments--action-buttons-actions risk-match-container-action-buttons-position">
                        { actionButtons }
                    {(this.props.overlayMsgFlag || this.props.enableIfActionable)? <ClientRiskCheckTreatmentsActionButtonsMessages {...this.props}/> : null}
                    <ClientRiskCheckTreatmentsActionButtonsOverlay {...this.props} resultId={this.resultID} enableIfActionable={this.props.enableIfActionable}/>

                </div>
            </div>
        )
    }
}

export {
    ClientRiskCheckTreatmentsActionButtons as default,
    ClientRiskCheckTreatmentsActionButtons,
    IClientRiskCheckTreatmentsActionButtonsProps
}
