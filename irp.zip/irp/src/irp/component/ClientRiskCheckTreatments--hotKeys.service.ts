import {IIRPStoreModel} from "../../service/IIRPStoreModel";
import {BaseButton} from "office-ui-fabric-react";
import {IKeyboardShortcutsService} from "../../service/KeyboardShortcuts.service";
import {KeyCodes} from "@uifabric/utilities";


interface IRiskMatchTreatmentBtnRef {
    resultId: string;
    defaultDismissBtnRef: BaseButton,
    primaryDismissBtnRef: BaseButton
}

interface IClientRiskCheckTreatmentsHotKeysService {
    findBtnRefsByResultId: (resultId: string) => number;
    getBtnRefsByResultId: (resultId: string) => IRiskMatchTreatmentBtnRef;
    hasBtnRefAdded: (resultId: string) => boolean;
    addBtnRefs: (refs: IRiskMatchTreatmentBtnRef) => IRiskMatchTreatmentBtnRef[];
}

class ClientRiskCheckTreatmentsHotKeysService implements IClientRiskCheckTreatmentsHotKeysService {
    private _btnRefs: IRiskMatchTreatmentBtnRef[] = [];
    private _IRPStore: IIRPStoreModel;
    private readonly _keyboardShortcutsService: IKeyboardShortcutsService;
    private _hotKeyCodes = {
        dismiss: KeyCodes.closeBracket
    };

    constructor(store: IIRPStoreModel) {
        this._IRPStore = store;
        this._keyboardShortcutsService = this._IRPStore.getViewModel().keyboardShortcutsService;
        if (this._keyboardShortcutsService) {

            this._keyboardShortcutsService.registerShortcut({
                keyCode: this._hotKeyCodes.dismiss,
                preventDefault: true,
                shortcutFunction: (e) => {
                    const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
                    if (selectedRiskMatch && selectedRiskMatch.riskActionable) {
                        const resultId = selectedRiskMatch.resultId;
                        if (this.hasBtnRefAdded(resultId)) {
                            this._keyboardShortcutsService.simulateKeyCode(KeyCodes.m);
                            setTimeout(() => {
                                const btnRefs = this.getBtnRefsByResultId(resultId);

                                if (btnRefs.primaryDismissBtnRef) {
                                    btnRefs.primaryDismissBtnRef.openMenu()
                                } else if (btnRefs.defaultDismissBtnRef) {
                                    btnRefs.defaultDismissBtnRef.openMenu()
                                }
                            }, 200)
                        }
                    }
                }
            });


        }
    }

    findBtnRefsByResultId = (resultId: string): number => {
        return this._btnRefs.findIndex(i => i.resultId === resultId);
    };

    getBtnRefsByResultId = (resultId: string): IRiskMatchTreatmentBtnRef => {
        return this._btnRefs.find(i => i.resultId === resultId);
    };

    hasBtnRefAdded = (resultId: string): boolean => {
        return this._btnRefs.findIndex(i => i.resultId === resultId) > -1;
    };

    addBtnRefs = (refs: IRiskMatchTreatmentBtnRef): IRiskMatchTreatmentBtnRef[] => {
        const resultId = refs.resultId
        if (this.hasBtnRefAdded(resultId)) {
            this._btnRefs.splice(this.findBtnRefsByResultId(resultId), 1, refs);
        } else {
            this._btnRefs.push(refs);
        }
        return this._btnRefs;
    };
}

export {
    ClientRiskCheckTreatmentsHotKeysService as default,
    ClientRiskCheckTreatmentsHotKeysService,
    IClientRiskCheckTreatmentsHotKeysService,
    IRiskMatchTreatmentBtnRef
}