import * as React from "react";

import {observer} from "mobx-react";
import {PrimaryButton, DefaultButton} from "office-ui-fabric-react/lib/Button";
import {Label} from "office-ui-fabric-react/lib/Label";
import {TextFieldBase, TextField, ITextField} from "office-ui-fabric-react/lib/TextField";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";
import "./ClientRiskCheckTreatments--actions.scss";
import {SyncContainer} from "../../shared/SyncContainer";
import {Icon} from "office-ui-fabric-react/lib/Icon";
import {IMatchEvalCaseDetails} from "../model/IGetMatchEvalCaseDetailsService";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import * as moment from "moment";
import {Output as DateFormats} from "@twii/common/lib/DateFormats";
import {computed} from "mobx";
import {KeyCodes} from "@uifabric/utilities";

interface IClientRiskCheckTreatmentsActionsProps extends IAppletProps {
    matchEvalCase: IMatchEvalCaseDetails;
}

@observer
class ClientRiskCheckTreatmentsActions extends React.Component<IClientRiskCheckTreatmentsActionsProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    private _IRPStoreViewModel = this._IRPStore.getViewModel();
    private _textFieldRef: TextFieldBase;

    private _setTextFieldRef = (ref: TextFieldBase) => {
        this._textFieldRef = ref;
        const keyboardShortcutService = this._IRPStoreViewModel.keyboardShortcutsService;
        if (keyboardShortcutService) {
            keyboardShortcutService.registerShortcut({
                keyCode: KeyCodes.s,
                shortcutFunction: (e) => {
                    const isTextFieldFocused = this._textFieldRef.state.isFocused;
                    if (isTextFieldFocused && this._IRPStore.treatmentsNotes.isDirtyTreatmentNote(this._IRPStore.selectedRiskMatch.resultId)) {
                        this._onAddNote();
                    }
                }
            });
            keyboardShortcutService.registerShortcut({
                keyCode: KeyCodes.o,
                shortcutFunction: (e) => {
                    if (this._textFieldRef) {
                        const textFieldElement = document.querySelector(`#${this._textFieldRef.props.id}`);
                        const irpAppletMainPanel = document.querySelector(".irp-applet--main-panel");
                        if (textFieldElement && irpAppletMainPanel) {
                            if (irpAppletMainPanel.scroll) {
                                irpAppletMainPanel.scroll({top: textFieldElement.getBoundingClientRect().top});
                            }
                        }
                        this._textFieldRef.focus();
                    }
                }
            });
        }
    };

    componentWillUnmount() {
        const keyboardShortcutService = this._IRPStoreViewModel.keyboardShortcutsService;
        if (keyboardShortcutService) {
            keyboardShortcutService.unRegisterShortcut({
                keyCode: KeyCodes.o
            });
        }
    }

    @computed
    private get _selectedRiskMatch() {
        return this._IRPStore.selectedRiskMatch;
    }

    _onClearNoteInput = () => {
        //this._textFieldRef. = "";
        this._IRPStore.treatmentsNotes.removeTreatmentNote(this._selectedRiskMatch.resultId);
    };
    _onAddNote = () => {
        const treatment = this._IRPStore.treatmentsNotes.findTreatmentById(this._selectedRiskMatch.resultId);
        this._IRPStore.saveNote(treatment);
    };

    _onRenderDone = () => {
        const dueDate = this.props.matchEvalCase.data.dueDate ? moment(this.props.matchEvalCase.data.dueDate).format(DateFormats.riskResumeDate) : "";
        const allocatedGroup = `Assessment Due: ${dueDate}\n`
            + `Case ID: ${this.props.matchEvalCase.data.caseId}\n`
            + `Unit: BIFC\n`
            + `Email: BIFC@homeaffairs.gov.au\n`
            + `Phone: (02) 6278 9898\n`;
        return <TextField label="Current Allocated Workgroup"
                          value={allocatedGroup}
                          disabled={true}
                          inputClassName="ande-client-risk-check-treatments--actions-allocated-workgroup-textbox"
                          resizable={false}
                          multiline={true}/>
    };

    render() {
        const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
        const renderOverlay = () => {
            const onRenderSync = () => (
                <div className="ande-client-risk-check-treatments--actions-add-note-overlay">
                    <div className="ande-client-risk-check-treatments--actions-add-note-overlay-back"/>
                    <div className="ande-client-risk-check-treatments--actions-add-note-overlay-content">
                        <Spinner/>Note is being saved, please wait...
                    </div>
                </div>
            );

            const onRenderError = e => (
                <div className="ande-client-risk-check-treatments--actions-add-note-overlay-error">
                    <div className="ande-client-risk-check-treatments--actions-add-note-overlay-back"/>
                    <div className="ande-client-risk-check-treatments--actions-add-note-overlay-content">
                        <div className="ande-client-risk-check-treatments--actions-add-note-overlay-icon"><Icon
                            iconName="ErrorBadge"/></div>
                        <div>Error in saving note!</div>
                        <div>
                            <PrimaryButton text="Close" onClick={this._IRPStore.treatmentsNotes.notes.sync.syncEnd}/>
                        </div>
                    </div>
                </div>
            );

            return this._IRPStore.treatmentsNotes.notes.sync.id === selectedRiskMatch.resultId
                ? <SyncContainer host={this.props.host}
                                 sync={this._IRPStore.treatmentsNotes.notes.sync}
                                 onRenderSync={onRenderSync}
                                 onRenderDone={() => null}
                                 onRenderError={onRenderError}/>
                : null;
        };

        const _unsavedNoteWarning = this._IRPStore.treatmentsNotes.isDirtyTreatmentNote(selectedRiskMatch.resultId) ?
            <span className="ande-client-risk-check-treatments--actions-add-note-actions-warning">Unsaved entry, please save... </span>
            : null;

        const _onChanged = (note: string) => {
            if (note && note !== "") {
                this._IRPStore.treatmentsNotes.editTreatmentNote(selectedRiskMatch.resultId, note);
            } else {
                this._IRPStore.treatmentsNotes.removeTreatmentNote(selectedRiskMatch.resultId);
            }
        };
        const treatmentUnsavedNote = this._IRPStore.treatmentsNotes.getTreatmentNote(selectedRiskMatch.resultId);
        const isDisabled = !selectedRiskMatch.riskActionable;
        const areBtnsDisabled = isDisabled || !treatmentUnsavedNote || treatmentUnsavedNote === "";
        return (
            <div className="ande-client-risk-check-treatments--actions ms-Grid" style={{display: "block"}}>
                <div className="ms-Grid-row ande-client-risk-check-treatments--actions-add-note">
                    <div className="ms-Grid-col ms-md12">
                        <div className="ms-Grid-row">
                            {renderOverlay()}
                            <div className="ms-Grid-col ms-md12 ande-client-risk-check-treatments--actions-add-label-note">
                                <Label htmlFor="addTreatmentAdviceNote"><Icon iconName="EditNote"/> <b> Add new match note</b></Label>
                                <TextField id="addTreatmentAdviceNote"
                                           name="addTreatmentAdviceNote"
                                           componentRef={this._setTextFieldRef}
                                           disabled={isDisabled}
                                           inputClassName="ande-client-risk-check-treatments--actions-add-note-text-box"
                                           multiline={true}
                                           onChanged={_onChanged}
                                           maxLength={4000}
                                           value={this._IRPStore.treatmentsNotes.getTreatmentNote(selectedRiskMatch.resultId) || ""}/>

                            </div>
                        </div>
                        <div style={{width:"100%"}}>
                            <div style={{float:"left", width:"20%"}}>
                                <DefaultButton
                                    disabled={areBtnsDisabled}
                                    ariaLabel="clear note"
                                    className="ande-client-risk-check-treatments--actions-add-note-actions-clear-btn"
                                    text="Clear"
                                    iconProps={{ iconName: "Clear"}}
                                    onClick={this._onClearNoteInput}/>
                            </div>
                            <div style={{float:"left", width:"60%", textAlign: "center"}}>
                                {_unsavedNoteWarning}
                            </div>
                            <div style={{float:"right", width:"20%"}}>
                                <PrimaryButton
                                    disabled={areBtnsDisabled}
                                    ariaLabel="save note"
                                    className="ande-client-risk-check-treatments--actions-add-note-actions-add-btn"
                                    text="Save"
                                    iconProps={{ iconName: "Save"}}
                                    onClick={this._onAddNote}/>
                            </div>
                        </div>
                        {/*<div className="ms-Grid-row">
                            <div
                                className="ms-Grid-col ms-md12 ande-client-risk-check-treatments--actions-add-note-actions">
                                <DefaultButton
                                    disabled={areBtnsDisabled}
                                    ariaLabel="clear note"
                                    className="ande-client-risk-check-treatments--actions-add-note-actions-clear-btn"
                                    text="Clear"
                                    iconProps={{ iconName: "Clear"}}
                                    onClick={this._onClearNoteInput}/>
                                <PrimaryButton
                                    disabled={areBtnsDisabled}
                                    ariaLabel="save note"
                                    className="ande-client-risk-check-treatments--actions-add-note-actions-add-btn"
                                    text="Save"
                                    iconProps={{ iconName: "Save"}}
                                    onClick={this._onAddNote}/>
                                {_unsavedNoteWarning}
                            </div>
                        </div>*/}
                    </div>
                </div>
                {/*<div className="ms-Grid-row">*/}
                {/*<div className="ms-Grid-col ms-md12">*/}
                {/*<SyncContainer sync={this.props.matchEvalCase.sync} onRenderDone={this._onRenderDone}/>*/}
                {/*</div>*/}
                {/*</div>*/}
                {/*<div className="ms-Grid-row">*/}
                {/*<div className="ms-Grid-col ms-md12">*/}
                {/*<TextField label="Risk Treatment Owner"*/}
                {/*value={owner}*/}
                {/*disabled={true}*/}
                {/*inputClassName="ande-client-risk-check-treatments--actions-risk-owner-textbox"*/}
                {/*resizable={false}*/}
                {/*multiline={true}/>*/}

                {/*</div>*/}
                {/*</div>*/}

            </div>
        )
    }
}

export {
    ClientRiskCheckTreatmentsActions as default,
    ClientRiskCheckTreatmentsActions,
    IClientRiskCheckTreatmentsActionsProps
}
