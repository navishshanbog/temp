import * as React from "react";
import CodeSet from "@twii/common/lib/CodeSet";
import {dataTextToInputMoment} from "@twii/common/lib/util/Date";
import {Output as DateFormats} from "@twii/common/lib/DateFormats"
import "./ClientBio.scss";
import {RiskSummaryField} from "../../shared/RiskSummaryField";
import {IRPExternalLinksModel, ValidIRPLinksSystemCodes} from "../model/IRPExternalLinksModel";
import {IClientSummaryServiceIdentifiers} from "../model/IClientSummaryService";
import {IClientDetailsModel} from "./ClientRiskOverviewSummary";
import {Label} from "office-ui-fabric-react/lib/Label";

interface IClientBioProps {
    clientDetails: IClientDetailsModel;
    identifiers: IClientSummaryServiceIdentifiers;
}

const GenderCd = new CodeSet({
    "M": "Male",
    "F": "Female"
});

class ClientBio extends React.Component<IClientBioProps, any> {
    private get _cspLink() {
        const ids = this.props.identifiers;
        let idType;
        let id: string;
        if (ids && ids.ICSEClientId && ids.ICSEClientId.length > 0) {
            idType = "CID";
            id = ids.ICSEClientId[0]
        } else if (ids && ids.TRIPSPersonId && ids.TRIPSPersonId.length > 0) {
            idType = "TRIPS";
            id = ids.TRIPSPersonId[0]
        }
        return new IRPExternalLinksModel(ValidIRPLinksSystemCodes.csp).generateLink({
            idType: idType,
            id: id,
            linkText: `${this.props.clientDetails ? (this.props.clientDetails.lastName ? this.props.clientDetails.lastName : "") : ""}, 
            ${this.props.clientDetails  ? (this.props.clientDetails.firstName ? this.props.clientDetails.firstName : "") : ""} (CSP)`, 
            ariaLabelText: "Client full name"
        });
    }

    render() {
        const clientDetails = this.props.clientDetails;
        return (
            <div className="client-bio-container">
                <div className="client-bio-title ms-Grid-row">
                    <div className="ms-Grid-col ms-md12">
                        {this._cspLink}
                    </div>
                </div>
                <div className="client-bio ms-Grid-row">
                    <div className="ms-Grid-col ms-md12">
                        <RiskSummaryField label="Gender:"
                                          value={clientDetails.genderCode && GenderCd.getDesc(clientDetails.genderCode)}/>
                        <RiskSummaryField label="DOB:"
                                          value={clientDetails.dob && dataTextToInputMoment(clientDetails.dob).format(DateFormats.riskResumeDate)}/>
                        <RiskSummaryField label="COB:" value={clientDetails.cob}/>
                        <RiskSummaryField label="Citizenships:"
                                          value={clientDetails.citizenships && clientDetails.citizenships.join(", ")}/>
                        <RiskSummaryField label="COR:" value={clientDetails.cor}/>
                    </div>
                </div>
            </div>
        )
    }
}

export {
    ClientBio as default,
    ClientBio,
    IClientBioProps
}