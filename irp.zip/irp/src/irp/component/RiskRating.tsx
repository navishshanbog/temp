import * as React from "react";
import { css } from "office-ui-fabric-react/lib/Utilities";
import "./RiskRating.scss";

interface IRiskRatingProps {
    riskLevelCode: string;
    label: string;
}

class RiskRating extends React.Component<IRiskRatingProps, any> {
    render() {
        let className = `risk-rating-${this.props.riskLevelCode.toLowerCase() || 'default'}`;
        let content = `${this.props.label} : ${this.props.riskLevelCode}`;
        return <div className={css("risk-rating", className)}>{content}</div>;
    }
}

export { RiskRating as default, RiskRating, IRiskRatingProps }