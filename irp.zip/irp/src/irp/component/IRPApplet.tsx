import * as React from "react";
import IAppletProps from "@twii/common/lib/IAppletProps";
import ClientRiskOverview from "./ClientRiskOverview";
import {ClientRiskOverviewList} from "./ClientRiskOverviewList";
import {observer} from "mobx-react";
import {IRPStoreModel} from "../../service/IRPStoreModel";
import {IRPSearchSearchCommandBar} from "../../search/component/IRPSearch--command-bar";
import {IIRPSimpleSearchRequest} from "../../search/model/IIRPSimpleSearchRequest";
import {IIRPSimpleSearchRequestModel} from "../../search/model/IIRPSimpleSearchRequestModel";
import {IIRPRiskSearchRequestModel} from "../../search/model/IIRPRiskSearchRequestModel";
import {ClientRiskCheckDetails} from "./ClientRiskCheckDetails";
import {initiateMock} from "../../mock/rrsMock";
import {initiateMock as cieMock} from "../../mock/cieMock";
//import {ClientRiskTreatmentsActioned} from "./ClientRiskTreatmentsActioned";
import "../../shared/IRPGlobal.scss";
import {IRPAppHostWrapper} from "./IRPAppHostWrapper";
import {css} from "@uifabric/utilities";
import {IIRPStoreModel, IIRPStoreViewModel} from "../../service/IIRPStoreModel";
import {CollapsableLayout} from "../../shared/CollapsableLayout";
import {CollapsableLayoutLeft} from "../../shared/CollapsableLayout--left";
import {CollapsableLayoutRight} from "../../shared/CollapsableLayout--right";
import QuickLinks from "../../shared/QuickLinks";

const title = "Integrated Risk Portal";
const IRPAppletClassName = "irp-applet";

interface IIRPAppletParams extends IAppletProps {
    urlParams?: IIRPSimpleSearchRequest
}

@observer
class IRPApplet extends React.Component<IIRPAppletParams, any> {
    private _IRPStore: IIRPStoreModel;
    private _IRPStoreViewModel: IIRPStoreViewModel;
    simpleSearchRequest: IIRPSimpleSearchRequestModel;
    riskSearchRequest: IIRPRiskSearchRequestModel;

    componentWillMount() {
        if (!this.props.host.state.irpState) {
            this.props.host.setState({
                irpState: new IRPStoreModel()
            });
            if (window.location.href.indexOf("ciemock") > -1) {
                cieMock();
            }
            if (window.location.href.indexOf("rrsmock") > -1) {
                initiateMock();
            }
        }

        this.props.host.title = title;

        this._IRPStore = this.props.host.state.irpState;
        this._IRPStoreViewModel = this._IRPStore.getViewModel();
        this.simpleSearchRequest = this._IRPStore.simpleSearchRequest;
        this.riskSearchRequest = this._IRPStore.riskSearchRequest;
        this._IRPStore.activateKeyboardShortcutsService(this.props.host);
    }

    componentDidMount() {
        //Handling url parameters
        if (this.props.urlParams && this.props.urlParams.idType && this.props.urlParams.referenceNumber) {
            this.simpleSearchRequest.setRequest(this.props.urlParams);
            this._IRPStore.setViewModel({rootElementSelector: `.${IRPAppletClassName}`});
            this._IRPStore.applySearch().then(() => {

                this.props.host.title = `IRP - ${this._IRPStore.clientRiskOverview? 
                    this._IRPStore.clientRiskOverview.data ? 
                        this._IRPStore.clientRiskOverview.data.fullName?  this._IRPStore.clientRiskOverview.data.fullName: "": "" :"" }`;
            })
        } else {
            this._IRPStore.routeToIRPSearchApplet(this.props.host);
        }
    }

    render() {
        let content = null;

        const isLeftPanelOpen = this._IRPStoreViewModel.isLeftPanelOpen;
        const irpBrandingClassName = this.props.host.root ? `${IRPAppletClassName}--app-is-root` : "";

        if (this.props.host.state.irpState) {
            content = <div className={css(IRPAppletClassName, " ms-Grid")}>
                <CollapsableLayout leftWidthPercent={23}
                                   collapseButtonWidthPixel={15}
                                   isLeftPanelOpen={isLeftPanelOpen}>
                    <CollapsableLayoutLeft>
                        <ClientRiskOverview
                            urlParams={this.props.urlParams}{...this.props} />
                    </CollapsableLayoutLeft>
                    <CollapsableLayoutRight>
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-md12">
                                <ClientRiskOverviewList {...this.props}/>
                            </div>
                            <div className="ms-Grid-col ms-md12">
                                <ClientRiskCheckDetails {...this.props}/>
                            </div>
                            {/*<div className="ms-Grid-col ms-md12">
                                <ClientRiskCheckTreatments {...this.props}/>
                                <ClientRiskTreatmentsActioned {...this.props} />
                            </div>*/}
                        </div>
                    </CollapsableLayoutRight>
                </CollapsableLayout>
            </div>
        }

        return <IRPAppHostWrapper host={this.props.host}
                                  className={`${IRPAppletClassName}--wrapper ${irpBrandingClassName} section-containers`}
                                  title={title}
                                  hideHelp={false}>
            <div className="irp-applet-top" style={{display: "flex"}}>
                <IRPSearchSearchCommandBar {...this.props}
                                       simpleSearchRequest={this.simpleSearchRequest}
                                       riskSearchRequest={this.riskSearchRequest}/>
                <QuickLinks />
            </div>
            <div className="ms-Grid">{content}</div>
        </IRPAppHostWrapper>;
    }
}

export {
    IRPApplet as default,
    IRPApplet,
    IIRPAppletParams
}