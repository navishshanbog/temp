import * as React from "react";
import { css } from "@uifabric/utilities/lib/css";
import {IAppHostWrapperProps} from "@twii/common/lib/component/AppHostWrapper";
import {IRPAppWrapper} from "./IRPAppWrapper";

/**
 * This is a convenience wrapper for wrapping a context based component in an
 * application wrapper if need be.
 */
class IRPAppHostWrapper extends React.Component<IAppHostWrapperProps, any> {
    render() {
        if(this.props.host.root) {
            return <IRPAppWrapper {...this.props}>{this.props.children}</IRPAppWrapper>;
        }
        return <div className={css("app-host-wrapper", this.props.className)}>{this.props.children}</div>;
    }
}

export { IRPAppHostWrapper as default, IRPAppHostWrapper}