import * as React from "react";
import {observer} from "mobx-react";
import {MessageBar, MessageBarType} from "office-ui-fabric-react/lib/MessageBar";
import {css, IContextualMenuItem} from "office-ui-fabric-react/lib";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";
import {IDealing} from "../model/IDealings";
import {SyncContainer} from "../../shared/SyncContainer";
import IAppletProps from "@twii/common/lib/IAppletProps";
import {ClientRiskOverviewListFilterPane} from "./ClientRiskOverviewList--filter-pane";
import {IDateRangeFilterModel} from "../../shared/DateRangeFilter";
import {computed, observable} from "mobx";
import "./ClientRiskOverviewList.scss";
import {SyncingOverlay} from "../../shared/SyncingOverlay";
import {SectionTitleBar, BreadCrumbItem} from "../../shared/SectionTitleBar";
import {ClientRiskOverviewListTable} from "./ClientRiskOverviewList--table";
import {ClientRiskOverviewListService} from "./ClientRiskOverviewList.service";
import {IClientRiskOverviewData} from "../model/ClientRiskOverviewModel";
import {IIRPStoreModel, IIRPStoreViewModel} from "../../service/IIRPStoreModel";
import * as StringUtils from "@twii/common/lib/util/String";
import clonedeep from "lodash.clonedeep";
import {Icon} from "office-ui-fabric-react/lib/Icon";
import {ServiceErrorMessages} from "../../shared/ServiceErrorMessages";

const detailsTitle = "Interactions";

@observer
class ClientRiskOverviewList extends React.Component<IAppletProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    @observable filterTerm: string;
    @observable mileStoneDateFilter: IDateRangeFilterModel;
    private iconName;
    private iconColorClass;
    private _autoScroll = null;
    private _clientRiskOverviewListService = new ClientRiskOverviewListService(this.props.host);
    private _tableColumns = this._clientRiskOverviewListService.columns;
    private _filterPaneRef;
    private _tableRef;
    @observable updatedfilteredItems : IDealing[];

    @computed
    private get filteredItems(): IDealing[] {
        const filterTerm = this.filterTerm;
        const mileStoneDateFilter = this.mileStoneDateFilter;
        const filterItems = this._clientRiskOverviewListService.getFilteredItems(this._IRPStore, filterTerm, mileStoneDateFilter);
        let updatedfilteredItems : IDealing[] = [];

        const clientBios = this._IRPStore.clientBiographics && this._IRPStore.clientBiographics.sync.hasSynced ? this._IRPStore.clientBiographics : null;
        const clientBiosData = clientBios && clientBios.data ? clientBios.data : null;
        const clientBiosLastName = clientBiosData && clientBiosData.lastName ? clientBiosData.lastName : "";
        const clientBiosFirstName = clientBiosData && clientBiosData.firstName ? clientBiosData.firstName : "";
        const clientBiosFullName = `${clientBiosLastName}, ${clientBiosFirstName}`;

        if(filterItems && filterItems.length > 0) {
            updatedfilteredItems = filterItems.map(i => {
                let dealing = clonedeep(i);
                dealing.cid = i.cid ? i.cid : null;
                dealing.pid = i.pid ? i.pid : null;
                dealing.iid = i.iid ? i.iid : null;
                dealing.vgn = i.vgn ? i.vgn : null;

                if (StringUtils.isNotBlank(i.fullName)) {
                    const theOtherFullName = `${i.fullName} (${StringUtils.isNotBlank(i.vRAClientRole) ? i.vRAClientRole : ""})`;
                    dealing.setFullName(theOtherFullName);
                } else {
                    if (clientBiosFullName) {
                        const theFullName = `${clientBiosFullName} (${StringUtils.isNotBlank(i.vRAClientRole) ? i.vRAClientRole : ""})`;
                        dealing.setFullName(theFullName);
                    }
                }
                return dealing;
            });
        }

        return updatedfilteredItems;
    };

    private _freeTextFilter = (filterTerm: string) => {
        this.filterTerm = filterTerm;
    };

    private _mileStoneDateFilter = (mileStoneDateFilter: IDateRangeFilterModel) => {
        this.mileStoneDateFilter = mileStoneDateFilter;
    };

    private _onSelectedItemsChange = (items: IDealing[]) => {
        const selectedDealing = items[0];
        const currentlySelectedDealing = this._IRPStore.getSelectedDealing();
        if (selectedDealing) {
            if (selectedDealing.isSelectedClient && (!currentlySelectedDealing || (currentlySelectedDealing.key !== selectedDealing.key))) {
                this._IRPStore.selectDealing(selectedDealing);
            } else if (!selectedDealing.isSelectedClient) {
                const dealingToSelect = this.filteredItems.find(d => {
                    return d.isSelectedClient && d.applicationId === selectedDealing.applicationId
                });
                if (dealingToSelect) {
                    this._IRPStore.selectDealing(dealingToSelect);
                }
                this.forceUpdate();
            }
        }
    };

    private _resetSortFilter = () => {
        this._tableColumns = this._clientRiskOverviewListService.columns.map(col => {
            col.isSorted = false;
            return col
        });

        this.filterTerm = "";
        this._clientRiskOverviewListService.applyInitialSorting(this.filteredItems);

        if (this._filterPaneRef) {
            this._filterPaneRef.reset();
        }
        if (this._tableRef) {
            this._tableRef.resetSort();
        }
    };

    _onRenderDone = () => {
        let selectedDealing = this._IRPStore.getSelectedDealing();
        if (!selectedDealing) selectedDealing = this.filteredItems.find(d => d.isSelectedClient);
        if (selectedDealing && !selectedDealing.isSelectedClient) {
            selectedDealing = this.filteredItems.find(d => d.isSelectedClient && d.applicationId === selectedDealing.applicationId);
        }

        let content;

        if (this._IRPStore.dealings.items.length as number === 0) {
            content = <MessageBar messageBarType={MessageBarType.warning}>No interactions found.</MessageBar>;
        } else {
            content = <ClientRiskOverviewListTable
                items={this.filteredItems}
                className={css("ande-irp-dealings-list")}
                columns={this._tableColumns}
                selectedDealing={selectedDealing}
                selectedItemsChanged={this._onSelectedItemsChange}
                autoScroll={this._autoScroll}
                groupByApplicationId={this._clientRiskOverviewListService.groupByApplicationId}
                wrapperMaxHeight={185}
                ref={ref => {
                    if (ref) this._tableRef = ref
                }}
                keyboardShortcutKeysService={this._IRPStore.getViewModel().keyboardShortcutsService}/>
        }

        const filteredItemsLength = this._clientRiskOverviewListService.groupByApplicationId(this.filteredItems).length;
        const dealingsGroup = this._clientRiskOverviewListService.groupByApplicationId;
        const itemsLength = this._IRPStore.dealings.total;
        const lastName = (this._IRPStore.clientRiskOverview && this._IRPStore.clientRiskOverview.data && this._IRPStore.clientRiskOverview.sync.hasSynced 
        && this._IRPStore.clientRiskOverview.data.lastName) ? this._IRPStore.clientRiskOverview.data.lastName : "";
        const firstName = (this._IRPStore.clientRiskOverview && this._IRPStore.clientRiskOverview.data && this._IRPStore.clientRiskOverview.sync.hasSynced 
            && this._IRPStore.clientRiskOverview.data.firstName) ? this._IRPStore.clientRiskOverview.data.firstName : "";
        const fullName = `${lastName}, ${firstName}`;
        const _breadcrumbItems:  BreadCrumbItem[] = selectedDealing
            ? [{label: "Client", value: `${fullName}`, identifirer: "ande-irp-dealings-list"}] : [];
        const resultsCounts = filteredItemsLength === itemsLength
            ? ` ${itemsLength} Interactions`
            : ` ${filteredItemsLength} of ${itemsLength} interactions`;

        const sectionTitleBarItems: IContextualMenuItem[] = [
        {
            key: "resultsCounts",
            name: resultsCounts,
            id: "resultsCounts",
            className: filteredItemsLength !== itemsLength ? "client-risk-overview-list--results-count-alert" : "", 
            secondaryText: "Showing: "
        }, {
            key: "defaultSortFilter",
            name: "Interactions default view",
            onClick: () => this._resetSortFilter()
        }];
        const sectionTitleBarFarItems: IContextualMenuItem[] = [{
            key: "filterPane",
            name: "Filter by",
            className: "client-risk-overview-list--filter",
            onRender: () => <ClientRiskOverviewListFilterPane
                ref={ref => {
                    if (ref) this._filterPaneRef = ref
                }}
                freeTextFilter={this._freeTextFilter}
                milestoneDateFilter={this._mileStoneDateFilter}/>
        }];

        this.iconName = this._IRPStore.clientApplicationDealings.getFiltered()  ? "IncidentTriangle" : "ContactInfo";
        this.iconColorClass = this._IRPStore.clientApplicationDealings.getFiltered()  ? "icon-color-class-orange" : "icon-color-class-blue";
        return (
            <div>
                <SectionTitleBar title={detailsTitle}
                                 breadcrumbItems={_breadcrumbItems}
                                 items={sectionTitleBarItems}
                                 iconName={this.iconName}
                                 farItems={sectionTitleBarFarItems} 
                                 className={this.iconColorClass} />
                {content}
            </div>
        )
    };

    render() {
        const _onRenderSync = () => {
            return this._IRPStore.dealings.items.length > 0
                ? <SyncingOverlay onRenderContent={this._onRenderDone}/>
                : <div className="client-risk-overview-list">
                    <SectionTitleBar title={detailsTitle}/>
                    <Spinner className="sync-spinner" label="Loading"/>
                </div>
        };

        const _irpSyncContainerElementBefore = () => {
            return <div className="client-risk-overview-list">
                <SectionTitleBar title={detailsTitle}/>
            </div>
        };

        return <div className="client-risk-overview-list">
            <SyncContainer host={this.props.host}
                           sync={this._IRPStore.dealings.sync}
                           onRenderDone={this._onRenderDone}
                           onRenderDefault={() => null}
                           onRenderSync={_onRenderSync}
                           elementBefore={_irpSyncContainerElementBefore}/>
        </div>
    }
}


export {
    ClientRiskOverviewList as default,
    ClientRiskOverviewList
}