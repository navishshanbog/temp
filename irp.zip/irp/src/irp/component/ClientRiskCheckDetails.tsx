import * as React from "react";

import {observer} from "mobx-react";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";
import {IButtonProps} from "office-ui-fabric-react/lib/Button";
import {SyncContainer} from "../../shared/SyncContainer";
import {observable} from "mobx";
import {IDateRangeFilterModel} from "../../shared/DateRangeFilter";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import * as StringUtils from "@twii/common/lib/util/String";
import "./ClientRiskCheckDetails.scss"
import {SectionTitleBar, BreadCrumbItem} from "../../shared/SectionTitleBar";
import {ClientRiskCheckDetailsTable} from "./ClientRiskCheckDetails--table";
import {ValidRiskMatchStatus} from "../../shared/RiskMatchValidValues";
import {IContextualMenuItem} from "office-ui-fabric-react/lib/ContextualMenu";
import { ValidRiskMatchViewStatus } from "../../shared/RiskMatchValidValues";
import {MessageBarType, MessageBar} from "office-ui-fabric-react/lib/MessageBar";
import {ServiceErrorMessages} from "../../shared/ServiceErrorMessages";

const componentClassNamePrefix = "ande-irp-risk-check-details";

@observer
class ClientRiskCheckDetails extends React.Component<IAppletProps, any> {
    private _IRPState = this.props.host.state.irpState;
    private headerTitle: string;
    @observable filterTerm: string;
    @observable statusFilters: IButtonProps[];
    @observable matchDateFilter: IDateRangeFilterModel;
    @observable _showOverlay: boolean = false;
    private _dismissed: any[]= [];
    private _confirmed: any[] = [];
    private _breadcrumbItems: BreadCrumbItem[] = [];


    private _updateRisks = () => {
        this.forceUpdate();
    }

    render() {
        const _onRenderSync = () => {
            return <div className={componentClassNamePrefix}>
                <SectionTitleBar title={"Risk matches"}/>
                <Spinner className="sync-spinner" label="Loading"/>
            </div>
        };

        this._dismissed = this._IRPState.clientRiskMatches.items.filter(item => {
            // todo: remove the turn for filter.
            return (StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.dismissed) || StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchStatus.COMPLETED))
        })
        this._confirmed = this._IRPState.clientRiskMatches.items.filter(item => {
            return StringUtils.equalsIgnoreCase(item.viewStatus, ValidRiskMatchViewStatus.confirmed)
        });

        const _onRenderDone = () => {
            let _breadcrumbItems: BreadCrumbItem[] = [];
            
            this.headerTitle = "Risk matches";
            let items: IContextualMenuItem[] = [];
            const selectedDealing = this._IRPState.getSelectedDealing();
            if (selectedDealing) {
                const lastName = (this._IRPState.clientRiskOverview && this._IRPState.clientRiskOverview.data 
                    && this._IRPState.clientRiskOverview.sync.hasSynced 
                    && this._IRPState.clientRiskOverview.data.lastName) ? this._IRPState.clientRiskOverview.data.lastName : "";
                const firstName = (this._IRPState.clientRiskOverview && this._IRPState.clientRiskOverview.data 
                    && this._IRPState.clientRiskOverview.sync.hasSynced 
                    && this._IRPState.clientRiskOverview.data.firstName) ? this._IRPState.clientRiskOverview.data.firstName : "";
                const fullName = `${lastName}, ${firstName}`;
                _breadcrumbItems.push({label: "Client", value: `${fullName}`, identifirer: componentClassNamePrefix});
                _breadcrumbItems.push({label: "Interaction", value: selectedDealing.applicationId, identifirer: componentClassNamePrefix});

                const itemsLength = this._IRPState.clientRiskMatches.total;

                this.headerTitle = `${this.headerTitle} (${itemsLength})`
                items.push({
                    key: "resultsCount"
                });
            }

            const iconName = ( this._IRPState.clientRiskMatches.getFiltered()) ?
            "IncidentTriangle" : "TaskGroup";
            const iconColorClass = ( this._IRPState.clientRiskMatches.getFiltered()) ? 
            "icon-color-class-orange" : "icon-color-class-blue";

            return <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-md12">
                    <SectionTitleBar title={this.headerTitle} items={items} breadcrumbItems={_breadcrumbItems}
                    iconName={iconName} className={iconColorClass}/>

                    {/* Work in progress for Part 2 of UI design .. leave this commented out
                    <SectionTitleBar title={this.headerTitle} items={items} breadcrumbItems={breadcrumbItems}
                    iconName={iconName} className={iconColorClass} dismissedMatch={ this._dismissed.length}
                                     confirmedMatch={this._confirmed.length}/>*/}
                </div>
                <div className="ms-Grid-col ms-md12">
                    {
                        this._IRPState.clientRiskMatches.getServiceErrored() ? 
                        <MessageBar messageBarType={MessageBarType.error} title="One of the data services errored" >
                            Errors encountered in one of the match retrieval services.
                        </MessageBar>
                        : null
                        
                    }
                    
                    <ClientRiskCheckDetailsTable {...this.props} updateRisks={this._updateRisks} />
                </div>
            </div>
        };

        return <SyncContainer host={this.props.host}
                              sync={this._IRPState.clientRiskMatches.sync}
                              onRenderDone={_onRenderDone}
                              onRenderSync={_onRenderSync}
                              elementBefore={() => <SectionTitleBar title={this.headerTitle}/>}
                              onRenderDefault={() => null}/>
    }
}

export {
    ClientRiskCheckDetails as default,
    ClientRiskCheckDetails
}
