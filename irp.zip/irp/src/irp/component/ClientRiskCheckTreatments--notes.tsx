import * as React from "react";

import {observer} from "mobx-react";
import {Label} from "office-ui-fabric-react/lib/Label";
import "./ClientRiskCheckTreatments--notes.scss";
import {dataTimestampToOutputText} from "@twii/common/lib/util/Date";
import {SyncContainer} from "../../shared/SyncContainer";
import {IMatchLogItem} from "./ClientRiskCheckTreatments";
import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {Icon} from "office-ui-fabric-react/lib/Icon";
//import {ButtonGroup} from "@twii/common/lib/component/ButtonGroup";
import {ButtonGroup} from "../../irpcommon/ButtonGroup";
import {IButtonProps} from "office-ui-fabric-react/lib/Button";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {observable} from "mobx";

interface IClientRiskCheckTreatmentNotesProps {
    data: IMatchLogItem[];
    filterChanged: (selectedItems: IButtonProps[]) => string[];
    sync: ISyncModel;
    host: IAppHost
}

export {
    ClientRiskCheckTreatmentsNotes as default,
    ClientRiskCheckTreatmentsNotes,
    IClientRiskCheckTreatmentNotesProps
}

@observer
class ClientRiskCheckTreatmentsNotes extends React.Component<IClientRiskCheckTreatmentNotesProps, any> {
    @observable selectedKeys: string[] = ["logs", "notes"];

    private _filterChange = (selectedItems: IButtonProps[]) => {
        this.selectedKeys = this.props.filterChanged(selectedItems);
    };

    private _onRenderDone = () => {
        return <div className="ande-client-risk-check-treatments--notes">
            <div className="ande-client-risk-check-treatments--notes--label-wrapper">
                <Label><Icon iconName="CustomListMirrored"/> <b> Match log</b></Label>
            </div>
            {/*<ButtonGroup label="Filter" items={[{*/}
                {/*name: "Logs",*/}
                {/*text: "Logs",*/}
                {/*uniqueId: "logs"*/}
            {/*}, {*/}
                {/*name: "Notes",*/}
                {/*text: "Notes",*/}
                {/*uniqueId: "notes"*/}
            {/*}]} selectedKeys={[]} transition multiSelect />*/}
            <div className="ande-client-risk-check-treatments--notes-note">
                {this.props.data.map((note, i) => {
                    return <p key={i}>
                        {`${dataTimestampToOutputText(note.timestamp)} - ${note.userId}`}
                        <br/>
                        {note.text}
                    </p>
                })}
            </div>
        </div>
    };

    render() {
        return <SyncContainer host={this.props.host} sync={this.props.sync} onRenderDone={this._onRenderDone}/>
    }
}
