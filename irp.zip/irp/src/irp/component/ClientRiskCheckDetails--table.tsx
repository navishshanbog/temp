import * as React from "react";

import {observer} from "mobx-react";
//import {CheckboxType, CustomDetailsList, ICustomColumn, SortType} from "@twii/common/lib/component/CustomDetailsList";
import {CheckboxType, CustomDetailsList, ICustomColumn, SortType} from "../../irpcommon/CustomDetailsList";
import {CheckboxVisibility, SelectionMode, IDetailsRowProps} from "office-ui-fabric-react/lib/DetailsList";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";
import {IButtonProps} from "office-ui-fabric-react/lib/Button";
import {dataTimestampToOutputText} from "@twii/common/lib/util/Date";
import {observable} from "mobx";
import {ClientRiskCheckTreatmentsActionButtons} from "./ClientRiskCheckTreatments--actionButtons";
import {Icon} from "office-ui-fabric-react/lib/Icon";
import {ClientRiskCheckDetailsAlert} from "./ClientRiskCheckDetails--alert";
import {IDateRangeFilterModel} from "../../shared/DateRangeFilter";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import { DefaultButton } from 'office-ui-fabric-react/lib/Button';
import * as StringUtils from "@twii/common/lib/util/String";
import "./ClientRiskCheckDetails.scss";
import "./ClientRiskCheckDetails--table.scss";
import {
    IClientRiskMatch,
    IRRClientRiskMatchesServiceResponseItem
} from "../model/IRRClientRiskMatchesServiceResponseItem";
import {MessageBarType} from "office-ui-fabric-react/lib/MessageBar";
import {MessageBar} from "office-ui-fabric-react/lib/components/MessageBar";
import {IRPExternalLinksModel, ValidIRPLinksSystemCodes} from "../model/IRPExternalLinksModel";
import {SyncingOverlay} from "../../shared/SyncingOverlay";
import {ValidRiskMatchStatus} from "../../shared/RiskMatchValidValues";
import {css, KeyCodes} from "@uifabric/utilities";
import {SyncContainer} from "../../shared/SyncContainer";
import {DetailsListBase} from "office-ui-fabric-react/lib/DetailsList";
import {IRegisteredShortcuts} from "../../service/KeyboardShortcuts.service";
import {ClientRiskCheckTreatmentsHotKeysService} from "./ClientRiskCheckTreatments--hotKeys.service";
import { DocumentCard } from 'office-ui-fabric-react/lib/DocumentCard';
import { ValidRiskMatchViewStatus } from "../../shared/RiskMatchValidValues";
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import {ClientRiskCheckTreatmentsNotesActions} from "./ClientRiskCheckTreatments--NotesActions";
import {ClientRiskCheckTreatments} from "./ClientRiskCheckTreatments";
import {Label} from "office-ui-fabric-react/lib/Label";

const componentClassNamePrefix = "ande-irp-risk-check-details";

interface IClientRiskItem {
    clientItem?: IClientRiskMatch;
    irpState?: any;
    host?: any;
    hotKeyService?: any;
    showNotes?:boolean;
    updateClientRisks?: (canAddNote?: boolean) => void;
    overlayMsgFlag?: boolean;
    showSelectedClientItemDetails?:(clientItem?: IClientRiskMatch, visible?: boolean) => void;
    setDimissalEntry?:(isDismissalValueRequired?: boolean) => void;
}

@observer
class ClientRiskItem extends React.Component<IClientRiskItem, any> {

    cardClicked = () => {
        if(!this.props.clientItem.showNotesForUserIp) {
            this.props.showSelectedClientItemDetails(this.props.clientItem, true);
        }
    }

    allowChange  = () => {
        if(((StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.confirmed)
                || StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.dismissed)
                ||  StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchStatus.COMPLETED)) &&
                (this.props.clientItem.riskActionable)) && !this.props.clientItem.showNotesForUserIp)
            return true;
        return false;
    }

    private _updateClientRisks = (canAddNote: boolean) => {
        this.props.clientItem.showNotesForUserIp = canAddNote;
        this.props.clientItem.actionedByUser = canAddNote;
        this.forceUpdate();
    }

    render() {
        let content;
        let contentIconThreatMatch;
        let contentIconFilterPolarity;
        const titleFilterPolarity = this.props.clientItem.filterPolarity ?
            (this.props.clientItem.filterPolarity === "POSITIVE" ? "Positive analytic" : "Negative analytic") : null;
        const iconNameFilterPolarity = this.props.clientItem.filterPolarity ?
            (this.props.clientItem.filterPolarity === "POSITIVE" ? "ExploreContentSingle" : "CollapseContentSingle") : null;
        contentIconThreatMatch = <div className="risk-match-container-item-threat-match">
            <Icon key={`${this.props.clientItem.resultId}-threatMatchIcon`}
                  className={css(`${componentClassNamePrefix}-risk-name-threat-match-icon`)}
                  iconName="ReportHacked" ariaLabel="Threat Match" title="Threat Match"/>
        </div>;
        contentIconFilterPolarity = <div className="risk-match-container-item-filter-polarity">
            <Icon key={`${this.props.clientItem.resultId}-filterPolarityIcon`}
                  className={css(`${componentClassNamePrefix}-risk-name-filter-polarity-icon`)}
                  iconName={iconNameFilterPolarity} ariaLabel="Filter Polarity" title={titleFilterPolarity} />
        </div>;
        const showNoteIcon = this.props.clientItem.showNoteIcon ? true :
            ((this.props.clientItem.noteCount && this.props.clientItem.noteCount > 0) && this.props.showNotes ? true : false);

        if(showNoteIcon) {
            content = <div className="risk-match-container-item-note">
                <Icon key={`${this.props.clientItem.resultId}-notesIcon`}
                      className={css(`${componentClassNamePrefix}--risk-name-icon`)}
                      iconName="EditNote" ariaLabel="Notes Available" title="Notes Available"/>
            </div>;
        }
        var rNumber = this.props.clientItem.riskNumber;
        var rName = this.props.clientItem.riskName;
        var riskLinkText="";
        riskLinkText = rName;
        if(rNumber && rNumber.length > 0) {
            /*if(rNumber.length>40) {
                riskLinkText = rNumber.substring(0, 40);
                riskLinkText = StringUtils.isBlank(riskLinkText) ? "" : `${riskLinkText}\n\r`;
                riskLinkText = riskLinkText+((rNumber.slice(0,40)+rName).substring(0,40));
            } else {
                riskLinkText = `${rNumber} - ${rName.substring(0, 70-rNumber.length)}\n\r`;
                riskLinkText = riskLinkText+(rName.substring(70-rNumber.length,70+(70-rNumber.length)));
            }*/
            riskLinkText = `${rNumber} - ${rName}\n\r`;
        } else if (rName && rName.length > 0){
            riskLinkText = rName;
        } else {
            riskLinkText = "";
        }

        const linkGenerator = new IRPExternalLinksModel(ValidIRPLinksSystemCodes.gois);
        const findTriggerName = () => {
            const desc = this.props.irpState.matchTriggersCodeSet.getDescByCd(this.props.clientItem.trigger);
            return desc ? <span style={{fontSize: "12px", fontWeight: 400}}>
            {desc.length > 45 ? desc.substring(0, 42) + "..." : desc}
            </span>: null;
        };
        let riskMatchContainerItemStyle = {borderLeft: null, backgroundColor: "#c6c6c6"};//gray #c6c6c6, transparent and white works in IE only (Chrome: gray displayed for non-CVOR)
        if(StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.historicalCVOR)) {
            riskMatchContainerItemStyle["backgroundColor"] = "#c6c6c6";//to set gray on top of match on Chrome
            riskMatchContainerItemStyle["background"] = "#c6c6c6";//to set gray on top of match
            riskMatchContainerItemStyle.backgroundColor = "#c6c6c6";
            riskMatchContainerItemStyle["borderLeft"] = "30px solid #005b70";//green
        } else {
            riskMatchContainerItemStyle["backgroundColor"] = "rgb(255,255,255, 1)";//tried white & transparent > not work in Chrome (gray displayed for non-CVOR)
            riskMatchContainerItemStyle.backgroundColor = "rgb(255,255,255, 1)";
        }

        if(StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.inProgress)) {
            riskMatchContainerItemStyle["borderLeft"] = "30px solid #004578";//blue
        }
        else if (StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.confirmed))  {
            riskMatchContainerItemStyle["borderLeft"] = "30px solid #a80000";//red
        }
        else if((StringUtils.containsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.dismissed) ||
                StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchStatus.COMPLETED))) {
            riskMatchContainerItemStyle["borderLeft"] = "30px solid #004b1c";//green
        }
        else if(
            StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.underThreatEval) ||
            StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.untreated)) {
            riskMatchContainerItemStyle["borderLeft"] = "30px solid gray";
        }

        else if(!this.props.clientItem.showNotesForUserIp && !(StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.inProgress)
                || StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.underThreatEval)
                || StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.untreated))) {
            riskMatchContainerItemStyle["backgroundColor"] = "#c6c6c6";
        }

        else if(StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.untreated)) {
            riskMatchContainerItemStyle.backgroundColor = "white"; //rgb(255,255,255, 1) does not work on IE; white does not work on Chrome
            riskMatchContainerItemStyle["backgroundColor"] = "white";
        }

        if (StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.confirmed)
            || StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.dismissed)
            || StringUtils.contains(this.props.clientItem.viewStatus, "Completed")
            || StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.historicalCVOR)) {
            riskMatchContainerItemStyle["backgroundColor"] = "#c6c6c6 !important";
            riskMatchContainerItemStyle["background"] = "#c6c6c6 !important";
        }

        if(this.props.clientItem.riskType && this.props.clientItem.riskType.length > 0) {
            let truncatedRiskType = this.props.clientItem.riskType.length>75 ? `${this.props.clientItem.riskType.substring(0,75)} ...` : this.props.clientItem.riskType;
        }

        if(this.props.clientItem.riskName && this.props.clientItem.riskName.length > 0) {
            let truncatedRiskName = this.props.clientItem.riskName.length >75 ? `${this.props.clientItem.riskName.substring(0,75)} ...` : this.props.clientItem.riskName;
        }

        let userToOverride = <div className={css("risk-match-container-item-row")} >
            <div className="risk-match-container-item-column" style={{paddingTop: "1%"}}>
                <div style={{height:"0px"}}>
                    <DefaultButton
                        style={{float: "right"}}
                        allowDisabledFocus={true}
                        text="Change"
                        onClick={this.cardClicked}
                    />
                </div>
            </div>
        </div>

        let isGrayedOut = (StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.confirmed) ||
            StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.dismissed) ||
            StringUtils.contains(this.props.clientItem.viewStatus, "Completed") ||
            StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.historicalCVOR)) ?
            { backgroundColor: "#c6c6c6 !important", background: "#c6c6c6 !important"} : { backgroundColor: "transparent !important"};

        const treatmentMatchEvalCaseDetails = this.props.irpState.matchEvalCaseDetails;

        let goisViewType: string = "";
        if(this.props.clientItem.goisEntityType === "PERSON" || this.props.clientItem.goisEntityType === "NATIONAL_ID") {
            goisViewType = "VIEW_PERSON";
        } else if (this.props.clientItem.goisEntityType === "ORGANISATION") {
            goisViewType = "VIEW_ORGANISATION";
        }  else if (this.props.clientItem.goisEntityType === "AGENT") {
            goisViewType = "VIEW_AGENT";
        } else if (this.props.clientItem.goisEntityType === "PHYSICAL_ADDRESS" || this.props.clientItem.goisEntityType === "TELEPHONE"
            || this.props.clientItem.goisEntityType === "IP_ADDRESS" || this.props.clientItem.goisEntityType === "EMAIL_ADDRESS") {
            goisViewType = "VIEW_ADDRESS";
        }

        return (
            <div className={`risk-match-container-item
                ${(StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.confirmed) ||
                StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.dismissed) ||
                StringUtils.contains(this.props.clientItem.viewStatus, "Completed") ||
                StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.historicalCVOR)) ?
                "risk-match-container-item-cvor" : "risk-match-container-item-non-cvor"}`}
                 style={riskMatchContainerItemStyle}>
                {this.props.clientItem.threatMatch ? contentIconThreatMatch : null}
                {contentIconFilterPolarity}
                {content}
                {this.allowChange() ? userToOverride : ""}

                <div className={css("risk-match-container-item-row")}>
                    <div className="risk-match-container-item-column">
                        <div className="risk-match-container-item-column-wrapper" style={{width: "395px"}}>
                            <Label htmlFor={`riskNameAndNumber`}><b>Risk name and number</b></Label>
                            <div style={{color: "#333333", fontSize: "12px", fontWeight: 400}}key={`${this.props.clientItem.riskName}-riskName`}>
                                <span style={{fontSize: "12px", wordWrap: "break-word", overflowWrap: "break-word"}} id="riskNameAndNumber">{this.props.clientItem.goisResult
                                    ? linkGenerator.generateLink({
                                        goisId: this.props.clientItem.riskNumber,
                                        goisViewType: goisViewType,
                                        linkText: riskLinkText
                                    })
                                    : riskLinkText}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className={css(`${this.props.clientItem.showNotesForUserIp &&
                this.props.clientItem.actionedByUser ? '': ''}` )}>
                    <div className={css(`risk-match-container-item-row
                     ${this.props.clientItem.showNotesForUserIp  ?
                        this.props.clientItem.actionedByUser ? "show-user-input" : "risk-match-display-none" :
                        "risk-match-display-none"}`)}>

                        {this.props.irpState.selectedRiskMatch ?
                            < ClientRiskCheckTreatmentsNotesActions matchEvalCase={treatmentMatchEvalCaseDetails}
                                                                    updateClientRisks={this._updateClientRisks}
                                                                    host={this.props.host}/>: <div></div>
                        }
                    </div>
                    <div className="risk-match-container-document-card-wrapper">
                        <DocumentCard className={`risk-match-document-container custom-docu-car
                        ${this.props.clientItem.actionedByUser?
                            this.props.clientItem.showNotesForUserIp ? "hide-user-actions" : "" : ""}
                          ${StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.historicalCVOR) ? "grayedOutCvor" : ((
                            StringUtils.equalsIgnoreCase(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.confirmed)
                            || StringUtils.contains(this.props.clientItem.viewStatus, ValidRiskMatchViewStatus.dismissed)
                            || StringUtils.contains(this.props.clientItem.viewStatus, "Completed")) ? "grayedOut" : "")}`} onClick={this.cardClicked} >
                            <div className={css(`risk-match-container-item-row ${riskLinkText.length > 45 ? "risk-match-container-item-row-padding" : ""}`)}>
                                <div className="risk-match-container-item-column">
                                    <div className="risk-match-container-item-column-wrapper">
                                        <b>Risk type </b>
                                        <div  style={{color: "#333333", fontSize: "12px", fontWeight: 400}}key={`${this.props.clientItem.riskType}-riskType`}>
                                            {this.props.clientItem.riskType? this.props.clientItem.riskType.length > 25 ? this.props.clientItem.riskType.substring(0, 21) + "..." : this.props.clientItem.riskType: ""}
                                        </div>
                                    </div>
                                </div>
                                <div className="risk-match-container-item-column">
                                    <div className="risk-match-container-item-column-wrapper">
                                        <b>First matched </b>
                                        <div style={{color: "#333333", fontSize: "12px", fontWeight: 400}}key={`${this.props.clientItem.matchedTs}-firstM`}>
                                            {dataTimestampToOutputText(this.props.clientItem.matchedTs)}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="risk-match-container-item-row">
                                <div className="risk-match-container-item-column">
                                    <div className="risk-match-container-item-column-wrapper">
                                        <b>Match trigger  </b>
                                        <div style={{color: "#333333"}}key={`${this.props.clientItem.trigger}-trigger`}>
                                            <SyncContainer host={this.props.host}
                                                           key={`${this.props.clientItem.trigger}-triggerName`}
                                                           sync={this.props.irpState.matchTriggersCodeSet.sync}
                                                           onRenderDone={findTriggerName}/>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="risk-match-container-item-row">
                                <div className="risk-match-container-item-column">
                                    <div className="risk-match-container-item-column-wrapper">
                                        <b>Treatment summary </b>
                                        <div style={{color: "#333333", fontSize: "12px", fontWeight: 400}}key={`${this.props.clientItem.treatmentSummary ? this.props.clientItem.treatmentSummary : null}-trigger`}>
                                            {this.props.clientItem.treatmentSummary && this.props.clientItem.treatmentSummary.length > 0 ?
                                                (this.props.clientItem.treatmentSummary.length > 45 ? this.props.clientItem.treatmentSummary.substring(0, 42) + "..." : this.props.clientItem.treatmentSummary) : null}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </DocumentCard>
                        <div className={`risk-match-document-container
                        ${this.props.clientItem.actionedByUser?
                            this.props.clientItem.showNotesForUserIp ? "hide-user-actions" : "" : ""}`} style={isGrayedOut}>
                            <ClientRiskCheckTreatmentsActionButtons resultId={this.props.clientItem.resultId}
                                                                    host={this.props.host}
                                                                    overlayMsgFlag={this.props.overlayMsgFlag}
                                                                    userToIPNotes={this.props.clientItem.showNotesForUserIp}
                                                                    updateClientRisks={this._updateClientRisks}
                                                                    setDimissalEntry = {this.props.setDimissalEntry}
                                                                    hotKeysService={this.props.hotKeyService}/>
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}

interface IClientRiskCheckDetailsTableProps extends  IAppletProps {
    updateRisks?: (canAddNote?: boolean) => void;
}


@observer
class   ClientRiskCheckDetailsTable extends React.Component<IClientRiskCheckDetailsTableProps, any> {
    private _IRPState = this.props.host.state.irpState;
    private showClientDetails: IClientRiskMatch;
    @observable filterTerm: string;
    @observable statusFilters: IButtonProps[];
    @observable matchDateFilter: IDateRangeFilterModel;
    @observable _showOverlay: boolean = false;
    @observable _showDetails: boolean = false;


    private _hotKeyCode = KeyCodes.m;
    private _tableRef: CustomDetailsList<IClientRiskMatch>;
    private _detailsListComponentRef: DetailsListBase;
    private _hotKeysService = new ClientRiskCheckTreatmentsHotKeysService(this._IRPState);
    private isDismissalValueRequired?: boolean = false;
    @observable dismissalValueWarning?: boolean;

    private _setTableRef = ref => {
        if (ref) {
            const keyboardShortcutRef = this._IRPState.getViewModel().keyboardShortcutsService;
            this._tableRef = ref;
            this._detailsListComponentRef = this._tableRef.detailsListComponentRef;

            if (keyboardShortcutRef) {
                const hotKeyObj: IRegisteredShortcuts = {
                    keyCode: this._hotKeyCode,
                    shortcutFunction: () => {
                        const selectedRiskMatch = this._IRPState.selectedRiskMatch;
                        const index = ref.getViewItems().findIndex(i => i.key === selectedRiskMatch.key);
                        this._detailsListComponentRef.focusIndex(index);
                    }
                };
                keyboardShortcutRef.registerShortcut(hotKeyObj);
            }
        }
    };

    private _onSelectedRiskChange = (items: IRRClientRiskMatchesServiceResponseItem[]) => {
        const selectedRisk = items[0];
        if (selectedRisk && (!this._IRPState.selectedRiskMatch || (this._IRPState.selectedRiskMatch.key !== selectedRisk["key"]))) {
            this._IRPState.selectedRiskMatch = items[0];
        }
    };


    private showSelectedClientItemDetails = (clientItem?: IClientRiskMatch, visible?: boolean) => {
        this._showDetails = visible;
        this._IRPState.selectedRiskMatch = clientItem;
        this.showClientDetails = clientItem;
    }

    private _setDimissalEntry = (isDismissalValueRequired?: boolean) => {
        this.isDismissalValueRequired = isDismissalValueRequired;
        this.forceUpdate();
    }

    private _onClosePanel = (e?: React.SyntheticEvent<HTMLElement>) => {
        this.dismissalValueWarning = true;
        if(! this.isDismissalValueRequired) {
            this.dismissalValueWarning = false;
            this._showDetails = false;
            this.showClientDetails = null;
            this._IRPState.selectedRiskMatch.showNotesForUserIp = false;
            this._IRPState.selectedRiskMatch.actionedByUser = false;
            this._IRPState.selectedRiskMatch = {};
        }
        this.forceUpdate();
    }

    private _updateClientRisks = (/* for Future from the detailed view */ canAddNotes: boolean) => {
        this.forceUpdate();
    }

    componentDidUpdate(prevProps) {
        if(this._IRPState.selectedRiskMatch && prevProps && prevProps._IRPState && prevProps._IRPState.selectedRiskMatch ) {
            const differentTitle = this._IRPState.selectedRiskMatch.showNotesForUserIp !== prevProps._IRPState.selectedRiskMatch.showNotesForUserIp;
            const differentDone = this._IRPState.selectedRiskMatch.showNotesForUserIp !== prevProps._IRPState.selectedRiskMatch.showNotesForUserIp;
            return differentTitle || differentDone;
        }
    }

    render() {
        const className = this._IRPState.treatmentsNotes.notes && this._IRPState.treatmentsNotes.notes.items.length > 0 ? "has-notes" : null;
        const selectedItems = this._IRPState.selectedRiskMatch ? [this._IRPState.selectedRiskMatch] : [this._IRPState.clientRiskMatches.items[0]];

        const _onRenderRow = (props: IDetailsRowProps, defaultRenderer) => {
            props.className = css(props.className, this._IRPState.treatmentsNotes.isDirtyTreatmentNote(props.item.treatmentActionId) ? "has-notes" : "");
            return <ClientRiskCheckDetailsAlert notesModel={this._IRPState.treatmentsNotes} rowProps={props}
                                                rowDefaultRenderer={defaultRenderer}/>
        };

        const messageBarNoRisksFound = <MessageBar messageBarType={MessageBarType.warning}>No risk matches found for selected interaction</MessageBar>;
        const riskMatchList =<div className="risk-match-container">
            {this._IRPState.clientRiskMatches.items.map((item, i) => {
                return ( <ClientRiskItem
                    key={i} clientItem ={item}
                    irpState={this._IRPState}
                    host={this.props.host}
                    showNotes={true}
                    updateClientRisks={this._updateClientRisks}
                    setDimissalEntry = {this._setDimissalEntry}
                    overlayMsgFlag = {this._showDetails}
                    showSelectedClientItemDetails = {this.showSelectedClientItemDetails}
                    hotKeyService ={this._hotKeysService}/>)
            })
            } </div>

        // Old IRP - Table view
        /*        const legacy =   <CustomDetailsList className={className}
                                       columns={this._columns}
                                       items={this._IRPState.clientRiskMatches.items}
                                       selectedItems={selectedItems}
                                       checkboxVisibility={CheckboxVisibility.hidden}
                                       selectionMode={SelectionMode.multiple}
                                       checkboxType={CheckboxType.square}
                                       compact={true}
                                       selectedItemsChanged={this._onSelectedRiskChange}
                                       stickyHeader={true}
                                       wrapperMaxHeight={300}
                                       onRenderRow={_onRenderRow}
                                       selectionPreservedOnEmptyClick={true}
                                       />;*/

        const syncingOverlay = this._showOverlay ?
            <SyncingOverlay onRenderContent={() => <Spinner label="Updating risk treatment status..."/>}/> : null;

        let noRisksFound : boolean = false;
        let showSpinning : boolean = false;
        let showData : boolean = false;

        if(this._IRPState.riskSearchResults.sync.hasSynced && this._IRPState.riskSearchResults.data.items.length === 0) {
            noRisksFound = true;
        }
        else if(this._IRPState._selectedDealing.isInRiskResults) { //if VRA matches
            if(this._IRPState.clientRiskMatches.sync.hasSynced && this._IRPState.clientRiskMatches.matchesFetched) {
                if(this._IRPState.clientRiskMatches.total === 0) {
                    noRisksFound = true;
                } else if (this._IRPState.clientRiskMatches.total > 0) {
                    showData = true;
                }
            } else {
                noRisksFound = true;
            }
        } else {//if CVOR History matches
            if(this._IRPState.clientRiskMatches.sync.hasSynced && this._IRPState.clientRiskMatches.matchesFetched) {
                if(this._IRPState.clientRiskMatches.total === 0) {
                    noRisksFound = true;
                } else if (this._IRPState.clientRiskMatches.total > 0) {
                    showData = true;
                }
            } else {
                noRisksFound = true;
            }
        }

        return <div className={componentClassNamePrefix}>
            {
                noRisksFound ? messageBarNoRisksFound : (showData ? <div>{riskMatchList} </div> :
                    (showSpinning ? <Spinner label="Loading..." /> : <div>{(riskMatchList ? riskMatchList : null)} </div>))
            }

            {syncingOverlay}
            <Panel
                isOpen={this._showDetails}
                type={PanelType.large}
                onDismiss={this._onClosePanel}
                isLightDismiss={true}
                hasCloseButton={false}
                onLightDismissClick={this._onClosePanel}
                closeButtonAriaLabel="Close">
                <ClientRiskCheckTreatments updateClientRisks={this._updateClientRisks}
                                           {...this.props}
                                           dismissalValueWarning = {this.dismissalValueWarning}
                                           hotKeysService = {this._hotKeysService}
                                           userToIPNotes={false}
                                           handleBackAction={this._onClosePanel}
                                           setDimissalEntry = {this._setDimissalEntry}
                                           irpState={this._IRPState}
                />
            </Panel>
            {/*<ClientRiskCheckDetailsDetailedView showDetails={this._showDetails} irpState={this._IRPState}
                hotKeysService={this._hotKeysService} host={this.props.host} onClose={this._onClosePanel}/>*/}
        </div>
    }

    private _columns: ICustomColumn[] = [
        {
            fieldName: "riskName",
            key: "riskName",
            name: "Risk number - name",
            minWidth: 250,
            isResizable: true,
            isSortable: true,
            sortType: SortType.date,
            isMultiline: true,
            data: (item: IRRClientRiskMatchesServiceResponseItem) => `${item.riskNumber} - ${item.riskName}`,
            onRender: (item: IRRClientRiskMatchesServiceResponseItem) => {
                let content: (JSX.Element | string)[] = [];
                const linkText = `${item.riskNumber} - ${item.riskName}`;
                const linkGenerator = new IRPExternalLinksModel(ValidIRPLinksSystemCodes.gois);

                if (item.noteCount && item.noteCount > 0) {
                    content.push(<Icon key={`${item.resultId}-notesIcon`}
                                       className={css(`${componentClassNamePrefix}--risk-name-icon`)}
                                       iconName="EditNote"/>);
                }

                content.push(<span key={`${item.resultId}-notesText`}>{item.goisResult
                    ? linkGenerator.generateLink({
                        goisId: item.riskNumber,
                        linkText: linkText
                    })
                    : linkText}</span>);

                return content;
            }
        }, {
            fieldName: "riskType",
            key: "riskType",
            name: "Risk type",
            minWidth: 100,
            isResizable: true,
            isSortable: true,
            sortType: SortType.text
        }, {
            fieldName: "matchedTs",
            key: "matchedTs",
            name: "First matched",
            minWidth: 100,
            isResizable: true,
            isSortable: true,
            sortType: SortType.date,
            onRender: (item: IRRClientRiskMatchesServiceResponseItem) => dataTimestampToOutputText(item.matchedTs)
        }, {
            fieldName: "trigger",
            key: "trigger",
            name: "Match trigger (ID)",
            minWidth: 100,
            isResizable: true,
            isSortable: true,
            sortType: SortType.text,
            data: (item: IClientRiskMatch) => {
                return (this._IRPState.matchTriggersCodeSet.sync.hasSynced ? this._IRPState.matchTriggersCodeSet.getDescByCd(item.trigger) : "")
                    + ` (${item.trigger})`;
            },
            onRender: (item: IClientRiskMatch) => {
                let content: (JSX.Element | string)[] = [];
                const findTriggerName = () => {
                    const desc = this._IRPState.matchTriggersCodeSet.getDescByCd(item.trigger);
                    return desc ? <span>{desc}</span> : null;
                };
                content.push(<SyncContainer host={this.props.host}
                                            key={`${item.trigger}-triggerName`}
                                            sync={this._IRPState.matchTriggersCodeSet.sync}
                                            onRenderDone={findTriggerName}/>);
                content.push(<span key={`${item.trigger}-triggerId`}> ({item.trigger})</span>);
                return content;
            }
        }, {
            fieldName: "treatmentSummary",
            key: "treatmentSummary",
            name: "Treatment summary",
            minWidth: 100,
            isResizable: true,
            isSortable: true,
            sortType: SortType.text,
            onRender: (item: IRRClientRiskMatchesServiceResponseItem) => {
                return item.treatmentSummary.length > 50 ? item.treatmentSummary.substring(0, 47) + "..." : item.treatmentSummary;
            }
        }, {
            fieldName: "treatmentOutcome",
            key: "treatmentOutcome",
            name: "Risk match status",
            minWidth: 600,
            maxWidth: 750,
            isResizable: true,
            isSortable: true,
            isMultiline: true,
            data: (item: IRRClientRiskMatchesServiceResponseItem) => {
                return item.status === ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS || item.status === ValidRiskMatchStatus.RISK_ASSESSMENT_UNTREATED ? item.status : item.riskAssessmentOutcome
            },
            onRender: (item: IClientRiskMatch) => {
                return <ClientRiskCheckTreatmentsActionButtons resultId={item.resultId}
                                                               host={this.props.host}
                                                               hotKeysService={this._hotKeysService}/>
            }

        }
    ];
}


export {
    ClientRiskCheckDetailsTable as default,
    ClientRiskCheckDetailsTable,
    ClientRiskItem
}


/*
<ClientRiskCheckDetailsDetailedView showDetails={this._showDetails} irpState={this._IRPState}
                hotKeysService={this._hotKeysService} host={this.props.host} onClose={() => this._onClosePanel}/>
 */