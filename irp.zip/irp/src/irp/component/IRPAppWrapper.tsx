import * as React from "react";
import {observer} from "mobx-react";
import {Image} from "office-ui-fabric-react/lib/Image";

import "../../shared/IRPGlobal.scss";
import {AppWrapper} from "@twii/common/lib/component/AppWrapper";
import {css} from "@uifabric/utilities/lib/css";

import * as DepOfHomeAffairsLogo from "../../shared/media/homeAffairsLogo_y55.png";
import {onRenderItemError, onRenderItemLoading} from "@twii/common/lib/component/AppItemHelper";
import {AppContainer} from "@twii/common/lib/component/AppContainer";
import {Accessibility} from "../../shared/Accessibility";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';

@observer
class IRPAppWrapper extends AppWrapper  {
    constructor(props) {
        super(props);
        this.state = {
            showPanel: false
        };
    }
    
    private _showPanel = () => {
        this.setState({ showPanel: true });
    };
    
    private _hidePanel = () => {
        this.setState({ showPanel: false });
    };

    render() {

        const _appHeaderTitle = this.props.title
            ? <div className="app-title">{this.props.title}</div>
            : null;

        const _renderAppHeaderFar = () => {
            const items = [];
            if (this.props.farItems) {
                this.props.farItems.forEach(item => {
                    items.push(<AppContainer className="app-menu-item" key={`${item.path}/far`} {...item}
                                             onRenderLoad={onRenderItemLoading} onRenderError={onRenderItemError}/>);
                });
            }
            if (!this.props.hideHelp) {
                items.push(
                    <div className="app-menu-item"><Icon iconName="Devices4" onClick={this._showPanel} style={{cursor: "pointer", fontSize: "1.1em"}}/></div>
                );
            }
            if (!this.props.hideUser) {
                items.push(
                    <AppContainer className="app-menu-item" key="/user/menuitem/far"
                                  path={this.props.userPath || "/user/menuitem"} onRenderLoad={onRenderItemLoading}
                                  onRenderError={onRenderItemError}/>
                );
            }
            return (
                <div className="app-header-far">
                    {items}
                </div>
            );
        };
        return (
            
            <div className={css("app-wrapper", this.props.className)}>
                <Panel
                    isOpen={this.state.showPanel}
                    type={PanelType.medium}
                    onDismiss={this._hidePanel}
                    isLightDismiss={true}
                    hasCloseButton={true}
                    headerText="Accessibility"
                    closeButtonAriaLabel="Close"
                >
                    <Accessibility />
                </Panel>
                <div className="app-header">
                    <div className={css("irp-app-brand")}>
                        <div className="app-brand-logo">
                            <Image src={String(DepOfHomeAffairsLogo)} alt="Logo of Australian Government - Department of Home Affairs"/>
                        </div>
                    </div>
                    {_appHeaderTitle}
                    {_renderAppHeaderFar()}
                </div>
                <div role="main" className={css("app-main", this.props.mainClassname)}>
                    {this.props.children}
                </div>
            </div>
        );
    }
}

export {
    IRPAppWrapper as default,
    IRPAppWrapper
}