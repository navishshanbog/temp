// import * as React from "react";
//
// import {observer} from "mobx-react";
// import {CheckboxType, CustomDetailsList, ICustomColumn, SortType} from "@twii/common/lib/component/CustomDetailsList";
// import {SyncContainer} from "./SyncContainer";
// import {IRRClientRiskCheckDetailsServiceResponseItem} from "../model/IRRClientRiskCheckDetailsServiceResponseItem";
// import {dataTimestampToOutputText} from "@twii/common/lib/util/Date";
// import {CheckboxVisibility, SelectionMode} from "office-ui-fabric-react/lib";
//
// @observer
// class IRPRiskSearchDetails extends React.Component<any, any> {
//
//     private _IRPStore = t
//     _onRenderDone = () => {
//         const riskMatches = IRPStore.riskMatches;
//         return <CustomDetailsList
//             columns={columns}
//             items={riskMatches.items}
//             selectedItems={[riskMatches.items[0]]}
//             checkboxVisibility={CheckboxVisibility.always}
//             selectionMode={SelectionMode.single}
//             checkboxType={CheckboxType.square}
//             compact={true}/>
//     };
//
//     render() {
//         if (!IRPStore.riskMatches) {
//             return null;
//         } else {
//             return <SyncContainer sync={IRPStore.riskMatches.sync} onRenderDone={this._onRenderDone}/>
//
//         }
//     }
// }
//
// const columns: ICustomColumn[] = [
//     {
//         fieldName: "firstMatchedTs",
//         key: "firstMatchedTs",
//         name: "First Matched",
//         minWidth: 100,
//         isResizable: true,
//         isSortable: true,
//         isSorted: true,
//         isSortedDescending: true,
//         sortType: SortType.date,
//         onRender: (item: IRRClientRiskCheckDetailsServiceResponseItem) => dataTimestampToOutputText(item.firstMatchedTs)
//     }
// ];
//
// export {
//     IRPRiskSearchDetails as default,
//     IRPRiskSearchDetails
// }
