import * as React from "react";
import {observer} from "mobx-react";
import "./ClientRiskCheckTreatments--actionButtons.scss";
import {IClientRiskCheckTreatmentsActionButtonsProps} from "./ClientRiskCheckTreatments--actionButtons";
import {ValidRiskMatchViewStatus} from "../../shared/RiskMatchValidValues";
import {PrimaryButton, DefaultButton} from "office-ui-fabric-react/lib/Button";
//import {ButtonGroup} from "@twii/common/lib/component/ButtonGroup";
import {ButtonGroup} from "../../irpcommon/ButtonGroup";
import {IButtonProps} from "office-ui-fabric-react/lib/Button";
import {BaseButton} from "office-ui-fabric-react";
import {IReactionDisposer, observable, reaction} from "mobx";
import "./ClientRiskCheckTreatments--actionButtons-actions.scss";

interface ClientRiskCheckTreatmentsActionButtonsActionsProps extends IClientRiskCheckTreatmentsActionButtonsProps {
    dismissButtonProps: IButtonProps;
    buttonGroupItems: IButtonProps[];
    selectedKey: ValidRiskMatchViewStatus;
    enableIfActionable?: boolean;
    onChanged;
    setRefs: (refs: {
        primaryBtnRef: BaseButton;
        defaultBtnRef: BaseButton;
    }) => any;
}

@observer
class ClientRiskCheckTreatmentsActionButtonsActions extends React.Component<ClientRiskCheckTreatmentsActionButtonsActionsProps, any> {
    @observable private _primaryBtnRef: BaseButton;
    @observable private _defaultBtnRef: BaseButton;

    refsObj = reaction(() => {
        const pbr = this._primaryBtnRef;
        const dbr = this._defaultBtnRef;
        return {
            primaryBtnRef: pbr,
            defaultBtnRef: dbr
        };
    }, (refsObj) => {
        if (this.props.setRefs) this.props.setRefs(refsObj);
        return refsObj;
    })

    private _setPrimaryBtnRef = ref => {
        if (ref && !this._primaryBtnRef) {
            this._primaryBtnRef = ref;
        }
    };

    private _setDefaultBtnRef = ref => {
        if (ref && !this._defaultBtnRef) {
            this._defaultBtnRef = ref;
        }
    };

    render() {
        const getButtonGroupContent = () => {
            return <div style={{float: "left", position: "relative", width: "100%"}}>
                <ButtonGroup style={{float: "left", width: "65%"}}
                             label="Treatment status action buttons"
                             labelHidden={true}
                             items={this.props.buttonGroupItems}
                             onChanged={this.props.onChanged}
                             selectedKeys={this.props.selectedKey ? [this.props.selectedKey] : []}/>
                {this.props.dismissButtonProps
                    ? this.props.selectedKey === ValidRiskMatchViewStatus.dismissed
                        ? <PrimaryButton
                            style={{float: "left", marginRight: "0 .5em", width: "30%", fontSize: "10px",paddingLeft:"0px" }}
                            {...this.props.dismissButtonProps}
                            iconProps={{ iconName: "StatusCircleErrorX"}} 
                            text="Dismissed"
                            componentRef={this._setPrimaryBtnRef} className="ande-irp-client-risk-check-treatment-button-dismiss" />
                        : <DefaultButton
                            style={{float: "left", width: "33%", 
                            margin:"1px 2px 1px 2px", border:"1px solid lightskyblue", paddingLeft:"0px"}}
                            {...this.props.dismissButtonProps}
                            iconProps={{ iconName: "StatusCircleErrorX"}}
                            componentRef={this._setDefaultBtnRef}/>
                    : null}
            </div>

        };
        return getButtonGroupContent();
    }
}

export {
    ClientRiskCheckTreatmentsActionButtonsActions as default,
    ClientRiskCheckTreatmentsActionButtonsActions,
    ClientRiskCheckTreatmentsActionButtonsActionsProps
}
