import * as React from "react";

import {observer} from "mobx-react";
import {COLOR_VALUES} from "office-ui-fabric-react/lib/utilities/color/colorValues";
import {rgb2hex} from "office-ui-fabric-react";
import {ResponsivePie} from "@nivo/pie";
import {IDealing} from "../model/IDealings";

interface IClientRiskCheckDetailsDoughnutProps {
    dealing: IDealing;
}

@observer
class ClientRiskCheckDetailsDoughnut extends React.Component<IClientRiskCheckDetailsDoughnutProps, any> {
    render() {
        if (this.props.dealing) {
            return <>
                <label style={{fontSize: "1.3em", textAlign: "center", marginBottom: "1em"}}>Application status</label>
                <div style={{height: 200}}>
                    <ResponsivePie
                        data={[
                            {
                                "id": "Incomplete",
                                "label": "Incomplete",
                                "value": this.props.dealing.incompleteResultCount
                            },
                            {
                                "id": "Confirmed",
                                "label": "Confirmed",
                                "value": this.props.dealing.confirmedResultCount
                            },
                            {
                                "id": "Dismissed",
                                "label": "Dismissed",
                                "value": this.props.dealing.dismissedResultCount
                            }
                        ]}
                        colors={[`#${rgb2hex(COLOR_VALUES.gray[0], COLOR_VALUES.gray[1], COLOR_VALUES.gray[2])}`,
                            `#${rgb2hex(COLOR_VALUES.red[0], COLOR_VALUES.red[1], COLOR_VALUES.red[2])}`,
                            `#${rgb2hex(COLOR_VALUES.green[0], COLOR_VALUES.green[1], COLOR_VALUES.green[2])}`]}
                        innerRadius={0.5}
                        padAngle={0.7}
                        cornerRadius={3}
                        borderWidth={1}
                        borderColor="inherit:darker(0.2)"
                        radialLabelsSkipAngle={10}
                        radialLabelsTextXOffset={6}
                        radialLabelsTextColor="#333333"
                        radialLabelsLinkOffset={0}
                        radialLabelsLinkDiagonalLength={16}
                        radialLabelsLinkHorizontalLength={24}
                        radialLabelsLinkStrokeWidth={1}
                        radialLabelsLinkColor="inherit"
                        slicesLabelsSkipAngle={10}
                        slicesLabelsTextColor="#333333"
                        margin={{
                            top: 15,
                            bottom:15,
                            left:15,
                            right:15
                        }}
                    />
                </div>
            </>
        }
    }
}


export {
    ClientRiskCheckDetailsDoughnut as default,
    ClientRiskCheckDetailsDoughnut,
    IClientRiskCheckDetailsDoughnutProps
}
