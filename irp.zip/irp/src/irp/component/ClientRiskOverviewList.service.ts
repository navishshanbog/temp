import * as React from "react";
import {Link} from "office-ui-fabric-react/lib/Link";
//import {ICustomColumn, SortType} from "@twii/common/lib/component/CustomDetailsList";
import {ICustomColumn, SortType} from "../../irpcommon/CustomDetailsList";
import {IDealing, ValidDealingStatus} from "../model/IDealings";
import {IDateRangeFilterModel} from "../../shared/DateRangeFilter";
import * as moment from "moment";
import {isFunction} from "@twii/common/lib/util/Lang";

import "./ClientRiskOverviewList.scss";
import {IRPExternalLinksModel, ValidIRPLinksSystemCodes} from "../model/IRPExternalLinksModel";
import {IAppHost} from "@twii/common/lib/IAppHost";
import {IIRPStoreModel} from "../../service/IIRPStoreModel";
import {validIdSourceENUM} from "../../shared/SystemIdTypeRefList";
import "./ClientRiskOverviewList.service.scss";

class ClientRiskOverviewListService {
    private _host: IAppHost;
    private _IRPStore: IIRPStoreModel;

    constructor(host: IAppHost) {
        this._host = host;
        this._IRPStore = this._host.state.irpState;
    }

    getFilteredItems = (store: IIRPStoreModel, filterTerm?: string, mileStoneDateFilter?: IDateRangeFilterModel): IDealing[] => {
        let filteredItems: IDealing[] = store.dealings.items.slice();
        filteredItems = this.applyInitialSorting(filteredItems);

        if (mileStoneDateFilter && !(!mileStoneDateFilter.from && !mileStoneDateFilter.to)) {
            const mileStoneDateFilterFrom = mileStoneDateFilter.from.valueOf();
            const mileStoneDateFilterTo = mileStoneDateFilter.to.valueOf();
            filteredItems = filteredItems.filter(item => {
                const matchDate = moment(item.milestoneDate).valueOf();
                return matchDate > mileStoneDateFilterFrom && matchDate < mileStoneDateFilterTo || !item.isSelectedClient; // All secondary applicants must remain
            })
        }

        if (filterTerm) {
            const intFilterTerm = filterTerm.toLowerCase();
            let keepingItems: IDealing[] = [];
            const columns = this.columns;
            filteredItems.forEach(item => {
                for (let i = 0; i < columns.length; i += 1) {
                    const col = columns[i];
                    const itemKey = col.fieldName;
                    const dataFunc = col.data && isFunction(col.data) ? col.data : null;
                    let cellValue = dataFunc ? dataFunc(item) : item[itemKey];
                    cellValue = cellValue && cellValue.toLowerCase ? cellValue.toLowerCase() : cellValue;
                    if (!item.isSelectedClient || (cellValue && cellValue.indexOf && cellValue.indexOf(intFilterTerm) !== -1)) {
                        keepingItems.push(item);
                        break;
                    }
                }
            });

            filteredItems = filteredItems.filter(i => keepingItems.find(j => i.key === j.key))
        }

        return filteredItems;
    };

    //Initial sorting by untreated high risk application
    applyInitialSorting = (dealingItems: IDealing[]) => {

        // If sorted by any column ignore initial sorting
        if (this.columns.findIndex(col => col.isSorted) > -1) {
            return dealingItems;
        } else {
            const primarySortFieldName = "applicationRiskStatus";
            const secondarySortFieldName = "applicationRiskRating";
            const isUntreated = (status) => status === ValidDealingStatus.Checking
                || status === ValidDealingStatus.in_risk_assessment
                || status === ValidDealingStatus.under_threat_val;

            const sortByMilestoneDate = (items: IDealing[]) => {
                return items.sort((i1, i2) => {
                    const date1 = moment(i1.milestoneDate);
                    const date2 = moment(i2.milestoneDate);
                    if (date1 && date2 && date1.isValid() && date2.isValid()) {
                        if (date1.valueOf() < date2.valueOf()) return 1;
                        if (date1.valueOf() === date2.valueOf()) return 0;
                        if (date1.valueOf() > date2.valueOf()) return -1;
                    } else {
                        return -1
                    }
                });
            };
            const untreatedHighItems = dealingItems.filter(d => {
                const status = d[primarySortFieldName];
                const rate = d[secondarySortFieldName];
                return status && isUntreated(status) && rate && rate.toLowerCase() === "high";
            });
            const untreatedLowItems = dealingItems.filter(d => {
                const status = d[primarySortFieldName];
                const rate = d[secondarySortFieldName];
                return status && isUntreated(status) && rate && rate.toLowerCase() === "low";
            });
            const untreatedNoRItems = dealingItems.filter(d => {
                const status = d[primarySortFieldName];
                const rate = d[secondarySortFieldName];
                return status && isUntreated(status) && rate && rate.toLowerCase() === "no rating";
            });
            const treatedItems = dealingItems.filter(d => untreatedHighItems.indexOf(d) === -1
                && untreatedLowItems.indexOf(d) === -1
                && untreatedNoRItems.indexOf(d) === -1);
            const treatedHighItems = treatedItems.filter(d => {
                const status = d[primarySortFieldName];
                const rate = d[secondarySortFieldName];
                return status && rate && rate.toLowerCase() === "high";
            });
            const treatedLowItems = treatedItems.filter(d => {
                const status = d[primarySortFieldName];
                const rate = d[secondarySortFieldName];
                return status && rate && rate.toLowerCase() === "low";
            });
            const treatedNoRItems = treatedItems.filter(d => {
                const status = d[primarySortFieldName];
                const rate = d[secondarySortFieldName];
                return status && rate && rate.toLowerCase() === "no rating";
            });
            const others = treatedItems.filter(d => treatedHighItems.indexOf(d) === -1
                && treatedLowItems.indexOf(d) === -1
                && treatedNoRItems.indexOf(d) === -1);
            return sortByMilestoneDate(untreatedHighItems).concat(sortByMilestoneDate(untreatedLowItems), sortByMilestoneDate(untreatedNoRItems), sortByMilestoneDate(treatedHighItems), sortByMilestoneDate(treatedLowItems), sortByMilestoneDate(treatedNoRItems), sortByMilestoneDate(others))
        }
    };

    // Group items by application Id
    groupByApplicationId = (dealingItems: IDealing[]): IDealing[] => {
        let tempDealings: IDealing[] = [];

        const primaryApplicantDealings = dealingItems.filter(d => d.isSelectedClient);
        const noPrimaryApplicantDealings = dealingItems.filter(d => !d.isSelectedClient);
        primaryApplicantDealings.forEach(dealing => {
            const relatedDealings = noPrimaryApplicantDealings.filter(d => d.applicationId === dealing.applicationId);
            tempDealings = tempDealings.concat([dealing].concat(relatedDealings));
        });

        return tempDealings;
    };

    get columns(): ICustomColumn[] {
        return [
            {
                fieldName: "applicationIdWithSystemCode",
                key: "applicationIdWithSystemCode",
                name: "ID (System)",
                minWidth: 150,
                headerClassName: "ande-irp-dealings-list--application-section",
                className: "ande-irp-dealings-list--application-section",
                isResizable: true,
                isSortable: true,
                sortType: SortType.text,
                onRender: (item: IDealing) => item.applicationIdWithSystemCode && item.applicationIdWithSystemCode !== "" ? 
                (   
                    item.sourceSystemCode === "IRIS" ? 
                        new IRPExternalLinksModel(ValidIRPLinksSystemCodes.iris).generateLink({
                            idType: "requestId",
                            id: item.applicationId,
                            userId: this._IRPStore.userProfile.user.username,
                            linkText: item.applicationIdWithSystemCode
                        }) : 
                    ( item.sourceSystemCode === "ICSE" ?
                        new IRPExternalLinksModel(ValidIRPLinksSystemCodes.icse).generateLink({
                            idType: "requestId",
                            id: item.applicationId,
                            userId: this._IRPStore.userProfile.user.username,
                            linkText: item.applicationIdWithSystemCode
                        }) : item.applicationIdWithSystemCode
                    )
                ) 
                : null
            },
            {
                fieldName: "applicationType",
                key: "applicationType",
                name: "Type (Subclass)",
                minWidth: 150,
                headerClassName: "ande-irp-dealings-list--application-section",
                className: "ande-irp-dealings-list--application-section",
                isResizable: true,
                isSortable: true,
                sortType: SortType.text
            },
            {
                fieldName: "applicationRiskStage",
                key: "applicationRiskStage",
                name: "Application risk stage (Rating)",
                minWidth: 150,
                headerClassName: "ande-irp-dealings-list--application-section ande-irp-dealings-list--right-border",
                className: "ande-irp-dealings-list--application-section ande-irp-dealings-list--right-border",
                isResizable: true,
                isSortable: true,
                sortType: SortType.text,
                data: (item: IDealing) => item.applicationRiskStage,
                onRender: (item: IDealing) => item.isCVORRiskRating
                    ? new IRPExternalLinksModel(ValidIRPLinksSystemCodes.cvor).generateLink({
                        id: item.applicationId,
                        linkText: item.applicationRiskStage
                    }) : item.applicationRiskStage
            },
            {
                fieldName: "fullName",
                key: "fullName",
                name: "Client name (Role)",
                minWidth: 200,
                headerClassName: "ande-irp-dealings-list--client-section",
                className: "ande-irp-dealings-list--client-section",
                isResizable: true,
                isSortable: true,
                sortType: SortType.text,
                isSortedDescending: true,
                onRender: (item: IDealing) => {
                    const _loadClient = (e) => {
                        e.preventDefault();
                        item.sourceSystemCode === "IRIS" ? {} : 
                        this._IRPStore.routeToIRPApplet(this._host, true, {
                                sourcesystem: validIdSourceENUM.ICSE,
                                cid: item.cid[0]
                            }
                        )
                    };
                    return item.isSelectedClient || item.sourceSystemCode === "IRIS" ? item.fullName : React.createElement(Link, {
                        href: "#",
                        onClick: _loadClient
                    }, item.fullName);
                }
            },
            {
                fieldName: "milestone",
                key: "milestone",
                name: "Milestone (Date)",
                minWidth: 100,
                headerClassName: "ande-irp-dealings-list--client-section",
                className: "ande-irp-dealings-list--client-section",
                isResizable: true,
                isSortable: true,
                data: (item: IDealing) => moment(item.milestoneDate).format("YYYY-MM-DD"),
                sortType: SortType.date
            },
            {
                fieldName: "lastRiskCheckTs",
                key: "lastRiskCheckTs",
                name: "Risk last checked",
                minWidth: 100,
                headerClassName: "ande-irp-dealings-list--client-section",
                className: "ande-irp-dealings-list--client-section",
                isResizable: true,
                isSortable: true,
                sortType: SortType.text
            },
            {
                fieldName: "clientRiskStatus",
                key: "clientRiskStatus",
                name: "Client risk stage (Rating)",
                minWidth: 150,
                headerClassName: "ande-irp-dealings-list--client-section ande-irp-dealings-list--right-border",
                className: "ande-irp-dealings-list--client-section  ande-irp-dealings-list--right-border",
                isResizable: true,
                isSortable: true,
                sortType: SortType.text
            },
            {
                fieldName: "incompleteResultCount",
                key: "incompleteResultCount",
                name: "Incomplete",
                minWidth: 60,
                headerClassName: "ande-irp-dealings-list--matchSummary-section",
                className: "ande-irp-dealings-list--matchSummary-section",
                isResizable: true,
                isSortable: true,
                sortType: SortType.number
            },
            {
                fieldName: "confirmedResultCount",
                key: "confirmedResultCount",
                name: "Confirmed",
                minWidth: 60,
                headerClassName: "ande-irp-dealings-list--matchSummary-section",
                className: "ande-irp-dealings-list--matchSummary-section",
                isResizable: true,
                isSortable: true,
                sortType: SortType.number
            },
            {
                fieldName: "dismissedResultCount",
                key: "dismissedResultCount",
                name: "Dismissed",
                minWidth: 60,
                headerClassName: "ande-irp-dealings-list--matchSummary-section",
                className: "ande-irp-dealings-list--matchSummary-section",
                isResizable: true,
                isSortable: true,
                sortType: SortType.number
            }
        ];
    }
}


export {
    ClientRiskOverviewListService as default,
    ClientRiskOverviewListService
}