import './ClientRiskOverviewSummary.scss';
import {observer} from 'mobx-react';
import {MessageBar, MessageBarType} from 'office-ui-fabric-react/lib/MessageBar';
import * as React from 'react';
import RiskSummaryField from '../../shared/RiskSummaryField';
import ClientBio from './ClientBio';
import {dataTextToInputMoment} from "@twii/common/lib/util/Date";
import {Output as DateFormats} from "@twii/common/lib/DateFormats";
import {IClientRiskOverviewData} from "../model/ClientRiskOverviewModel";
import {isArray} from "@twii/common/lib/util/Lang";
import {IDocumentIdData} from "../model/IClientSummaryService";
import {IRPExternalLinksModel} from "../model/IRPExternalLinksModel";
import {ValidIRPLinksSystemCodes} from "../model/IRPExternalLinksModel";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import {HTMLProps} from "react";
import {IIRPStoreModel} from "../../service/IIRPStoreModel";
import {isEmptyObject} from "../../util/IRPHelper";
import {isBlank} from "@twii/common/lib/util/String";
import {SectionTitleBar} from "../../shared/SectionTitleBar";
import {ICmalItem} from "../model/ICmalService";

interface IClientDetailsModel {
    firstName?: string;
    lastName?: string;
    dob?: string;
    cob?: string;
    cor?: string;
    genderCode?: string
    citizenships?: string[];
    sourceSystemCode: string;
}

interface IVisaData {
    subClassCode?: string;
    subClassDesc?: string;
    expiryDate?: string;
}

interface IClientRiskOverviewListProps extends IAppletProps, HTMLProps<HTMLDivElement> {
    applicationClientRiskOverviewItem: IClientRiskOverviewData;
    cmalData: ICmalItem;
    cmalServiceStatus?: string;
}
@observer
class ClientRiskOverviewSummary extends React.Component<IClientRiskOverviewListProps, any> {
    private _IRPStore: IIRPStoreModel = this.props.host.state.irpState;
    
    render() {
        const className = "client-risk-overview-summary";
        if (!this.props.applicationClientRiskOverviewItem) {
            return null
        }
        const clientRiskOverview = this.props.applicationClientRiskOverviewItem;
        
        const clientBio: IClientDetailsModel = {
            firstName: clientRiskOverview.firstName,
            lastName: clientRiskOverview.lastName,
            dob: clientRiskOverview.dateOfBirth,
            cob: clientRiskOverview.countryOfBirth,
            cor: clientRiskOverview.countryOfResidences.join(', '),
            genderCode: clientRiskOverview.gender,
            citizenships: clientRiskOverview.citizenships,
            sourceSystemCode: ""
        };

        const alerts = clientRiskOverview && clientRiskOverview.data && clientRiskOverview.data.alerts ? clientRiskOverview.data.alerts : null;
        const statuses = clientRiskOverview && clientRiskOverview.data && clientRiskOverview.data.statuses ? clientRiskOverview.data.statuses : null;
        const ids = clientRiskOverview && clientRiskOverview.data && clientRiskOverview.data.identifiers ? clientRiskOverview.data.identifiers : null;
        const status = this.props.cmalData && this.props.cmalData.status ? this.props.cmalData.status : 
        (this.props.cmalServiceStatus ? this.props.cmalServiceStatus : null);

        const ccmdAlrts = alerts && alerts.ccmdAlert ?
            (alerts.ccmdAlert.openCasesCount ? `${alerts.ccmdAlert.openCasesCount} (Open), ` : "Nil (Open)") + " - " + 
            (alerts.ccmdAlert.closedCasesCount ? `${alerts.ccmdAlert.closedCasesCount} (Closed)` : "Nil (Closed)")
            : "Nil (Open) - Nil (Closed)";

        const renderCurrentVisas = () => {
            const currentVisas = statuses ? (statuses.currentVisas || []) : [];
            if(currentVisas && currentVisas.length > 0 ) {
                let isNotAllKeysNull = false;
                Object.values(currentVisas).map(key => {
                    if(key) {
                        if(key.currentVisaStatusCode || key.expiryDate || key.subClassCode || key.subClassDesc) {
                            isNotAllKeysNull = true;
                            return;
                        }
                        return "Not held";
                    }
                }); 

                if(!isNotAllKeysNull) {
                    return "Not held";
                }

                return currentVisas.map((i: IVisaData, index) => {
                    if(i.subClassCode || i.subClassDesc || i.expiryDate) {
                        const hyphen = i.subClassCode && i.subClassDesc ? " - " : " "; 
                        const subClassCode = i.subClassCode ? i.subClassCode + hyphen : "";
                        const subClassDesc = i.subClassDesc ? i.subClassDesc + " " : '';
                        const endDate = i.expiryDate ? `(End: ${dataTextToInputMoment(i.expiryDate).format(DateFormats.riskResumeDate)})` : "";
                        const currentVisaDetails = subClassCode + subClassDesc + endDate;
                        return <div key={index}>{currentVisaDetails}</div>;
                    }
                    return "Not held";
                });
            }
            else {
                return "Not held";
            }
            
        };

        const malAlertStatus = status || "";
        const renderMalAlertLink = () => {
            let idType: "ICSE" | "TRIPS" | "";
            let id: string;

            if(ids) {
                if (ids.ICSEClientId && ids.ICSEClientId.length > 0) {
                    idType = "ICSE";
                    id = ids.ICSEClientId[0];
                } else if (ids.TRIPSPersonId && ids.TRIPSPersonId.length > 0) {
                    idType = "TRIPS";
                    id = ids.TRIPSPersonId[0];
                } else {
                    idType = "";
                }
            }

            return idType ? (malAlertStatus !== "Status unavailable" 
                ? new IRPExternalLinksModel(ValidIRPLinksSystemCodes.mal).generateLink({
                    idType: idType,
                    id: id,
                    linkText: malAlertStatus
                }) : malAlertStatus)
                : null;
        };

        const renderLastVisa = () => {
            const lastVisa = statuses.lastVisa;
            if(lastVisa === null || isEmptyObject(lastVisa) || lastVisa === undefined) {
                return "Not held";
            }
            
            else if (lastVisa) {
                let isNotAllKeysNull = false;
                Object.values(lastVisa).map(key => {
                    if(key) {
                        isNotAllKeysNull = true;
                        return;
                    }
                }); 
                if(!isNotAllKeysNull) {
                    return "Not held";
                }
                const endDate = lastVisa.expiryDate ? `(End: ${dataTextToInputMoment(lastVisa.expiryDate).format(DateFormats.riskResumeDate)})` : "";
                const lastVisaSubClassDesc = lastVisa.subClassDesc ? lastVisa.subClassDesc + " " : "";
                const lastVisaSubClass = lastVisa.subClassCode  ? 
                (
                    (!isBlank(lastVisaSubClassDesc) ? lastVisa.subClassCode + " - "  + lastVisaSubClassDesc + " " : "")

                ) : " ";

                const lastVisaCombined = lastVisaSubClass + endDate;
                const lastVisaStr = isBlank(lastVisaCombined) ? "" : lastVisaCombined;
                return lastVisaStr;
                
            }
        };
        const renderTravelDocs = () => {
            const travelDocs = ids.travelDocs || [];
            if(travelDocs && travelDocs.length > 0) {
                return isArray(travelDocs)
                ? (travelDocs as Array<IDocumentIdData>).map((i, index) => <div
                    key={index}>{i.documentId} {i.issuingCountry ? `(${i.issuingCountry})` : ""}</div>)
                : travelDocs
            }
            else {
                return "No document recorded";
            }
           
        };

        const renderNationalIds = () => {
            const nationalIds = ids.nationalIds || [];
            if(nationalIds  && nationalIds.length > 0) {
                return nationalIds.map((i, index) =>
                <div key={index}>{i.documentId} ({i.issuingCountry})</div>)
            }
            else {
                return "No document recorded";
            }
        };

        const renderICSELinks = () => ids.ICSEClientId.map((cid, i) => {
            const userId = this._IRPStore.userProfile && this._IRPStore.userProfile.user && this._IRPStore.userProfile.user.username
                ? this._IRPStore.userProfile.user.username
                : "";
            const link = new IRPExternalLinksModel(ValidIRPLinksSystemCodes.icse)
                .generateLink({idType: "clientId", id: cid, linkText: `${cid} (ICSE)`, userId: userId});
            return <div key={i}>{link}</div>
        });

        const renderTRIPS = () => ids.TRIPSPersonId.map((pid, i) => {
                return <div key={i}>
                    {`${pid} (TRIPS)`}
                </div>
            }
        );

        const gridColClass = "risk-summary-item-col ms-Grid-col ms-md12";
        const iconNameStatuses = clientRiskOverview.getFiltered() ? "IncidentTriangle" : "Info";
        const iconColorClass = clientRiskOverview.getFiltered() ? "icon-color-class-orange" : "icon-color-class-blue";

        return clientRiskOverview
            ? (
                <div className={`ms-Grid ${this.props.className}`}>
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12">
                            <ClientBio clientDetails={clientBio} identifiers={ids}/>
                        </div>
                    </div>
                    <div className="ms-Grid-row risk-summary-item-container">
                        <div className={gridColClass}>
                            <SectionTitleBar title="Alerts" items={[]} breadcrumbItems={[]} iconName="AlertSolid" className={`icon-color-class-blue`} />
                            <RiskSummaryField label="MAL: "
                                              className={`risk-summary-item--mal-${malAlertStatus.toLowerCase()}`}
                                              onRenderValue={renderMalAlertLink}/>
                            <RiskSummaryField label="CCMD cases: " value={ccmdAlrts} className={className} />
                            <RiskSummaryField label="COI notes: "
                                              value={alerts && alerts.clientOfInterestAlert ? "Yes" : "No"} className={className} />
                        </div>
                        <div className={gridColClass}>
                            <SectionTitleBar title="Statuses" items={[]} breadcrumbItems={[]} iconName={iconNameStatuses} className={iconColorClass} />
                            <RiskSummaryField label="Lawful status:"
                                              value={statuses.lawfulStatus} className={className} />
                            <RiskSummaryField label="Current location:" value={statuses.currentLocation} className={className} />
                            <RiskSummaryField label="Current visas held:" onRenderValue={renderCurrentVisas} className={className} />
                            <RiskSummaryField label="Last visa held:" onRenderValue={renderLastVisa} className={className} />
                        </div>
                        <div className={gridColClass}>
                            <SectionTitleBar title="Client system identifiers" items={[]} breadcrumbItems={[]} iconName="Contact" className={`icon-color-class-blue`}/>
                            <RiskSummaryField label="Client ID (CID):"
                                              onRenderValue={renderICSELinks} className={className} />
                            <RiskSummaryField label="Trips ID (PID):"
                                              onRenderValue={renderTRIPS} className={className} />
                            <RiskSummaryField label="Travel documents:" onRenderValue={renderTravelDocs} className={className} />
                            <RiskSummaryField label="National IDs:" onRenderValue={renderNationalIds} className={className} />
                        </div>
                    </div>
                </div>
            )
            : <MessageBar messageBarType={MessageBarType.warning}>No client risk overview found</MessageBar>
    }
}

export {
    ClientRiskOverviewSummary as default,
    ClientRiskOverviewSummary,
    IClientRiskOverviewListProps,
    IClientDetailsModel
}