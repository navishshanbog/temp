import {
    ValidRiskMatchAssessmentOutcome, ViewMovement,
    ValidRiskMatchStatus, ValidRiskMatchViewStatus
} from "../../shared/RiskMatchValidValues";
import {IIRPStoreModel} from "../../service/IIRPStoreModel";
import {IButtonProps} from "office-ui-fabric-react/lib/Button";
import {IContextualMenuItem} from "office-ui-fabric-react/lib/ContextualMenu";
import {ICodeSet} from "../model/IGetCodeSetService";
import {IClientRiskMatch} from "../model/IRRClientRiskMatchesServiceResponseItem";

class ClientRiskCheckTreatmentsActionButtonsService {
    private _treatmentStatusButtons = [
        ValidRiskMatchViewStatus.inProgress,
        ValidRiskMatchViewStatus.confirmed,
        ValidRiskMatchViewStatus.dismissed
    ];

    //UniqueId: selected treatment status
    //data: dismissal reason Description
    updateRRS = (uniqueId: ValidRiskMatchViewStatus, data: string, store: IIRPStoreModel, item: IClientRiskMatch, userToIPNotes?: boolean) => {
        if (uniqueId) {
            data = store.dismissalReasons.getCdByDesc(data) || "OTH";
            const isDismissedSelected = uniqueId === ValidRiskMatchViewStatus.dismissed;
            if (uniqueId !== item.viewStatus || (isDismissedSelected && data !== item.dismissalReasonCode)) {
                return this.updateTreatmentStatus(uniqueId, data, store, userToIPNotes);
            } else {
                return Promise.resolve()
            }
        } else {
            return Promise.resolve()
        }
    };

    saveOtherReasonAsNote = (reason: string, item: IClientRiskMatch, store: IIRPStoreModel) => {
        const resultId = item.resultId;
        const treatmentsNotes = store.treatmentsNotes;

        const currentNote = treatmentsNotes.getTreatmentNote(resultId);
        treatmentsNotes.addTreatmentNote(resultId, reason);
        return store.saveNote({resultId: resultId, note: reason}).then(() => {
            if (currentNote) treatmentsNotes.addTreatmentNote(resultId, currentNote);
        }).catch(e => {
            if (currentNote) treatmentsNotes.addTreatmentNote(resultId, currentNote);
        });
    };

    getButtonGroupItems = (item: IClientRiskMatch) => {
        return this._treatmentStatusButtons
            .filter(i => i !== ValidRiskMatchViewStatus.dismissed)
            .map(i => {
                return {
                    uniqueId: i,
                    text: i,
                    disabled: item? !item.riskActionable : true
                };
            });
    };

    getDismissButtonProps = (item: IClientRiskMatch, dismissalReasons: ICodeSet,
                             onChangeFunction: (selectedItems: IButtonProps[]) => void): IButtonProps => {
        const dismissedOption = this._treatmentStatusButtons
            .find(i => i === ValidRiskMatchViewStatus.dismissed);

        let dismissalReasonDesc = (dismissalReasons && item && item.dismissalReasonCode) ? dismissalReasons.getDescByCd(item.dismissalReasonCode): "";
        return {
            text: `${dismissedOption} ${dismissalReasonDesc ? "- " + dismissalReasonDesc : ""}`,
            disabled: item ? !item.riskActionable: true,
            menuProps: {
                items: dismissalReasons.items
                    .map(reason => {
                        const menuItem: IContextualMenuItem = {
                            key: dismissedOption,
                            name: reason.description,
                            data: reason.description,
                            onClick: () => {
                                onChangeFunction([{
                                    uniqueId: dismissedOption,
                                    data: reason.description
                                }])
                            }
                        };
                        return menuItem;
                    })
            }
        }
    };

    updateTreatmentStatus = (uniqueId: ValidRiskMatchViewStatus, data: string, store: IIRPStoreModel, userToIPNotes?: boolean) => {
        // data = store.dismissalReasons.getCdByDesc(data);
        const item = store.selectedRiskMatch;
        
        if (uniqueId) {
            const isDismissedSelected = uniqueId === ValidRiskMatchViewStatus.dismissed;
            const selectedDealing = store.getSelectedDealing();
            if (uniqueId !== item.viewStatus || (isDismissedSelected && data !== item.dismissalReasonCode)) {
                let status;
                let outcome;
                let reason;
                let viewForUser;
                const applicationVersion: number = selectedDealing.applicationRiskCheckVersion;
                const clientVersion: number = selectedDealing.clientRiskCheckVersion;
                if (uniqueId === ValidRiskMatchViewStatus.inProgress) {
                    if(item.status && item.status === ValidRiskMatchStatus.COMPLETED) viewForUser=ViewMovement.U;
                    if(item.status || item.status == null) viewForUser= null;
                    status = ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS;
                    outcome = null;
                    reason = null;
                } else if (uniqueId === ValidRiskMatchViewStatus.dismissed) {
                    if(item.status && (item.status === ValidRiskMatchStatus.COMPLETED || item.status === ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS)) viewForUser=ViewMovement.D;
                    status = ValidRiskMatchStatus.COMPLETED;
                    outcome = ValidRiskMatchAssessmentOutcome.DISMISSED;
                    reason = data;
                } else if (uniqueId === ValidRiskMatchViewStatus.confirmed) {
                    if(item.status && (item.status === ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS)) viewForUser=ViewMovement.D;
                    status = ValidRiskMatchStatus.COMPLETED;
                    outcome = ValidRiskMatchAssessmentOutcome.CONFIRMED;
                }

                return store.updateTreatment({
                    resultId: item.resultId,
                    status: status,
                    outcome: outcome,
                    dismissalReasonCode: reason,
                    applicationRiskCheckVersion: applicationVersion,
                    clientRiskCheckVersion: clientVersion
                }).then(res => {
                    store.setViewModel({noClientRiskMatchesDataReFetch: true});
                    store.clientRiskMatches.updateClientRiskMatch(item.resultId, {
                        status: status,
                        riskAssessmentOutcome: outcome,
                        dismissalReasonCode: reason,
                        viewStatus: item.getRiskMatchViewStatus()
                    }, userToIPNotes);
                    const clientRisks = res.client;
                    if (clientRisks && clientRisks.identifiers) {
                        store.updateApplicationRiskCheckClient(clientRisks.identifiers, res);
                        store.reFetchTreatmentDetails(item.resultId);
                    }
                    store.setViewModel({noClientRiskMatchesDataReFetch: false});
                    return res;
                })
            } else {
                return Promise.resolve();
            }
        } else {
            return Promise.resolve();
        }
    }
}

export {
    ClientRiskCheckTreatmentsActionButtonsService as default,
    ClientRiskCheckTreatmentsActionButtonsService
}