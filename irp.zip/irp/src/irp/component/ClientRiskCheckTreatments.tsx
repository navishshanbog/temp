import * as React from "react";
import {css, KeyCodes} from "@uifabric/utilities";
import {observer} from "mobx-react";
import {Label} from "office-ui-fabric-react/lib/Label";
import {Icon} from "office-ui-fabric-react/lib/Icon";
import {ClientRiskCheckTreatmentsAdvice} from "./ClientRiskCheckTreatments--advice";
import {ClientRiskCheckTreatmentsNotes} from "./ClientRiskCheckTreatments--notes";
import {ClientRiskCheckTreatmentsActions} from "./ClientRiskCheckTreatments--actions";
import {SectionTitleBar, BreadCrumbItem} from "../../shared/SectionTitleBar";
import {IGetTreatmentNotesServiceResItem} from "../model/IGetTreatmentNotesService";
import {IGetTreatmentHistoryServiceResItem} from "../model/IGetTreatmentHistoryService";
import * as moment from "moment";
import {ISyncModel} from "@twii/common/lib/ISyncModel"
import {
    IClientRiskMatch
} from "../model/IRRClientRiskMatchesServiceResponseItem";
import "./ClientRiskCheckTreatments.scss"
import {IButtonProps, PrimaryButton } from "office-ui-fabric-react";
import {observable} from "mobx";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import * as StringUtils from "@twii/common/lib/util/String";
import {dataTimestampToOutputText} from "@twii/common/lib/util/Date";
import {ClientRiskCheckTreatmentsActionButtons} from "./ClientRiskCheckTreatments--actionButtons";

const sectionTitle = "Match details";

interface IMatchLogItem {
    userId: string;
    text: string;
    timestamp: string;
}

interface IClientRiskCheckTreatmentsProps extends IAppletProps {
    hotKeysService ?: any;
    userToIPNotes?: boolean;
    updateClientRisks?:(canAddNote?: boolean)=> void;
    setDimissalEntry?:(isDismissalValueRequired?: boolean) => void;
    handleBackAction?:()=> void;
    dismissalValueWarning?: boolean;
    irpState?: any;
}
interface ISubHeaderProps extends IAppletProps {
    selectedRiskMatch?: IClientRiskMatch;
    irpState?: any;
    hotKeysService ?: any;
    userToIPNotes?: boolean;
    dismissalValueWarning?: boolean;
    updateClientRisks?:(canAddNote?: boolean)=> void;
    setDimissalEntry?:(isDismissalValueRequired?: boolean) => void;
}

// should be merged with ClientRiskCheckDetails--table rendering ...
@observer
class SubHeaderDetails extends React.Component<ISubHeaderProps, any> {
    render() {
        const attachmentsCodeSet = this.props.irpState.attachmentsCodeSet;
        const treatmentAdvices = this.props.irpState.treatmentAdvices;
        var rNumber = this.props.selectedRiskMatch.riskNumber  && this.props.selectedRiskMatch.riskNumber.length > 0 ? this.props.selectedRiskMatch.riskNumber : "";
        var rName = this.props.selectedRiskMatch.riskName && this.props.selectedRiskMatch.riskName.length > 0 ? this.props.selectedRiskMatch.riskName : "";
        var riskLinkText = "";
        /*if (rNumber && rNumber.length > 30) {
            riskLinkText = rNumber.substring(0, 30);
            riskLinkText = StringUtils.isBlank(riskLinkText) ? "" : `${riskLinkText}\n\r`;
            riskLinkText = riskLinkText + ((rNumber.slice(0, 30) + rName).substring(0, 30));
        } else {
            if (rName) {
                riskLinkText = `${rNumber} - ${rName.substring(0, 35 - rNumber.length)}\n\r`;
                riskLinkText = riskLinkText + (rName.substring(35 - rNumber.length, 35 + (35 - rNumber.length)));
            }
        }*/
        riskLinkText = `${rNumber} - ${rName}\n\r`;
		
        // convert this to grid layout
        return (

            <div className="ande-treatments-risk-match-container-item">
                <div className="risk-match-details-sub-header-container">
                    <div className="risk-match-container-item-column-sub-header-wrapper-name">
                        <b>Risk name and number </b>
                        <div key={`${this.props.selectedRiskMatch.riskName}-sub-header-riskName`} 
                        style={{wordWrap: "break-word", overflowWrap: "break-word"}}>{riskLinkText}
                        </div>
                    </div>
                    <div className="risk-match-container-item-column-sub-header-wrapper-type">
                        <b>Risk type </b>
                        <div key={`${this.props.selectedRiskMatch.riskType}-sub-header-riskType`}>{this.props.selectedRiskMatch.riskType}</div>
                    </div>
                    <div className="risk-match-container-item-column-sub-header-wrapper-match">
                        <b>First matched </b>
                        <div key={`${this.props.selectedRiskMatch.matchedTs}-sub-header-firstM`}>{dataTimestampToOutputText(this.props.selectedRiskMatch.matchedTs)}
                        </div>
                    </div>
                    <div className="risk-match-container-item-column-sub-header-wrapper-trigger">
                        <b>Match trigger </b>
                        <div key={`${this.props.selectedRiskMatch.trigger}-sub-header-trigger`}>{this.props.irpState.matchTriggersCodeSet.getDescByCd(this.props.selectedRiskMatch.trigger)}
                        </div>
                    </div>
                    <div className="risk-match-container-item-column-sub-header-wrapper-status">
                        <b>Risk match status </b>
                        <div style={{paddingTop:"6%"}}>
                        <ClientRiskCheckTreatmentsActionButtons resultId={this.props.selectedRiskMatch.resultId}
                                                                host={this.props.host}
                                                                setDimissalEntry = {this.props.setDimissalEntry}
                                                                dismissalValueWarning = {this.props.dismissalValueWarning}
                                                                updateClientRisks={this.props.updateClientRisks}
                                                                enableIfActionable={true} userToIPNotes={this.props.userToIPNotes}
                                                                hotKeysService={this.props.hotKeysService}/>
                        </div>
                    </div>
                </div>
                
                <div className="ms-Grid" style={{paddingTop: "10px"}}>
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-md8" style={{borderWidth: "0px 1px 0px 0px", borderStyle: "solid", color: "#333333"}}>
                            { this.props.selectedRiskMatch.cvorMatch ? 
                                <Label><Icon iconName="Info" /><b>Treatment advice</b></Label> : null
                            }
                            { this.props.selectedRiskMatch.cvorMatch ? 
                                <div className="ande-client-risk-check-treatments-treatment-summary-long">
                                    {this.props.selectedRiskMatch.treatmentSummary ? this.props.selectedRiskMatch.treatmentSummary : null}
                                </div>
                            : 
                                <ClientRiskCheckTreatmentsAdvice host={this.props.host}
                                                                data={treatmentAdvices}
                                                                attachmentsCodeSet={attachmentsCodeSet} 
                                                                irpState={this.props.irpState}/>
                            }
                        </div>
                        <div className="ms-Grid-col ms-md4 treatments-current-allocated-workpoint-wrapper" style={{paddingTop: "0px"}}>
                                <div className="ms-Grid-row ms-md12" style={{borderWidth: "0px 1px 0px 0px", borderStyle: "solid", color: "#333333", paddingLeft: "7px"}}>
                                    <Label><Icon iconName="Work" /><b> Current allocated workpoint</b></Label>
                                    <div key={`ande-client-allocated-workgrp`} className="treatments-current-allocated-workpoint-text">{this.props.irpState.selectedRiskMatch.cvorMatch ? null :
                                        this.props.irpState.selectedDealing.allocatedWorkPoint}</div>
                                </div>
                                {/*<div className="ms-Grid-row ms-md12" style={{borderWidth: "0px 1px 0px 0px", borderStyle: "solid", color: "gray", paddingLeft: "7px"}}>
                                    <b>Risk treatment owner </b>
                                    <div key={`ande-client-allocated-risk-treatment-owner`}>placeholder</div>
                                </div>*/}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}



@observer
class ClientRiskCheckTreatments extends React.Component<IClientRiskCheckTreatmentsProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    @observable _filters: ("notes" | "logs")[] = ["notes", "logs"];
    private _breadcrumbItems: BreadCrumbItem[] = [];

    private _filterChanged = (items: IButtonProps[]) => {
        return this._filters = items.map(i => i.uniqueId as "notes" | "logs");
    };

    private _className = "client-risk-check-treatments";

    render() {
        const attachmentsCodeSet = this._IRPStore.attachmentsCodeSet;
        const selectedRiskMatch = this._IRPStore.selectedRiskMatch;
        const treatmentAdvices = this._IRPStore.treatmentAdvices;
        const treatmentNotes: IMatchLogItem[] = this._IRPStore.treatmentNotes.items.map((note: IGetTreatmentNotesServiceResItem) => {
            return {
                userId: note.userId,
                text: note.text,
                timestamp: note.noteTs
            }
        });
        const treatmentHistory: IMatchLogItem[] = this._IRPStore.treatmentHistory.items.map((revision: IGetTreatmentHistoryServiceResItem) => {
            return {
                userId: revision.revisionUser,
                text: revision.action,
                timestamp: revision.revisionTs
            }
        });
        const treatmentMatchEvalCaseDetails = this._IRPStore.matchEvalCaseDetails;
        const selectedDealing = this._IRPStore.getSelectedDealing();

        let matchLog = this._filters.indexOf("notes") > -1 ? treatmentNotes : [];
        matchLog = this._filters.indexOf("logs") > -1 ? matchLog.concat(treatmentHistory) : matchLog;
        matchLog = matchLog.sort((a, b) => {
            const momentA = moment(a.timestamp).unix();
            const momentB = moment(b.timestamp).unix();
            return momentB > momentA ? 1 : -1;
        });

        const matchLogSync: ISyncModel = this._IRPStore.treatmentNotes.sync.syncing || this._IRPStore.treatmentHistory.sync.error ? this._IRPStore.treatmentNotes.sync : this._IRPStore.treatmentHistory.sync;

        const _breadcrumbItems: BreadCrumbItem[] = [];
        const lastName = this._IRPStore.clientRiskOverview.data.lastName ? this._IRPStore.clientRiskOverview.data.lastName : "";
        const firstName = this._IRPStore.clientRiskOverview.data.firstName ? this._IRPStore.clientRiskOverview.data.firstName : "";
        const fullName = lastName + `, ` + firstName;
        if (selectedDealing) {
            _breadcrumbItems.push({label: `Client`, value: `${fullName}`, identifirer: this._className});
            _breadcrumbItems.push({label: `Interaction`, value: `${selectedDealing.applicationId} (${selectedDealing.sourceSystemCode})`, identifirer: this._className});
            _breadcrumbItems.push({label: `Risk Match`, value: `${selectedRiskMatch.riskNumber} - ${selectedRiskMatch.riskName}`, identifirer: this._className});
        }

        return (
            <div className="ande-treatments">
                <PrimaryButton style={{marginTop:"1%"}}
                    onClick={this.props.handleBackAction}
                    iconProps={{ iconName: "NavigateBack" }} className="ande-treatments-primary-button-back">Back</PrimaryButton>
                <SectionTitleBar title={sectionTitle} breadcrumbItems={_breadcrumbItems}/>
                    <SubHeaderDetails key={"client-details-sub-header"}
                        selectedRiskMatch={selectedRiskMatch} updateClientRisks={this.props.updateClientRisks} 
                        irpState={this._IRPStore} userToIPNotes={this.props.userToIPNotes} setDimissalEntry = {this.props.setDimissalEntry}
                        hotKeysService={this.props.hotKeysService} host={this.props.host} dismissalValueWarning = {this.props.dismissalValueWarning}/>
                <SectionTitleBar title={""}/>
                <div className="ms-Grid">
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-md8">
                            {selectedRiskMatch.cvorMatch ? 
                            <div>
                                <Label><Icon iconName="CustomListMirrored"/> <b> Match log</b></Label>
                                <div className="ande-client-risk-check-treatments--notes-cvor">
                                </div>
                            </div>
                             : 
                            <ClientRiskCheckTreatmentsNotes host={this.props.host}
                                                            data={matchLog}
                                                            sync={matchLogSync}
                                                            filterChanged={this._filterChanged}/>}
                        </div>
                        <div className="ms-Grid-col ms-md4">
                            <ClientRiskCheckTreatmentsActions matchEvalCase={treatmentMatchEvalCaseDetails}
                                                              host={this.props.host}/>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export {
    ClientRiskCheckTreatments as default,
    ClientRiskCheckTreatments,
    IMatchLogItem,
    IClientRiskCheckTreatmentsProps
}
