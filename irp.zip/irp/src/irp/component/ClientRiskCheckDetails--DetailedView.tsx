import * as React from "react";
import {observer} from "mobx-react";
import {observable} from "mobx";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import {ClientRiskCheckTreatments} from "./ClientRiskCheckTreatments";

interface IClientRiskCheckDetailsDetailedViewProps {
    showDetails?: boolean;
    irpState?: any;
    hotKeysService?: any;
    host: any;
    onClose?:() => void;
}

@observer
class ClientRiskCheckDetailsDetailedView extends React.Component<IClientRiskCheckDetailsDetailedViewProps, any> {

    private _onDismiss = () => {
        this.props.onClose();
    }

    render() {
        return (
            <Panel
                isOpen={this.props.showDetails}
                type={PanelType.large}
                onDismiss={this._onDismiss}
                isLightDismiss={true}
                onLightDismissClick={this.props.onClose}
                closeButtonAriaLabel="Close">
                <ClientRiskCheckTreatments {...this.props} hotKeysService = {this.props.hotKeysService} userToIPNotes={false}/>
            </Panel>
        )
    }
}
//isLightDismiss={true}*/
export { ClientRiskCheckDetailsDetailedView, IClientRiskCheckDetailsDetailedViewProps }
