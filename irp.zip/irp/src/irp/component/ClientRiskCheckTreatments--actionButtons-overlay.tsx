import * as React from "react";
import {observer} from "mobx-react";
import "./ClientRiskCheckTreatments--actionButtons.scss";
import {IAppletProps} from "@twii/common/lib/IAppletProps";
import {SyncingOverlay} from "../../shared/SyncingOverlay";
import {computed} from "mobx";
import {IClientRiskCheckTreatmentsHotKeysService} from "./ClientRiskCheckTreatments--hotKeys.service";
import * as StringUtils from "@twii/common/lib/util/String";
import { ValidRiskMatchViewStatus } from "../../shared/RiskMatchValidValues";

interface ClientRiskCheckTreatmentsActionButtonsOverlayProps extends IAppletProps {
    resultId?: string;
    enableIfActionable?: boolean;
  //  hotKeysService?: IClientRiskCheckTreatmentsHotKeysService
}


@observer
class ClientRiskCheckTreatmentsActionButtonsOverlay extends React.Component<ClientRiskCheckTreatmentsActionButtonsOverlayProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    @computed
    private get _item() {
        const riskMatches = this._IRPStore.clientRiskMatches;
        return riskMatches.items.find(i => i.resultId === this.props.resultId);
    }

    shouldComponentUpdate(nextProps) {
        return true;
    }

    render() {
        const isDismissalReasonSyncing = this._IRPStore.dismissalReasons.sync.syncing;
        
        if ((this._item && !this._item.riskActionable && !isDismissalReasonSyncing) ||
            (((this._item && StringUtils.equalsIgnoreCase(this._item.viewStatus, "Confirmed")) || 
                (this._item && StringUtils.equalsIgnoreCase(this._item.viewStatus, "Completed"))
                || (this._item && StringUtils.equalsIgnoreCase(this._item.viewStatus, "Dismissed"))) 
                && !this.props.enableIfActionable)) {

            let borderBorder = {};
            if(StringUtils.equalsIgnoreCase(this._item.viewStatus, "Confirmed"))  borderBorder["backgroundColor"] = "#a80000";
            else if((StringUtils.containsIgnoreCase(this._item.viewStatus, "Dismissed") ||
                    StringUtils.equalsIgnoreCase(this._item.viewStatus, "Completed")))
                borderBorder["backgroundColor"] = "#004b1c";
            else if(StringUtils.equalsIgnoreCase(this._item.viewStatus, ValidRiskMatchViewStatus.historicalCVOR)) {
                borderBorder["backgroundColor"] = "#005b70";
            }
            return <SyncingOverlay syncedBckGrnd={borderBorder} onRenderContent={() => this._item.viewStatus}/>

        } else if(this._item && !this._item.riskActionable && !isDismissalReasonSyncing && this.props.enableIfActionable) {
            let borderBorder = {};
            if(StringUtils.equalsIgnoreCase(this._item.viewStatus, "Confirmed"))  borderBorder["backgroundColor"] = "#a80000";
            else if((StringUtils.containsIgnoreCase(this._item.viewStatus, "Dismissed") ||
                    StringUtils.equalsIgnoreCase(this._item.viewStatus, "Completed")))
                borderBorder["backgroundColor"] = "#004b1c";
            return <SyncingOverlay syncedBckGrnd={borderBorder} onRenderContent={() => this._item.viewStatus}/>
        }
        /*if ((!this._item.riskActionable && !isDismissalReasonSyncing) ||
            (StringUtils.equalsIgnoreCase(this._item.viewStatus, "Confirmed") || StringUtils.equalsIgnoreCase(this._item.viewStatus, "Completed")
            || StringUtils.equalsIgnoreCase(this._item.viewStatus, "Dismissed"))) {

            return <SyncingOverlay onRenderContent={() => this._item.viewStatus}/>
        } */else {
            const syncElements: JSX.Element[] = [
                <SyncingOverlay key="saveDismissalReasonOvelay"
                                onRenderSync={() => "Loading Dismissal Reasons"}
                                onRenderContent={() => null}
                                onRenderError={{overlay: true, function: e => "Error: Dismissal reasons"}}
                                showSpinner
                                sync={this._IRPStore.dismissalReasons.sync}
                />];
            if (this._item && this._item.resultId && this._IRPStore.treatmentsNotes.isDirtyTreatmentNote(this._item.resultId)) {
                syncElements.push(<SyncingOverlay key="saveDismissalReasonNoteOverlay"
                                                  showSpinner
                                                  sync={this._IRPStore.treatmentsNotes.notes.sync}
                                                  onRenderSync={() => "Saving note"}/>);
            }
            const updateTreatmentStatusSync = this._item && this._item.resultId ? 
            this._IRPStore.updateTreatmentRequest.syncList.getSync(this._item.resultId) : null;
            if (updateTreatmentStatusSync) {
                syncElements.push(<SyncingOverlay key="updateTreatmentStatusOverlay"
                                                  showSpinner
                                                  onRenderError={{function: e => null, overlay: false}}
                                                  sync={updateTreatmentStatusSync}
                                                  onRenderSync={() => "Updating Status"}/>);
            }
            return syncElements;
        }
    }
}

export {
    ClientRiskCheckTreatmentsActionButtonsOverlay as default,
    ClientRiskCheckTreatmentsActionButtonsOverlay
}
