import * as React from "react";
import IAppletProps from "@twii/common/lib/IAppletProps";
import SyncContainer from "../../shared/SyncContainer";

import {ClientRiskOverviewSummary} from "./ClientRiskOverviewSummary";
import {observer} from "mobx-react";
import {Spinner} from "office-ui-fabric-react/lib/Spinner";
import {SyncingOverlay} from "../../shared/SyncingOverlay";
import {IIRPSimpleSearchRequest} from "../../search/model/IIRPSimpleSearchRequest";

import {css} from "@uifabric/utilities";

interface IClientRiskOverviewAppletProps extends IAppletProps {
    icseId?: string;
    tripsId?: string;
    caller?: string;
    urlParams?: IIRPSimpleSearchRequest;
}

@observer
class ClientRiskOverview extends React.Component<IClientRiskOverviewAppletProps, any> {
    private _IRPStore = this.props.host.state.irpState;

    render() {
        const _onRenderDone = () => {
            return <ClientRiskOverviewSummary {...this.props}
                                              className={css("client-risk-overview--summary")}
                                              applicationClientRiskOverviewItem={this._IRPStore.clientRiskOverview.data} 
                                                cmalData={this._IRPStore.clientRiskOverview.cmalData} cmalServiceStatus={this._IRPStore.clientRiskOverview.cmalServiceStatus}/>
        };

        const _onRenderSync = () => {
            return this._IRPStore.clientRiskOverview && this._IRPStore.clientRiskOverview.clientRiskOverview
                ? <SyncingOverlay onRenderContent={_onRenderDone}/>
                : (
                    <div>
                        <div className="client-risk-overview-container">
                            <Spinner className="sync-spinner" label="Loading..."/>
                        </div>
                    </div>
                )
        };

        return (
            <div className="client-risk-overview-applet">
                <SyncContainer host={this.props.host}
                               sync={this._IRPStore.clientRiskOverview.sync}
                               onRenderDefault={() => null}
                               onRenderSync={_onRenderSync}
                               onRenderDone={_onRenderDone}/>
            </div>
        )
    }
}

export {
    ClientRiskOverview as default,
    ClientRiskOverview,
    IClientRiskOverviewAppletProps
}
