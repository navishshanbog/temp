import {observable} from "mobx";
import {IListModel} from "@twii/common/lib/IListModel";
import {ListModel} from "@twii/common/lib/ListModel";

interface ITreatmentNoteModel {
    resultId: string;
    note: string;
}

class TreatmentNoteModel implements ITreatmentNoteModel {
    note: "";
    resultId: string;

    constructor(resultId, note?) {
        this.resultId = resultId;
        this.note = note ? note : "";
    }
}

interface ITreatmentNotesServiceModel {
    notes: IListModel<ITreatmentNoteModel>;

    findTreatmentById: (resultId: string) => ITreatmentNoteModel | false;
    findIndexById: (resultId: string) => number | false;
    getTreatmentNote: (resultId: string) => string;
    isDirtyTreatmentNote: (resultId: string) => boolean;
    addTreatmentNote: (resultId: string, note: string) => ITreatmentNoteModel;
    editTreatmentNote: (resultId: string, note: string) => ITreatmentNoteModel;
    removeTreatmentNote: (resultId: string) => boolean;
}

class TreatmentNotesServiceModel implements ITreatmentNotesServiceModel {
    @observable notes = new ListModel<ITreatmentNoteModel>();

    findTreatmentById = (resultId: string) => {
        const treatmentNote = this.notes.items.find((note: ITreatmentNoteModel) => resultId === note.resultId);
        return treatmentNote ? treatmentNote : false;
    };

    findIndexById = (resultId: string) => {
        const treatment = this.findTreatmentById(resultId);
        if (treatment) {
            const index = this.notes.items.indexOf(treatment);
            return index !== -1 ? index : false;
        } else {
            return false;
        }
    };

    getTreatmentNote = (resultId: string) => {
        const treatment = this.findTreatmentById(resultId);
        if (treatment) {
            return treatment.note;
        } else {
            return null
        }
    };

    isDirtyTreatmentNote = (resultId: string) => {
        const treatment = this.findTreatmentById(resultId);
        return !!treatment;
    };

    addTreatmentNote = (resultId: string, note: string) => {
        let treatmentNotes = this.notes.items.slice();
        let treatment = this.findTreatmentById(resultId);
        if (treatment) {
            this.editTreatmentNote(resultId, note);
        } else {
            treatment = new TreatmentNoteModel(resultId, note)
        }
        treatmentNotes.push(treatment);
        this.notes.setItems(treatmentNotes);
        return treatment;
    };

    editTreatmentNote = (resultId: string, note: string) => {
        let treatment = this.findTreatmentById(resultId);
        if (treatment) {
            treatment.note = note;
        } else {
            treatment = this.addTreatmentNote(resultId, note);
        }
        return treatment
    };

    removeTreatmentNote = (resultId: string) => {
        let treatmentIndex = this.findIndexById(resultId);
        if (treatmentIndex || treatmentIndex === 0) {
            let treatments = this.notes.items;
            treatments.splice(treatmentIndex, 1);
            this.notes.setItems(treatments);
            return true;
        } else {
            return false;
        }
    }
}

export {
    TreatmentNotesServiceModel as default,
    TreatmentNotesServiceModel,
    ITreatmentNotesServiceModel,
    ITreatmentNoteModel,
    TreatmentNoteModel
}