import {AxiosRequestConfig} from "axios";
import {IListModel} from "@twii/common/lib/IListModel";
import {ListModel} from "@twii/common/lib/ListModel";

enum ValidCodeSetNames {
    dismissalreasons = "dismissalreasons",
    attachments = "attachments",
    riskfilters = "riskfilters",
    threattypes = "threattypes",
    triggers = "triggers"
}

interface IGetCodeSetServiceReq extends AxiosRequestConfig {
    codeSetName: string;
}

interface IGetCodeSetServiceResItem {
    code: string;
    description: string;
}

interface IGetCodeSetServiceRes {
    entries: IGetCodeSetServiceResItem[]
}

interface IGetCodeSetService {
    getCodeSet(req: IGetCodeSetServiceReq): Promise<IGetCodeSetServiceResItem[]>;
}

interface ICodeSet extends IListModel<IGetCodeSetServiceResItem> {
    getDescByCd: (code: string) => string;
    getCdByDesc: (desc: string) => string;
}

class CodeSet extends ListModel<IGetCodeSetServiceResItem> implements ICodeSet {
    getDescByCd = (code: string) => {
        if(code) {
            const item = this.items.find(i => i.code === code);
            return item ? item.description : code;
        }
        return null;
    };

    getCdByDesc = (desc: string) => {
        const item = this.items.find(i => i.description === desc);
        return item ? item.code : null;
    }
}

export {
    IGetCodeSetService as default,
    IGetCodeSetService,
    IGetCodeSetServiceResItem,
    IGetCodeSetServiceReq,
    ICodeSet,
    CodeSet,
    IGetCodeSetServiceRes,
    ValidCodeSetNames
};