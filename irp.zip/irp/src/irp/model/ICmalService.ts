import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {SyncModel} from "@twii/common/lib/SyncModel";
import {validIdSourceENUM, validIdTypeENUM} from "../../shared/SystemIdTypeRefList";
import {isArray} from "@twii/common/lib/util/Lang";

enum ValidMalAlertStatus {
    Green = "Green",
    Red = "Red",
    Amber = "Amber"
}

interface ICmalItem {
    identifier: string;
    identifierType: string;
    status: string;
}

interface ICmal {
    data: ICmalItem;
    setData: (data: ICmalItem) => void;
    sync: ISyncModel;
    serviceStatus?: string;
}

class Cmal implements ICmal {
    private _initialState: ICmalItem = {
        identifier: undefined,
        identifierType: undefined,
        status: undefined
    };
    data: ICmalItem;
    sync: ISyncModel = new SyncModel();
    serviceStatus: string;
    setData = (data: ICmalItem) => {
        const cmalData = this._initialState;
        if(data.identifier) cmalData.identifier = data.identifier
        if(data.identifierType) cmalData.identifierType = data.identifierType
        if(data.status) cmalData.status = data.status

        this.data = cmalData;
    }
    setServiceStatus(serviceStatus: string) {
        this.serviceStatus = serviceStatus;
    }
}

interface ICmalServiceRes {
    CmalStatus: ICmalItem;
    errors?: any;
}


interface ICmalServiceReq {
    searchId: string;
    searchIdType: validIdTypeENUM,
    searchIdSource: validIdSourceENUM
}

interface ICmalService {
    getCmalService(req: ICmalServiceReq): Promise<ICmalServiceRes>;
}

export {
    ICmalService as default,
    ICmalService,
    ICmalServiceReq,
    ICmalServiceRes,
    ICmal,
    ICmalItem,
    Cmal,
    ValidMalAlertStatus
}