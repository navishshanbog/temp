import {IRRClientRiskMatchesServiceResponseItem} from "./IRRClientRiskMatchesServiceResponseItem";

interface IRRCvorHistoryClientRiskMatchesServiceRequest {
    ids: string;
    type: string;

}

interface CvorHistories {
    CvorHistory: IRRClientRiskMatchesServiceResponseItem[];
    filtered?: boolean;
}

interface GetRRCvorHistoryClientRiskMatchesServiceRestResponse {
    errors?: any;
    CvorHistories: CvorHistories[];
}

interface IRRCvorHistoryClientRiskMatchesService {
    getRRCvorHistoryClientRiskMatches(params: IRRCvorHistoryClientRiskMatchesServiceRequest): 
        Promise<GetRRCvorHistoryClientRiskMatchesServiceRestResponse>;
}

export {
    IRRCvorHistoryClientRiskMatchesService as default,
    IRRCvorHistoryClientRiskMatchesService,
    IRRCvorHistoryClientRiskMatchesServiceRequest, 
    GetRRCvorHistoryClientRiskMatchesServiceRestResponse, 
    CvorHistories
}