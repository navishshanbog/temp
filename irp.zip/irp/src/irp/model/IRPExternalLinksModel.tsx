import * as React from "react";
import {Link} from "office-ui-fabric-react/lib/Link";
import {DefaultButton} from "office-ui-fabric-react/lib/Button";

const icseValidValues = new (class {
    validParamKeys = {
        EnquiryName: "EnquiryName",
        EnquiryParameter: "EnquiryParameter",
        Environment: "Environment"
    };
    validEnquiryNameValues = {
        D_ClientEnquiryByTypeValue: "D_ClientEnquiryByTypeValue",
        D_ClientEnquiryToPRByTypeValue: "D_ClientEnquiryToPRByTypeValue",
        D_ClientEnquiryToMenuByTypeValue: "D_ClientEnquiryToMenuByTypeValue",
        D_PermissionRequestEnquiryByRID: "D_PermissionRequestEnquiryByRID"
    };
    validEnquiryParamValues = {
        Client_ID: "Client ID",
        Request_ID: "Request ID",
        PID: "PID", 
        IRIS_ID: "IRIS Application ID"
    };
    validEnvironmentValues = {
        DEV_ICSE: "DEV_ICSE", // PROD_ICSE	ICSE in production (E9)
        PROD_ICSE: "PROD_ICSE", // PROD_ICSE	ICSE in production (E9)
        STAGE_ICSE: "STAGE_ICSE", // STAGE_ICSE	ICSE in STAGE (E7)
        USERTEST_ICSE: "USERTEST_ICSE", // USERTEST_ICSE	ICSE in Integration Test (E6)
        PROD_OFFSPRING: "PROD_OFFSPRING", // PROD_OFFSPRING	ICSE-IRIS in production (E9)
        STAGE_OFFSPRING: "STAGE_OFFSPRING", // STAGE_OFFSPRING	ICSE-IRIS in STAGE (E7)
        USERTEST_OFFSPRING: "USERTEST_OFFSPRING" // USERTEST_OFFSPRING	ICSE-IRIS in Integration Test (E6)
        
    };
    getEnvironmentValue = (env) => {
        switch (env) {
            case "E4":
            return this.validEnvironmentValues.DEV_ICSE;
            case "E6":
                return this.validEnvironmentValues.USERTEST_ICSE;
            case "E7":
                return this.validEnvironmentValues.STAGE_ICSE;
            case "E9":
                return this.validEnvironmentValues.PROD_ICSE;
            default:
                return this.validEnvironmentValues.USERTEST_ICSE;
        }
    }

    getEnvironmentValueOffSpring = (env) => {
        switch (env) {
            case "E6":
                return this.validEnvironmentValues.USERTEST_OFFSPRING;
            case "E7":
                return this.validEnvironmentValues.STAGE_OFFSPRING;
            case "E9":
                return this.validEnvironmentValues.PROD_OFFSPRING;
            default:
                return this.validEnvironmentValues.USERTEST_OFFSPRING;
        }
    }
});

enum ValidIRPLinksSystemCodes {
    gois = "gois",
    csp = "csp",
    mal = "mal",
    cvor = "cvor",
    icse = "icse",
    iris = "iris"
}

interface IIRPExternalLinksModelOPTS {
    goisId?: string,
    goisViewType?: string;
    idType?: "ICSE" | "TRIPS" | "clientId" | "requestId" | "CID" | "PID" | "PRID" | "IRIS",
    id?: string,
    linkText?: string,
    env?: string,
    userId?: string, 
    ariaLabelText?: string, 
    applicationId?: string
}

const getEnv = () => {
    const hostName = window.location.hostname.toLowerCase();
    if (hostName.indexOf("localhost") > -1) return "local";
    else if (hostName.indexOf("e1") > -1) return "E1";
    else if (hostName.indexOf("e4") > -1) return "E4";
    else if (hostName.indexOf("e6") > -1) return "E6";
    else if (hostName.indexOf("portalsstage") > -1) return "E7";
    else if (hostName.indexOf("portals") > -1) return "E9";
    else return "local";
};

class IRPExternalLinksModel {
    private system: ValidIRPLinksSystemCodes;

    constructor(system: ValidIRPLinksSystemCodes) {
        this.setSystem(system);
    }

    setSystem(system: ValidIRPLinksSystemCodes) {
        this.system = system;
    };

    private get _env() {
        return getEnv();
    };

    get generateLink(): (opts: IIRPExternalLinksModelOPTS) => JSX.Element {
        switch (this.system) {
            case  ValidIRPLinksSystemCodes.gois :
                return (opts: { goisId: string, goisViewType?: string, linkText: string, applicationId?: string, idType: "ICSE" | "IRIS" }) => {
                    let href;
                    if(opts.goisViewType) {
                        href = `/gois/app?idType=GOIS_CLIENT_ID&action=${opts.goisViewType}&id=${opts.goisId}`;
                    } else {
                        if (opts.idType === "ICSE") {
                            href = `/gois/app?REQUEST_PAGE=MATCHED_ENTITY_SEARCH&APPLICATION_ID=${opts.applicationId}&ID_TYPE=PR_ID`;
                        } else if(opts.idType === "IRIS") {
                            href = `/gois/app?REQUEST_PAGE=MATCHED_ENTITY_SEARCH&APPLICATION_ID=${opts.applicationId}&ID_TYPE=IRIS_FAMILY_ID`;
                        }
                    }
                    return <Link
                        href={href}
                        target="_blank">
                        {opts.linkText}
                    </Link>
                };
            case ValidIRPLinksSystemCodes.mal :
                return (opts: { idType: "ICSE" | "TRIPS", id: string, linkText: string }) => <Link
                    href={`/cmal/status?s=${opts.idType}&i=${opts.id}`}
                    target="_blank">
                    {opts.linkText}
                </Link>;
            case ValidIRPLinksSystemCodes.icse :
                return (opts: { idType: "clientId" | "requestId", id: string, linkText: string, userId: string }) => {
                    let href;
                    let env: string = this._env;
                    env = (env.localeCompare("E6") !== 0 || env.localeCompare("E7") !== 0 || env.localeCompare("E9") !== 0) ? "E6" : env;
                    if (opts.idType === "clientId") {
                        href = `immi:icse? ${env} ${icseValidValues.validEnquiryNameValues.D_ClientEnquiryByTypeValue} "${icseValidValues.validEnquiryParamValues.Client_ID};${opts.id}" ${icseValidValues.getEnvironmentValue(this._env)}`;
                    } else if (opts.idType === "requestId") {
                        href = `immi:icse? ${env} ${icseValidValues.validEnquiryNameValues.D_PermissionRequestEnquiryByRID} "${icseValidValues.validEnquiryParamValues.Request_ID};${opts.id}" ${icseValidValues.getEnvironmentValue(this._env)}`;
                    }

                    return <Link href={href ? href : "#"} >
                        {opts.linkText}
                    </Link>
                };
            case ValidIRPLinksSystemCodes.csp :
                return (opts: { idType: "CID" | "PID", id: string, linkText: string, ariaLabelText: string }) => {
                    const url = `/clientSearchWeb/PortletController?identifier=${opts.id}&identifierType=${opts.idType}&partyType=PERSON&action=viewParty`;
                    return <Link href={url}
                        aria-label={`${opts.ariaLabelText} ${opts.linkText}`}
                        target="_blank">{opts.linkText}</Link>
                };
            case ValidIRPLinksSystemCodes.cvor :
                return (opts: { idType: "PRID", id: string, linkText: string }) => {
                    const url = `/riskresume/app?idType=PR_ID&id=${opts.id}`;
                    return <Link href={url}
                                 target="_blank">{opts.linkText}</Link>
                };
            case ValidIRPLinksSystemCodes.iris :
                return (opts: { idType: "clientId" | "requestId", id: string, linkText: string, userId: string }) => {
                    let href;
                    let env: string = this._env;
                    env = (env.localeCompare("E6") !== 0 || env.localeCompare("E7") !== 0 || env.localeCompare("E9") !== 0) ? "E6" : env;
                    if (opts.idType === "clientId") {
                        href = `immi:icse? ${env} ${icseValidValues.validEnquiryNameValues.D_ClientEnquiryByTypeValue} "${icseValidValues.validEnquiryParamValues.Client_ID};${opts.id}" ${icseValidValues.getEnvironmentValueOffSpring(this._env)}`;
                    } else if (opts.idType === "requestId") {
                        href = `immi:icse? ${env} ${icseValidValues.validEnquiryNameValues.D_PermissionRequestEnquiryByRID} "${icseValidValues.validEnquiryParamValues.IRIS_ID};${opts.id}" ${icseValidValues.getEnvironmentValueOffSpring(this._env)}`;
                    }

                    return <Link href={href ? href : "#"} >
                        {opts.linkText}
                    </Link>
                };
        }
    }
}

export {
    IRPExternalLinksModel as default,
    IRPExternalLinksModel,
    ValidIRPLinksSystemCodes,
    IIRPExternalLinksModelOPTS
}