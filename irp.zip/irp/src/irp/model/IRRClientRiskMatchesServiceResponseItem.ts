import {IListModel} from "@twii/common/lib/IListModel";
import {ListModel} from "@twii/common/lib/ListModel";
import {IDealing} from "./IDealings";
import {
    ValidRiskMatchAssessmentOutcome,
    ValidRiskMatchStatus,
    ValidRiskMatchViewStatus,
    ViewMovement
} from "../../shared/RiskMatchValidValues";
import * as moment from "moment";

interface IRRClientRiskMatchesServiceResponseItem {
    resultId: string;
    riskNumber: string;
    riskName: string;
    riskType: string;
    goisResult: boolean;
    goisEntityType?: string;
    matchEvalDismissed: boolean;
    matchedTs: string;
    trigger: string;
    treatmentSummary: string;
    noteCount: number;
    status: string;
    riskAssessmentOutcome: ValidRiskMatchAssessmentOutcome;
    riskRating: string;
    riskActionable: boolean;
    dismissalReasonCode: string;
    reassessmentWarning: boolean;
    threatMatch?: boolean;
    filterPolarity?: string;
    cvorMatch?: boolean;
}

interface IClientRiskMatch extends IRRClientRiskMatchesServiceResponseItem {
    getRiskMatchViewStatus: () => ValidRiskMatchViewStatus;
    visaSubclass: string;
    viewStatus: ValidRiskMatchViewStatus;
    key: string;
    showNotesForUserIp: boolean;
    showNoteIcon: boolean;
    actionedByUser: boolean;
    lastUpdated?: string;
}

class ClientRiskMatch implements IClientRiskMatch {
    resultId: string;
    riskNumber: string;
    riskName: string;
    riskType: string;
    goisResult: boolean;
    goisEntityType: string;
    matchEvalDismissed: boolean;
    matchedTs: string;
    trigger: string;
    treatmentSummary: string;
    noteCount: number;
    status: string;
    riskAssessmentOutcome: ValidRiskMatchAssessmentOutcome;
    riskRating: string;
    riskActionable: boolean;
    dismissalReasonCode: string;
    visaSubclass: string;
    showNotesForUserIp: boolean;
    showNoteIcon: boolean;
    actionedByUser: boolean;
    reassessmentWarning: boolean;
    key: string;
    lastUpdated?: string;
    cvorMatch?: boolean;

    get viewStatus() {
        return this.getRiskMatchViewStatus();
    }

    constructor(item: IRRClientRiskMatchesServiceResponseItem, dealing: IDealing) {
        Object.keys(item).forEach(key => {
            this[key] = item[key]
        });
        this.key = item.resultId;
        this.visaSubclass = dealing.applicationId;
        this.actionedByUser= false;
        this.showNotesForUserIp = false;
        this.showNoteIcon = false;
        this.lastUpdated = new Date().toString();
    }

    getRiskMatchViewStatus = (): ValidRiskMatchViewStatus => {
        let status: ValidRiskMatchViewStatus;

        if (this.status === ValidRiskMatchStatus.RISK_ASSESSMENT_UNTREATED) {
            status = ValidRiskMatchViewStatus.untreated;
        } else if (this.status === ValidRiskMatchStatus.RISK_ASSESSMENT_IN_PROGRESS) {
            status = ValidRiskMatchViewStatus.inProgress;
        } else if (this.riskAssessmentOutcome === ValidRiskMatchAssessmentOutcome.CONFIRMED) {
            status = ValidRiskMatchViewStatus.confirmed;
        } else if (this.riskAssessmentOutcome === ValidRiskMatchAssessmentOutcome.DISMISSED) {
            status = ValidRiskMatchViewStatus.dismissed;
        } else if (!this.riskActionable) {
            if (this.matchEvalDismissed) {
                status = ValidRiskMatchViewStatus.matchEvalDismissed;
            } else if (this.riskRating && this.riskRating.toLowerCase() === "low") {
                status = ValidRiskMatchViewStatus.positiveProfile;
            } else if (this.status === ValidRiskMatchStatus.UNDER_THREAT_EVAL) {
                status = ValidRiskMatchViewStatus.underThreatEval;
            } else {
                status = ValidRiskMatchViewStatus.historicalCVOR;
            }
        }

        return status;
    };
}

interface IClientRiskMatches extends IListModel<IClientRiskMatch> {
    initialSortRiskMatches: (items: IClientRiskMatch[]) => IClientRiskMatch[];
    updateClientRiskMatch: (resultId: string, newRiskMatchData: {
        status: string;
        riskAssessmentOutcome: string;
        dismissalReasonCode: string;
        viewStatus: string;
    }, uiFlag?: boolean) => void;
    setFiltered:(filtered: boolean) => void;
    getFiltered:() => boolean;
    setServiceErrored:(serviceErrored: boolean) => void;
    getServiceErrored:() => boolean;
}

class ClientRiskMatches extends ListModel<IClientRiskMatch> implements IClientRiskMatches {
    private filtered?: boolean = false;
    private serviceErrored?: boolean = false;
    private matchesFetched?: boolean = false;

    setFiltered = (filtered: boolean) => {
        this.filtered = filtered;
    }

    getFiltered = () => {
        return this.filtered;
    }

    setServiceErrored = (serviceErrored: boolean) => {
        this.serviceErrored = serviceErrored;
    }

    getServiceErrored = () => {
        return this.serviceErrored;
    }

    setMatchesFetched = (matchesFetched: boolean) => {
        this.matchesFetched = matchesFetched;
    }

    getMatchesFetched = () => {
        return this.matchesFetched;
    }

    

    initialSortRiskMatches = (items: IClientRiskMatch[]): IClientRiskMatch[] => {
        const sortByDate = (items: IClientRiskMatch[]) => {
            return items.sort((a, b) => {
                const aDate = moment(a.matchedTs).unix();
                const bDate = moment(b.matchedTs).unix();
                return aDate > bDate ? 1 : -1;
            });
        };

        const untreatedItems = sortByDate(items.filter(riskMatch => riskMatch.viewStatus === ValidRiskMatchViewStatus.untreated));
        const inProgressItems = sortByDate(items.filter(riskMatch => riskMatch.viewStatus === ValidRiskMatchViewStatus.inProgress));
        const underThreatEvalItems = sortByDate(items.filter(riskMatch => riskMatch.viewStatus === ValidRiskMatchViewStatus.underThreatEval));
        const confirmedItems = sortByDate(items.filter(riskMatch => riskMatch.viewStatus === ValidRiskMatchViewStatus.confirmed));
        const dismissedItems = sortByDate(items.filter(riskMatch => riskMatch.viewStatus === ValidRiskMatchViewStatus.dismissed));
        const completedOrDismissedThreatEval = sortByDate(items.filter(riskMatch => riskMatch.viewStatus === ValidRiskMatchViewStatus.positiveProfile
            || riskMatch.viewStatus === ValidRiskMatchViewStatus.matchEvalDismissed));

        const otherItems = sortByDate(items.filter(riskMatch => {
            return !untreatedItems.includes(riskMatch)
                && !inProgressItems.includes(riskMatch)
                && !underThreatEvalItems.includes(riskMatch)
                && !confirmedItems.includes(riskMatch)
                && !dismissedItems.includes(riskMatch)
                && !completedOrDismissedThreatEval.includes(riskMatch)
        }));

        return sortByDate(untreatedItems).concat(inProgressItems, underThreatEvalItems, confirmedItems, dismissedItems, completedOrDismissedThreatEval, otherItems);
    };

    updateClientRiskMatch = (resultId: string, newRiskMatchData, uiFlag?: boolean) => {
        const riskMatchIdx = this.items.findIndex(r => r.resultId === resultId);
        const riskMatch = this.items[riskMatchIdx];

        if (riskMatch) {
            Object.keys(newRiskMatchData).forEach(key => {
                if (riskMatch.hasOwnProperty(key) && key !== "viewStatus") {
                    riskMatch[key] = newRiskMatchData[key];
                }
                riskMatch.showNotesForUserIp = uiFlag;
                riskMatch.actionedByUser = uiFlag;

            });
            riskMatch.lastUpdated = new Date().toString();
        }
        this.setItems(this.items.slice());
    };
}

export {
    IRRClientRiskMatchesServiceResponseItem as default,
    IRRClientRiskMatchesServiceResponseItem,
    IClientRiskMatch,
    IClientRiskMatches,
    ClientRiskMatches,
    ClientRiskMatch,
    ValidRiskMatchViewStatus,
    ValidRiskMatchStatus,
    ValidRiskMatchAssessmentOutcome
}