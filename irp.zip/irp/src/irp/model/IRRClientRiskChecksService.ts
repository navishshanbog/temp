import {ListModel} from "@twii/common/lib/ListModel";
import {IListModel} from "@twii/common/lib/IListModel";
import {Subject} from "rxjs";
import {map} from "rxjs/operators/map";
import {IUpdateTreatmentServiceRes} from "./IUptateTreatmentService";
import {concat} from "rxjs/internal/operators";

enum ValidRRIdTypes {
    CLIENT_ROLE_ID = "CLIENT_ROLE_ID",
    VISA_GRANT_NUMBER = "VISA_GRANT_NUMBER"
}

interface IClientIds {
    type: ValidRRIdTypes;
    value: string;
}

interface IApps {
    sourceSystemId: string;      // mandatory
    sourceSystemCode: string;             // mandatory
}

interface IApplication{
    sourceSystemId: string;
    sourceSystemCode: string;
}

interface IRRClientRiskChecksServiceRequest {
    applications: IApps[];
    setRequest: (applications: IApplication[]) => IRRClientRiskChecksServiceRequest;
}

class RRClientRiskChecksServiceRequest implements IRRClientRiskChecksServiceRequest {
    applications: IApps[] = [];
    setRequest = (applications: IApplication[]) => {
        this.applications = applications.map(app => {
            return {
                sourceSystemId: app.sourceSystemId,
                sourceSystemCode: app.sourceSystemCode
            }
        });
        return this;
    }
}

interface IRRClientRiskChecksServiceResponseItemClient {
    identifiers: IClientIds[],
    riskRating: string,
    riskCheckStatus: string,
    lastRiskCheckTs: string,
    updatedTs: string,
    incompleteResultCount: number,
    untreatedResultCount: number,
    dismissedResultCount: number,
    confirmedResultCount: number,
    version: number
}

interface IRRClientRiskChecksServiceResponseItem {
    sourceSystemCode: string;
    sourceSystemId: string;
    riskCheckStatus: string;
    riskRating: string;
    updatedTs: string;
    fetchVRAMatches?: boolean;
    clients?: IRRClientRiskChecksServiceResponseItemClient[];
    version: number;
}

interface GetRRClientRiskCheckServiceRestResponse {
    errors?: any;
    applications?: IRRClientRiskChecksServiceResponseItem[];
    filtered?: boolean;
}

interface IUpdateApplicationClientSubject {
    id?: string;
    clientIds: IClientIds[],
    updateTreatmentRes: IUpdateTreatmentServiceRes;
}

interface IRRClientRiskChecks extends IListModel<IRRClientRiskChecksServiceResponseItem> {
    updateApplicationRiskCheckClientSubject: Subject<IUpdateApplicationClientSubject>;
    filtered?: boolean;
    setRiskChecksRetrieved:(riskChecksRetrieved: boolean) => void;
    getRiskChecksRetrieved:() => boolean;
}

class RRClientRiskChecks extends ListModel<IRRClientRiskChecksServiceResponseItem> implements IRRClientRiskChecks {
    updateApplicationRiskCheckClientSubject = new Subject<IUpdateApplicationClientSubject>();
    filtered?: boolean;//
    private riskChecksRetrieved?: boolean = false;

    constructor() {
        super();
        this.updateApplicationRiskCheckClientSubject.pipe(map(x => x), concat());
        this.updateApplicationRiskCheckClientSubject.subscribe((val: IUpdateApplicationClientSubject) => {
            this._updateApplicationRiskCheckClient(val.clientIds, val.updateTreatmentRes);
        })
    };

    setRiskChecksRetrieved = (riskChecksRetrieved: boolean) => {
        this.riskChecksRetrieved = riskChecksRetrieved;
    }

    getRiskChecksRetrieved = () => {
        return this.riskChecksRetrieved;
    }

    private _updateApplicationRiskCheckClient = (clientIds: IClientIds[], updateTreatmentRes: IUpdateTreatmentServiceRes) => {
        // Updating a particular client's application risk check details
        const tempItems = this.items.map(r => {
            const clients = r.clients.map(c => {
                const clientIndex = c.identifiers.findIndex(id => {
                    return (id.type === ValidRRIdTypes.CLIENT_ROLE_ID && clientIds.findIndex(i => i.value === id.value) > -1)
                        || (id.type === ValidRRIdTypes.VISA_GRANT_NUMBER && clientIds.findIndex(i => i.value === id.value) > -1)
                });

                if (clientIndex > -1) {
                    r.riskRating = updateTreatmentRes.application.riskRating;
                    r.riskCheckStatus = updateTreatmentRes.application.riskCheckStatus;
                    r.sourceSystemId = updateTreatmentRes.application.sourceSystemId;
                    r.sourceSystemCode = updateTreatmentRes.application.sourceSystemCode;
                    r.updatedTs = updateTreatmentRes.application.updatedTs;
                    r.version = updateTreatmentRes.application.version;
                    return updateTreatmentRes.client;
                } else {
                    return c;
                }
            });
            r.clients = clients;
            return r;
        });
        this.setItems(tempItems);
        return Promise.resolve();
    };
}

interface IRRClientRiskChecksService {
    getRRClientRiskChecks(params: IRRClientRiskChecksServiceRequest): Promise<GetRRClientRiskCheckServiceRestResponse>;
}

export {
    IRRClientRiskChecksService as default,
    IRRClientRiskChecksService,
    IApplication,
    IRRClientRiskChecksServiceRequest,
    RRClientRiskChecksServiceRequest,
    IClientIds,
    IApps,
    IRRClientRiskChecksServiceResponseItem,
    IRRClientRiskChecksServiceResponseItemClient,
    ValidRRIdTypes,
    IRRClientRiskChecks,
    RRClientRiskChecks,
    IUpdateApplicationClientSubject, 
    GetRRClientRiskCheckServiceRestResponse
}