import {AxiosRequestConfig} from "axios";
import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {SyncModel} from "@twii/common/lib/SyncModel";

interface IGetMatchEvalCaseDetailsServiceReq extends AxiosRequestConfig {
    resultId: string;
}

interface IGetMatchEvalCaseDetailsServiceResItem {
    caseId: string;                     // mandatory
    createdTs: string;   // mandatory; ISO-8601 format
    userId: string;                            // optional
    userName: string;                      // optional
    allocatedTs: string; // optional; ISO-8601 format
    dueDate: string;     // mandatory; ISO-8601 format
    status: string;                         // mandatory; CREATED/ALLOCATED/CLOSED
    updatedTs: string;   // optional; ISO-8601 format
}

interface IGetMatchEvalCaseDetailsServiceRes {
    case: IGetMatchEvalCaseDetailsServiceResItem
}

interface IGetMatchEvalCaseDetailsService {
    getMatchEvalCaseDetails(req: IGetMatchEvalCaseDetailsServiceReq): Promise<IGetMatchEvalCaseDetailsServiceResItem>;
}

interface IMatchEvalCaseDetails {
    data: IGetMatchEvalCaseDetailsServiceResItem;
    sync: ISyncModel;
    setData: (data: IGetMatchEvalCaseDetailsServiceResItem) => void;
}


class MatchEvalCaseDetails implements IMatchEvalCaseDetails {
    private _initialState = {
        caseId: "",                     // mandatory
        createdTs: "",   // mandatory, ISO-8601 format
        userId: "",                            // optional
        userName: "",                      // optional
        allocatedTs: "", // optional, ISO-8601 format
        dueDate: "",     // mandatory, ISO-8601 format
        status: "",                         // mandatory, CREATED/ALLOCATED/CLOSED
        updatedTs: ""   // optional, ISO-8601 format
    };

    data: IGetMatchEvalCaseDetailsServiceResItem;
    sync = new SyncModel();

    setData = (data: IGetMatchEvalCaseDetailsServiceResItem) => {
        const dataToBe: IGetMatchEvalCaseDetailsServiceResItem = this._initialState;
        if(data){
            if (data.caseId) dataToBe.caseId = data.caseId;
            if (data.createdTs) dataToBe.createdTs = data.createdTs;
            if (data.userId) dataToBe.userId = data.userId;
            if (data.userName) dataToBe.userName = data.userName;
            if (data.allocatedTs) dataToBe.allocatedTs = data.allocatedTs;
            if (data.dueDate) dataToBe.dueDate = data.dueDate;
            if (data.status) dataToBe.status = data.status;
            if (data.updatedTs) dataToBe.updatedTs = data.updatedTs;
        }

        this.data = dataToBe;
    }
}

export {
    IGetMatchEvalCaseDetailsService as default,
    IGetMatchEvalCaseDetailsService,
    IGetMatchEvalCaseDetailsServiceResItem,
    IGetMatchEvalCaseDetailsServiceReq,
    IGetMatchEvalCaseDetailsServiceRes,
    IMatchEvalCaseDetails,
    MatchEvalCaseDetails
};