import {AxiosRequestConfig} from "axios";
import {IListModel} from "@twii/common/lib/IListModel";
import {ListModel} from "@twii/common/lib/ListModel";

interface IGetTreatmentNotesServiceReq extends AxiosRequestConfig {
    resultId: string;
}

interface IGetTreatmentNotesServiceResItem {
    userId: string;
    text: string;
    noteTs: string
}

interface IGetTreatmentNotesServiceRes {
    notes: IGetTreatmentNotesServiceResItem[]
}

interface IGetTreatmentNotesService {
    getTreatmentNotes(req: IGetTreatmentNotesServiceReq): Promise<IGetTreatmentNotesServiceResItem[]>;
}

interface ITreatmentNotes extends IListModel<IGetTreatmentNotesServiceResItem> {
}

class TreatmentNotes extends ListModel<IGetTreatmentNotesServiceResItem> implements ITreatmentNotes {

}

export {
    IGetTreatmentNotesService as default,
    IGetTreatmentNotesService,
    IGetTreatmentNotesServiceReq,
    IGetTreatmentNotesServiceRes,
    IGetTreatmentNotesServiceResItem,
    ITreatmentNotes,
    TreatmentNotes
};