import IRiskResumeSearchHistoryEntry from "./IIRPSearchHistoryEntry";
import IListModel from "@twii/common/lib/IListModel";
import {IIRPSimpleSearchRequest} from "../../search/model/IIRPSimpleSearchRequest";
import {IIRPRiskSearchRequest} from "../../search/model/IIRPRiskSearchRequest";

interface IMasterEntitySearchHistoryModel extends IListModel<IRiskResumeSearchHistoryEntry> {
    load() : Promise<any>;
    addRequest(request : IIRPSimpleSearchRequest | IIRPRiskSearchRequest) : Promise<any>;
}

export { IMasterEntitySearchHistoryModel as default, IMasterEntitySearchHistoryModel };