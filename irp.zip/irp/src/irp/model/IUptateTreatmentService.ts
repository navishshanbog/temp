import {ValidRiskMatchAssessmentOutcome, ValidRiskMatchStatus} from "../../shared/RiskMatchValidValues";
import {ValidRRIdTypes} from "./IRRClientRiskChecksService";

interface IUpdateTreatmentServiceParams {
    resultId: string;
    status: ValidRiskMatchStatus;                // mandatory, RISK_ASSESSMENT_UNTREATED/RISK_ASSESSMENT_IN_PROGRESS/COMPLETED
    outcome: ValidRiskMatchAssessmentOutcome;               // CONFIRMED/DISMISSED. Mandatory when status is COMPLETED, must be null otherwise
    dismissalReasonCode: string;         // Mandatory when outcome is DISMISSED, must be null otherwise
    applicationRiskCheckVersion: number;
    clientRiskCheckVersion: number;
    transitionClass?: string,
}

interface IUpdateTreatmentServiceRes{
    status: ValidRiskMatchStatus,
    outcome: ValidRiskMatchAssessmentOutcome,
    dismissalReasonCode: string,
    riskRating: string,
    application: {
        sourceSystemId: string,
        sourceSystemCode: string,
        riskRating: string,
        riskCheckStatus: string,
        updatedTs: string,
        version: number
    },
    client: {
        identifiers: [{
            type: ValidRRIdTypes,
            value: string
        }],
        riskRating: string,
        riskCheckStatus: string,
        lastRiskCheckTs: string,
        updatedTs: string,
        incompleteResultCount: number,
        untreatedResultCount: number,
        dismissedResultCount: number,
        confirmedResultCount: number,
        version: number
    }
}

interface IUpdateTreatmentService {
    updateTreatment(req: IUpdateTreatmentServiceParams): Promise<IUpdateTreatmentServiceRes | any>;
}

export {
    IUpdateTreatmentService as default,
    IUpdateTreatmentService,
    IUpdateTreatmentServiceParams,
    IUpdateTreatmentServiceRes
};