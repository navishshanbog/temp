import {IIRPSimpleSearchRequest} from "../../search/model/IIRPSimpleSearchRequest";
import {IHistoryEntry} from "@twii/common/lib/IHistoryEntry";
import {IIRPRiskSearchRequest} from "../../search/model/IIRPRiskSearchRequest";

interface IIRPSearchHistoryEntry extends IHistoryEntry<IIRPSimpleSearchRequest | IIRPRiskSearchRequest> {}

export { IIRPSearchHistoryEntry as default, IIRPSearchHistoryEntry };