import {IListModel} from "@twii/common/lib/IListModel";
import {ListModel} from "@twii/common/lib/ListModel";
import {validIdSourceENUM, validIdTypeENUM} from "../../shared/SystemIdTypeRefList";

interface IClientBiographicsMileStone {
    milestone: string;
    milestoneDate: string;
}

interface IClientApplicationDealingsClient {
    lastName?: string;
    firstName?: string;
    VRAClientRole: string;
    ICSEClientId?: string[];
    TRIPSPersonId?: string[];
    IRISClientId?: string[];
    milestone: IClientBiographicsMileStone;
    visaGrantNumber: string;
    currentVisaStatusCode: string;
    finalisedFlag: string;
    prmsnRqstClientId?: string;
    TRIPSApplnId?: string;
    CVORClientRiskRating?: string;
    CVORMatchedDate?: string;
}

interface IClientApplicationDealingsItem {
    applicationId: string;
    sourceSystem: string;
    applicationType: {
        subClassCode: string;
        subClassDesc: string
    };
    clients: IClientApplicationDealingsClient[];
    CVORApplnRiskRating?: string;
    allocatedWorkPoint?: string;
}

interface IClientApplicationDealings extends IListModel<IClientApplicationDealingsItem> {
    getFiltered: () => boolean;
    setFiltered: (filtered: boolean) => void;
    setClientDealings:(_filtered: boolean, items: any) => void;
}

class ClientApplicationDealings extends ListModel<IClientApplicationDealingsItem> implements IClientApplicationDealings {
     filtered?: boolean = false;
     setClientDealings(_filtered: boolean, items: any) {
         this.setFiltered(_filtered);
         this.setItems(items);
     }

    getFiltered = () => {
        return this.filtered;
    }
    setFiltered = (filtered: boolean) => {
        this.filtered = filtered;
    }
}

interface IClientApplicationDealingsServiceRes {
    ClientApplicationDealings: IClientApplicationDealingsItem[];
    filtered?: boolean;
    errors?: any;
}

interface IClientApplicationDealingsServiceReq {
    searchId: string;
    searchIdType: validIdTypeENUM;
    searchIdSource: validIdSourceENUM;
    setRequest?: (icseId: string, tripsId: string) => IClientApplicationDealingsServiceReq;
}

class ClientApplicationDealingsServiceReq implements IClientApplicationDealingsServiceReq {
    searchId: string;
    searchIdType: validIdTypeENUM;
    searchIdSource: validIdSourceENUM;
    setRequest = (icseId: string, tripsId: string) => {
        if(icseId) {
            this.searchId = icseId;
            this.searchIdSource = validIdSourceENUM.ICSE;
            this.searchIdType = validIdTypeENUM.CID;
        } else if(tripsId) {
            this.searchId = tripsId;
            this.searchIdSource = validIdSourceENUM.TRIPS;
            this.searchIdType = validIdTypeENUM.PID;
        }
        return this;
}
}

interface IClientApplicationDealingsService {
    getClientApplicationDealings(req: IClientApplicationDealingsServiceReq): Promise<IClientApplicationDealingsServiceRes>;
}

export {
    IClientApplicationDealingsService as default,
    IClientApplicationDealingsService,
    IClientApplicationDealings,
    IClientApplicationDealingsServiceRes,
    IClientApplicationDealingsServiceReq,
    ClientApplicationDealingsServiceReq,
    IClientBiographicsMileStone,
    IClientApplicationDealingsClient,
    ClientApplicationDealings,
    IClientApplicationDealingsItem
}