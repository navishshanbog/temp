import {IIRPSimpleSearchRequest} from "../../search/model/IIRPSimpleSearchRequest";
import {IHistoryModel} from "@twii/common/lib/IHistoryModel";
import {HistoryModel} from "@twii/common/lib/HistoryModel";
import {Subject} from "rxjs/Subject";
import {concatMap} from "rxjs/internal/operators";
import {IIRPRiskSearchRequest} from "../../search/model/IIRPRiskSearchRequest";

enum SimpleSearchKeyEnum {
    idType = "Id type",
    referenceNumber = "Id number"
}

interface IIRPHistorySubjectItem {
    method: "get" | "add" | "remove" | "clear" | "setItems";
    value?: IIRPSimpleSearchRequest[] | IIRPRiskSearchRequest[];
}

interface ISearchHistoryModel extends IHistoryModel<IIRPSimpleSearchRequest | IIRPRiskSearchRequest> {
    funcExecuteSub;
    storageKey: string;
}

enum searchHistoryMethodTypes {
    add = "add",
    get = "get",
    setItems = "setItems",
    remove = "remove",
    clear = "clear",
    error = "error"
}

const countNotUndefinedItems = (obj: IIRPSimpleSearchRequest | IIRPRiskSearchRequest) => {
    let count = 0;
    Object.keys(obj).forEach(key => {
        if (obj[key]) {
            count += 1;
        }
    });
    return count;
};

class SearchHistoryModel extends HistoryModel<IIRPSimpleSearchRequest | IIRPRiskSearchRequest> implements ISearchHistoryModel {
    private _funcExecuteSub = new Subject<IIRPHistorySubjectItem>();
    funcExecuteSub;
    storageKey = "IRP-visited-items";

    constructor() {
        super();
        this.funcExecuteSub = this._funcExecuteSub.pipe(concatMap(item => {
            let output;
            switch (item.method) {
                case searchHistoryMethodTypes.get:
                    output = this._loadImpl().then(res => {
                        return {
                            method: searchHistoryMethodTypes.get,
                            value: res
                        };
                    }).catch(e => {
                        console.log(e);
                    });
                    break;
                case searchHistoryMethodTypes.add:
                    if (!searchHistoryMethodTypes.hasOwnProperty(item.method)) {
                        output = Promise.resolve({
                            method: searchHistoryMethodTypes.error,
                            value: "Error in making search history"
                        });
                    } else if (countNotUndefinedItems(item.value[0]) <= 0) {
                        output = Promise.reject({
                            method: searchHistoryMethodTypes.error,
                            value: "History has not properties"
                        });
                    } else {
                        output = this.addEntry(item.value[0]).then(() => {
                            return this._funcExecuteSub.next({method: searchHistoryMethodTypes.get});
                        }).catch(e => {
                            console.log(e)
                        });
                    }
                    break;
                case searchHistoryMethodTypes.setItems:
                    output = this.addEntry(item.value[0]).then(() => {
                        return this._funcExecuteSub.next({method: searchHistoryMethodTypes.get});
                    });
                    break;
                case searchHistoryMethodTypes.remove:
                    break;
                case searchHistoryMethodTypes.clear:
                    output = this.service.setItem(this.storageKey, []).then(() => {
                        return this.funcExecuteSub.next({method: searchHistoryMethodTypes.get});
                    });
                    break;
            }
            return output;
        }));
    }
}

export {
    SearchHistoryModel as default,
    SearchHistoryModel,
    ISearchHistoryModel,
    IIRPHistorySubjectItem,
    searchHistoryMethodTypes,
    SimpleSearchKeyEnum
}