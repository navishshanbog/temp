import {observable, action, computed} from "mobx";
import IError from "@twii/common/lib/IError";
import * as StringUtils from "@twii/common/lib/util/String";
import {IUpdateTreatmentServiceParams} from "./IUptateTreatmentService";
import {IMultiSyncModel, MultiSyncModel} from "../../shared/MultiSyncModel";
import {ValidRiskMatchAssessmentOutcome, ValidRiskMatchStatus} from "../../shared/RiskMatchValidValues";

interface IIRPUpdateTreatmentRequestModel {
    syncList: IMultiSyncModel
    validationErrors?: IError[];
}

class IRPUpdateTreatmentRequestModel implements IIRPUpdateTreatmentRequestModel {
    @observable syncList: IMultiSyncModel = new MultiSyncModel();
    @observable validationErrors?: IError[] = [];
    @observable private resultId: string;
    @observable private outcome: ValidRiskMatchAssessmentOutcome;
    @observable private status: ValidRiskMatchStatus;
    @observable private dismissalReasonCode: string;
    @observable private applicationRiskCheckVersion: number;
    @observable private clientRiskCheckVersion: number;

    @computed
    get isValid() {
        return this.validationErrors.length === 0;
    }

    @computed
    get areAllValueSpecified() {
        return this.isResultIdSpecified &&
            this.isOutcomeSpecified &&
            this.isDismissalReasonSpecified &&
            this.isStatusSpecified;
    }

    @action
    setResultId(resultId?: string): void {
        this.resultId = resultId;
    }

    @action
    setOutcome(outcome?: ValidRiskMatchAssessmentOutcome): void {
        this.outcome = outcome;
    }

    @action
    setStatus(status?: ValidRiskMatchStatus): void {
        this.status = status;
    }

    @action
    setDismissalReason(dismissalReasonCode?: string): void {
        this.dismissalReasonCode = dismissalReasonCode;
    }

    @action
    setApplicationVersion(version?: number): void {
        this.applicationRiskCheckVersion = version;
    }

    @action
    setClientVersion(version?: number): void {
        this.clientRiskCheckVersion = version;
    }

    @computed
    get isResultIdSpecified() {
        return StringUtils.isNotBlank(this.resultId);
    }

    @computed
    get isStatusSpecified() {
        return StringUtils.isNotBlank(this.status);
    }

    @action
    clearResultId() {
        this.resultId = undefined;
    }

    @computed
    get isDismissalReasonSpecified() {
        return StringUtils.isNotBlank(this.dismissalReasonCode);
    }

    @action
    clearDismissalReason() {
        this.dismissalReasonCode = undefined;
    }

    @action
    clearStatus() {
        this.status = undefined;
    }

    @computed
    get isOutcomeSpecified() {
        return StringUtils.isNotBlank(this.outcome);
    }

    @action
    clearOutcome() {
        this.outcome = undefined;
    }

    @computed
    get isApplicationVersionSpecified() {
        return !!(this.applicationRiskCheckVersion);
    }

    @action
    clearApplicationVersion() {
        this.applicationRiskCheckVersion = undefined;
    }

    @computed
    get isClientVersionSpecified() {
        return !!(this.clientRiskCheckVersion);
    }

    @action
    clearClientVersion() {
        this.clientRiskCheckVersion = undefined;
    }

    @computed
    get request(): IUpdateTreatmentServiceParams {
        return {
            resultId: StringUtils.isNotBlank(this.resultId) ? this.resultId : undefined,
            status: StringUtils.isNotBlank(this.status) ? this.status : undefined,
            outcome: StringUtils.isNotBlank(this.outcome) ? this.outcome : undefined,
            dismissalReasonCode: StringUtils.isNotBlank(this.dismissalReasonCode) ? this.dismissalReasonCode : undefined,
            applicationRiskCheckVersion: !!(this.applicationRiskCheckVersion) ? this.applicationRiskCheckVersion: undefined,
            clientRiskCheckVersion: !!(this.clientRiskCheckVersion) ? this.clientRiskCheckVersion : undefined
        };
    }

    set request(request: IUpdateTreatmentServiceParams) {
        this.setRequest(request);
    }

    @action
    setRequest(request: IUpdateTreatmentServiceParams) {
        if (request) {
            this.setResultId(request.resultId);
            this.setOutcome(request.outcome);
            this.setDismissalReason(request.dismissalReasonCode);
            this.setStatus(request.status);
            this.setApplicationVersion(request.applicationRiskCheckVersion);
            this.setClientVersion(request.clientRiskCheckVersion);
        } else {
            this.clear();
        }
    }

    @action
    validate() {
        this.validationErrors = [];
        if (!this.areAllValueSpecified) {
            this.validationErrors.push({message: "All values must be specified"});
        }
    }

    @action
    submit(requestHandler?: () => void) {
        this.validate();
        if (this.isValid && requestHandler) {
            requestHandler();
        }
    }

    @action
    clearValidation() {
        this.validationErrors = [];
    }

    @action
    clear(): void {
        this.clearValidation();
        this.clearResultId();
        this.clearOutcome();
        this.clearStatus();
        this.clearDismissalReason();
    }
}

export {
    IRPUpdateTreatmentRequestModel as default,
    IRPUpdateTreatmentRequestModel,
    IIRPUpdateTreatmentRequestModel
};