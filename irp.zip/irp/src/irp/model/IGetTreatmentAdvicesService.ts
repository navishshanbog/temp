import {AxiosRequestConfig} from "axios";
import {IListModel} from "@twii/common/lib/IListModel";
import {ListModel} from "@twii/common/lib/ListModel";

interface IGetTreatmentAdvicesServiceReq extends AxiosRequestConfig {
    resultId: string;
}

interface IGetTreatmentAdvicesServiceResItem {
    treatmentId: string;
    treatmentVersion: string;
    adviceType: string;
    adviceText: string;
    createdTs: string;
}

interface IGetTreatmentAdvicesServiceRes {
    treatmentAdvices: IGetTreatmentAdvicesServiceResItem[]
}

interface IGetTreatmentAdvicesService {
    getTreatmentAdvices(req: IGetTreatmentAdvicesServiceReq): Promise<IGetTreatmentAdvicesServiceResItem[]>;
}

interface ITreatmentAdvices extends IListModel<IGetTreatmentAdvicesServiceResItem> {}

class TreatmentAdvices extends ListModel<IGetTreatmentAdvicesServiceResItem> implements ITreatmentAdvices {
}

export {
    IGetTreatmentAdvicesService as default,
    IGetTreatmentAdvicesService,
    IGetTreatmentAdvicesServiceResItem,
    IGetTreatmentAdvicesServiceReq,
    IGetTreatmentAdvicesServiceRes,
    ITreatmentAdvices,
    TreatmentAdvices
};