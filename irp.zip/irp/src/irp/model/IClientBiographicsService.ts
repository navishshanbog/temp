import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {SyncModel} from "@twii/common/lib/SyncModel";
import {validIdSourceENUM, validIdTypeENUM} from "../../shared/SystemIdTypeRefList";
import {isArray} from "@twii/common/lib/util/Lang";

interface IClientBiographicsItem {
    firstName: string;
    lastName: string;
    fullName: string;
    dateOfBirth: string;
    gender: string;
    countryOfBirth: string;
    countryOfResidences: string[];
    citizenships: string[];
}

interface IClientBiographics {
    data: IClientBiographicsItem;
    setData: (data: IClientBiographicsItem) => void;
    sync: ISyncModel;
}

class ClientBiographics implements IClientBiographics {
    private _initialState: IClientBiographicsItem = {
        firstName: "",
        lastName: "",
        fullName: "",
        dateOfBirth: "",
        gender: "",
        countryOfBirth: "",
        countryOfResidences: [],
        citizenships: []
    };
    data: IClientBiographicsItem;
    setData = (data: IClientBiographicsItem) => {
        const clientBiographics = this._initialState;
        if(data.firstName) clientBiographics.firstName = data.firstName;
        if(data.lastName) clientBiographics.lastName = data.lastName;
        if(data.fullName) clientBiographics.fullName = data.fullName;
        if(data.dateOfBirth) clientBiographics.dateOfBirth = data.dateOfBirth;
        if(data.gender) clientBiographics.gender = data.gender;
        if(data.countryOfBirth) clientBiographics.countryOfBirth = data.countryOfBirth;
        if(isArray(data.citizenships)) clientBiographics.citizenships = data.citizenships;
        if(isArray(data.countryOfResidences)) clientBiographics.countryOfResidences = data.countryOfResidences;

        this.data = clientBiographics;
    };
    sync = new SyncModel();
}

interface IClientBiographicsServiceRes {
    ClientBiographics: IClientBiographicsItem;
    errors?: any;
}

interface IClientBiographicsServiceReq {
    searchId: string;
    searchIdType: validIdTypeENUM;
    searchIdSource: validIdSourceENUM;
    setRequest?: (icseid: string, tripsId: string) => void;
}

class ClientBiographicsServiceReq implements IClientBiographicsServiceReq {
    searchId: string;
    searchIdType: validIdTypeENUM;
    searchIdSource: validIdSourceENUM;
    setRequest = (icseId: string, tripsId: validIdTypeENUM) => {
        if(icseId) {
            this.searchIdType = validIdTypeENUM.CID;
            this.searchId = icseId;
            this.searchIdSource = validIdSourceENUM.ICSE;
        } else if(tripsId) {
            this.searchIdType = validIdTypeENUM.PID;
            this.searchId = tripsId;
            this.searchIdSource = validIdSourceENUM.TRIPS;
        }
    }
}

interface IClientBiographicsService {
    getClientBiographics(req: IClientBiographicsServiceReq): Promise<IClientBiographicsServiceRes>;
}

export {
    IClientBiographicsService as default,
    IClientBiographicsService,
    ClientBiographicsServiceReq,
    IClientBiographicsServiceReq,
    IClientBiographicsServiceRes,
    IClientBiographics,
    ClientBiographics,
    IClientBiographicsItem
}