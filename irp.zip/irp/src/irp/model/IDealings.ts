import {ISortableListModel} from "@twii/common/lib/ISortableListModel";
import {ISortModel} from "@twii/common/lib/ISortModel";
import {ListModel} from "@twii/common/lib/ListModel";
import {
    IRRClientRiskChecksServiceResponseItem, IRRClientRiskChecksServiceResponseItemClient,
    ValidRRIdTypes
} from "./IRRClientRiskChecksService";
import {IClientApplicationDealingsClient, IClientApplicationDealingsItem} from "./IClientApplicationDealingsService";
import {dataTextToInputMoment} from "@twii/common/lib/util/Date";
import {Output as DateFormats} from "@twii/common/lib/DateFormats";
import {isArray, isNumber} from "@twii/common/lib/util/Lang";
import * as moment from "moment";
import {IClientSummaryServiceIdentifiers} from "./IClientSummaryService";
import {observable, computed, action} from "mobx";
import CVORCodeTypeRefList from "../../util/CVORCodeTypeRefList";
import {
    ClientRiskMatches,
    IClientRiskMatch, ClientRiskMatch
} from "../model/IRRClientRiskMatchesServiceResponseItem";

enum ValidDealingStatus {
    Checking = "Checking",
    under_threat_val = "Under Threat Evaluation",
    in_risk_assessment = "In Risk Assessment",
    completed = "Completed"
}

interface IDealing {
    permissionReqId: string;
    vgn: string;
    cid?: string[],
    pid?: string[],
    iid?: string[],
    applicationId: string;
    applicationIdWithSystemCode: string;
    sourceSystemCode: string;
    applicationType: string;
    milestone: string;
    milestoneDate: string;
    applicationRiskRating: string;  //Required for table sorting
    applicationRiskStatus: string;  //Required for table sorting
    applicationRiskStage: string;
    clientRiskStatus: string;
    lastRiskCheckTs: string;
    updatedTs: string;
    incompleteResultCount: number;
    untreatedResultCount: number;
    dismissedResultCount: number;
    confirmedResultCount: number;
    fullName?: string;
    vRAClientRole?: string;
    isCVORRiskRating: boolean;
    hasCVORHistoricalMatches?: boolean;
    isSelectedClient: boolean;
    isPrimaryApplicant: boolean;
    isInRiskResults: boolean;
    riskResultsMathedId: ValidRRIdTypes;
    clientRiskCheckVersion: number;
    applicationRiskCheckVersion: number;
    cvorMatchesRetrieved?: boolean;
    cvorMatches?: IClientRiskMatch[];
    allocatedWorkPoint?: string;
    key: string;
    setDealing?: (data: IDealing) => IDealing;
    setFullName?: (fullName: string) => void;
}

class Dealing implements IDealing {
    @observable permissionReqId;
    @observable vgn;
    @observable cid;
    @observable pid;
    @observable iid;
    @observable applicationId;
    @observable applicationIdWithSystemCode;
    @observable sourceSystemCode;
    @observable applicationType;
    @observable milestone;
    @observable milestoneDate;
    @observable applicationRiskRating;
    @observable applicationRiskStatus;
    @observable applicationRiskStage;
    @observable clientRiskStatus;
    @observable lastRiskCheckTs;
    @observable updatedTs;
    @observable incompleteResultCount;
    @observable untreatedResultCount;
    @observable dismissedResultCount;
    @observable confirmedResultCount;
    fullName;
    @observable vRAClientRole;
    @observable isCVORRiskRating;
    @observable hasCVORHistoricalMatches;
    @observable isSelectedClient;
    @observable isPrimaryApplicant;
    @observable isInRiskResults;//When VRA client exists
    @observable riskResultsMathedId;
    @observable clientRiskCheckVersion;
    @observable applicationRiskCheckVersion;
    @observable cvorMatchesRetrieved;
    @observable cvorMatches;
    @observable key;
    @observable allocatedWorkPoint;

    private _initialState: IDealing = {
        applicationId: "",
        applicationIdWithSystemCode: "",
        permissionReqId: undefined,
        vgn: undefined,
        cid: [],
        pid: [],
        iid: [],
        sourceSystemCode: "",
        applicationType: "",
        milestone: "",
        milestoneDate: "",
        applicationRiskRating: "",
        applicationRiskStatus: "No data",
        applicationRiskStage: "",
        clientRiskStatus: "No data",
        lastRiskCheckTs: "",
        updatedTs: "",
        incompleteResultCount: undefined,
        untreatedResultCount: undefined,
        dismissedResultCount: undefined,
        confirmedResultCount: undefined,
        fullName: "",
        vRAClientRole: "",
        isCVORRiskRating: false,
        hasCVORHistoricalMatches: false,
        isSelectedClient: false,
        isPrimaryApplicant: false,
        isInRiskResults: false,
        riskResultsMathedId: undefined,
        clientRiskCheckVersion: undefined,
        applicationRiskCheckVersion: undefined,
        cvorMatchesRetrieved: false,
        cvorMatches: [],
        key: undefined
    };

    @action
    setFullName(fullName : string) {
        this.fullName = fullName;
    }

    setDealing = (data: IDealing) => {
        this.permissionReqId = data.permissionReqId ? data.permissionReqId : this._initialState.permissionReqId;
        this.vgn = data.vgn ? data.vgn : this._initialState.vgn;
        this.cid = data.cid ? data.cid : this._initialState.cid;
        this.pid = data.pid ? data.pid : this._initialState.pid;
        this.iid = data.iid ? data.iid : this._initialState.iid;
        this.applicationId = data.applicationId ? data.applicationId : this._initialState.applicationId;
        this.sourceSystemCode = data.sourceSystemCode ? data.sourceSystemCode : this._initialState.sourceSystemCode;
        this.applicationIdWithSystemCode = data.applicationIdWithSystemCode ? data.applicationIdWithSystemCode : this._initialState.applicationIdWithSystemCode;
        this.applicationType = data.applicationType ? data.applicationType : this._initialState.applicationType;
        this.milestone = data.milestone ? data.milestone : this._initialState.milestone;
        this.milestoneDate = data.milestoneDate ? data.milestoneDate : this._initialState.milestoneDate;
        this.applicationRiskRating = data.applicationRiskRating ? data.applicationRiskRating : this._initialState.applicationRiskRating;
        this.applicationRiskStatus = data.applicationRiskStatus ? data.applicationRiskStatus : this._initialState.applicationRiskStatus;
        this.applicationRiskStage = data.applicationRiskStage ? data.applicationRiskStage : this._initialState.applicationRiskStage;
        this.clientRiskStatus = data.clientRiskStatus ? data.clientRiskStatus : this._initialState.clientRiskStatus;
        this.confirmedResultCount = isNumber(data.confirmedResultCount) ? data.confirmedResultCount : this._initialState.confirmedResultCount;
        this.incompleteResultCount = isNumber(data.incompleteResultCount) ? data.incompleteResultCount : this._initialState.incompleteResultCount;
        this.dismissedResultCount = isNumber(data.dismissedResultCount) ? data.dismissedResultCount : this._initialState.dismissedResultCount;
        this.untreatedResultCount = isNumber(data.untreatedResultCount) ? data.untreatedResultCount : this._initialState.untreatedResultCount;
        this.lastRiskCheckTs = data.lastRiskCheckTs ? data.lastRiskCheckTs : this._initialState.lastRiskCheckTs;
        this.fullName = data.fullName ? data.fullName : this._initialState.fullName;
        this.vRAClientRole = data.vRAClientRole ? data.vRAClientRole : this._initialState.vRAClientRole;
        this.updatedTs = data.updatedTs ? data.updatedTs : this._initialState.updatedTs;
        this.isCVORRiskRating = data.isCVORRiskRating ? data.isCVORRiskRating : this._initialState.isCVORRiskRating;
        this.hasCVORHistoricalMatches = data.hasCVORHistoricalMatches ? data.hasCVORHistoricalMatches : this._initialState.hasCVORHistoricalMatches;
        this.isSelectedClient = data.isSelectedClient ? data.isSelectedClient : this._initialState.isSelectedClient;
        this.isPrimaryApplicant = data.isPrimaryApplicant ? data.isPrimaryApplicant : this._initialState.isPrimaryApplicant;
        this.isInRiskResults = data.isInRiskResults ? data.isInRiskResults : this._initialState.isInRiskResults;
        this.riskResultsMathedId = data.riskResultsMathedId ? data.riskResultsMathedId : this._initialState.riskResultsMathedId;
        this.clientRiskCheckVersion = data.clientRiskCheckVersion ? data.clientRiskCheckVersion : this._initialState.clientRiskCheckVersion;
        this.applicationRiskCheckVersion = data.applicationRiskCheckVersion ? data.applicationRiskCheckVersion : this._initialState.applicationRiskCheckVersion;
        this.cvorMatchesRetrieved = false;
        this.cvorMatches = [];
        this.allocatedWorkPoint = data.allocatedWorkPoint ? data.allocatedWorkPoint : this._initialState.allocatedWorkPoint;

        this.key = `${this.permissionReqId ? this.permissionReqId : ""}${this.vgn ? this.vgn : ""}
            ${this.iid && this.iid.length > 0 && this.iid[0] ? this.iid[0] : ""}`;
        return this;
    }
}

interface IDealingsModel extends ISortableListModel<IDealing> {
    matchApplicationDealings: (cieClientApplicationOverview: IClientApplicationDealingsItem[], rrApplicationClientRiskOverview: IRRClientRiskChecksServiceResponseItem[], selectedClient: IClientSummaryServiceIdentifiers) => IDealing[];
    setRRApplicationClientRiskFilteredStatus: (rrApplicationClientRiskFilteredStatus: boolean) => void;
    getRRApplicationClientRiskFilteredStatus: () => boolean;
}

class DealingsModel extends ListModel<IDealing> implements IDealingsModel {
    sort: ISortModel;
    private rrApplicationClientRiskFilteredStatus?: boolean;

    setRRApplicationClientRiskFilteredStatus = (rrApplicationClientRiskFilteredStatus: boolean) => {
        this.rrApplicationClientRiskFilteredStatus = rrApplicationClientRiskFilteredStatus;
    };
    getRRApplicationClientRiskFilteredStatus = () => {
        return this.rrApplicationClientRiskFilteredStatus;
    };

    private _findMatchingDealing = (appId: string, client: IClientApplicationDealingsClient, rrApplicationClientRiskOverview: IRRClientRiskChecksServiceResponseItem[]): { dealing: IRRClientRiskChecksServiceResponseItem, client: IRRClientRiskChecksServiceResponseItemClient, matchedIdType: ValidRRIdTypes } => {
        let out: { dealing: IRRClientRiskChecksServiceResponseItem, client: IRRClientRiskChecksServiceResponseItemClient, matchedIdType: ValidRRIdTypes };
        const rrApplicationClientRiskOverviewApplication = rrApplicationClientRiskOverview.find(application => application.sourceSystemId === appId);
        if (rrApplicationClientRiskOverviewApplication) {
            out = {
                dealing: rrApplicationClientRiskOverviewApplication,
                client: null,
                matchedIdType: null
            };
            rrApplicationClientRiskOverviewApplication.clients.forEach((c, index) => {
                const permissionReqType = c.identifiers.find(i => i.type === ValidRRIdTypes.CLIENT_ROLE_ID);
                const permissionReqId = permissionReqType ? permissionReqType.value : null;
                const vgnType = c.identifiers.find(i => i.type === ValidRRIdTypes.VISA_GRANT_NUMBER);
                const vgn = vgnType ? vgnType.value : null;
                const c1 = !!(client.prmsnRqstClientId || permissionReqId) && client.prmsnRqstClientId === permissionReqId;
                const c2 = !!(client.visaGrantNumber || vgn) && client.visaGrantNumber === vgn;

                if (c1 || c2) {
                    out.client = c;
                    out.matchedIdType = c1 ? ValidRRIdTypes.CLIENT_ROLE_ID : (c2 ? ValidRRIdTypes.VISA_GRANT_NUMBER : null);
                }
            });
            return out;
        } else {
            return null;
        }
    };


    matchApplicationDealings = (cieClientApplicationOverview: IClientApplicationDealingsItem[],
                                rrApplicationClientRiskOverview: IRRClientRiskChecksServiceResponseItem[],
                                selectedClient: IClientSummaryServiceIdentifiers): IDealing[] => {
        const dealings: IDealing[] = [];

        cieClientApplicationOverview.forEach(application => {
            application.clients.forEach((client, index) => {
                if ((client.ICSEClientId && client.ICSEClientId.length > 0) || (client.TRIPSPersonId && client.TRIPSPersonId.length > 0)
                    || (client.IRISClientId && client.IRISClientId.length > 0)) {
                    const matchingRRDealingItem = this._findMatchingDealing(application.applicationId, client, rrApplicationClientRiskOverview);
                    const matchingRRDealing = matchingRRDealingItem ? matchingRRDealingItem.dealing : null;
                    const riskResultsMatchedId = matchingRRDealingItem ? matchingRRDealingItem.matchedIdType : undefined;
                    const matchingRRDealingClient = matchingRRDealingItem ? matchingRRDealingItem.client : undefined;
                    const milestone = client.milestone ? client.milestone : undefined;

                    const milestoneDate = milestone && client.milestone.milestoneDate ? dataTextToInputMoment(client.milestone.milestoneDate).format(DateFormats.riskResumeDate) : "";
                    const milestoneTxt = milestone && (`${client.milestone.milestone ? client.milestone.milestone + " " : ""}`) + (milestoneDate ? `(${milestoneDate})` : "");

                    const applicationType = application.applicationType.subClassDesc ? application.applicationType.subClassDesc : "" + application.applicationType.subClassCode ? `(${application.applicationType.subClassCode})` : "";

                    let isSelectedClient = false;
                    const selectedClientICSEClientId = selectedClient.ICSEClientId && selectedClient.ICSEClientId.length > 0 ? selectedClient.ICSEClientId : [];
                    const selectedClientTRIPSPersonId = selectedClient.TRIPSPersonId && selectedClient.TRIPSPersonId.length > 0 ? selectedClient.TRIPSPersonId : [];
                    const selectedClientIRISClientId = selectedClient.IRISClientId && selectedClient.IRISClientId.length > 0 ? selectedClient.IRISClientId : [];
                    const clientICSEClientId = client.ICSEClientId  && client.ICSEClientId.length > 0 ? client.ICSEClientId : [];
                    const clientTRIPSPersonId = client.TRIPSPersonId && client.TRIPSPersonId.length > 0 ? client.TRIPSPersonId : [];
                    const clientIRISClientId = client.IRISClientId && client.IRISClientId.length > 0 ? client.IRISClientId : [];

                    if((selectedClientICSEClientId && selectedClientICSEClientId.length > 0)
                        || (selectedClientTRIPSPersonId && selectedClientTRIPSPersonId.length > 0)
                        || (selectedClientIRISClientId && selectedClientIRISClientId.length > 0) &&
                        (clientICSEClientId && clientICSEClientId.length > 0 )
                        || (clientTRIPSPersonId && clientTRIPSPersonId.length > 0)
                        || (clientIRISClientId && clientIRISClientId.length > 0))
                    {
                        isSelectedClient = selectedClientICSEClientId.findIndex(cid => clientICSEClientId.indexOf(cid) > -1) > -1
                            || selectedClientTRIPSPersonId.findIndex(pid => clientTRIPSPersonId.indexOf(pid) > -1) > -1
                            || selectedClientIRISClientId.findIndex(iid => clientIRISClientId.indexOf(iid) > -1) > -1
                    }

                    const isPrimaryApplicant = client.VRAClientRole && client.VRAClientRole.toLowerCase().indexOf("primary") > -1;

                    let applicationRiskStage;
                    let isCVORRiskRating = false;
                    if (matchingRRDealing) {
                        applicationRiskStage = (matchingRRDealing.riskCheckStatus || matchingRRDealing.riskRating ?
                            (matchingRRDealing.riskCheckStatus ? matchingRRDealing.riskCheckStatus : "")
                            + (matchingRRDealing.riskRating ? ` (${matchingRRDealing.riskRating})` : "") : "No data");
                    } else if (application.CVORApplnRiskRating) {
                        applicationRiskStage = CVORCodeTypeRefList.getItemByKey(application.CVORApplnRiskRating).text;
                        isCVORRiskRating = true;
                    } else {
                        applicationRiskStage = "No data";
                        isCVORRiskRating = false;
                    }
                    const hasCVORHistoricalMatches = application.CVORApplnRiskRating ? true : false;
                    const lastRiskCheckTs = matchingRRDealing && (!matchingRRDealing.clients || matchingRRDealing.clients.length  === 0) ? null : (matchingRRDealingClient ?
                        (matchingRRDealingClient.lastRiskCheckTs ? matchingRRDealingClient.lastRiskCheckTs : null) : null);

                    const matchingRRDealingClientRiskCheckStatus = matchingRRDealingClient ?
                        (matchingRRDealingClient.riskCheckStatus ? matchingRRDealingClient.riskCheckStatus : "No data") : "No data";

                    const matchingRRDealingClientRiskRating = matchingRRDealingClient ?
                        (matchingRRDealingClient.riskRating ? matchingRRDealingClient.riskRating : "No data") : "No data";

                    const clientFirstName = client.firstName ? client.firstName : "";
                    const clientLastName = client.lastName ? client.lastName : "";
                    const clientFullName = !clientFirstName && !clientLastName ? "" : `${clientLastName}, ${clientFirstName}`;
                    const vRAClientRole = client.VRAClientRole ? client.VRAClientRole : "";
                    const clientCVORClientRiskRating = client.CVORClientRiskRating ? client.CVORClientRiskRating : "";

                    const dealingVal: IDealing = {
                        permissionReqId: client.prmsnRqstClientId ? client.prmsnRqstClientId : undefined,
                        vgn: client.visaGrantNumber ? client.visaGrantNumber : undefined,
                        cid: (client.ICSEClientId && client.ICSEClientId.length > 0 && isArray(client.ICSEClientId.slice())) ? client.ICSEClientId : [],
                        pid: (client.TRIPSPersonId && client.TRIPSPersonId.length > 0 && isArray(client.TRIPSPersonId.slice())) ? client.TRIPSPersonId : [],
                        iid: (client.IRISClientId && client.IRISClientId.length > 0 && isArray(client.IRISClientId.slice())) ? client.IRISClientId : [],
                        applicationId: application.applicationId,
                        allocatedWorkPoint: application.allocatedWorkPoint,
                        applicationIdWithSystemCode: `${application.applicationId} (${application.sourceSystem})`,
                        sourceSystemCode: application.sourceSystem,
                        applicationType: applicationType,
                        milestone: milestoneTxt,
                        milestoneDate: milestoneDate,
                        applicationRiskRating: matchingRRDealing ? matchingRRDealing.riskRating :
                            (application.CVORApplnRiskRating ? CVORCodeTypeRefList.getItemByKey(application.CVORApplnRiskRating).text : "No data"),
                        applicationRiskStatus: matchingRRDealing ? matchingRRDealing.riskCheckStatus : "No data",
                        applicationRiskStage: applicationRiskStage,
                        clientRiskStatus: matchingRRDealing && (!matchingRRDealing.clients || matchingRRDealing.clients.length  === 0) ? "No data" :
                            (matchingRRDealingClient ? `${matchingRRDealingClientRiskCheckStatus} (${matchingRRDealingClientRiskRating})`
                                : (CVORCodeTypeRefList.getItemByKey(clientCVORClientRiskRating) ?
                                    CVORCodeTypeRefList.getItemByKey(clientCVORClientRiskRating).text : "No data")),
                        lastRiskCheckTs: lastRiskCheckTs ? moment(lastRiskCheckTs).format(DateFormats.riskResumeDate)
                            : client.CVORMatchedDate ? moment(client.CVORMatchedDate).format(DateFormats.riskResumeDate) : "",
                        updatedTs: matchingRRDealingClient
                            ? moment(matchingRRDealingClient.updatedTs).format(DateFormats.riskResumeDate)
                            : undefined,
                        incompleteResultCount: matchingRRDealingClient ? matchingRRDealingClient.incompleteResultCount : undefined,
                        untreatedResultCount: matchingRRDealingClient ? matchingRRDealingClient.untreatedResultCount : undefined,
                        dismissedResultCount: matchingRRDealingClient ? matchingRRDealingClient.dismissedResultCount : undefined,
                        confirmedResultCount: matchingRRDealingClient ? matchingRRDealingClient.confirmedResultCount : undefined,
                        fullName: clientFullName,
                        vRAClientRole: client.VRAClientRole,
                        isCVORRiskRating: isCVORRiskRating,
                        hasCVORHistoricalMatches: hasCVORHistoricalMatches,
                        isSelectedClient: isSelectedClient,
                        isPrimaryApplicant: isPrimaryApplicant,
                        isInRiskResults: !!(matchingRRDealingClient),
                        riskResultsMathedId: riskResultsMatchedId,
                        clientRiskCheckVersion: matchingRRDealingClient ? matchingRRDealingClient.version : null,
                        applicationRiskCheckVersion: matchingRRDealing ? matchingRRDealing.version : null,
                        key: null
                    };
                    if (!dealingVal.isSelectedClient) {
                        dealingVal.applicationIdWithSystemCode = "";
                        dealingVal.applicationType = "";
                        dealingVal.applicationRiskStage = "";
                    }

                    const dealing: IDealing = new Dealing();
                    dealing.setDealing(dealingVal);
                    dealings.push(dealing);
                }
            })
        });
        return dealings;
    }
}

export {
    IDealingsModel as default,
    IDealingsModel,
    DealingsModel,
    IDealing,
    Dealing,
    ValidDealingStatus
};