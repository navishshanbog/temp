import {IClientSummary, IClientSummaryItem} from "./IClientSummaryService";
import {ICmalItem} from "./ICmalService";
import {IClientBiographicsItem} from "./IClientBiographicsService";
import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {SyncModel} from "@twii/common/lib/SyncModel";

interface IClientRiskOverviewData extends IClientBiographicsItem, IClientSummary {
    
}

interface IClientRiskOverview {
    cmalServiceStatus?: string;
    data: IClientRiskOverviewData;
    setData: (clientSummary: IClientSummary, clientBiographics: IClientBiographicsItem) => void;
    sync: ISyncModel;
    cmalData?: ICmalItem;
    setCmalData: (cmal?: ICmalItem) => void;
    setCmalServiceStatus(cmalServiceStatus: string);
}

class ClientRiskOverviewModel implements IClientRiskOverview {
    cmalServiceStatus: string;
    data: IClientRiskOverviewData;
    sync = new SyncModel();
    cmalData?: ICmalItem;
    
    setData = (clientSummary: IClientSummary, clientBiographics: IClientBiographicsItem) => {
        if (clientBiographics && clientSummary) {
            this.data = Object.assign({}, clientBiographics, clientSummary, {})
        }
        else {
            this.data = undefined;
        }
    }

    setCmalData = (cmal: ICmalItem) => {
        if (cmal) {
            this.cmalData = Object.assign({}, cmal, {})
        }
        else {
            this.cmalData = undefined;
        }
    }

    setCmalServiceStatus = (cmalServiceStatus: string) => {
        if (cmalServiceStatus) {
            this.cmalServiceStatus = cmalServiceStatus;
        }
        else {
            this.cmalServiceStatus = undefined;
        }
    }
}

export {
    IClientRiskOverview,
    IClientRiskOverviewData,
    ClientRiskOverviewModel
}