import {ITreatmentNoteModel} from "./TreatmentNotesServiceModel";

interface IAddTreatmentNoteServiceParams extends ITreatmentNoteModel{
}

interface IAddTreatmentNoteService {
    addTreatmentNote(params: IAddTreatmentNoteServiceParams): Promise<any>;
}

export {
    IAddTreatmentNoteService as default,
    IAddTreatmentNoteService,
    IAddTreatmentNoteServiceParams
};