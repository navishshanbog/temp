import {AxiosRequestConfig} from "axios";
import {IListModel} from "@twii/common/lib/IListModel";
import {ListModel} from "@twii/common/lib/ListModel";

interface IGetTreatmentHistoryServiceReq extends AxiosRequestConfig {
    resultId: string;
}

interface IGetTreatmentHistoryServiceResItem {
    revisionTs: string;
    revisionUser: string;
    action: string;
}

interface IGetTreatmentHistoryServiceRes {
    revisions: IGetTreatmentHistoryServiceResItem[]
}

interface IGetTreatmentHistoryService {
    getTreatmentHistory(req: IGetTreatmentHistoryServiceReq): Promise<IGetTreatmentHistoryServiceResItem[]>;
}

interface ITreatmentHistory extends IListModel<IGetTreatmentHistoryServiceResItem> {
}

class TreatmentHistory extends ListModel<IGetTreatmentHistoryServiceResItem> implements ITreatmentHistory {

}

export {
    IGetTreatmentHistoryService as default,
    IGetTreatmentHistoryService,
    IGetTreatmentHistoryServiceReq,
    IGetTreatmentHistoryServiceRes,
    IGetTreatmentHistoryServiceResItem,
    ITreatmentHistory,
    TreatmentHistory
};