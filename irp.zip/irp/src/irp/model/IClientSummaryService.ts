import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {SyncModel} from "@twii/common/lib/SyncModel";
import {validIdSourceENUM, validIdTypeENUM} from "../../shared/SystemIdTypeRefList";
import {isArray} from "@twii/common/lib/util/Lang";

enum ValidMalAlertStatus {
    Green = "Green",
    Red = "Red",
    Amber = "Amber"
}

interface IDocumentIdData {
    documentId: string;
    documentName: string;
    issuingCountry: string;
}

interface IClientSummaryServiceIdentifiers {
    ICSEClientId: string[];
    TRIPSPersonId: string[];
    IRISClientId?: string[];
    nationalIds: IDocumentIdData[];
    travelDocs: IDocumentIdData[] | "No Current Documents Exist";
}

interface IClientSummaryServiceAlerts {
    malAlertStatus?: string;
    cmalId?: string,
    ccmdAlert?: ICCMDAlertData;
    clientOfInterestAlert?: boolean;
}

interface IClientSummaryServiceStatuses {
    currentLocation: string;
    lawfulStatus: string;
    currentVisas: IVisaData[];
    lastVisa: IVisaData;
}

interface ICCMDAlertData {
    openCasesCount: number;
    closedCasesCount: number
}

interface IVisaData {
    subClassCode?: string;
    subClassDesc?: string;
    expiryDate: string;
    currentVisaStatusCode: string;
}

interface IClientSummaryItem {
    identifiers: IClientSummaryServiceIdentifiers;
    alerts: IClientSummaryServiceAlerts;
    statuses: IClientSummaryServiceStatuses;
}

interface IClientSummary {
    data: IClientSummaryItem;
    setData: (data: IClientSummaryItem) => void;
    sync: ISyncModel;
    setFiltered:(filtered: boolean) => void;
    getFiltered:() => boolean;
}

class ClientSummary implements IClientSummary {
    private _initialState: IClientSummaryItem = {
        identifiers: {
            TRIPSPersonId: [],
            travelDocs: [],
            nationalIds: [],
            ICSEClientId: [], 
            IRISClientId: []

        },
        statuses: {
            currentVisas: [],
            lastVisa: null,
            currentLocation: "Unavailable",
            lawfulStatus: "Unavailable"
        },
        alerts: {
            ccmdAlert: {
                openCasesCount: null,
                closedCasesCount: null
            },
            malAlertStatus: null,
            clientOfInterestAlert: null,
            cmalId: null
        }
    };

    private filtered?: boolean = false;

    setFiltered = (filtered: boolean) => {
        this.filtered = filtered;
    }

    getFiltered = () => {
        return this.filtered;
    }

    data: IClientSummaryItem;
    sync: ISyncModel = new SyncModel();
    setData = (data: IClientSummaryItem) => {
        const clientSummaryData = this._initialState;
        if (data.identifiers) {
            if (isArray(data.identifiers.ICSEClientId)) clientSummaryData.identifiers.ICSEClientId = data.identifiers.ICSEClientId;
            if (isArray(data.identifiers.TRIPSPersonId)) clientSummaryData.identifiers.TRIPSPersonId = data.identifiers.TRIPSPersonId;
            clientSummaryData.identifiers.IRISClientId = (data.identifiers.IRISClientId && data.identifiers.IRISClientId.length > 0 && isArray(data.identifiers.IRISClientId)) ? 
            data.identifiers.IRISClientId: [];
            if (isArray(data.identifiers.travelDocs)) {
                if(data.identifiers.travelDocs.length > 0) clientSummaryData.identifiers.travelDocs = data.identifiers.travelDocs
            }
            if (isArray(data.identifiers.nationalIds)) clientSummaryData.identifiers.nationalIds = data.identifiers.nationalIds;
        }
        if (data.statuses) {
            if (data.statuses.lawfulStatus) clientSummaryData.statuses.lawfulStatus = data.statuses.lawfulStatus;
            if (data.statuses.currentLocation) clientSummaryData.statuses.currentLocation = data.statuses.currentLocation;
            if (data.statuses.lastVisa) clientSummaryData.statuses.lastVisa = data.statuses.lastVisa;
            if (isArray(data.statuses.currentVisas)) clientSummaryData.statuses.currentVisas = data.statuses.currentVisas;
        }
        if (data.alerts) {
            if (data.alerts.cmalId) clientSummaryData.alerts.cmalId = data.alerts.cmalId;
            if (data.alerts.clientOfInterestAlert) clientSummaryData.alerts.clientOfInterestAlert = data.alerts.clientOfInterestAlert;
            if (data.alerts.malAlertStatus) clientSummaryData.alerts.malAlertStatus = data.alerts.malAlertStatus;
            if (data.alerts.ccmdAlert) clientSummaryData.alerts.ccmdAlert = data.alerts.ccmdAlert;
        }

        this.data = clientSummaryData;
    }
}

interface IClientSummaryServiceRes {
    ClientSummary: IClientSummaryItem;
    filtered: boolean;
    errors?: any;
}


interface IClientSummaryServiceReq {
    searchId: string;
    searchIdType: validIdTypeENUM,
    searchIdSource: validIdSourceENUM
}

interface IClientSummaryService {
    getClientSummaryService(req: IClientSummaryServiceReq): Promise<IClientSummaryServiceRes>;
}

export {
    IClientSummaryService as default,
    IClientSummaryService,
    IClientSummaryServiceReq,
    IClientSummaryServiceRes,
    IClientSummaryServiceIdentifiers,
    IClientSummaryServiceAlerts,
    IClientSummaryServiceStatuses,
    IVisaData,
    ICCMDAlertData,
    IDocumentIdData,
    IClientSummary,
    IClientSummaryItem,
    ClientSummary,
    ValidMalAlertStatus
}