import {IRRClientRiskMatchesServiceResponseItem} from "./IRRClientRiskMatchesServiceResponseItem";
import {IClientIds} from "./IRRClientRiskChecksService";

interface IRRClientRiskMatchesServiceRequest {
    identifier: IClientIds;
}

interface GetRRClientRiskMatchesServiceRestResponse {
    errors?: any;
    filterResults?: IRRClientRiskMatchesServiceResponseItem[];
    filtered?: boolean;
}

interface IRRClientRiskMatchesService {
    getRRClientRiskMatches(params: IRRClientRiskMatchesServiceRequest): Promise<GetRRClientRiskMatchesServiceRestResponse>;
}

export {
    IRRClientRiskMatchesService as default,
    IRRClientRiskMatchesService,
    IRRClientRiskMatchesServiceRequest, 
    GetRRClientRiskMatchesServiceRestResponse
}