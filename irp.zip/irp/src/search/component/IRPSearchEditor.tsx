import * as React from "react";
import {observer} from "mobx-react";
import {TextField} from "office-ui-fabric-react/lib/TextField";
import SystemIdTypeRefList from "../../shared/SystemIdTypeRefList";
import ValidationErrors from "@twii/common/lib/component/ValidationErrors";
//import {ButtonGroup} from "@twii/common/lib/component/ButtonGroup";
import {ButtonGroup} from "../../irpcommon/ButtonGroup";
import {IButtonProps} from "office-ui-fabric-react/lib";
import {IRPSearchActions} from "./IRPSearch--actions";
import {IIRPSearchProps} from "./IRPSearch";
import {isString} from "@twii/common/lib/util/Lang";

@observer
class IRPSearchEditor extends React.Component<IIRPSearchProps, any> {
    _handleIdChange = (value: string) => {
        this.props.searchRequest.setReferenceNumber(value);
    };

    render() {
        const idTypeOptions = SystemIdTypeRefList.itemsSorted;
        let buttonGroupItems: IButtonProps[] = [];
        idTypeOptions.forEach(i => {
            buttonGroupItems.push({
                uniqueId: i.key,
                text: i.text,
                href: ""
            });
        });

        const _onChanged = (selectedItems: IButtonProps[]) => {
            if (selectedItems && selectedItems.length > 0) {
                const selectedItem = selectedItems[0];
                const idType = selectedItem && selectedItem.uniqueId ? selectedItem.uniqueId : null;
                if (idType != null) {
                    this.props.searchRequest.setIdType(idType ? String(idType) : null);
                    this.props.searchRequest.validate();
                }
            }
        };

        const _onType = (e: React.KeyboardEvent<HTMLElement>) => {
            let value = (e.target as HTMLInputElement).value;
            value = isString(value) ? value.trim() : "";
            this.props.searchRequest.setReferenceNumber(value);
            this.props.searchRequest.validate();
        };

        return (
            <div className="risk-resume-search-editor">
                <ValidationErrors errors={this.props.searchRequest.validationErrors}/>
                <div className="ms-Grid">
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-ms12">
                            <ButtonGroup label="ID Type"
                                         items={buttonGroupItems}
                                         transition
                                         selectedKeys={[this.props.searchRequest.idType || ""]}
                                         onChanged={_onChanged}/>
                        </div>
                        <div className="ms-Grid-col ms-md12">
                            <TextField label="ID"
                                       onChanged={this._handleIdChange}
                                       value={this.props.searchRequest.request.referenceNumber || ""}
                                       onKeyUp={e => {
                                           _onType(e)
                                       }}/>
                        </div>
                        <div className="ms-Grid-col ms-md12">
                            <IRPSearchActions {...this.props}/>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export {IRPSearchEditor as default, IRPSearchEditor};