import * as React from "react";
import IAppletProps from "@twii/common/lib/IAppletProps";
import "../../shared/IRPGlobal.scss";
import "./IRPSearchApplet.scss";
import {IRPStoreModel} from "../../service/IRPStoreModel";
import {IRPSearch} from "./IRPSearch";
import {IRPSearchSearchCommandBar} from "./IRPSearch--command-bar";
import {IIRPRiskSearchRequestModel} from "../model/IIRPRiskSearchRequestModel";
import {IIRPSimpleSearchRequestModel} from "../model/IIRPSimpleSearchRequestModel";
import {IIRPSimpleSearchRequest} from "../model/IIRPSimpleSearchRequest";
import {initiateMock as cieMock} from "../../mock/cieMock";
import {initiateMock} from "../../mock/rrsMock";
import {IIRPStoreModel, IIRPStoreViewModel, ValidSearchTypes} from "../../service/IIRPStoreModel";
import {IRPAppHostWrapper} from "../../irp/component/IRPAppHostWrapper";
import {css} from "@uifabric/utilities";
import {IRPRiskSearch} from "./IRPRiskSearch";
import {IRPSearchResults} from "./IRPSearchResults";
import {SectionTitleBar} from "../../shared/SectionTitleBar";
import {IIRPRiskSearchRequest} from "../model/IIRPRiskSearchRequest";
import {observer} from "mobx-react";
import {observable} from "mobx";
//import {ButtonGroup} from "@twii/common/lib/component/ButtonGroup";
import {ButtonGroup} from "../../irpcommon/ButtonGroup";
import {IButtonProps} from "office-ui-fabric-react";
import {CollapsableLayout} from "../../shared/CollapsableLayout";
import {CollapsableLayoutHeader} from "../../shared/CollapsableLayout--header";
import {CollapsableLayoutLeft} from "../../shared/CollapsableLayout--left";
import {CollapsableLayoutRight} from "../../shared/CollapsableLayout--right";
import QuickLinks from "../../shared/QuickLinks";

interface IIRPSearchAppletParams extends IAppletProps {
    urlParams?: {
        riskSearchReq?: IIRPRiskSearchRequest,
        simpleSearchReq?: IIRPSimpleSearchRequest
    }
}

const IRPSearchAppletClassName = "irp-search-applet";
const IRPLayoutClassNames = {
    wrapper: "irp-applets-layout",
    withLeftPanel: "irp-applets-layout--with-left-panel",
    noLeftPanel: "irp-applets-layout--with-no-left-panel",
    left: "irp-applets-layout--left-panel",
    toggleBtn: "irp-applets-layout--toggle-button",
    toggleBtnIcon: "irp-applets-layout--toggle-button-icon",
    main: "irp-applets-layout--main-panel"
};

@observer
class IRPSearchApplet extends React.Component<IIRPSearchAppletParams, any> {
    private _IRPStore: IIRPStoreModel;
    private _IRPStoreViewModel: IIRPStoreViewModel;
    private riskSearchRequest: IIRPRiskSearchRequestModel;
    private simpleSearchRequest: IIRPSimpleSearchRequestModel;
    @observable defaultPageNumber: number = 0;

    componentWillMount() {
        if (!this.props.host.state.irpState) {
            this.props.host.setState({
                irpState: new IRPStoreModel()
            });
            if (window.location.href.indexOf("ciemock") > -1) {
                cieMock();
            }
            if (window.location.href.indexOf("rrsmock") > -1) {
                initiateMock();
            }
        }
        this._IRPStore = this.props.host.state.irpState;
        this._IRPStoreViewModel = this._IRPStore.getViewModel();
        this.riskSearchRequest = this._IRPStore.riskSearchRequest;
        this.simpleSearchRequest = this._IRPStore.simpleSearchRequest;
        this.props.host.title = "Risk search";
        this._IRPStore.activateKeyboardShortcutsService(this.props.host);
    };

    componentDidMount() {
        //Handling url parameters
        if (this.props.urlParams) {
            if (this.props.urlParams.riskSearchReq) {
                this.riskSearchRequest.setRequest(this.props.urlParams.riskSearchReq)
            }
            else if (this.props.urlParams.simpleSearchReq.idType || this.props.urlParams.simpleSearchReq.referenceNumber) {
                this.simpleSearchRequest.setIdType(this.props.urlParams.simpleSearchReq.idType);
                this.simpleSearchRequest.setReferenceNumber(this.props.urlParams.simpleSearchReq.referenceNumber);
            } else {
                this.simpleSearchRequest.setIdType("icseId");
            }
        }
    }

    private _simpleSearch = () => {
        this.simpleSearchRequest.submit(() => this._IRPStore.routeToIRPApplet(this.props.host));
    };

    private _riskSearch = () => {
        this.riskSearchRequest.setSort();
        this._IRPStore.applyRiskSearch();
        this.defaultPageNumber = 0;
    };

    private _pageChanged = (_pageNumber: number) => {
        this.defaultPageNumber = _pageNumber;
    }
    render() {
        const isLeftPanelOpen = this._IRPStoreViewModel.isLeftPanelOpen;
        const dPageNumber = this.defaultPageNumber;
        const irpBrandingClassName = this.props.host.root ? `${IRPSearchAppletClassName}--app-is-root` : "";
        const searchResult = this._IRPStore.riskSearchResults;

        const searchToggleBtns: IButtonProps[] = [{
            uniqueId: ValidSearchTypes.simpleSearch,
            text: "ID search"
        }, {
            uniqueId: ValidSearchTypes.riskSearch,
            text: "Risk search"
        }];
        const onSelectedSearchChange = (selectedSearches: IButtonProps[]) => {
            if (selectedSearches.length > 0) {
                this._IRPStoreViewModel.setSelectedSearch(selectedSearches[0].uniqueId as ValidSearchTypes);
            } else {
                this.forceUpdate();
            }
        };
		
        return (
            <IRPAppHostWrapper
                className={css(IRPSearchAppletClassName, `${IRPSearchAppletClassName}--wrapper`, irpBrandingClassName, "ms-Grid")}
                host={this.props.host} title="Risk search"
                hideHelp>
                <div className="irp-search-applet-top-bar" style={{display: "flex"}}>
                    <IRPSearchSearchCommandBar pageChanged={this._pageChanged} {...this.props} simpleSearchRequest={this.simpleSearchRequest}
                                           riskSearchRequest={this.riskSearchRequest}/>
                    <QuickLinks />
                </div>

                <div className="irp-search-applet-content">
                    <CollapsableLayout leftWidthPercent={23}
                                       collapseButtonWidthPixel={15}
                                       isLeftPanelOpen={isLeftPanelOpen}>
                        <CollapsableLayoutLeft width={0} offset={0}>
                            <div className={css(`${IRPSearchAppletClassName}--search-toggle-wrapper`)}>
                                <ButtonGroup items={searchToggleBtns}
                                             className={css(`${IRPSearchAppletClassName}--search-toggle`)}
                                             label="Search toggle"
                                             labelHidden
                                             transition
                                             transitionSeconds={.1}
                                             selectedKeys={[this._IRPStoreViewModel.selectedSearch]}
                                             onChanged={onSelectedSearchChange}/>
                            </div>
                            {this._IRPStoreViewModel.selectedSearch === ValidSearchTypes.simpleSearch
                                ? <><SectionTitleBar
                                    title="Client risk"/>
                                    <IRPSearch searchRequest={this.simpleSearchRequest}
                                               onSubmitRequest={this._simpleSearch}
                                               host={this.props.host}/></>
                                : <><SectionTitleBar title="Risk search"/>
                                    <IRPRiskSearch {...this.props}
                                                   searchRequest={this.riskSearchRequest}
                                                   threatTypesCodeSet={this._IRPStore.threatTypesCodeSet}
                                                   onSubmitRequest={this._riskSearch}/></>}
                        </CollapsableLayoutLeft>
                        <CollapsableLayoutRight>
                            <IRPSearchResults pageChanged={this._pageChanged} defaultPageNumber = {dPageNumber} host={this.props.host} searchResult={searchResult}/>
                        </CollapsableLayoutRight>
                    </CollapsableLayout>
                </div>
            </IRPAppHostWrapper>
        );
    }
}

export {
    IRPSearchApplet as default,
    IRPSearchApplet,
    IIRPSearchAppletParams
}