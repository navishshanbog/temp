import * as React from "react";
import {observer} from "mobx-react";
import {CommandBar} from "office-ui-fabric-react/lib/CommandBar";
import {IContextualMenuItem} from "office-ui-fabric-react/lib/ContextualMenu";
import IAppletProps from "@twii/common/lib/IAppletProps";
import {IIRPSimpleSearchRequest} from "../model/IIRPSimpleSearchRequest";
import {createHistoryMenuItem} from "@twii/common/lib/component/History";
import "../../shared/IRPGlobal.scss"
import "./IRPSearch.scss";
import {IIRPRiskSearchRequestModel} from "../model/IIRPRiskSearchRequestModel";
import {IHistoryEntry} from "@twii/common/lib/IHistoryEntry";
import {ISearchHistoryModel, searchHistoryMethodTypes, SimpleSearchKeyEnum} from "../../irp/model/SearchHistoryModel";
import {IIRPSimpleSearchRequestModel} from "../model/IIRPSimpleSearchRequestModel";
import {DefinitionList} from "@twii/common/lib/component/DefinitionList";
import {IIRPStoreModel, IIRPStoreViewModel, ValidSearchTypes} from "../../service/IIRPStoreModel";
import {SystemIdTypeRefList} from "../../shared/SystemIdTypeRefList";
import {IIRPRiskSearchRequest} from "../model/IIRPRiskSearchRequest";
import {isString} from "@twii/common/lib/util/Lang";
import {BaseButton} from "office-ui-fabric-react";
import {KeyCodes} from "@uifabric/utilities";
import {IRegisteredShortcuts, ShortcutType} from "../../service/KeyboardShortcuts.service";
import "./IRPSearch--command-bar.scss";

interface IRiskResumeSearchCommandBarProps extends IAppletProps {
    simpleSearchRequest?: IIRPSimpleSearchRequestModel;
    riskSearchRequest?: IIRPRiskSearchRequestModel;
    pageChanged?:(pageNumber: number)=> void;
}

@observer
class IRPSearchSearchCommandBar extends React.Component<IRiskResumeSearchCommandBarProps, any> {
    private _IRPStore: IIRPStoreModel;
    private _IRPStoreViewModel: IIRPStoreViewModel;
    private _searchHistory: ISearchHistoryModel;
    private _searchHistoryRef: BaseButton;

    private _setSearchHistoryRef = (ref: BaseButton) => {
        const keyBoardShortCutRef = this._IRPStoreViewModel.keyboardShortcutsService;
        if (ref && keyBoardShortCutRef) {
            this._searchHistoryRef = ref;
            const shortcutKeyObj: IRegisteredShortcuts = {
                keyCode: KeyCodes.r,
                shortcutFunction: () => {
                    if (ref) {
                        ref.openMenu();
                    }
                }
            };
            if (!keyBoardShortCutRef.isKeyRegistered(shortcutKeyObj)) {
                keyBoardShortCutRef.registerShortcut(shortcutKeyObj);
            }
        }
    };

    private _backToSearch = (): IContextualMenuItem => {
        if (this.props.host.path.toLowerCase().indexOf('search') === -1) {
            return {
                key: "backToSearch",
                name: "Back to Search",
                title: "Back to Search",
                ariaLabel: "Back to Search",
                iconProps: {
                    iconName: "Back"
                },
                onClick: () => {
                    this._IRPStore.routeToIRPSearchApplet(this.props.host);
                }
            }
        }
    };

    componentWillMount() {
        this._IRPStore = this.props.host.state.irpState;
        this._IRPStore.visitedItems.funcExecuteSub.next({method: searchHistoryMethodTypes.get});
        this._searchHistory = this._IRPStore.visitedItems;
        this._IRPStoreViewModel = this._IRPStore.getViewModel();
    }

    render() {
        const items: IContextualMenuItem[] = [
            createHistoryMenuItem({
                history: this._searchHistory,
                key: "recentSearches",
                title: `Recent Searches (${this._searchHistory.items.length})`,
                name: `Recent Searches (${this._searchHistory.items.length})`,
                ariaLabel: `Recent Searches (${this._searchHistory.items.length})`,
                id: "ande-irp-command-bar--search-history-button",
                componentRef: this._setSearchHistoryRef,
                onSelectItem: (item: IHistoryEntry<IIRPSimpleSearchRequest | IIRPRiskSearchRequest>) => {
                    //this.props.pageChanged(0);
                    if (item.value.hasOwnProperty("idType") || item.value.hasOwnProperty("referenceNumber")) {
                        this.props.simpleSearchRequest.setRequest(item.value as IIRPSimpleSearchRequest);
                        this._IRPStore.routeToIRPApplet(this.props.host);
                        this._IRPStoreViewModel.selectedSearch = ValidSearchTypes.simpleSearch;
                    } else {
                        this.props.riskSearchRequest.setRequest(item.value as IIRPRiskSearchRequest);
                        this._IRPStoreViewModel.selectedSearch = ValidSearchTypes.riskSearch;
                        this._IRPStore.routeToIRPSearchApplet(this.props.host);
                    }
                },
                onRenderItem: (item) => {
                    return Object.keys(item.value).map(key => {
                        const historyItemText = `${SimpleSearchKeyEnum[key] ? SimpleSearchKeyEnum[key] : key}: `;
                        const historyItemValue = SystemIdTypeRefList.getItemByKey(item.value[key])
                            ? SystemIdTypeRefList.getItemByKey(item.value[key]).text
                            : item.value[key];
                        return isString(historyItemValue) ? <DefinitionList className="ande-irp-search-history-item"
                                                                            key={key}
                                                                            name={historyItemText}>{`${historyItemValue} ;`}</DefinitionList> : null;
                    })
                }
            }),
            {
                key: "clearHistory",
                name: "Clear History",
                title: "Clear History",
                ariaLabel: "Clear History",
                disabled: !this._searchHistory || this._searchHistory.items.length === 0,
                onClick: () => {
                    this._IRPStore.visitedItems.funcExecuteSub.next({method: searchHistoryMethodTypes.clear})
                }
            }
        ];

        if (this._backToSearch()) {
            items.unshift(this._backToSearch())
        }

        return <CommandBar items={items} className="ande-irp-command-bar" />
    }
}

export {
    IRPSearchSearchCommandBar as default,
    IRPSearchSearchCommandBar,
    IRiskResumeSearchCommandBarProps
}