import * as React from "react";
import IRPSearchEditor from "./IRPSearchEditor";
import {KeyCodes} from "office-ui-fabric-react/lib/Utilities";
import {observer} from "mobx-react";
import {IIRPSearchProps} from "./IRPSearch";

@observer
class IRPSearchContainer extends React.Component<IIRPSearchProps, any> {

    private _handleKeyDown = (e: React.KeyboardEvent<HTMLElement>) => {
        if (e.which === KeyCodes.enter) {
            this.props.searchRequest.submit(this.props.onSubmitRequest)
        }
    };

    render() {
        return <div onKeyDown={this._handleKeyDown}>
            <IRPSearchEditor {...this.props} />
        </div>
    }
}

export {IRPSearchContainer as default, IRPSearchContainer};