import * as React from "react";
import IAppletProps from "@twii/common/lib/IAppletProps";
import IRPSearchContainer from "./IRPSearch--container";

import "../../shared/IRPGlobal.scss"
import "./IRPSearch.scss";
import {IIRPSimpleSearchRequestModel} from "../model/IIRPSimpleSearchRequestModel";

interface IIRPSearchProps extends IAppletProps {
    searchRequest?: IIRPSimpleSearchRequestModel;
    onSubmitRequest?: () => Promise<any> | void;
}

class IRPSearch extends React.Component<IIRPSearchProps, any> {
    render() {
        return (
            <div className="irp-search-applet">
                <IRPSearchContainer {...this.props}/>
            </div>
        );
    }
}

export {
    IRPSearch as default,
    IRPSearch,
    IIRPSearchProps
}