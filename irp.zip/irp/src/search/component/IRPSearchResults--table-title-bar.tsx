import * as React from "react";
import {observer} from "mobx-react";
import "../../irp/component/ClientRiskOverviewList.scss";
import {IButtonProps, IContextualMenuItem} from "office-ui-fabric-react/lib";
import {Button, PrimaryButton} from "office-ui-fabric-react/lib/Button";
import {IIRPSearchResultProps} from "./IRPSearchResults";
import {SectionTitleBar} from "../../shared/SectionTitleBar";
import "./IRPSearchResults--table.scss"
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import {IRPSearchResultItemColumns} from "../model/IRPSearchResultItemColumns";
import * as moment from "moment";
import {Output as DateOutputs} from '@twii/common/lib/DateFormats';
import {saveAs} from "file-saver";
import {IIRPRiskSearchResultItem} from "../model/IRPRiskSearchResultModel";

interface IIRPSearchResultsTableTitleBarProps extends IIRPSearchResultProps {
    openItems: () => void;
}

@observer
class IRPSearchResultsTableTitleBar extends React.Component<IIRPSearchResultsTableTitleBarProps, any> {
    private _IRPStore = this.props.host.state.irpState;

    private _onDownloadCSVClick = (items: IIRPRiskSearchResultItem[]) => {
        const blob = new Blob([ColumnTextHelper.getCSV(items, IRPSearchResultItemColumns)], {type: "text/csv"});
        saveAs(blob, "IRPSearchResult-" + moment(this.props.searchResult.sync.endDate).format(DateOutputs.filename) + ".csv");
    };

    render() {
        const title = "Search results";
        const resultsFrom = this._IRPStore.riskSearchResults.request.firstResult + 1;
        const maxResults = this._IRPStore.riskSearchResults.request.maxResults;
        const totalResults = this._IRPStore.riskSearchResults.data.total;
        let resultsTo = resultsFrom === 1 ? maxResults: (resultsFrom + maxResults -1);
        resultsTo = resultsTo > totalResults ? totalResults : resultsTo;
        const titleBarItems: IContextualMenuItem[] = [
            {
                key: "resultsStats",
                title: "Total results found",
                name: `Showing ${resultsFrom} to ${resultsTo} from ${totalResults} results`,
                text: `Total results: ${this.props.searchResult.data.total}`
            }
        ];
        const downloadCSVButtonProps: IButtonProps = {
            title: "Download CSV",
            name: `Download CSV`,
            text: "Download CSV",
            menuProps: {
                items: [{
                    key: "downloadCSVAll",
                    title: "Download all",
                    name: `Download all`,
                    text: "Download all",
                    onClick: () => {
                        this._onDownloadCSVClick(this.props.searchResult.data.items.map(item => {
                            const output = Object.assign({}, item);
                            output.riskType = output.riskType.split(",").join(";");
                            return output;
                        }))
                    }
                }, {
                    key: "downloadCSVSelected",
                    title: "Download selected",
                    name: `Download selected`,
                    text: "Download selected",
                    disabled: this.props.searchResult.selectedIds.length === 0,
                    onClick: () => {
                        this._onDownloadCSVClick(this.props.searchResult.selectedItems)
                    }
                }]
            },
        };

        const farItems: IContextualMenuItem[] = [
            {
                key: "openSelected",
                title: "Open selected",
                name: `Open selected`,
                text: "",
                onRender: () => <PrimaryButton text="Open selected"
                                               onClick={this.props.openItems}
                                               disabled={this.props.searchResult.selectedIds.length === 0}/>
            },
            {
                key: "downloadCSV",
                title: "Download Selected",
                name: `Download Selected`,
                text: "Download Selected",
                onRender: () => <PrimaryButton text="Download selected"
                                               onClick={()=>{this._onDownloadCSVClick(this.props.searchResult.selectedItems)}}
                                               disabled={this.props.searchResult.selectedIds.length === 0}/>
            }];

        const iconName = this._IRPStore.riskSearchResults.data.filtered ? "IncidentTriangle" : "SearchAndApps";
        const iconColorClass = this._IRPStore.riskSearchResults.data.filtered ? "icon-color-class-orange" : "icon-color-class-blue";
        return <SectionTitleBar title={title} items={titleBarItems} farItems={farItems} iconName={iconName} className={iconColorClass} />
    }
}

export {
    IRPSearchResultsTableTitleBar as default,
    IRPSearchResultsTableTitleBar,
    IIRPSearchResultsTableTitleBarProps
}