import * as React from "react";
import {observer} from "mobx-react";
import IAppHost from "@twii/common/lib/IAppHost";
import DefinitionList from "@twii/common/lib/component/DefinitionList";
import SystemIdTypeRefList from "../../shared/SystemIdTypeRefList"
import IRiskResumeSearchHistoryEntry from "../../irp/model/IIRPSearchHistoryEntry";

import "../../shared/IRPGlobal.scss"
import "./IRPSearch.scss";

interface IRiskResumeSearchHistoryEntryButtonProps {
    host: IAppHost;
    entry: IRiskResumeSearchHistoryEntry;
    componentRef: Element;
    onSearchSubmit: () => Promise<any>;
}

@observer
class IRPSearchHistoryEntryButton extends React.Component<IRiskResumeSearchHistoryEntryButtonProps, any> {

    private _onClick = () => {
        this.props.onSearchSubmit().then(() => {
            this.props.componentRef.dispatchEvent(new Event("click"));
        });
    };

    render() {
        let idTypeRefItem = SystemIdTypeRefList.getItemByKey(this.props.entry.request.idType);
        let idTypeText = idTypeRefItem ? idTypeRefItem.text : "";
        return (
            <div role="button" data-is-focusable={true} className="risk-resume-search-history-item-button"
                 onClick={this._onClick}>
                <div className="risk-resume-search-request-summary" aria-label="Risk Resume Search Request Summary">
                    <DefinitionList inline={true}
                                    name={idTypeText}>{this.props.entry.request.referenceNumber}</DefinitionList>
                </div>
            </div>
        );
    }
}

export {
    IRPSearchHistoryEntryButton as default,
    IRPSearchHistoryEntryButton,
    IRiskResumeSearchHistoryEntryButtonProps
}