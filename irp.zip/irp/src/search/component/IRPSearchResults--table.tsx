import * as React from "react";
import {observer} from "mobx-react";
import "../../irp/component/ClientRiskOverviewList.scss";
import {css, IColumn} from "office-ui-fabric-react/lib";
import {SelectionMode, CheckboxVisibility} from "office-ui-fabric-react/lib/DetailsList";
import {IRPSearchResultItemColumns} from "../model/IRPSearchResultItemColumns";
//import {CheckboxType, CustomDetailsList} from "@twii/common/lib/component/CustomDetailsList";
import {CheckboxType, CustomDetailsList} from "../../irpcommon/CustomDetailsList";
import {IIRPSearchResultProps} from "./IRPSearchResults";
import "./IRPSearchResults--table.scss"
import {isNumber} from "@twii/common/lib/util/Lang";
import {
    getItemKeyFromViewKey,
    getViewKeyFromItemKey,
    IIRPRiskSearchResultItem
} from "../model/IRPRiskSearchResultModel";
import {observable} from "mobx";
import {IRPSearchResultsPagination} from "./IRPSearchResults--pagination";
import {Subscription} from "rxjs";
import {validIdSourceENUM} from "../../shared/SystemIdTypeRefList";
import {IIRPRouterUrlParams} from "../../IRPRouter";
import {IRPSearchResultsTableTitleBar} from "./IRPSearchResults--table-title-bar";


@observer
class IRPSearchResultsTable extends React.Component<IIRPSearchResultProps, any> {
    private _IRPStore = this.props.host.state.irpState;
    private _IRPStoreViewModel = this._IRPStore.getViewModel();
    private _windowResizeSubscription: Subscription;
    private _wrapperRef;
    private _titleRef;
    private _defaultSelection: boolean = true;
    @observable private _tableMaxHeight: number;

    componentWillMount() {
        if (this._IRPStoreViewModel.windowResizeObservable) {
            this._windowResizeSubscription = this._IRPStoreViewModel.windowResizeObservable.subscribe(() => {
                this._setTableHeight();
            })
        }
    };

    componentWillUnmount() {
        this._windowResizeSubscription.unsubscribe();
    }

    private _onItemSelected = (items: IIRPRiskSearchResultItem[]) => {
        this.props.searchResult.selectItems(items);
    };

    private _openItems = () => {
        for (let id of this.props.searchResult.selectedIds) {
            const item = this.props.searchResult.data.items.find(i => i.resultId === id);
            this._openItem(item);
        }
    };

    private _openItem = (item: IIRPRiskSearchResultItem) => {
        const cid = item.client.cid;
        const vgn = item.client.vgn;
        const appId = item.application.sourceSystemId;
        const appCode = item.application.sourceSystemCode;
        let query: IIRPRouterUrlParams;
        if (cid) {
            query = {
                sourcesystem: validIdSourceENUM.ICSE,
                cid: cid,
                windowId: cid
            }
        } else if (vgn) {
            query = {
                sourcesystem: validIdSourceENUM.TRIPS,
                applicationId: vgn,
                windowId: vgn
            }
        } else if (appId && appCode) {
            query = {
                applicationId: appId,
                sourcesystem: appCode as validIdSourceENUM,
                windowId: appId
            }
        }
        if (query) {
            this._IRPStore.routeToIRPApplet(this.props.host, true, query);
        }
    };

    private _setTableHeight = () => {
        if (this._wrapperRef && this._titleRef) {
            const wrapperHeight = this._wrapperRef.getBoundingClientRect().height;
            const titleHeight = this._titleRef.getBoundingClientRect().height;
            if (isNumber(wrapperHeight) && isNumber(titleHeight)) {
                this._tableMaxHeight = wrapperHeight - titleHeight - 90;
            }
        }
    };

    private _setTitleRef = ref => {
        if (ref) {
            this._titleRef = ref;
            this._setTableHeight();
        }
    };

    private _setWrapperRef = ref => {
        if (ref) {
            this._wrapperRef = ref;
            this._setTableHeight();
        }
    };

    private _sortTriggered = (e, col: IColumn) => {
        const sortFieldName = col.fieldName;
        let fieldName = getItemKeyFromViewKey(sortFieldName);
        let isDescending: boolean = true;

        const irpSearchRequest = this._IRPStore.riskSearchResults.request;

        if (fieldName) {
            if (irpSearchRequest && irpSearchRequest.sort) {
                isDescending = irpSearchRequest.sort.direction === "DESC";
                if (irpSearchRequest.sort.fieldName === fieldName) {
                    isDescending = !isDescending;
                }
            }
            this._IRPStore.riskSearchRequest.setSort({
                fieldName: fieldName,
                direction: isDescending ? "DESC" : "ASC"
            });
            this._IRPStore.applyRiskSearch();
        }
    };
    
    private _pageMoved =() => {
        this._defaultSelection = false;
    }

    render() {
        const results = this.props.searchResult.data;
        const tableMaxHeight = this._tableMaxHeight;
        const searchReq = this._IRPStore.riskSearchResults.request;
        let cols = IRPSearchResultItemColumns;

        cols = cols.map(c => {
            if (searchReq.sort && c.fieldName === getViewKeyFromItemKey(searchReq.sort.fieldName)) {
                c.isSorted = true;
                c.isSortedDescending = searchReq.sort.direction === "DESC";
            } else {
                c.isSorted = undefined;
                c.isSortedDescending = undefined;
            }
            return c;
        });
        return (
            results.items ?
                <div className="irp-risk-search-result-list"
                     ref={this._setWrapperRef}>
                    <div className={css("irp-search-result-title-view")}
                         ref={this._setTitleRef}>
                        <IRPSearchResultsTableTitleBar {...this.props} openItems={this._openItems}/>
                    </div>
                    <div className={css("irp-search-result-list-view")}>
                        <CustomDetailsList compact={true}
                                           selectionPreservedOnEmptyClick
                                           items={this.props.searchResult.data.items}
                                           columns={cols}
                                           stickyHeader
                                           selectionMode={SelectionMode.multiple}
                                           checkboxVisibility={CheckboxVisibility.always}
                                           checkboxType={CheckboxType.square}
                                           wrapperMaxHeight={isNumber(tableMaxHeight) ? tableMaxHeight : 500}
                                           selectedItems={[]}
                                           selectedItemsChanged={this._onItemSelected}
                                           onColumnHeaderClick={this._sortTriggered}
                                           onItemInvoked={this._openItems}/>
                    </div>
                    <IRPSearchResultsPagination defaultPageNumber = {this.props.defaultPageNumber} pageChanged = {this.props.pageChanged} {...this.props} />
                </div> : null
        );
    }
}

export {
    IRPSearchResultsTable as default,
    IRPSearchResultsTable
}