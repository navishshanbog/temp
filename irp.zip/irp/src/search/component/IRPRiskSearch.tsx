import * as React from "react";
import IAppletProps from "@twii/common/lib/IAppletProps";
import {Dropdown, IDropdownOption} from "office-ui-fabric-react/lib/Dropdown";
import {TextField} from "office-ui-fabric-react/lib/TextField";
import {DatePicker} from "office-ui-fabric-react/lib/DatePicker";
import MomentField from "@twii/common/lib/component/MomentField";
import {IRPSearchActions} from "./IRPSearch--actions";
import * as DateFormats from "@twii/common/lib/DateFormats";
import * as moment from "moment";

import "./IRPSearch.scss";
import "../../shared/IRPGlobal.scss"
import {ValidationErrors} from "@twii/common/lib/component/ValidationErrors";
import {observer} from "mobx-react";
import {IRPRiskSearchDateRange} from "./IRPRiskSearch--date-range";
import {observable} from "mobx";
import {ICodeSet} from "../../irp/model/IGetCodeSetService";
import {ValidRiskSearchMatchStatus} from "../model/IIRPRiskSearchRequest";
import {IIRPRiskSearchRequestModel} from "../model/IIRPRiskSearchRequestModel";

interface IIRPSearchProps extends IAppletProps {
    searchRequest: IIRPRiskSearchRequestModel;
    threatTypesCodeSet: ICodeSet;
    onSubmitRequest: () => void;
}

@observer
class IRPRiskSearch extends React.Component<IIRPSearchProps, any> {
    @observable private _customMatchDatesEntry: boolean = false;

    private _onRiskNumberChanged = (value: string) => {
        this.props.searchRequest.setRiskNumber(value);
        this.props.searchRequest.validate();
    };
    private _onRiskTypeChanged = (item: IDropdownOption) => {
        this.props.searchRequest.setRiskType(String(item.key) == "null" ? undefined: String(item.key) );
        this.props.searchRequest.validate();
    };
    private _onRiskMatchStatusChanged = (item: IDropdownOption) => {
        this.props.searchRequest.setStatus(String(item.key) == "null" ? undefined: String(item.key) );
        this.props.searchRequest.validate();
    };
    private _onRiskMatchedFromChanged = (value: moment.Moment) => {
        this.props.searchRequest.setFirstMatchTsFrom(value);
        this.props.searchRequest.validate();
    };
    private _onRiskMatchedToChanged = (value: moment.Moment) => {
        this.props.searchRequest.setFirstMatchTsTo(value);
        this.props.searchRequest.validate();
    };

    private _onDateRangeFieldOptionChangeEntry = (startDate: moment.Moment, endDate: moment.Moment, custom?: boolean,selectedDateKey?:string) => {
        if (!custom) {
            this._onRiskMatchedFromChanged(startDate);
            this._onRiskMatchedToChanged(endDate);
        }
        this._customMatchDatesEntry = custom;
    };
    private resetCustomFlag = () => {
        this._customMatchDatesEntry = false;
        //this.props.searchRequest.isFromHistory =false;
    }
    render() {
        const riskMatchOptions: IDropdownOption[] = [{key: null, text: ""}];
        for (status in ValidRiskSearchMatchStatus) {
            riskMatchOptions.push({
                key: status,
                text: ValidRiskSearchMatchStatus[status]
            })
        }
        const riskTypeOptions: IDropdownOption[] = this.props.threatTypesCodeSet.items.map(codeSet => {
            return {
                key: codeSet.description,
                text: codeSet.description
            }
        });
        riskTypeOptions.unshift({key: null, text: ""});
        return <div className="irp-risk-search">
            <div className="ms-Grid">
                <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-md12">
                        <ValidationErrors errors={this.props.searchRequest.validationErrors}/>
                    </div>
                    <div className="ms-Grid-col ms-md12">
                        <TextField label="Risk number:" onChanged={this._onRiskNumberChanged}
                                   value={this.props.searchRequest.riskNumber || ""}/>
                    </div>
                    <div className="ms-Grid-col ms-md6">
                        <Dropdown label="Risk type:"
                                  placeHolder="Select risk type"
                                  options={riskTypeOptions}
                                  onChanged={this._onRiskTypeChanged}
                                  selectedKey={this.props.searchRequest.riskType || ""}/>
                    </div>
                    <div className="ms-Grid-col ms-md6">
                        <Dropdown label="Risk match status:"
                                  placeHolder="Select match status"
                                  defaultSelectedKey={riskMatchOptions[0].key}
                                  options={riskMatchOptions}
                                  onChanged={this._onRiskMatchStatusChanged}
                                  selectedKey={this.props.searchRequest.status || ""}/>
                    </div>
                    <div className="ms-Grid-col ms-md12">
                        <IRPRiskSearchDateRange defaultSelect={this.props.searchRequest.firstMatchTsFrom?true:false} requestModel = {this.props.searchRequest}
                           selectedDateKey={'pastDay'} isCustomMatchDates={this._customMatchDatesEntry} onChange={this._onDateRangeFieldOptionChangeEntry}/>
                    </div>
                    {
                        this._customMatchDatesEntry ? <>
                            <div className="ms-Grid-col ms-md6">
                                <DatePicker label="First matched from:"
                                            allowTextInput
                                            parseDateFromString={date => moment(date, DateFormats.Output.default).toDate()}
                                            formatDate={date => moment(date).format(DateFormats.Output.default)}
                                            onSelectDate={(date: Date) => this._onRiskMatchedFromChanged(moment(date))}
                                            value={moment(this.props.searchRequest.request.firstMatchTsFrom).toDate()}
                                            placeholder={DateFormats.Output.default}/>
                            </div>
                            <div className="ms-Grid-col ms-md6">
                                <DatePicker label="First matched to:"
                                            allowTextInput
                                            parseDateFromString={date => moment(date, DateFormats.Output.default).toDate()}
                                            formatDate={date => moment(date).format(DateFormats.Output.default)}
                                            onSelectDate={(date: Date) => this._onRiskMatchedToChanged(moment(date))}
                                            value={moment(this.props.searchRequest.request.firstMatchTsTo).toDate()}
                                            placeholder={DateFormats.Output.default}/>
                            </div>
                        </> : null}
                </div>
            </div>
            <IRPSearchActions {...this.props} onClear={this.resetCustomFlag}/>
        </div>
    }
}

export {
    IRPRiskSearch as default,
    IRPRiskSearch,
    IIRPSearchProps
}