import * as React from "react";
import {observer} from "mobx-react";
import {IButtonProps} from "office-ui-fabric-react/lib";
import {IIRPSearchResultProps} from "./IRPSearchResults";
import "./IRPSearchResults--table.scss"
//import {ButtonGroup} from "@twii/common/lib/component/ButtonGroup";
import {ButtonGroup} from "../../irpcommon/ButtonGroup";
import {
    IIRPSearchResultsPaginationService,
    IRPSearchResultsPaginationService
} from "./IRPSearchResults--pagination.service";
import {IIRPStoreModel} from "../../service/IIRPStoreModel";
import {isNumber, isString} from "@twii/common/lib/util/Lang";

@observer
class IRPSearchResultsPagination extends React.Component<IIRPSearchResultProps, any> {
    private _IRPStore: IIRPStoreModel;
    private _paginationService: IIRPSearchResultsPaginationService;

    componentWillMount() {
        this._IRPStore = this.props.host.state.irpState;
        this._paginationService = new IRPSearchResultsPaginationService(this._IRPStore)
    };

    componentDidUpdate() {
        if(this.props.defaultPageNumber==0) { this._paginationService.resetToFirstPage(); } else {
        }
    }

    onPageChange = (selectedPages: IButtonProps[]) => {
        if (selectedPages.length > 0) {
            const selectedPageItem = selectedPages[0];
            const selectedPageNumber = selectedPageItem.data;
            if (selectedPageNumber && isNumber(selectedPageNumber)) {
                this._paginationService.goToPage(selectedPageNumber);
            } else if (isString(selectedPageNumber)) {
                switch (selectedPageNumber) {
                    case "firstPage":
                        this._paginationService.goToFirstPage();
                        break;
                    case "lastPage":
                        this._paginationService.goToLastPage();
                        break;
                    case "nextPage":
                        this._paginationService.goToNextPage();
                        break;
                    case "previousPage":
                        this._paginationService.goToPreviousPage();
                }
            }
            // any page number will do to prevent from defaulting to page 0
            this.props.pageChanged(-999)
            this.forceUpdate();
        }
    };

    render() {
        return <div className="irp-search-result-list--pagination">
            <ButtonGroup items={this._paginationService.pagesButtonGroupItems}
                         label="Search results pagination"
                         selectedKeys={[this._paginationService.currentPage.toString()]}
                         onChanged={this.onPageChange}
                         labelHidden
                         transition/>
        </div>
    };
}

export {
    IRPSearchResultsPagination as default,
    IRPSearchResultsPagination
}