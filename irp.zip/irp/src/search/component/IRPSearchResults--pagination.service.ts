import * as React from "react";
import {IIRPStoreModel} from "../../service/IIRPStoreModel";
import {IIRPRiskSearchRequestModel} from "../model/IIRPRiskSearchRequestModel";
import {IIRPRiskSearchResultModel} from "../model/IRPRiskSearchResultModel";
import {IButtonProps} from "office-ui-fabric-react";
import {computed} from "mobx";

interface IIRPSearchResultsPaginationService {
    pagesButtonGroupItems: IButtonProps[];
    currentPage: number;
    lastPage: number;

    goToPage(pageNumber: number): void;

    goToNextPage(): void;

    goToPreviousPage(): void;

    goToLastPage(): void;

    goToFirstPage(): void;

    resetToFirstPage(): void;
}

class IRPSearchResultsPaginationService implements IIRPSearchResultsPaginationService {
    private _IRPStore: IIRPStoreModel;
    private _riskSearchRequest: IIRPRiskSearchRequestModel;
    private _riskSearchResults: IIRPRiskSearchResultModel;

    constructor(store: IIRPStoreModel) {
        this._IRPStore = store;
        this._riskSearchResults = this._IRPStore.riskSearchResults;
        this._riskSearchRequest = this._IRPStore.riskSearchRequest;
    };

    @computed
    get currentPage() {
        const searchResultsData = this._riskSearchResults.data;
        const firstResult = this._riskSearchResults.request.firstResult;
        return searchResultsData ? Math.floor(firstResult / 50) + 1 : 1;
    }

    @computed
    get lastPage() {
        return Math.floor((this._riskSearchResults.data.total) / 50) + 1;
    }

    @computed
    get pagesButtonGroupItems() {
        const paginationPostItems: IButtonProps[] = [
            {
                uniqueId: "nextPage",
                text: ">",
                data: "nextPage"
            }, {
                uniqueId: "lastPage",
                text: ">>",
                data: "lastPage"
            }
        ];

        const paginationPreItems: IButtonProps[] = [
            {
                uniqueId: "firstPage",
                text: "<<",
                data: "firstPage"
            }, {
                uniqueId: "previousPage",
                text: "<",
                data: "previousPage"
            }
        ];

        let paginationMainItems: IButtonProps[] = [];
        const searchResultsData = this._riskSearchResults.data;
        let neighborsArray = [];
        if (searchResultsData) {
            if (this.lastPage > 5) {
                neighborsArray = [this.currentPage - 2, this.currentPage - 1, this.currentPage, this.currentPage + 1, this.currentPage + 2];
                if (neighborsArray[0] < 1) {
                    const shiftToRight = 1 - neighborsArray[0];
                    neighborsArray = neighborsArray.map(i => i + shiftToRight);
                }
                if (neighborsArray[neighborsArray.length - 1] > this.lastPage) {
                    const shiftToLeft = neighborsArray[neighborsArray.length - 1] - this.lastPage;
                    neighborsArray = neighborsArray.map(i => i - shiftToLeft).filter(i => i > 0);
                }
            } else {
                let pageNum = 1;
                while (pageNum <= this.lastPage) {
                    neighborsArray.push(pageNum);
                    pageNum++;
                }
            }

            for (let pageNum of neighborsArray) {
                paginationMainItems.push({
                    uniqueId: pageNum.toString(),
                    text: pageNum.toString(),
                    data: pageNum
                });
            }
        }


        return paginationPreItems.concat(paginationMainItems, paginationPostItems);
    }

    goToPage(page: number) {
        if (page > this.lastPage) {
            page = this.lastPage;
        } else if (page < 1) {
            page = 1;
        }
        if (page !== this.currentPage) {
            this._riskSearchRequest.setFirstResult((page - 1) * this._riskSearchRequest.maxResults);
            this._IRPStore.applyRiskSearch();
        }
    }

    resetToFirstPage () {
        this.goToFirstPage();
    }

    goToNextPage() {
        this.goToPage(this.currentPage + 1);
    }

    goToPreviousPage() {
        this.goToPage(this.currentPage - 1);
    }

    goToLastPage() {
        this.goToPage(this.lastPage);
    }

    goToFirstPage() {
        this.goToPage(1);
    }
}

export {
    IRPSearchResultsPaginationService as default,
    IRPSearchResultsPaginationService,
    IIRPSearchResultsPaginationService
}