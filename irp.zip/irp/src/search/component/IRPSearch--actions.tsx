import * as React from "react";
import {observer} from "mobx-react";
import {PrimaryButton} from "office-ui-fabric-react/lib/Button";
import {IIRPRiskSearchRequestModel} from "../model/IIRPRiskSearchRequestModel";
import IAppletProps from "@twii/common/lib/IAppletProps";
import "./IRPSearch--actions.scss";
import {IIRPSimpleSearchRequestModel} from "../model/IIRPSimpleSearchRequestModel";

interface IIRPSearchActionsProps extends IAppletProps {
    searchRequest?: IIRPRiskSearchRequestModel | IIRPSimpleSearchRequestModel;
    onSubmitRequest?: () => void;
    onClear?: () => void;
    searchContext?: string;
}

@observer
class IRPSearchActions extends React.Component<IIRPSearchActionsProps, any> {

    _handleClear = () => {
        this.props.searchRequest.clear();
        if (this.props.onClear) {
            this.props.onClear();
        }
    };

    private _search = () => {
        if (this.props.searchRequest.hasOwnProperty("setFirstResult")) {
            const req = (this.props.searchRequest as IIRPRiskSearchRequestModel);
            req.setFirstResult(0);
            req.setSort();
        }
        this.props.onSubmitRequest();
    };

    render() {
        return (
            <div className="irp-simple-search-actions">
                <PrimaryButton
                    className="irp-search-action"
                    disabled={!this.props.searchRequest.isValueSpecified}
                    onClick={this._search}
                    iconProps={{iconName: "Search"}}>Search</PrimaryButton>
                <PrimaryButton
                    className="irp-search-action"
                    onClick={this._handleClear}
                    disabled={!this.props.searchRequest.isValueSpecified}
                    iconProps={{iconName: "Clear"}}>Clear</PrimaryButton>
            </div>
        );
    }
}

export {IRPSearchActions as default, IRPSearchActions, IIRPSearchActionsProps};