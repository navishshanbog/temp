import * as React from "react";
import * as moment from "moment";

//import {ButtonGroup} from "@twii/common/lib/component/ButtonGroup";
import {ButtonGroup} from "../../irpcommon/ButtonGroup";
import {IButtonProps} from "office-ui-fabric-react";
import {observer} from "mobx-react";
import {observable} from "mobx";
import {IIRPRiskSearchRequestModel} from "../model/IIRPRiskSearchRequestModel";



interface IIRPRiskSearchDateRange {
    defaultSelect?:boolean;
    selectedDateKey?:string;
    requestModel?: IIRPRiskSearchRequestModel;
    onChange: (startDate: moment.Moment, endDate: moment.Moment, custom?: boolean,selectedKey?:string) => any;
    isCustomMatchDates?: boolean;
}

@observer
class IRPRiskSearchDateRange extends React.Component<IIRPRiskSearchDateRange, any> {
    @observable private _selectedKey;
    private _buttonProps: IButtonProps[] = [
        {
            uniqueId: "pastDay",
            text: "Past day",
            data: -1
        }, {
            uniqueId: "pastWeek",
            text: "Past week",
            data: -7
        }, {
            uniqueId: "pastMonth",
            text: "Past month",
            data: -30
        }, {
            uniqueId: "custom",
            text: "Custom",
            data: 0
        }
    ];

    private _onChanged = (selectedItems: IButtonProps[]) => {
        if (selectedItems.length > 0) {
            this._selectedKey = selectedItems[0].uniqueId.toString();
        }
        const dateRangeInDays = this._buttonProps.find(prop => prop.uniqueId === this._selectedKey).data;
        const endDate = moment();
        const startDate = moment().add(dateRangeInDays, "days");
        if (this.props.onChange) {
            this.props.onChange(startDate, endDate, dateRangeInDays === 0,this._selectedKey);
        }

    };

    private setDefaultSelect =() =>{
        this._selectedKey = "pastDay";
    };

    componentDidMount() {
        this.setSelectedKey();
        //this.setDefaultSelect();
    }

    private setSelectedKey = () => {
        let fromDt = this.props.requestModel.firstMatchTsFrom;
        let toDt = this.props.requestModel.firstMatchTsTo;
        var index = 0;
        if(fromDt && toDt) {
            let diffDt = toDt.diff(fromDt, 'days');
            index = this._buttonProps.findIndex(prop => prop.data == (0 - diffDt))
        }
        if(!this.props.isCustomMatchDates && index>=0) {
            this._selectedKey = this._buttonProps[index].uniqueId;
        } else if(index<0) {
            this._selectedKey = "custom";
        }
    }

    componentDidUpdate(prevProps){
        this.setSelectedKey();
        /*if(!this.props.isCustomMatchDates) {
            let fromDt = this.props.requestModel.firstMatchTsFrom;
            let toDt = this.props.requestModel.firstMatchTsTo;

            let diffDt = toDt.diff(fromDt, 'days');
            var index = this._buttonProps.findIndex(prop => prop.data == (0 - diffDt))
            if (index < 0)
                this._selectedKey = "custom";
            else this._selectedKey = this._buttonProps[index].uniqueId;
        }*/
    }

    render() {
        let fromDt = this.props.requestModel.firstMatchTsFrom;
        let toDt = this.props.requestModel.firstMatchTsTo;
        return <div className="irp-risk-search--date-range">
            <ButtonGroup items={this._buttonProps}
                         label="First match date range"
                         transition
                         selectedKeys={[this._selectedKey]}
                         onChanged={this._onChanged}/>
        </div>
    }
}

export {
    IRPRiskSearchDateRange as default,
    IRPRiskSearchDateRange,
    IIRPRiskSearchDateRange
}