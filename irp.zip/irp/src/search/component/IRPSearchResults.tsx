import * as React from "react";
import IAppHost from "@twii/common/lib/IAppHost";
import {IIRPRiskSearchResultItem, IIRPRiskSearchResultModel} from "../model/IRPRiskSearchResultModel";
import {IRPSearchResultsTable} from "./IRPSearchResults--table";
import {MessageBar} from "office-ui-fabric-react/lib/MessageBar";
import {css, MessageBarType} from "office-ui-fabric-react";
import {SyncingOverlay} from "../../shared/SyncingOverlay";
import "./IRPSearchResults.scss";
import {observer} from "mobx-react";
import {SectionTitleBar} from "../../shared/SectionTitleBar";

interface IIRPSearchResultProps {
    host: IAppHost;
    searchResult: IIRPRiskSearchResultModel;
    onItemSelected?: (item: IIRPRiskSearchResultModel) => void;
    onOpenItems?: (items: IIRPRiskSearchResultItem[]) => void;
    pageChanged?: (pageNumber: number) => void;
    defaultPageNumber?: number;
}

@observer
class IRPSearchResults extends React.Component<IIRPSearchResultProps, any> {
    render() {
        const sync = this.props.searchResult.sync;
        let content: JSX.Element;
        if (sync && !sync.hasSynced) {
            content = <div>
                <SectionTitleBar title={"Search results"}/>
                <MessageBar messageBarType={MessageBarType.warning}>Use the left panel to search for risk
                    matches.</MessageBar>
            </div>
        } else {
            if (this.props.searchResult.data.total === 0) {
                content =
                    <MessageBar messageBarType={MessageBarType.warning}>Sorry, no risk matches were found</MessageBar>;
            } else if(!this.props.searchResult.data.total) {
                <MessageBar messageBarType={MessageBarType.warning}>Sorry, this could be a permission issue</MessageBar>;
            } else {
                content = <IRPSearchResultsTable pageChanged={this.props.pageChanged} defaultPageNumber = {this.props.defaultPageNumber} searchResult={this.props.searchResult} host={this.props.host}/>;
            }
        }
        return <div className="irp-risk-search-results">
            {content}
            <SyncingOverlay sync={sync} showSpinner/>
        </div>
    };
}

export {
    IRPSearchResults as default,
    IRPSearchResults,
    IIRPSearchResultProps
}