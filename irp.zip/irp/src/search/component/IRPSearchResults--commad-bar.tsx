import * as React from "react";
import {observer} from "mobx-react";
import "../../irp/component/ClientRiskOverviewList.scss";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import {IContextualMenuItem} from "office-ui-fabric-react/lib";
import {Output as DateOutputFormats} from "@twii/common/lib/DateFormats";
import {saveAs} from "file-saver";
import * as moment from "moment";
import * as ActivityFilterMenuHelper from "@twii/common/lib/component/ActivityFilterMenuHelper";
import {CommandBar} from "office-ui-fabric-react/lib";
import {IRPSearchResultItemColumns} from "../../search/model/IRPSearchResultItemColumns";
import {IIRPSearchResultProps} from "./IRPSearchResults";

@observer
class IRPSearchResultsCommandBar extends React.Component<IIRPSearchResultProps, any> {
    private _onDownloadCSVClick = () => {
        const blob = new Blob([ColumnTextHelper.getCSV(this.props.searchResult.data.items, IRPSearchResultItemColumns)], {type: "text/csv"});
        saveAs(blob, "IRPSearchResult-" + moment(this.props.searchResult.sync.endDate).format(DateOutputFormats.filename) + ".csv");
    };

    // private _onRefreshClick = () => {
    //     this.props.searchResult.refresh();
    // };
    //
    // private _clearVisitedItemsList = () => {
    //     this.props.searchResult.visitedItems.setSelectedItems([]);
    // };
    //
    // private _openSelectedItems = () => {
    //     this.props.searchResult.selection.selectedItems.forEach(item => {
    //         this.props.host.state.irpState.openClient(this.props.host, item);
    //     })
    // };

    render() {
        const menuItems: IContextualMenuItem[] = [
            // {
            //     key: "refresh",
            //     name: "Refresh",
            //     iconProps: {iconName: "Refresh"},
            //     ariaLabel: "Refresh Search Result",
            //     onClick: this._onRefreshClick
            // }
        ];
        const farMenuItems: IContextualMenuItem[] = [
            // {
            //     key: "clearVisitedItemsHistory",
            //     name: "Clear Visited Items History",
            //     ariaLabel: "Clear Visited Items History",
            //     disabled: !(this.props.searchResult.visitedItems.selectionCount > 0),
            //     iconProps: {
            //         iconName: "Read"
            //     },
            //     onClick: this._clearVisitedItemsList
            // }, {
            //     key: "openMultiple",
            //     name: "Open Selected Items",
            //     ariaLabel: "Open Selected Items",
            //     disabled: !(this.props.searchResult.selection.selectedItems.length > 0),
            //     iconProps: {
            //         iconName: "MultiSelect"
            //     },
            //     onClick: this._openSelectedItems
            // }, {
            //     key: "download",
            //     name: "Download as CSV",
            //     iconProps: {iconName: "Download"},
            //     ariaLabel: "Download as CSV",
            //     onClick: this._onDownloadCSVClick
            // }
        ];

        return (
            <CommandBar className="master-entity-search-result-command-bar" items={menuItems} farItems={farMenuItems}/>
        );
    }
}

export {
    IRPSearchResultsCommandBar as default,
    IRPSearchResultsCommandBar
}