import {IIRPRiskSearchRequest} from "./IIRPRiskSearchRequest";
import {IIRPRiskSearchResultDataModel} from "./IRPRiskSearchResultModel";

interface IIRPSearchService {
    search(request : IIRPRiskSearchRequest) : Promise<IIRPRiskSearchResultDataModel>;
}

export { IIRPSearchService as default, IIRPSearchService };