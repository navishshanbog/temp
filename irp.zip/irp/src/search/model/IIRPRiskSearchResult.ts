import {IIRPRiskSearchResultItem} from "./IRPRiskSearchResultModel";

interface IIRPRiskSearchResult {
    filterResults: IIRPRiskSearchResultItem[];
    totalResults: number;
    filtered?: boolean;
}

export { IIRPRiskSearchResult as default, IIRPRiskSearchResult };