const apiBaseUrl = "http://localhost:3010";

const RestIRPDataServicesConfig ={

    baseUrl: apiBaseUrl + "/VRAService",
    apiVersion: "v1"
};

export { RestIRPDataServicesConfig as default, RestIRPDataServicesConfig };