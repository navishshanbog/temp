import IError from "@twii/common/lib/IError";
import {IIRPSimpleSearchRequest} from "./IIRPSimpleSearchRequest";

interface IIRPSimpleSearchRequestModel {
    validationErrors?: IError[];
    isValueSpecified?: boolean;
    idType?: string;
    referenceNo?: string;
    clientId?: string;

    setIdType(idType?: string): void;

    setReferenceNumber(referenceNumber?: string): void;

    setClientId(clientId?: string): void;

    validate(): void;

    isValid: boolean;

    isIdTypeSpecified: boolean;
    isReferenceNoSpecified: boolean;

    request: IIRPSimpleSearchRequest;

    setRequest(request: IIRPSimpleSearchRequest): void;

    submit(requestHandler: () => void);

    clear(): void;
}

export {
    IIRPSimpleSearchRequestModel as default,
    IIRPSimpleSearchRequestModel
}