import {observable, action, computed} from "mobx";
import IError from "@twii/common/lib/IError";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as StringUtils from "@twii/common/lib/util/String";
import * as moment from "moment";
import {IIIRPRiskSearchRequestSort, IIRPRiskSearchRequestModel} from "./IIRPRiskSearchRequestModel";
import {IIRPRiskSearchRequest, ValidRiskSearchMatchStatus} from "./IIRPRiskSearchRequest";
import {isNumber} from "@twii/common/lib/util/Lang";

class IRPRiskSearchRequestModel implements IIRPRiskSearchRequestModel {
    @observable validationErrors: IError[] = [];
    @observable riskNumber: string;
    @observable riskType: string;
    @observable status: ValidRiskSearchMatchStatus;
    @observable riskAssessmentOutcome: string;
    @observable firstMatchTsFrom: moment.Moment;
    @observable firstMatchTsTo: moment.Moment;
    @observable firstResult: number = 0;
    @observable maxResults: number = 50;
    @observable sort: IIIRPRiskSearchRequestSort;

    @computed
    get isValid() {
        return this.validationErrors.length === 0;
    }

    @computed
    get isValueSpecified() {
        return this.isRiskNumberSpecified ||
            this.isStatusSpecified ||
            this.isRiskTypeSpecified ||
            this.isFirstMatchTsFromSpecified ||
            this.isFirstMatchTsToSpecified;
    }




    @action
    setRiskNumber(riskNumber?: string): void {
        this.riskNumber = riskNumber;
    }



    @action
    setRiskType(riskType?: string): void {
        this.riskType = riskType;
    }

    @action
    setStatus(status?: ValidRiskSearchMatchStatus): void {
        this.status = status;
    }

    @action
    setFirstMatchTsFrom(firstMatchTsFrom?: moment.Moment): void {
        this.firstMatchTsFrom = firstMatchTsFrom;
    }

    @action
    setFirstMatchTsTo(firstMatchTsTo?: moment.Moment): void {
        this.firstMatchTsTo = firstMatchTsTo;
    }

    @action
    setFirstResult(firstResult: number): void {
        this.firstResult = firstResult;
    }

    @action
    setMaxResults(maxResults: number): void {
        this.maxResults = maxResults;
    }

    @action
    setSort(sort: IIIRPRiskSearchRequestSort):void {
        this.sort = sort;
    }

    @computed
    get page() {
        return {
            firstResult: this.firstResult,
            maxResults: this.maxResults
        }
    }

    @computed
    get isRiskNumberSpecified() {
        return StringUtils.isNotBlank(this.riskNumber);
    }

    @action
    clearRiskNumber() {
        this.riskNumber = undefined;
    }

    @computed
    get isRiskTypeSpecified() {
        return StringUtils.isNotBlank(this.riskType);
    }

    @action
    clearRiskType() {
        this.riskType = undefined;
    }

    @computed
    get isStatusSpecified() {
        return StringUtils.isNotBlank(this.status);
    }

    @action
    clearStatus() {
        this.status = undefined;
    }

    @computed
    get isFirstMatchTsFromSpecified() {
        return DateUtils.isValidMoment(this.firstMatchTsFrom)
    }

    @action
    clearFirstMatchTsFrom() {
        this.firstMatchTsFrom = undefined;
    }

    @computed
    get isFirstMatchTsToSpecified() {
        return DateUtils.isValidMoment(this.firstMatchTsTo)
    }

    @action
    clearFirstMatchTsTo() {
        this.firstMatchTsTo = undefined;
    }

    @computed
    get isFirstResultSpecified() {
        return isNumber(this.firstResult);
    }

    @action
    clearFirstResult() {
        this.firstResult = undefined;
    }

    @computed
    get isMaxResultsSpecified() {
        return isNumber(this.maxResults);
    }

    @action
    clearMaxResults() {
        this.maxResults = undefined;
    }

    @action
    clearSort() {
        this.sort = undefined;
    }

    @computed
    get request(): IIRPRiskSearchRequest {
        return {
            riskNumber: StringUtils.isNotBlank(this.riskNumber) ? this.riskNumber : undefined,
            riskType: StringUtils.isNotBlank(this.riskType) ? this.riskType : undefined,
            status: StringUtils.isNotBlank(this.status) ? this.status : undefined,
            firstMatchTsFrom: this.firstMatchTsFrom,
            firstMatchTsTo: this.firstMatchTsTo,
            page: this.page,
            riskAssessmentOutcome: this.riskAssessmentOutcome,
            sort: this.sort
        };
    }

    set request(request: IIRPRiskSearchRequest) {
        this.setRequest(request);
    }

    @action
    setRequest(request: IIRPRiskSearchRequest) {
        if (request) {
            this.setRiskNumber(request.riskNumber);
            this.setRiskType(request.riskType);
            this.setStatus(request.status);
            this.setFirstMatchTsFrom(moment(request.firstMatchTsFrom));
            this.setFirstMatchTsTo(moment(request.firstMatchTsTo));
           // this.setIsFromHistory(true);
            this.clearSort();
        } else {
            this.clear();
        }
    }

    get countFilledFields() {
        let count = 0;
        if (this.riskNumber) {
            count += 1;
        }
        if (this.riskType) {
            count += 1;
        }
        if (this.status) {
            count += 1;
        }
        return count;
    };

    @action
    validate() {
        const minimumFilledFields = 1;
        this.validationErrors = [];
        if (!this.isValueSpecified) {
            this.validationErrors.push({message: "You must select at least one search term."});
        }
        if (this.riskNumber && !(new RegExp("^[0-9]+$")).test(this.riskNumber)) {
            this.validationErrors.push({
                prop: "riskNumber",
                propTitle: "Risk number",
                message: "Risk number can only contain numbers"
            });
        }
        if (this.countFilledFields < minimumFilledFields) {
            this.validationErrors.push({
                prop: "",
                propTitle: "",
                message: `Minimum of ${minimumFilledFields} fields must be filled.`
            });
        }
        if (this.firstMatchTsFrom && this.firstMatchTsFrom.isValid() && this.firstMatchTsTo && this.firstMatchTsTo.isValid()) {
            if (this.firstMatchTsFrom.unix() > this.firstMatchTsTo.unix()) {
                this.validationErrors.push({
                    prop: "",
                    propTitle: "",
                    message: `The end date cannot be before the start date.`
                });
            }
        }
    }

    @action
    submit(requestHandler?: (req: IIRPRiskSearchRequest) => void) {
        this.validate();
        if (this.isValid && requestHandler) {
            requestHandler(this.request);
        }
    }

    @action
    clearValidation() {
        this.validationErrors = [];
    }

    @action
    clear(): void {
        this.clearValidation();
        this.clearStatus();
        this.clearRiskType();
        this.clearRiskNumber();
        this.clearFirstMatchTsFrom();
        this.clearFirstMatchTsTo();
        //this.clearMaxResults();
        //this.clearFirstResult()
    }
}

export {IRPRiskSearchRequestModel as default, IRPRiskSearchRequestModel};