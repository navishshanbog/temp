import * as moment from "moment";
enum ValidRiskSearchSortFieldName {
    status = "status",
    riskNumber = "riskNumber",
    matchedTs = "matchedTs",
    trigger = "trigger",
    applicationId = "applicationId",
    visaSubclassCode = "visaSubclassCode",
    riskCheckStatus = "riskCheckStatus",
    riskType = "riskType",
    cid = "cid"
}

enum ValidRiskSearchMatchStatus {
    UNDER_THREAT_EVAL = "Under threat evaluation",
    RISK_ASSESSMENT_UNTREATED = "Untreated",
    RISK_ASSESSMENT_IN_PROGRESS = "In progress",
    COMPLETED = "Completed"
}

interface IIRPRiskSearchRequest {
    riskNumber?: string;
    riskType?: string;
    status?: ValidRiskSearchMatchStatus;
    riskAssessmentOutcome?: string;
    firstMatchTsFrom: moment.Moment;
    firstMatchTsTo: moment.Moment;
    page: {
        firstResult: number;
        maxResults: number
    };
    sort: {
        fieldName: ValidRiskSearchSortFieldName;
        direction: "ASC" | "DESC";
    };
}

export {
    IIRPRiskSearchRequest as default,
    IIRPRiskSearchRequest,
    ValidRiskSearchSortFieldName,
    ValidRiskSearchMatchStatus
};