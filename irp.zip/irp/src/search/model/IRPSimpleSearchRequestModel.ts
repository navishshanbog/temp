import {observable, action, computed} from "mobx";
import IError from "@twii/common/lib/IError";
import * as StringUtils from "@twii/common/lib/util/String";
import SystemIdTypeRefList from "../../shared/SystemIdTypeRefList";
import {IIRPSimpleSearchRequestModel} from "./IIRPSimpleSearchRequestModel";
import {IIRPSimpleSearchRequest} from "./IIRPSimpleSearchRequest";

class IRPSimpleSearchRequestModel implements IIRPSimpleSearchRequestModel {
    @observable validationErrors?: IError[] = [];
    @observable idType?: "icseId" | "tripsId" | "prId" | "vgn" | string;
    @observable referenceNumber?: string;
    @observable clientId?: string;

    @computed
    get isValid() {
        return this.validationErrors.length === 0;
    }

    @computed
    get isValueSpecified() {
        return this.isIdTypeSpecified && this.isReferenceNoSpecified;
    }

    @action
    setIdType(idType?: string): void {
        this.idType = idType;
    }

    @action
    setClientId(clientId?: string): void {
        this.clientId = clientId;
    }

    @action
    setReferenceNumber(referenceNumber?: string): void {
        this.referenceNumber = referenceNumber;
    }

    @computed
    get isIdTypeSpecified() {
        return StringUtils.isNotBlank(this.idType);
    }

    @action
    clearIdType() {
        this.idType = undefined;
    }

    @computed
    get isReferenceNoSpecified() {
        return StringUtils.isNotBlank(this.referenceNumber);
    }

    @computed
    get isClientIdSpecified() {
        return StringUtils.isNotBlank(this.clientId);
    }

    @action
    clearReferenceNo() {
        this.referenceNumber = undefined;
    }

    @computed
    get request(): IIRPSimpleSearchRequest {
        return {
            idType: StringUtils.isNotBlank(this.idType) ? this.idType : undefined,
            referenceNumber: StringUtils.isNotBlank(this.referenceNumber) ? this.referenceNumber : undefined,
            clientId: StringUtils.isNotBlank(this.clientId) ? this.clientId : undefined,
        };
    }

    set request(request: IIRPSimpleSearchRequest) {
        this.setRequest(request);
    }

    @action
    setRequest(request: IIRPSimpleSearchRequest) {
        if (request) {
            this.setIdType(request.idType);
            this.setReferenceNumber(request.referenceNumber);
            this.setClientId(request.clientId);
        } else {
            this.clear();
        }
    }

    @action
    validate() {
        this.validationErrors = [];
        const validateLength = () => {
            let msg = `${SystemIdTypeRefList.getSystemItemByKey(this.idType).text} cannot be longer than `;
            if (this.idType === "icseId" && this.referenceNumber.length > 11)
                return msg + "11 characters";
            if (this.idType === "tripsId" && this.referenceNumber.length > 10)
                return msg + "10 characters";
            if (this.idType === "prId" && this.referenceNumber.length > 10)
                return msg + "10 characters";
            if (this.idType === "vgn" && this.referenceNumber.length > 13)
                return msg + "13 characters";
            else
                return false;
        };

        if (this.referenceNumber && !this.idType) {
            this.validationErrors.push({
                prop: "idType",
                propTitle: "ID Type",
                message: "Choose an ID Type"
            });
        }
        if (this.isReferenceNoSpecified && !(new RegExp("^[0-9]+$")).test(this.referenceNumber)) {
            this.validationErrors.push({
                prop: "referenceNumber",
                propTitle: "Reference Number",
                message: "ID must contain numbers only"
            });
        }
        if (this.referenceNumber) {
            const maxLengthError = validateLength();
            if (maxLengthError) {
                this.validationErrors.push({
                    prop: "referenceNumber",
                    propTitle: "ID too long",
                    message: maxLengthError
                });
            }
        }
    }

    @action
    submit(requestHandler?: () => void) {
        this.validate();
        if (this.isValid && requestHandler) {
            requestHandler();
        }
    }

    @action
    clearValidation() {
        this.validationErrors = [];
    }

    @action
    clear(): void {
        this.clearValidation();
        this.clearIdType();
        this.clearReferenceNo();
    }

}

export {
    IRPSimpleSearchRequestModel as default,
    IRPSimpleSearchRequestModel
};