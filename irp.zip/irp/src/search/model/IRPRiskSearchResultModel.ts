import {ISyncModel} from "@twii/common/lib/ISyncModel";
import {SyncModel} from "@twii/common/lib/SyncModel";
import {IIRPRiskSearchRequestModel} from "./IIRPRiskSearchRequestModel";
import {computed, observable} from "mobx";
import {Output} from "@twii/common/lib/DateFormats"
import * as moment from "moment";

interface IIRPRiskSearchResultItem {
    resultId: string;
    riskNumber: string;
    riskName: string;
    riskType: string;
    matchedTs: string;
    trigger: string;
    riskAssessmentOutcome: string;
    matchEvalOutcome: string;
    application: {
        sourceSystemId: string;
        sourceSystemCode: string;
        visaSubclass: string;
    };
    client: {
        cid: string;
        vgn: string;
        riskRating: string;
        riskCheckStatus: string;
    }
}

interface IIRPRiskSearchResultViewItem extends IIRPRiskSearchResultItem {
    key: string;
    matchedViewTS: string;
    riskNameNumber: string;
    subClassCode: string;
    applicationIdSystem: string;
    clientIdSystem: string;
    clientRiskStageRating: string;
    matchTriggerName: string;
}

const getItemKeyFromViewKey = key => {
    switch(key) {
        case "matchedViewTS":
            return "matchedTs";
        case "riskNameNumber":
            return "riskNumber";
        case "subClassCode":
            return"visaSubclassCode";
        case "clientRiskStageRating":
            return "riskCheckStatus";
        case "matchTriggerName":
            return "trigger";
    }
};
const getViewKeyFromItemKey = key => {
    switch(key) {
        case "matchedTs":
            return "matchedViewTS";
        case "riskNumber":
            return "riskNameNumber";
        case "visaSubclassCode":
            return "subClassCode";
        case "riskCheckStatus":
            return "clientRiskStageRating";
        case "trigger":
            return "matchTriggerName";
    }
}

interface IIRPRiskSearchResultDataModel {
    total: number;
    items: IIRPRiskSearchResultViewItem[];
    filtered?: boolean;
}

class IRPRiskSearchResultDataModel implements IIRPRiskSearchResultDataModel {
    @observable total;
    @observable items;
    @observable filtered;
}

interface IIRPRiskSearchResultModel {
    data: IIRPRiskSearchResultDataModel;
    request: IIRPRiskSearchRequestModel;
    sync: ISyncModel;
    setData: (data: { total: string; items: IIRPRiskSearchResultItem[]; filtered: boolean }) => IIRPRiskSearchResultDataModel;
    selectedIds: string[];
    selectedItems: IIRPRiskSearchResultItem[];
    selectItem: (item: IIRPRiskSearchResultItem) => string[];
    selectItems: (items: IIRPRiskSearchResultItem[]) => string[];
    deSelectItem: (item: IIRPRiskSearchResultItem) => string[];
    isSelected: (item: IIRPRiskSearchResultItem) => boolean;
    clearSelectedItems: () => string[];
}

class IRPRiskSearchResultModel implements IIRPRiskSearchResultModel {
    @observable data = new IRPRiskSearchResultDataModel();
    request: IIRPRiskSearchRequestModel;
    sync = new SyncModel();
    @observable selectedIds = [];

    @computed
    get selectedItems() {
        const selectedIds = this.selectedIds;
        return this.data.items.filter(item => selectedIds.indexOf(item.resultId) > -1)
    }

    setData = (data): IIRPRiskSearchResultDataModel => {
        this.data =  {
            total: data.total,
            items: this._mapRiskSearchResultItemsToViewItems(data.items), 
            filtered: data.filtered
        };
        return this.data;
    };

    private _mapRiskSearchResultItemsToViewItems = (items: IIRPRiskSearchResultItem[], ): IIRPRiskSearchResultViewItem[] => {
        const mappedItems: IIRPRiskSearchResultViewItem[] = [];

        const getClientIdSystem = (item: IIRPRiskSearchResultItem) => {
            if (item.client.cid) {
                return `${item.client.cid} (ICSE)`
            } else if (item.client.vgn) {
                return `${item.client.vgn} (TRIPS)`
            } else {
                return "";
            }
        };

        for (let item of items) {
            mappedItems.push(Object.assign({}, item, {
                key: item.resultId,
                matchedViewTS: moment(item.matchedTs).format(Output.riskResumeTimestamp),
                riskNameNumber: `${item.riskNumber} - ${item.riskName}`,
                subClassCode: item.application.visaSubclass,
                applicationIdSystem: `${item.application.sourceSystemId} (${item.application.sourceSystemCode})`,
                clientIdSystem: getClientIdSystem(item),
                clientRiskStageRating: `${item.client.riskCheckStatus} (${item.client.riskRating})`,
                matchTriggerName: undefined
            }));
        }
        return mappedItems;
    };

    selectItem = (item: IIRPRiskSearchResultItem) => {
        if (!this.isSelected(item)) {
            this.selectedIds.push(item.resultId);
        }
        return this.selectedIds;
    };

    selectItems = (items: IIRPRiskSearchResultItem[]) => {
        this.selectedIds = [];
        for (let item of items) {
            this.selectItem(item);
        }
        return this.selectedIds;
    };

    clearSelectedItems = () => {
        this.selectedIds = [];
        return this.selectedIds;
    };

    isSelected = (item: IIRPRiskSearchResultItem) => {
        return this.selectedIds.findIndex(i => i === item.resultId) > -1;
    };

    deSelectItem = (item: IIRPRiskSearchResultItem) => {
        if (this.isSelected(item)) {
            const index = this.selectedIds.findIndex(i => i === item.resultId);
            this.selectedIds.splice(index, 1);
        }
        return this.selectedIds;
    }
}


export {
    IRPRiskSearchResultModel as default,
    IRPRiskSearchResultModel,
    IIRPRiskSearchResultModel,
    IIRPRiskSearchResultItem,
    IIRPRiskSearchResultViewItem,
    IRPRiskSearchResultDataModel,
    IIRPRiskSearchResultDataModel,
    getItemKeyFromViewKey,
    getViewKeyFromItemKey
};