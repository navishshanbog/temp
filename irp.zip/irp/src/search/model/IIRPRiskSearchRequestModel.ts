import IError from "@twii/common/lib/IError";
import * as moment from "moment";
import {IIRPRiskSearchRequest, ValidRiskSearchMatchStatus, ValidRiskSearchSortFieldName} from "./IIRPRiskSearchRequest";

interface IIIRPRiskSearchRequestSort {
    fieldName: ValidRiskSearchSortFieldName;
    direction: "ASC" | "DESC";
}

interface IIRPRiskSearchRequestModel {
    validationErrors: IError[];
    isValueSpecified: boolean;
    riskNumber: string;
    riskType: string;
    status: ValidRiskSearchMatchStatus;
    firstMatchTsFrom: moment.Moment;
    firstMatchTsTo: moment.Moment;
    firstResult: number;
    maxResults: number;
    page: {
        firstResult: number;
        maxResults: number;
    };

    sort: IIIRPRiskSearchRequestSort;

    setRiskNumber(riskNumber?: string): void;

    setRiskType(riskType?: string): void;

    setStatus(status?: string): void;

    setFirstMatchTsFrom(riskMatchedFrom?: moment.Moment): void;

    setFirstMatchTsTo(riskMatchedTo?: moment.Moment): void;
    setFirstResult(firstResult: number): void;
    setMaxResults(maxResults?: number): void;
    setSort(sort?: IIIRPRiskSearchRequestSort): void;

    isRiskNumberSpecified: boolean;
    isRiskTypeSpecified: boolean;
    isStatusSpecified: boolean;
    isFirstMatchTsFromSpecified: boolean;
    isFirstMatchTsToSpecified: boolean;


    request: IIRPRiskSearchRequest;

    setRequest(request: IIRPRiskSearchRequest): void;

    submit(requestHandler: () => void);

    clear(): void;
    validate(): void;
}

export {
    IIRPRiskSearchRequestModel as default,
    IIRPRiskSearchRequestModel,
    IIIRPRiskSearchRequestSort
};