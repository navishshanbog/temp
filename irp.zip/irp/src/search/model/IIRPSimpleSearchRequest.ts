
import {validIdSourceENUM} from "../../shared/SystemIdTypeRefList";

interface IIRPSimpleSearchRequest {
    idType?: string;
    referenceNumber?: string;
    applicationId?: string;
    cid?: string;
    clientId?: string;
    sourcesystem?: validIdSourceENUM;
    caller?: string;
    windowId?: string;
}

export {IIRPSimpleSearchRequest as default, IIRPSimpleSearchRequest}