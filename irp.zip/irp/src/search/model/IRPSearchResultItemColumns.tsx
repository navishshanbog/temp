import * as React from "react";
//import {ICustomColumn} from "@twii/common/lib/component/CustomDetailsList";
import {ICustomColumn} from "../../irpcommon/CustomDetailsList";
import {ColumnActionsMode} from "office-ui-fabric-react/lib/components/DetailsList/DetailsList.types";

const IRPSearchResultItemColumns: ICustomColumn[] = [
    {
        key: "matchedViewTS",
        ariaLabel: "First matched date",
        name: "First matched date",
        fieldName: "matchedViewTS",
        minWidth: 150,
        maxWidth: 200,
        isResizable: true,
        isMultiline: true,
        columnActionsMode: ColumnActionsMode.clickable
    },
    {
        key: "riskNameNumber",
        ariaLabel: "Risk number and name",
        name: "Risk number and name",
        fieldName: "riskNameNumber",
        minWidth: 150,
        maxWidth: 200,
        isResizable: true,
        isMultiline: true,
        isSorted: false
    },

    {
        key: "riskType",
        ariaLabel: "Risk type(s)",
        name: "Risk type(s)",
        fieldName: "riskType",
        minWidth: 150,
        maxWidth: 200,
        isResizable: true,
        isSorted: false
    },
    {
        key: "matchTriggerName",
        ariaLabel: "Match trigger",
        name: "Match trigger",
        fieldName: "matchTriggerName",
        isResizable: true,
        minWidth: 150,
        maxWidth: 200,
        isSorted: false
    },
    {
        key: "status",
        ariaLabel: "Risk match status",
        name: "Risk match status",
        fieldName: "status",
        isResizable: true,
        isMultiline: true,
        minWidth: 150,
        maxWidth: 150,
        isSorted: false
    },
    {
        key: "subClassCode",
        ariaLabel: "Application subclass number and name",
        name: "Application subclass number and name",
        fieldName: "subClassCode",
        isResizable: true,
        minWidth: 220,
        maxWidth: 250,
        isSorted: false
    },
    {
        key: "applicationIdSystem",
        ariaLabel: "Application ID and system",
        name: "Application ID and system",
        fieldName: "applicationIdSystem",
        isResizable: true,
        minWidth: 150,
        maxWidth: 200,
        isSorted: false
    },
    {
        key: "clientIdSystem",
        ariaLabel: "Client ID and ID type",
        name: "Client ID and ID type",
        fieldName: "clientIdSystem",
        isResizable: true,
        minWidth: 150,
        maxWidth: 200,
        isSorted: false
    },
    {
        key: "clientRiskStageRating",
        ariaLabel: "Client risk stage and rating",
        name: "Client risk stage and rating",
        fieldName: "clientRiskStageRating",
        minWidth: 150,
        maxWidth: 200,
        isResizable: true,
        isMultiline: true,
        isSorted: false
    }
];

export {IRPSearchResultItemColumns as default, IRPSearchResultItemColumns}