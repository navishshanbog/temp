import * as React from "react";
import Router from "roota/lib/Router";
import {exactPath} from "@twii/common/lib/RouterUtils";
import {SystemIdTypeRefList, validIdSourceENUM} from "./shared/SystemIdTypeRefList";
import {IIRPSimpleSearchRequest} from "./search/model/IIRPSimpleSearchRequest";
import { reactRouter } from "@twii/common/lib/Routers";
import { Icon } from "office-ui-fabric-react/lib/Icon";

const r = new Router();

interface IIRPRouterUrlParams {
    applicationId?: string;
    cid?: string;
    sourcesystem?: validIdSourceENUM;
    caller?: string;
    windowId?: string;
    clientId?: string;
}

r.use("/search", exactPath((req) => {
    return import("./search/component/IRPSearchApplet").then(m => {
        return <m.IRPSearchApplet host={req.app} urlParams={{simpleSearchReq: req.params as IIRPSimpleSearchRequest}}/>;
    });
}));

r.use('*', exactPath(req => {
    return import("./irp/component/IRPApplet").then(m => {
        return <m.IRPApplet host={req.app} urlParams={mapRoutingParams(req.params) as IIRPSimpleSearchRequest}/>;
    });
}));

const mapRoutingParams = (urlParams: IIRPRouterUrlParams): IIRPSimpleSearchRequest | IIRPRouterUrlParams => {
    let idRefItem;
    if (urlParams.sourcesystem === validIdSourceENUM.ICSE) {
        if (urlParams.applicationId) {
            idRefItem = SystemIdTypeRefList.getItemByKey("prId");
            if(urlParams.clientId) {
                return {
                    idType: idRefItem.key,
                    referenceNumber: urlParams.applicationId,
                    clientId: urlParams.clientId
                };
            }
            return {
                idType: idRefItem.key,
                referenceNumber: urlParams.applicationId
            };
        }
        else if (urlParams.cid) {
            idRefItem = SystemIdTypeRefList.getItemByKey("icseId");
            return {
                idType: idRefItem.key,
                referenceNumber: urlParams.cid
            };
        }
    }
    return urlParams;
};

export {
    r as default,
    r as IRPRouter,
    IIRPRouterUrlParams
}