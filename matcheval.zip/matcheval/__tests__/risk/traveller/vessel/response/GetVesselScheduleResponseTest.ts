import { deserializeEnvelope } from "@twii/common/lib/xml/SoapDeserializer";
import { string, date, dateTime, time, boolean, int } from "@twii/common/lib/xml/SimpleXmlType";
import IXmlType from "@twii/common/lib/xml/IXmlType";
import * as DateUtils from "@twii/common/lib/util/Date";
import { soapEnvelopeNamespaceURI } from "@twii/common/lib/xml/SoapCommon";
import { GetVesselScheduleResponseType } from "risk/traveller/vessel/response/XmlSchema";
import IGetVesselScheduleResponse from 'risk/traveller/vessel/response/IGetVesselScheduleResponse';
import {IVesselItinerary} from "../../../../../src/risk/traveller/vessel/response/IVesselItinerary";

describe("GetVesselScheduleResponseTest", () => {
    test("deserializeEnvelope()", () => {
        const source =
        `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
           <soapenv:Body>
              <GetVesselScheduleResponse xmlns="http://border.gov.au/service/vessel/schedule/response/v1" xmlns:vescom="http://border.gov.au/service/vessel/common/v1" xmlns:vessch="http://border.gov.au/service/vessel/schedule/v1">
                 <VesselMovementInfo>
                    <vescom:DirectionCode>I</vescom:DirectionCode>
                    <vescom:LocalPortCode>SYD</vescom:LocalPortCode>
                    <vescom:VesselType>AIR</vescom:VesselType>
                    <vescom:RouteId>SQ211</vescom:RouteId>
                 </VesselMovementInfo>
                 <ListOfVesselItinerary>
                    <VesselItinerary>
                        <vessch:BorderPortInd>Y</vessch:BorderPortInd>
                        <vessch:RouteId>SQ211</vessch:RouteId>
                        <vessch:LocalScheduledDate>2017-06-14</vessch:LocalScheduledDate>
                        <vessch:LocalPortCode>SYD</vessch:LocalPortCode>
                        <vessch:DirectionCode>I</vessch:DirectionCode>
                        <vessch:ForeignPortCode>SIN</vessch:ForeignPortCode>
                        <vessch:LocalScheduledDayOfWeek>Wed</vessch:LocalScheduledDayOfWeek>
                        <vessch:FullRountingText>SINSYD</vessch:FullRountingText>
                        <vessch:ArrivalDateTime>2017-06-14T19:15:00</vessch:ArrivalDateTime>
                        <vessch:ArrivalPortCode>SYD</vessch:ArrivalPortCode>
                        <vessch:ArrivalPortName>Sydney Kingsford Smith Apt</vessch:ArrivalPortName>
                        <vessch:ArrivalPortCountryCode>AUS</vessch:ArrivalPortCountryCode>
                        <vessch:ArrivalPortCountryName>AUSTRALIA</vessch:ArrivalPortCountryName>
                        <vessch:DepartureDateTime>2017-06-14T09:35:00</vessch:DepartureDateTime>
                        <vessch:CanberraDepartureDateTime>2017-06-14T11:35:00</vessch:CanberraDepartureDateTime>
                        <vessch:CanberraArrivalDateTime>2017-06-14T19:15:00</vessch:CanberraArrivalDateTime>
                        <vessch:DeparturePortCode>SIN</vessch:DeparturePortCode>
                        <vessch:DeparturePortName>Singapore Changi Apt</vessch:DeparturePortName>
                        <vessch:DeparturePortCountryCode>SGP</vessch:DeparturePortCountryCode>
                        </VesselItinerary>
                 </ListOfVesselItinerary>
              </GetVesselScheduleResponse>
           </soapenv:Body>
        </soapenv:Envelope>`;

        const er = deserializeEnvelope(source, GetVesselScheduleResponseType);

        console.log("-- Get Vessel Schedule Response Envelope Result: " + JSON.stringify(er));
        expect(er.header).toBeFalsy();
        expect(er.fault).toBeFalsy();
        expect(er.body).toBeTruthy();

        const res = er.body as IGetVesselScheduleResponse;
        expect(res.ListOfVesselItinerary.VesselItinerary[0].RouteId).toBe("SQ211");
        const listOfVesselSchedule = res.ListOfVesselItinerary;
        expect(listOfVesselSchedule).toBeTruthy();
        expect(listOfVesselSchedule.VesselItinerary.length).toBe(1);

        const vesselItinerary : IVesselItinerary = listOfVesselSchedule.VesselItinerary[0];
        expect(vesselItinerary.ForeignPortCode).toBe("SIN");
    });
});
