import { deserializeEnvelope } from "@twii/common/lib/xml/SoapDeserializer";
import { string, date, dateTime, time, boolean, int } from "@twii/common/lib/xml/SimpleXmlType";
import IXmlType from "@twii/common/lib/xml/IXmlType";
import * as DateUtils from "@twii/common/lib/util/Date";
import { soapEnvelopeNamespaceURI } from "@twii/common/lib/xml/SoapCommon";
import { GetTravellerHistoryResponseType } from "risk/traveller/iat/response/XmlSchema";
import IGetTravellerHistoryResponse from "risk/traveller/iat/response/IGetTravellerHistoryResponse";

describe("GetTravellerHistoryResponseTest", () => {
    test("deserializeEnvelope()", () => {
        const source =
         `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
        <soapenv:Body>
            <GetTravellerHistoryResponse xmlns="http://border.gov.au/service/risk/traveller/iat/response/v1" xmlns:iatcom="http://border.gov.au/service/risk/traveller/iat/common/v1" xmlns:iat="http://border.gov.au/service/risk/traveller/iat/v1">
                <ListOfTravellerHistory>
                    <TravellerHistory>
                    <IATTravellerID>0114954323</IATTravellerID>
                    <ListOfPassportInfo>
                    <PassportInfo>
                      <iatcom:travelDocInfo>
                       <iatcom:travelDocId>G34121151</iatcom:travelDocId>
                       <iatcom:travelDocCountryCode>AUS</iatcom:travelDocCountryCode>
                       <iatcom:travelDocTypeCode>PASSPORT</iatcom:travelDocTypeCode>
                       <iatcom:travelDocSequenceNbr>-1</iatcom:travelDocSequenceNbr>
                       <iatcom:issueCountryCode>AUS</iatcom:issueCountryCode>
                       <iatcom:travelDocExpiryDate>2015-09-10</iatcom:travelDocExpiryDate>
                      </iatcom:travelDocInfo>
                      <iatcom:departmentRunNbr>1</iatcom:departmentRunNbr>
                      <iatcom:documentImpoundIndicator>N</iatcom:documentImpoundIndicator>
                      <iatcom:immigrationDirectiveCode>E</iatcom:immigrationDirectiveCode>
                      <iatcom:lastUpdateDate>2017-09-05</iatcom:lastUpdateDate>
                      <iatcom:passportIssueDate>2017-09-05</iatcom:passportIssueDate>
                      <iatcom:passportIssueOfficeCode>175</iatcom:passportIssueOfficeCode>
                      <iatcom:passportStatusCode>ACTIVE</iatcom:passportStatusCode>
                      <iatcom:passportTypeCode>DIPLOMATIC</iatcom:passportTypeCode>
                      <iatcom:sourceSystemCode>IAT</iatcom:sourceSystemCode>
                    </PassportInfo>
                    </ListOfPassportInfo>
                    <ListOfVisaInfo>
                        <VisaInfo>
                            <iatcom:travelDocInfo>
                                <iatcom:travelDocId>G34121151</iatcom:travelDocId>
                                <iatcom:travelDocCountryCode>CHN</iatcom:travelDocCountryCode>
                                <iatcom:issueCountryCode>CHN</iatcom:issueCountryCode>
                            </iatcom:travelDocInfo>
                            <iatcom:lastUpdatedDate>2017-03-11</iatcom:lastUpdatedDate>
                            <iatcom:occupationCode>0000</iatcom:occupationCode>
                            <iatcom:SourceSystemCode>MBV</iatcom:SourceSystemCode>
                            <iatcom:visaEntriesAllowedCode>1</iatcom:visaEntriesAllowedCode>
                            <iatcom:visaEntriesMadeCount>001</iatcom:visaEntriesMadeCount>
                            <iatcom:visaEvidenceNumber>0000000000</iatcom:visaEvidenceNumber>
                            <iatcom:visaImmigrationDirectiveCode>E</iatcom:visaImmigrationDirectiveCode>
                            <iatcom:visaLawfulGrantNumber>7579584760523</iatcom:visaLawfulGrantNumber>
                            <iatcom:visaLawfulUntilDate>2017-03-11</iatcom:visaLawfulUntilDate>
                            <iatcom:visaMigrantExpiryDate>2017-03-11</iatcom:visaMigrantExpiryDate>
                            <iatcom:visaPersonSeqNbr>0</iatcom:visaPersonSeqNbr>
                            <iatcom:visaPhysicalEvidenceStatusCode></iatcom:visaPhysicalEvidenceStatusCode>
                            <iatcom:visaResidenceCountryCode>-</iatcom:visaResidenceCountryCode>
                            <iatcom:visaStatusCode>S</iatcom:visaStatusCode>
                            <iatcom:visaStayPeriodText>20170319</iatcom:visaStayPeriodText>
                        </VisaInfo>
                    </ListOfVisaInfo>
                    <ListOfBioDataInfo>
                        <BioDataInfo>
                            <iatcom:aliasSequenceNbr>1</iatcom:aliasSequenceNbr>
                            <iatcom:personInfo>
                                <iatcom:familyName>AAA</iatcom:familyName>
                                <iatcom:givenName>SSSSSS</iatcom:givenName>
                                <iatcom:sexCode>M</iatcom:sexCode>
                                <iatcom:birthDate>19660704</iatcom:birthDate>
                            </iatcom:personInfo>
                            <iatcom:birthNameInd>N</iatcom:birthNameInd>
                            <iatcom:currentNameInd>N</iatcom:currentNameInd>
                            <iatcom:lastUpdateDate>2017-02-21</iatcom:lastUpdateDate>
                        </BioDataInfo>
                    </ListOfBioDataInfo>
                    <ListOfMovementInfo>
                        <MovementInfo>
                            <iat:travelDocInfo>
                                <iatcom:travelDocId>G34121151</iatcom:travelDocId>
                                <iatcom:travelDocCountryCode>CHN</iatcom:travelDocCountryCode>
                            </iat:travelDocInfo>
                            <iat:checkInPortCode>PEK</iat:checkInPortCode>
                            <iat:directionCode>I</iat:directionCode>
                            <iat:localPortCode>CNS</iat:localPortCode>
                            <iat:localScheduledDate>2017-03-05</iat:localScheduledDate>
                            <iat:routeId>CX103</iat:routeId>
                            <iat:visaSubClassCode>600</iat:visaSubClassCode>
                            <iat:passengerCrewCode>P</iat:passengerCrewCode>
                            <iat:movementDate>2017-03-05</iat:movementDate>
                            <iat:movementTime>07:28:21</iat:movementTime>
                            <iat:movementStatusCode>A</iat:movementStatusCode>
                        </MovementInfo>
                        <MovementInfo>
                            <iat:travelDocInfo>
                                <iatcom:travelDocId>G34121151</iatcom:travelDocId>
                                <iatcom:travelDocCountryCode>CHN</iatcom:travelDocCountryCode>
                            </iat:travelDocInfo>
                            <iat:checkInPortCode>MEL</iat:checkInPortCode>
                            <iat:directionCode>O</iat:directionCode>
                            <iat:localPortCode>MEL</iat:localPortCode>
                            <iat:localScheduledDate>2017-03-12</iat:localScheduledDate>
                            <iat:routeId>CX178</iat:routeId>
                            <iat:visaSubClassCode>600</iat:visaSubClassCode>
                            <iat:passengerCrewCode>P</iat:passengerCrewCode>
                            <iat:movementDate>2017-03-11</iat:movementDate>
                            <iat:movementTime>22:17:13</iat:movementTime>
                            <iat:movementStatusCode>A</iat:movementStatusCode>
                        </MovementInfo>
                    </ListOfMovementInfo>
                    <ListOfAlertInfo>
                        <AlertInfo>
                            <iat:alertNumber>12345</iat:alertNumber>
                            <iat:alertStatusCode>123</iat:alertStatusCode>
                            <iat:accessCategoryCode>abc</iat:accessCategoryCode>
                            <iat:issueDate>2017-03-12</iat:issueDate>
                            <iat:departmentCode>12</iat:departmentCode>
                            <iat:FIDInAction>Act</iat:FIDInAction>
                            <iat:FIDOutAction>Act</iat:FIDOutAction>
                            <iat:BIDInAction>Act</iat:BIDInAction>
                            <iat:BIDOutAction>Act</iat:BIDOutAction>
                            <iat:suspectType>A</iat:suspectType>
                            <iat:FIDInNarrative>abc</iat:FIDInNarrative>
                            <iat:FIDOutNarrative>def</iat:FIDOutNarrative>
                            <iat:FIDBothNarrative>xyz</iat:FIDBothNarrative>
                        </AlertInfo>
                    </ListOfAlertInfo>
                    <ListOfAlertMovementInfo>
                        <AlertMovementInfo>
                            <iat:alertNumber>12345</iat:alertNumber>
                            <iat:localScheduledDate>2017-03-12</iat:localScheduledDate>
                            <iat:localPortCode>MEL</iat:localPortCode>
                            <iat:matchCategoryCode>ABC</iat:matchCategoryCode>
                            <iat:BIDSelectStatus>ABC</iat:BIDSelectStatus>
                            <iat:FIDSelectStatus>AAA</iat:FIDSelectStatus>
                            <iat:ExpectedMovementIndicator>Y</iat:ExpectedMovementIndicator>
                        </AlertMovementInfo>
                    </ListOfAlertMovementInfo>
                    <ListOfBagsExamResultInfo>
                        <BagsExamResultInfo>
                            <iat:localScheduledDate>2017-03-12</iat:localScheduledDate>
                            <iat:routeId>CX178</iat:routeId>
                            <iat:examinationNbr>123</iat:examinationNbr>
                            <iat:targettingMethod>TECH</iat:targettingMethod>
                            <iat:alertNumber>12345</iat:alertNumber>
                            <iat:highestResultsType>BBB</iat:highestResultsType>
                            <iat:examinationResultType>jdfdjf</iat:examinationResultType>
                            <iat:findMethod>S</iat:findMethod>
                            <iat:baggageLocation>CABIN</iat:baggageLocation>
                            <iat:notes>result notes</iat:notes>
                            <iat:outcomeType>POSITIVE</iat:outcomeType>
                            <iat:quantityValue>1</iat:quantityValue>
                            <iat:quantityUnit>C</iat:quantityUnit>
                        </BagsExamResultInfo>
                    </ListOfBagsExamResultInfo>

                    </TravellerHistory>
                </ListOfTravellerHistory>
            </GetTravellerHistoryResponse>
        </soapenv:Body>
        </soapenv:Envelope>`;

        const er = deserializeEnvelope(source, GetTravellerHistoryResponseType);

        console.log("-- Get Traveller History Envelope Result: " + JSON.stringify(er));
        expect(er.header).toBeFalsy();
        expect(er.fault).toBeFalsy();
        expect(er.body).toBeTruthy();

        const res = er.body as IGetTravellerHistoryResponse;

        expect(res.ListOfTravellerHistory).toBeTruthy();
        expect(res.ListOfTravellerHistory.TravellerHistory.length).toBe(1);

        const th = res.ListOfTravellerHistory.TravellerHistory[0];

        expect(th.IATTravellerID).toBe("0114954323");
        expect(th.ListOfPassportInfo).toBeTruthy();
        expect(th.ListOfPassportInfo.PassportInfo.length).toBe(1);

        const pp = th.ListOfPassportInfo.PassportInfo[0];

        expect(pp.travelDocInfo).toBeTruthy();
        expect(pp.travelDocInfo.travelDocId).toBe("G34121151");
        expect(pp.travelDocInfo.travelDocSequenceNbr).toBe(-1);

    });
});
