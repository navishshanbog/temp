import { deserializeEnvelope } from "@twii/common/lib/xml/SoapDeserializer";
import { string, date, dateTime, time, boolean, int } from "@twii/common/lib/xml/SimpleXmlType";
import IXmlType from "@twii/common/lib/xml/IXmlType";
import * as DateUtils from "@twii/common/lib/util/Date";
import { soapEnvelopeNamespaceURI } from "@twii/common/lib/xml/SoapCommon";
import { GetProfileMatchesResponseType } from "risk/traveller/profilematchdataservice/response/XmlSchema";
import IGetProfileMatchesResponse from "risk/traveller/profilematchdataservice/response/IGetProfileMatchesResponse";

describe("GetCurrentBookingDataResponseTest", () => {
    test("deserializeEnvelope()", () => {
        const source =
        `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
        <soapenv:Body>
            <GetProfileMatchesResponse xmlns="http://border.gov.au/service/risk/traveller/profilematchdataservice/response/v1" xmlns:com="http://border.gov.au/service/risk/traveller/pnr/common/v1" xmlns:iat="http://border.gov.au/service/risk/traveller/iat/common/v1">
                <IATTravellerId>0000577559</IATTravellerId>
                <ListsOfProfileMatch>
                    <ListOfProfileMatch>
                    <IATTravellerId>0000577559</IATTravellerId>
                    <ProfileMatches>
                        <ProfileMatch>
                            <ResultId>O201702122159041680</ResultId>
                            <BiographicFamilyName>)$ SName&amp;&lt;>'"</BiographicFamilyName>
                            <BiographicGivenName>! &amp; "r '" ( &amp;&lt;>'"FName!</BiographicGivenName>
                            <BiographicBirthDate>19450818</BiographicBirthDate>
                            <BiographicSexCode>M</BiographicSexCode>
                            <BiographicIssueCountryCode>AUS</BiographicIssueCountryCode>
                            <BiographicTravelDocNbr>EDOC1L0055</BiographicTravelDocNbr>
                            <BookingPassengerNumber>0</BookingPassengerNumber>
                            <IATTravellerID>0000577559</IATTravellerID>
                            <ProfileId>-731</ProfileId>
                            <ProfileName>JK MR41 TEST</ProfileName>
                            <ResultCreationTimeStamp>2017-02-12T21:54:40.180</ResultCreationTimeStamp>
                            <ReasonForMatch>Matched Profile JK MR41 Test</ReasonForMatch>
                            <ResultTypeCode>A</ResultTypeCode>
                            <LocalScheduleDate>2016-12-26</LocalScheduleDate>
                            <RouteId>JQ43</RouteId>
                            <Direction>O</Direction>
                            <LocalPortCode>MEL</LocalPortCode>
                            <CBRScheduledDateTime>2016-12-26T09:55:00</CBRScheduledDateTime>
                            <ProfileNote>This is a test profile with very relax rules</ProfileNote>
                            <ProfileTier>1</ProfileTier>
                            <ActionInd>U</ActionInd>
                        </ProfileMatch>
                        <ProfileMatch>
                            <ResultId>O201702122159041681</ResultId>
                            <BiographicFamilyName>)$ SName&amp;&lt;>'"</BiographicFamilyName>
                            <BiographicGivenName>! &amp; "r '" ( &amp;&lt;>'"FName!</BiographicGivenName>
                            <BiographicBirthDate>19450818</BiographicBirthDate>
                            <BiographicSexCode>M</BiographicSexCode>
                            <BiographicIssueCountryCode>AUS</BiographicIssueCountryCode>
                            <BiographicTravelDocNbr>EDOC1L0055</BiographicTravelDocNbr>
                            <BookingPassengerNumber>0</BookingPassengerNumber>
                            <IATTravellerID>0000577559</IATTravellerID>
                            <ProfileId>-732</ProfileId>
                            <ProfileName>jktest2</ProfileName>
                            <ResultCreationTimeStamp>2017-02-12T21:54:40.180</ResultCreationTimeStamp>
                            <ReasonForMatch>eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee</ReasonForMatch>
                            <ResultTypeCode>A</ResultTypeCode>
                            <LocalScheduleDate>2016-12-26</LocalScheduleDate>
                            <RouteId>JQ43</RouteId>
                            <Direction>O</Direction>
                            <LocalPortCode>MEL</LocalPortCode>
                            <CBRScheduledDateTime>2016-12-26T09:55:00</CBRScheduledDateTime>
                            <ProfileNote>This is a test profile with very relax rules</ProfileNote>
                            <ProfileTier>1</ProfileTier>
                            <ActionInd>U</ActionInd>
                        </ProfileMatch>
                        <ProfileMatch>
                            <ResultId>O201705241405264</ResultId>
                            <BiographicFamilyName>)$ SName&amp;&lt;>'"</BiographicFamilyName>
                            <BiographicGivenName>! &amp; "r '" ( &amp;&lt;>'"FName!</BiographicGivenName>
                            <BiographicBirthDate>19450818</BiographicBirthDate>
                            <BiographicSexCode>M</BiographicSexCode>
                            <BiographicIssueCountryCode>AUS</BiographicIssueCountryCode>
                            <BiographicTravelDocNbr>EDOC1L0055</BiographicTravelDocNbr>
                            <BookingPassengerNumber>0</BookingPassengerNumber>
                            <IATTravellerID>0000577559</IATTravellerID>
                            <ProfileId>-733</ProfileId>
                            <ProfileName>ZIPLINE</ProfileName>
                            <ResultCreationTimeStamp>2017-05-24T14:04:57.050</ResultCreationTimeStamp>
                            <ReasonForMatch>Age of Traveller = 71 ; Gender = M</ReasonForMatch>
                            <ResultTypeCode>A</ResultTypeCode>
                            <LocalScheduleDate>2017-03-26</LocalScheduleDate>
                            <RouteId>GA719</RouteId>
                            <Direction>O</Direction>
                            <LocalPortCode>MEL</LocalPortCode>
                            <CBRScheduledDateTime>2017-03-26T10:10:00</CBRScheduledDateTime>
                            <ProfileNote>This is a test profile with very relax rules</ProfileNote>
                            <ProfileTier>3</ProfileTier>
                            <ActionInd>U</ActionInd>
                        </ProfileMatch>
                    </ProfileMatches>
                    </ListOfProfileMatch>
                </ListsOfProfileMatch>
            </GetProfileMatchesResponse>
        </soapenv:Body>
        </soapenv:Envelope>`;


        const er = deserializeEnvelope(source, GetProfileMatchesResponseType);

        console.log("-- Get Profile Match Response Envelope Result: " + JSON.stringify(er));
        expect(er.header).toBeFalsy();
        expect(er.fault).toBeFalsy();
        expect(er.body).toBeTruthy();

        const res = er.body as IGetProfileMatchesResponse;
        expect(res.IATTravellerId).toBe("0000577559");
        const lopms = res.ListsOfProfileMatch;
        expect(lopms).toBeTruthy();
        expect(lopms.ListOfProfileMatch.length).toBe(1);
        
        const lopm = lopms.ListOfProfileMatch[0];
        expect(lopm.IATTravellerId).toBe("0000577559");
        const profileMatches = lopm.ProfileMatches;
        expect(profileMatches).toBeTruthy();
        expect(profileMatches.ProfileMatch.length).toBe(3);
        expect(profileMatches.ProfileMatch[0].ResultId).toBe("O201702122159041680");

        let pm = profileMatches.ProfileMatch[0];
        expect(pm.ResultId).toBe("O201702122159041680");

        pm = profileMatches.ProfileMatch[1];
        expect(pm.ResultId).toBe("O201702122159041681");

        pm = profileMatches.ProfileMatch[2];
        expect(pm.ResultId).toBe("O201705241405264");
    });
});