import axios from "axios";
import * as settle from "axios/lib/core/settle";
import SoapPNRDataService from "risk/traveller/pnr/SoapPNRDataService";
import { envelope as source } from "./response/GetCurrentBookingDataSampleResponseEnvelope";

describe("SoapPNRDataServiceTest", () => {
    test("GetCurrentBookingData", async () => {
        let requestConfig;

        axios.defaults.adapter = (config) => {
            requestConfig = config;
            return new Promise((resolve, reject) => {
                settle(resolve, reject, {
                    status: 200,
                    headers: {
                        "content-type": "text/xml"
                    },
                    data: source,
                    config: config
                });
            });
        };

        const service = new SoapPNRDataService({ baseUrl: "http://who.cares" });

        const bookingCreationTimeStamp = new Date();
        const recordLocator = "332424";

        const r = await service.GetCurrentBookingData({
            BookingSystemCode: "EK",
            BookingCreationTimeStamp: bookingCreationTimeStamp,
            RecordLocator: recordLocator
        });

        expect(requestConfig).toBeTruthy();
        expect(requestConfig.headers.SOAPAction).toBeTruthy();
        expect(requestConfig.headers.SOAPAction).toBe("http://border.gov.au/risk/traveller/pnr/v1/GetCurrentBookingData");
    });
});