import IGetCurrentBookingDataRequest from "risk/traveller/pnr/request/IGetCurrentBookingDataRequest";
import { GetCurrentBookingDataRequestType } from "risk/traveller/pnr/request/XmlSchema";
import { serializeEnvelope } from "@twii/common/lib/xml/SoapSerializer";
import PNRDataSubject from "risk/traveller/pnr/common/PNRDataSubject";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as StringUtils from "@twii/common/lib/util/String";
import ElementBuilder from "@twii/common/lib/xml/ElementBuilder";
import * as moment from "moment";

describe("GetCurrentBookingDataRequestTest", () => {
    test("serializeRequest", () => {
        const reqTs = DateUtils.dateFromTimestampDataText("2002-06-11T18:22:21.000+10:00");
        const bookingTs = DateUtils.dateFromTimestampDataText("2002-06-11T18:22:21.000");
        const req : IGetCurrentBookingDataRequest = {
            RequestHeader: {
                correlationRequestId: "test1",
                userId: "test-user",
                userRole: "test-role",
                sourceSystemId: "test-ss",
                requestTimeStamp: reqTs
            },
            BookingSystemCode: "TEST",
            BookingCreationTimeStamp: bookingTs,
            RecordLocator: "1",
            RequestedDataSubjects: {
                PNRDataSubject: [PNRDataSubject.Booking, PNRDataSubject.Itinerary]
            }
        };

        const actions = new ElementBuilder();

        serializeEnvelope({
            actions: actions,
            body: {
                value: req,
                name: "GetCurrentBookingDataRequest",
                type: GetCurrentBookingDataRequestType
            }
        });

        const r = actions.result;

        // TODO: assertions
        expect(r.childNodes.length).toBe(1);

        const bodyNode = r.childNodes.item(0);
        expect(StringUtils.contains(bodyNode.nodeName, "Body")).toBeTruthy();

        expect(bodyNode.childNodes.length).toBe(1);

        const requestNode = bodyNode.childNodes.item(0);

        expect(StringUtils.contains(requestNode.nodeName, "GetCurrentBookingDataRequest")).toBeTruthy();

        const requestHeaderNode = requestNode.childNodes.item(0);

        expect(StringUtils.contains(requestHeaderNode.nodeName, "RequestHeader")).toBeTruthy();

        const correlationIdNode = requestHeaderNode.childNodes.item(0);
        expect(StringUtils.contains(correlationIdNode.nodeName, "correlationRequestId")).toBeTruthy();
        expect(correlationIdNode.textContent).toBe("test1");

        const userIdNode = requestHeaderNode.childNodes.item(1);
        expect(StringUtils.contains(userIdNode.nodeName, "userId")).toBeTruthy();
        expect(userIdNode.textContent).toBe("test-user");

        const userRoleNode = requestHeaderNode.childNodes.item(2);
        expect(StringUtils.contains(userRoleNode.nodeName, "userRole")).toBeTruthy();
        expect(userRoleNode.textContent).toBe("test-role");

        const sourceSystemIdNode = requestHeaderNode.childNodes.item(3);
        expect(StringUtils.contains(sourceSystemIdNode.nodeName, "sourceSystemId")).toBeTruthy();
        expect(sourceSystemIdNode.textContent).toBe("test-ss");

        const requestTimestampNode = requestHeaderNode.childNodes.item(4);
        expect(StringUtils.contains(requestTimestampNode.nodeName, "requestTimeStamp")).toBeTruthy();
        expect(requestTimestampNode.textContent).toBe("2002-06-11T08:22:21.000Z");

        const BookingSystemCodeNode = requestNode.childNodes.item(1);
        expect(StringUtils.containsIgnoreCase(BookingSystemCodeNode.nodeName, "BookingSystemCode")).toBeTruthy();
        expect(BookingSystemCodeNode.textContent).toBe("TEST");

        const BookingCreationTimeStampNode = requestNode.childNodes.item(2);
        expect(StringUtils.containsIgnoreCase(BookingCreationTimeStampNode.nodeName, "BookingCreationTimeStamp")).toBeTruthy();

        let timeStampValue : string = BookingCreationTimeStampNode.textContent;

        expect(timeStampValue).toEqual("2002-06-11T18:22:21.000");

        const RecordLocatorNode = requestNode.childNodes.item(3);
        expect(StringUtils.containsIgnoreCase(RecordLocatorNode.nodeName, "RecordLocator")).toBeTruthy();
        expect(RecordLocatorNode.textContent).toBe("1");

        const RequestedDataSubjectsNode = requestNode.childNodes.item(4);
        expect(StringUtils.containsIgnoreCase(RequestedDataSubjectsNode.nodeName, "RequestedDataSubjects")).toBeTruthy();
        
        expect(RequestedDataSubjectsNode.childNodes.length).toBe(2);

        let RequestedDataSubjectNode = RequestedDataSubjectsNode.childNodes.item(0);
        expect(StringUtils.containsIgnoreCase(RequestedDataSubjectNode.nodeName, "PNRDataSubject"));
        expect(RequestedDataSubjectNode.textContent).toBe(PNRDataSubject.Booking);

        RequestedDataSubjectNode = RequestedDataSubjectsNode.childNodes.item(1);
        expect(StringUtils.containsIgnoreCase(RequestedDataSubjectNode.nodeName, "PNRDataSubject"));
        expect(RequestedDataSubjectNode.textContent).toBe(PNRDataSubject.Itinerary);
    });
});