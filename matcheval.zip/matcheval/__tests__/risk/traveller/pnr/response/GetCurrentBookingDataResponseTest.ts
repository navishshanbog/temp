import { deserializeEnvelope } from "@twii/common/lib/xml/SoapDeserializer";
import { string, date, dateTime, time, boolean, int } from "@twii/common/lib/xml/SimpleXmlType";
import IXmlType from "@twii/common/lib/xml/IXmlType";
import * as DateUtils from "@twii/common/lib/util/Date";
import { soapEnvelopeNamespaceURI } from "@twii/common/lib/xml/SoapCommon";
import { GetCurrentBookingDataResponseType } from "risk/traveller/pnr/response/XmlSchema";
import IGetCurrentBookingDataResponse from "risk/traveller/pnr/response/IGetCurrentBookingDataResponse";
import { envelope as source } from "./GetCurrentBookingDataSampleResponseEnvelope";

describe("GetCurrentBookingDataResponseTest", () => {
    test("deserializeEnvelope()", () => {
        const er = deserializeEnvelope(source, GetCurrentBookingDataResponseType);

        //console.log("-- Envelope Result: " + JSON.stringify(er));
        expect(er.header).toBeFalsy();
        expect(er.fault).toBeFalsy();
        expect(er.body).toBeTruthy();

        const res = er.body as IGetCurrentBookingDataResponse;
        
        const data = res.CurrentBookingData;
        expect(data).toBeTruthy();

        const bookingRecordInfo = data.BookingRecordInfo;
        expect(bookingRecordInfo).toBeTruthy();
        expect(bookingRecordInfo.BookingSystemCode).toBe("1A");
        expect(bookingRecordInfo.RecordLocator).toBe("26WT55");
        expect(bookingRecordInfo.PNRSource).toBe("EU Hosted PNR");

        const bookingSummaryInfo = data.BookingSummaryInfo;
        expect(bookingSummaryInfo).toBeTruthy();
        expect(bookingSummaryInfo.PNRTravelType).toBe("Travel To AUS - Round Trip");
        expect(DateUtils.dateToDataText(bookingSummaryInfo.BookingDate)).toBe("2014-09-09");
        expect(bookingSummaryInfo.BookingCity).toBe("CAN");
        expect(bookingSummaryInfo.FormOfPayment).toBe("CC");
        expect(DateUtils.dateToDataText(bookingSummaryInfo.IntentToTravelDate)).toBe("2015-02-01");
        expect(bookingSummaryInfo.TravelGroupName).toBe("NICETRIP");
        expect(bookingSummaryInfo.OriginalBookingDBT).toBe(145);
        expect(bookingSummaryInfo.CurrentBookingDBT).toBe(145);
        expect(bookingSummaryInfo.MostTimeSpentDays).toBe(23);
        expect(bookingSummaryInfo.MostTimeSpentCountry).toBe("AUS");
        expect(bookingSummaryInfo.MostTimeSpentPort).toBe("CAN");
        expect(bookingSummaryInfo.TotalLengthOfStay).toBe(13);
        expect(bookingSummaryInfo.IntendLengthOfStay).toBe(13);
        expect(bookingSummaryInfo.TotalLengthOfTrip).toBe(54);
        expect(bookingSummaryInfo.ActiveSegmentCount).toBe(54);
        expect(bookingSummaryInfo.CancelledSegmentCount).toBe(0);
        expect(bookingSummaryInfo.TravellerCount).toBe(29);
        expect(bookingSummaryInfo.MinorsInGroupCount).toBeFalsy();
        expect(bookingSummaryInfo.TCPNumber).toBe(30);
        expect(DateUtils.dateToTimestampOutputText(bookingSummaryInfo.DepartureCanberraTimeStamp)).toBe("15/02/2015 11:25:00");

        const linkedPNR = data.LinkedPNRInfo;

        expect(linkedPNR).toBeTruthy();

        expect(linkedPNR.PNRRecordKey.length).toBe(1);

        const linkedPNRRecordKey = linkedPNR.PNRRecordKey[0];

        expect(linkedPNRRecordKey.RecordLocator).toBe("A9384232");
        expect(linkedPNRRecordKey.BookingSystemCode).toBe("A2");
        expect(DateUtils.dateToTimestampOutputText(linkedPNRRecordKey.PNRCreationTimeStamp)).toBe("10/09/2015 09:54:00");
    });
});