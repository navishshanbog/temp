enum Gender {
    Male = "M",
    Female = "F",
    Unknown = "-"
}

export { Gender as default, Gender }