import IRequestHeader from "./IRequestHeader";
import * as IdUtils from "@twii/common/lib/util/Id";

const SourceSystemId = "USR";

const getRequestHeader = (spec?: IRequestHeader) : Promise<IRequestHeader> => {
    const sourceSystemId = spec && spec.sourceSystemId ? spec.sourceSystemId : SourceSystemId;
    const timestamp = new Date();
    const userId = spec && spec.userId ? spec.userId : "unknown";
    return Promise.resolve({
        correlationRequestId: `${IdUtils.next(sourceSystemId + "-" + userId + "-")}-${timestamp.getTime()}`,
        requestTimeStamp: timestamp,
        sourceSystemId: sourceSystemId,
        userId: userId
    });
};

export { getRequestHeader }