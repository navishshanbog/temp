enum YesNo {
    Yes = "Y",
    No = "N"
}

export { YesNo as default, YesNo }