import IAddress from "./common/IAddress";

interface IListOfAddress {
    Address?: IAddress[];
}

export { IListOfAddress as default, IListOfAddress }