import ICruiseBookingData from "../ICruiseBookingData";

interface IGetCurrentCruBookingDataResponse {
    CurrentCruBookingData?: ICruiseBookingData;
}

export { IGetCurrentCruBookingDataResponse as default, IGetCurrentCruBookingDataResponse }