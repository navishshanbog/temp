interface IGetHistoricalCruBookingDataResponse {
    
}

export { IGetHistoricalCruBookingDataResponse as default, IGetHistoricalCruBookingDataResponse }