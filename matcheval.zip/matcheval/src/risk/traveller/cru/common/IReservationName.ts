interface IReservationName {
    familyName?: string;
    givenName?: string;
}

export { IReservationName as default, IReservationName }