import ITravelDocInfo from "./ITravelDocInfo";
import IPersonInfo from "../../iat/common/IPersonInfo";

interface IIATTraveller {
    IATTravellerId?: string;
    TravelDoc?: ITravelDocInfo;
    Biographic?: IPersonInfo;
    MatchedTravelDoc?: ITravelDocInfo;
}

export { IIATTraveller as default, IIATTraveller }