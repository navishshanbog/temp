enum ContactType {
    NAME = "NAME",
    EMAIL = "EMAIL",
    HOME_PHONE = "HOME_PHONE",
    FAX = "FAX",
    WORK_PHONE = "WORK_PHONE"
}

export { ContactType as default, ContactType }