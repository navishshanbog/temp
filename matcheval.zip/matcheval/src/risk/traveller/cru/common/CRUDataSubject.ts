enum CRUDataSubject {
    Booking = "Booking",
    Itinerary = "Itinerary",
    Traveller = "Traveller"
}

export { CRUDataSubject as default, CRUDataSubject }