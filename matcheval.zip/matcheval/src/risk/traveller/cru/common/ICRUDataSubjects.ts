import CRUDataSubject from "./CRUDataSubject";

interface ICRUDataSubjects {
    CRUDataSubject: CRUDataSubject[];
}

export { ICRUDataSubjects as default, ICRUDataSubjects }