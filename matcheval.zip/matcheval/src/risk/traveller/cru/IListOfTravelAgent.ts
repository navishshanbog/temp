import ITravelAgent from "./ITravelAgent";

interface IListOfTravelAgent {
    TravelAgent?: ITravelAgent[];
}

export { IListOfTravelAgent as default, IListOfTravelAgent }