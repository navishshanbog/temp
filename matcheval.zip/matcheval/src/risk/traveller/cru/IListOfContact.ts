import IContact from "./common/IContact";

interface IListOfContact {
    Contact?: IContact[];
}

export { IListOfContact as default, IListOfContact }