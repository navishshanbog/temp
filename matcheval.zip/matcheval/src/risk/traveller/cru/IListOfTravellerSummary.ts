import ITravellerSummary from "./ITravellerSummary";

interface IListOfTravellerSummary {
    TravellerSummary?: ITravellerSummary[];
}

export { IListOfTravellerSummary as default, IListOfTravellerSummary }