import IConnection from "./common/IConnection";

interface IListOfConnection {
    Connection?: IConnection[];
}

export { IListOfConnection as default, IListOfConnection }