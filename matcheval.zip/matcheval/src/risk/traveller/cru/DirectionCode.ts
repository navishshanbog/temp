enum DirectionCode {
    In = "I",
    Out = "O"
}

export { DirectionCode as default, DirectionCode }