import IVisaInfo from "../iat/common/IVisaInfo";

interface IBookingVisa {
    Visa?: IVisaInfo;
    VisaDBT?: number;
}

export { IBookingVisa as default, IBookingVisa }