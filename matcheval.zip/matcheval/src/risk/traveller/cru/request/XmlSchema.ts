import IXmlType from "@twii/common/lib/xml/IXmlType";
import { string, dateTime } from "@twii/common/lib/xml/SimpleXmlType";
import { RequestHeaderType } from "../../common/XmlSchema";
import { CRUDataSubjectsType } from "../common/XmlSchema";

const namespaceURI = "http://border.gov.au/service/risk/traveller/cru/request/v1";

const GetCurrentCruBookingDataRequestType : IXmlType = {
    namespaceURI: namespaceURI,
    name: "GetCurrentCruBookingDataRequestType",
    props: {
        RequestHeader: { type: RequestHeaderType },
        BookingSystemCode: { type: string },
        BookingCreationTimeStamp: { type: dateTime, withTimezone: false },
        RecordLocator: { type: string },
        RequestedDataSubjects: { type: CRUDataSubjectsType }
    }
};

const GetHistoricalCruBookingDataRequestType : IXmlType = {
    namespaceURI: namespaceURI,
    name: "GetHistoricalCruBookingDataRequestType",
    props: {
        RequestHeader: { type: RequestHeaderType },
        BookingSystemCode: { type: string },
        BookingCreationTimeStamp: { type: dateTime, withTimezone: false },
        RecordLocator: { type: string },
    }
};


export {
    namespaceURI,
    GetCurrentCruBookingDataRequestType,
    GetHistoricalCruBookingDataRequestType
}

