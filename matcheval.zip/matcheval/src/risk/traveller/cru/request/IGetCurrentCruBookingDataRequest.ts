import IRequestHeader from "../../common/IRequestHeader";
import ICRUDataSubjects from "../common/ICRUDataSubjects";

interface IGetCurrentCruBookingDataRequest {
    RequestHeader?: IRequestHeader;
    BookingSystemCode?: string;
    BookingCreationTimeStamp?: Date;
    RecordLocator?: string;
    RequestedDataSubjects?: ICRUDataSubjects;
}

export { IGetCurrentCruBookingDataRequest as default, IGetCurrentCruBookingDataRequest }