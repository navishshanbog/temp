import ICruiseBookingItinerary from "./common/ICruiseBookingItinerary";

interface IListOfCruiseBookingItinerary {
    CruiseBookingItinerary?: ICruiseBookingItinerary[];
}

export { IListOfCruiseBookingItinerary as default, IListOfCruiseBookingItinerary }