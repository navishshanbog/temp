import ITravelDocInfo from "./common/ITravelDocInfo";

interface IListOfTravelDocInfo {
    TravelDocInfo?: ITravelDocInfo[];
}

export { IListOfTravelDocInfo as default, IListOfTravelDocInfo }