import IListOfTravelDocInfo from "./IListOfTravelDocInfo";
import IListOfAddress from "./IListOfAddress";
import IListOfContact from "./IListOfContact";
import IPersonInfo from "../iat/common/IPersonInfo";
import IReservationName from "./common/IReservationName";

interface ICruiseTraveller {
    //PassengerNumber?: number; // moved to travllerinformation
    TravelDoc?: IListOfTravelDocInfo;
    Addresses?: IListOfAddress;
    Contacts?: IListOfContact;
    Biographic?: IPersonInfo;
    ReservationName?: IReservationName;
}

export { ICruiseTraveller as default, ICruiseTraveller }