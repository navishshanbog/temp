import * as React from "react";
import CRUDataServiceContext from "../CRUDataServiceContext";
import IAppHost from "@twii/common/lib/IAppHost";
import AppHostWrapper from "@twii/common/lib/component/AppHostWrapper";
import IGetCurrentCruBookingDataRequest from "../request/IGetCurrentCruBookingDataRequest";
import IGetCurrentCruBookingDataResponse from "../response/IGetCurrentCruBookingDataResponse";
import CRUDataSubject from "../common/CRUDataSubject";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import { Dropdown, IDropdownOption } from "office-ui-fabric-react/lib/Dropdown";
import Error from "@twii/common/lib/component/Error";
import * as DateUtils from "@twii/common/lib/util/Date";

interface IGetCurrentCruBookingRequestProps {
    onSubmit?(request : IGetCurrentCruBookingDataRequest) : void;
}

interface IGetCurrentCruBookingRequestState {
    sourceSystemId?: string;
    userId?: string;
    BookingSystemCode?: string;
    BookingCreationTimestamp?: string;
    RecordLocator?: string;
    RequestedDataSubjects: CRUDataSubject[];
}

class GetCurrentBookingDataRequest extends React.Component<IGetCurrentCruBookingRequestProps, IGetCurrentCruBookingRequestState> {
    constructor(props) {
        super(props);
        this.state = { RequestedDataSubjects: [] };
    }
    private _onSourceSystemIdChange = (value : string) => {
        this.setState({ sourceSystemId: value });
    }
    private _onUserIdChange = (value : string) => {
        this.setState({ userId: value });
    }
    private _onBookingSystemCodeChange = (value : string) => {
        this.setState({ BookingSystemCode: value });
    }
    private _onBookingCreationTimestampChange = (value : string) => {
        this.setState({ BookingCreationTimestamp: value });
    }
    private _onRecordLocatorChange = (value : string) => {
        this.setState({ RecordLocator: value });
    }
    private _onSubmit = () => {
        if(this.props.onSubmit) {
            const BookingCreationTimestamp = DateUtils.dateFromTimestampDataText(this.state.BookingCreationTimestamp);
            const request : IGetCurrentCruBookingDataRequest = {
                RequestHeader: {
                    sourceSystemId: this.state.sourceSystemId,
                    userId: this.state.userId
                },
                BookingSystemCode: this.state.BookingSystemCode,
                BookingCreationTimeStamp: BookingCreationTimestamp,
                RecordLocator: this.state.RecordLocator,
                RequestedDataSubjects: this.state.RequestedDataSubjects && this.state.RequestedDataSubjects.length > 0 ? { CRUDataSubject: this.state.RequestedDataSubjects } : undefined
            };
            this.props.onSubmit(request);
        }
    }
    private _onDataSubjectsChanged = (option : IDropdownOption) => {
        let subjects;
        if(option.selected) {
            subjects = this.state.RequestedDataSubjects.concat(option.key as CRUDataSubject);
        } else {
            subjects = this.state.RequestedDataSubjects.slice(0);
            const idx = subjects.indexOf(option.key as CRUDataSubject);
            if(idx >= 0) {
                subjects.slice(idx, 1);
            }
        }
        this.setState({ RequestedDataSubjects: subjects });
    }
    render() {
        const dataSubjectOptions : IDropdownOption[] = [
            {
                key: CRUDataSubject.Booking,
                text: CRUDataSubject.Booking,
                selected: this.state.RequestedDataSubjects.indexOf(CRUDataSubject.Booking) >= 0
            },
            {
                key: CRUDataSubject.Itinerary,
                text: CRUDataSubject.Itinerary,
                selected: this.state.RequestedDataSubjects.indexOf(CRUDataSubject.Itinerary) >= 0
            },
            {
                key: CRUDataSubject.Traveller,
                text: CRUDataSubject.Traveller,
                selected: this.state.RequestedDataSubjects.indexOf(CRUDataSubject.Traveller) >= 0
            }
        ];
        return (
            <div className="pnr-get-current-cru-booking-data-request">
                <TextField label="Source System Id" onChanged={this._onSourceSystemIdChange} value={this.state.sourceSystemId || ""} />
                <TextField label="User Id" onChanged={this._onUserIdChange} value={this.state.userId || ""} />
                <TextField label="Booking System Code" onChanged={this._onBookingSystemCodeChange} value={this.state.BookingSystemCode || ""} />
                <TextField label="Booking Creation Timestamp" onChanged={this._onBookingCreationTimestampChange} value={this.state.BookingCreationTimestamp || ""} />
                <TextField label="Record Locator" onChanged={this._onRecordLocatorChange} value={this.state.RecordLocator || ""} />
                <Dropdown label="CRU Data Subjects" options={dataSubjectOptions} multiSelect={true} onChanged={this._onDataSubjectsChanged} />
                <PrimaryButton onClick={this._onSubmit}>Submit</PrimaryButton>
            </div>
        );
    }
}

interface IGetCurrentCruBookingDataResponseProps {
    response: IGetCurrentCruBookingDataResponse;
}

class GetCurrentBookingDataResponse extends React.Component<IGetCurrentCruBookingDataResponseProps, any> {
    render() {
        return (
            <pre>{JSON.stringify(this.props.response, null, "\t")}</pre>
        );
    }
}

interface IGetCurrentBookingDataState {
    loading: boolean;
    response?: IGetCurrentCruBookingDataResponse;
    error?: any;
}

class GetCurrentBookingData extends React.Component<any, IGetCurrentBookingDataState> {
    constructor(props) {
        super(props);
        this.state = { loading: false };
    }
    _handleRequestSubmit = (request : IGetCurrentCruBookingDataRequest) => {
        this.setState({ loading: true });
        CRUDataServiceContext.value.GetCurrentCruBookingData(request).then(response => {
            this.setState({ loading: false, response: response });
        }).catch(error => {
            this.setState({ loading: false, error: error, response: null });
        });
    }
    render() {
        let content;
        if(this.state.loading) {
            content = <Spinner label="Getting Current Booking Data..." />;
        } else if(this.state.error) {
            content = <Error error={this.state.error} />;
        } else {
            content = <GetCurrentBookingDataResponse response={this.state.response} />;
        }
        return (
            <div className="pnr-get-current-booking-data" style={{ padding: "10px" }}>
                <GetCurrentBookingDataRequest onSubmit={this._handleRequestSubmit} />
                <div className="pnr-get-current-booking-response-container">
                    {content}
                </div>
            </div>
        );
    }
}

class IGetCurrentBookingDataAppletProps {
    host: IAppHost;
}

class GetCurrentBookingDataApplet extends React.Component<IGetCurrentBookingDataAppletProps, any> {
    render() {
        return (
            <AppHostWrapper host={this.props.host} title="PNR: Get Current Booking Data Test">
                <GetCurrentBookingData />
            </AppHostWrapper>
        );
    }
}

export { GetCurrentBookingDataApplet as default, GetCurrentBookingDataApplet, IGetCurrentBookingDataAppletProps }