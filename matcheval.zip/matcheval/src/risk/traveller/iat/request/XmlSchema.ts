import IXmlType from "@twii/common/lib/xml/IXmlType";
import { string } from "@twii/common/lib/xml/SimpleXmlType";
import { RequestHeaderType } from "../../common/XmlSchema";
import { IATDataSubjectsType } from "../common/XmlSchema";
const namespaceURI = "http://border.gov.au/service/risk/traveller/iat/request/v1";

const ListOfIATTravellerIdType : IXmlType = {
    namespaceURI: namespaceURI,
    name: "ListOfIATTravellerIdType",
    props: {
        IATTravellerId: { type: string }
    }
};

const GetTravellerHistoryRequestType : IXmlType = {
    namespaceURI: namespaceURI,
    name: "GetTravellerHistoryRequestType",
    props: {
        RequestHeader: { type: RequestHeaderType },
        ListOfIATTravellerId: { type: ListOfIATTravellerIdType },
        RequestedDataSubjects: { type: IATDataSubjectsType }
    }
};

export {
    namespaceURI,
    GetTravellerHistoryRequestType
}