import IRequestHeader from "../../common/IRequestHeader";
import IListOfTravellerId from "./IListOfTravellerId";
import IIATDataSubjects from "../common/IIATDataSubjects";

interface IGetTravellerHistoryRequest {
    RequestHeader?: IRequestHeader;
    ListOfIATTravellerId?: IListOfTravellerId;
    RequestedDataSubjects?: IIATDataSubjects;
}

export { IGetTravellerHistoryRequest as default, IGetTravellerHistoryRequest }