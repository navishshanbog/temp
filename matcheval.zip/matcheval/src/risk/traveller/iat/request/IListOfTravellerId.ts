interface IListOfTravellerId {
    IATTravellerId?: string[];
}

export { IListOfTravellerId as default, IListOfTravellerId }