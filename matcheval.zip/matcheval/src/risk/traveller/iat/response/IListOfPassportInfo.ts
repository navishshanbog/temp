import IPassportInfo from "../common/IPassportInfo";

interface IListOfPassportInfo {
    PassportInfo?: IPassportInfo[];
}

export { IListOfPassportInfo as default, IListOfPassportInfo }