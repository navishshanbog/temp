import IAlertInfo from "../IAlertInfo";

interface IListOfAlertInfo {
    AlertInfo?: IAlertInfo[];
}

export { IListOfAlertInfo as default, IListOfAlertInfo }