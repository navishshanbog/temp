import IListOfTravellerHistory from "./IListOfTravellerHistory";

interface IGetTravellerHistoryResponse {
    ListOfTravellerHistory?: IListOfTravellerHistory;
}

export { IGetTravellerHistoryResponse as default, IGetTravellerHistoryResponse }