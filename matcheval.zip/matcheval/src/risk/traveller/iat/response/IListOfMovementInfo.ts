import IMovementInfo from "../IMovementInfo";

interface IListOfMovementInfo {
    MovementInfo?: IMovementInfo[];
}

export { IListOfMovementInfo as default, IListOfMovementInfo }