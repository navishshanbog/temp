import IBioDataInfo from "../common/IBioDataInfo";

interface IListOfBioDataInfo {
    BioDataInfo?: IBioDataInfo[];
}

export { IListOfBioDataInfo as default, IListOfBioDataInfo }