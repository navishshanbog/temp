import IVisaInfo from "../common/IVisaInfo";

interface IListOfVisaInfo {
    VisaInfo?: IVisaInfo[];
}

export { IListOfVisaInfo as default, IListOfVisaInfo }