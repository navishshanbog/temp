import IBagsExamResultInfo from "../IBagsExamResultInfo";

interface IListOfBagsExamResultInfo {
    BagsExamResultInfo?: IBagsExamResultInfo[];
}

export { IListOfBagsExamResultInfo as default, IListOfBagsExamResultInfo }