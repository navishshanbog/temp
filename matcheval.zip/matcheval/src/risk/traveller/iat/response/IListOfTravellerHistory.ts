import ITravellerHistory from "./ITravellerHistory";

interface IListOfTravellerHistory {
    TravellerHistory?: ITravellerHistory[];
}

export { IListOfTravellerHistory as default, IListOfTravellerHistory }