import IAlertMovementInfo from "../IAlertMovementInfo";

interface IListOfAlertMovementInfo {
    AlertMovementInfo?: IAlertMovementInfo[];
}

export { IListOfAlertMovementInfo as default, IListOfAlertMovementInfo }