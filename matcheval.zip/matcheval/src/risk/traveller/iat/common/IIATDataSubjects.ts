import IATDataSubject from "./IATDataSubject";

interface IIATDataSubjects {
    IATDataSubject: IATDataSubject[];
}

export { IIATDataSubjects as default, IIATDataSubjects }