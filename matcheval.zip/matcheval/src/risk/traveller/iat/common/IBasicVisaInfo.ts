interface IBasicVisaInfo {
    visaGrantDate?: Date;
    visaGrantNbr?: string;
    visaClassCode?: string;
    visaConditionText?: string;
    visaSubClassCode?: string;
}

export { IBasicVisaInfo as default, IBasicVisaInfo }