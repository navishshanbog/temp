enum IATDataSubject {
    Movements = "Movements",
    Documents = "Documents",
    Intervention = "Intervention"
}

export { IATDataSubject as default, IATDataSubject }