import IPNRRecordKey from "./IPNRRecordKey";

interface IListOfPNRRecordKey {
    PNRRecordKey: IPNRRecordKey[]
}

export { IListOfPNRRecordKey as default, IListOfPNRRecordKey }