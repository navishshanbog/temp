import IPNRHistory from "./IPNRHistory";

interface IListOfPNRHistory {
    PNRHistory?: IPNRHistory[];
}

export { IListOfPNRHistory as default, IListOfPNRHistory }