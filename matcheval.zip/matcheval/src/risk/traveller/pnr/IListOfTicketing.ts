import ITicketing from "./ITicketing";

interface IListOfTicketing {
    Ticketing?: ITicketing[];
}

export { IListOfTicketing as default, IListOfTicketing }