interface IContact {
    PassengerTattoo?: number;
    Type?: string;
    FreeTextValue?: string;
    SegmentTattoo?: number;
}

export { IContact as default, IContact }