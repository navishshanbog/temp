import IPNRPushHistory from "./IPNRPushHistory";

interface IListOfPNRPushHistory {
    PNRPushHistory?: IPNRPushHistory[];
}

export { IListOfPNRPushHistory as default, IListOfPNRPushHistory }