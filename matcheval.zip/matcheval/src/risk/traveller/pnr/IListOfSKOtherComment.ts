import ISKOtherComment from "./ISKOtherComment";

interface IListOfSKOtherComment {
    SKOtherComment?: ISKOtherComment[];
}

export { IListOfSKOtherComment as default, IListOfSKOtherComment }