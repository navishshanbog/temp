import IItinerary from "./IItinerary";

interface IListOfItinerary {
    Itinerary?: IItinerary[];
}

export { IListOfItinerary as default, IListOfItinerary }