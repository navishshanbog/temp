import * as React from "react";
import PNRDataServiceContext from "../PNRDataServiceContext";
import IAppHost from "@twii/common/lib/IAppHost";
import AppHostWrapper from "@twii/common/lib/component/AppHostWrapper";
import IGetHistoricalBookingDataRequest from "../request/IGetHistoricalBookingDataRequest";
import IGetHistoricalBookingDataResponse from "../response/IGetHistoricalBookingDataResponse";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Error from "@twii/common/lib/component/Error";
import * as DateUtils from "@twii/common/lib/util/Date";

interface IGetHistoricalBookingRequestProps {
    onSubmit?(request : IGetHistoricalBookingDataRequest) : void;
}

interface IGetHistoricalBookingRequestState {
    sourceSystemId?: string;
    userId?: string;
    BookingSystemCode?: string;
    BookingCreationTimestamp?: string;
    RecordLocator?: string;
}

class GetHistoricalBookingDataRequest extends React.Component<IGetHistoricalBookingRequestProps, IGetHistoricalBookingRequestState> {
    constructor(props) {
        super(props);
        this.state = {};
    }
    private _onSourceSystemIdChange = (value : string) => {
        this.setState({ sourceSystemId: value });
    }
    private _onUserIdChange = (value : string) => {
        this.setState({ userId: value });
    }
    private _onBookingSystemCodeChange = (value : string) => {
        this.setState({ BookingSystemCode: value });
    }
    private _onBookingCreationTimestampChange = (value : string) => {
        this.setState({ BookingCreationTimestamp: value });
    }
    private _onRecordLocatorChange = (value : string) => {
        this.setState({ RecordLocator: value });
    }
    private _onSubmit = () => {
        if(this.props.onSubmit) {
            const BookingCreationTimestamp = DateUtils.dateFromTimestampDataText(this.state.BookingCreationTimestamp);
            const request : IGetHistoricalBookingDataRequest = {
                RequestHeader: {
                    sourceSystemId: this.state.sourceSystemId,
                    userId: this.state.userId
                },
                BookingSystemCode: this.state.BookingSystemCode,
                BookingCreationTimeStamp: BookingCreationTimestamp,
                RecordLocator: this.state.RecordLocator
            };
            this.props.onSubmit(request);
        }
    }
    render() {
        return (
            <div className="pnr-get-current-booking-data-request">
                <TextField label="Source System Id" onChanged={this._onSourceSystemIdChange} value={this.state.sourceSystemId || ""} />
                <TextField label="User Id" onChanged={this._onUserIdChange} value={this.state.userId || ""} />
                <TextField label="Booking System Code" onChanged={this._onBookingSystemCodeChange} value={this.state.BookingSystemCode || ""} />
                <TextField label="Booking Creation Timestamp" onChanged={this._onBookingCreationTimestampChange} value={this.state.BookingCreationTimestamp || ""} />
                <TextField label="Record Locator" onChanged={this._onRecordLocatorChange} value={this.state.RecordLocator || ""} />
                <PrimaryButton onClick={this._onSubmit}>Submit</PrimaryButton>
            </div>
        );
    }
}

interface IGetHistoricalBookingDataResponseProps {
    response: IGetHistoricalBookingDataResponse;
}

class GetHistoricalBookingDataResponse extends React.Component<IGetHistoricalBookingDataResponseProps, any> {
    render() {
        return (
            <pre>{JSON.stringify(this.props.response, null, "\t")}</pre>
        );
    }
}

interface IGetHistoricalBookingDataState {
    loading: boolean;
    response?: IGetHistoricalBookingDataResponse;
    error?: any;
}

class GetHistoricalBookingData extends React.Component<any, IGetHistoricalBookingDataState> {
    constructor(props) {
        super(props);
        this.state = { loading: false };
    }
    _handleRequestSubmit = (request : IGetHistoricalBookingDataRequest) => {
        this.setState({ loading: true });
        PNRDataServiceContext.value.GetHistoricalBookingData(request).then(response => {
            this.setState({ loading: false, response: response });
        }).catch(error => {
            this.setState({ loading: false, error: error, response: null });
        });
    }
    render() {
        let content;
        if(this.state.loading) {
            content = <Spinner label="Getting Historical Booking Data..." />;
        } else if(this.state.error) {
            content = <Error error={this.state.error} />;
        } else {
            content = <GetHistoricalBookingDataResponse response={this.state.response} />;
        }
        return (
            <div className="pnr-get-historical-booking-data" style={{ padding: "10px" }}>
                <GetHistoricalBookingDataRequest onSubmit={this._handleRequestSubmit} />
                <div className="pnr-get-historical-booking-response-container">
                    {content}
                </div>
            </div>
        );
    }
}

class IGetHistoricalBookingDataAppletProps {
    host: IAppHost;
}

class GetHistoricalBookingDataApplet extends React.Component<IGetHistoricalBookingDataAppletProps, any> {
    render() {
        return (
            <AppHostWrapper host={this.props.host} title="PNR: Get Historical Booking Data Test">
                <GetHistoricalBookingData />
            </AppHostWrapper>
        );
    }
}

export { GetHistoricalBookingDataApplet as default, GetHistoricalBookingDataApplet, IGetHistoricalBookingDataAppletProps }