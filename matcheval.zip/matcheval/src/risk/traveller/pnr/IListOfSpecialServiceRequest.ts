import ISpecialServiceRequest from "./ISpecialServiceRequest";

interface IListOfSpecialServiceRequest {
    SpecialServiceRequest?: ISpecialServiceRequest[];
}

export { IListOfSpecialServiceRequest as default, IListOfSpecialServiceRequest }