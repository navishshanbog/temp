interface IPNRRecordKey {
    RecordLocator?: string;
    BookingSystemCode?: string;
    PNRCreationTimeStamp?: Date;
}

export { IPNRRecordKey as default, IPNRRecordKey }