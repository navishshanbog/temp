enum PNRDataSubject {
    Booking = "Booking",
    CheckInAndBoarding = "CheckInAndBoarding",
    FreeText = "FreeText",
    Itinerary = "Itinerary",
    Traveller = "Traveller"
}

export { PNRDataSubject as default, PNRDataSubject }