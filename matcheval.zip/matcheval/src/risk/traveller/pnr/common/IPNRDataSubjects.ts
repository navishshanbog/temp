import PNRDataSubject from "./PNRDataSubject";

interface IPNRDataSubjects {
    PNRDataSubject: PNRDataSubject[];
}

export { IPNRDataSubjects as default, IPNRDataSubjects }