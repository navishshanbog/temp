import IPersonInfo from "../../iat/common/IPersonInfo";

interface ICheckInInfo {
    personInfo?: IPersonInfo;
    CheckinSequence?: string;
    checkInAgent?: string;
    canberraCheckInDateTime?: Date;
    checkInCountryCode?: string;
    checkInCountryName?: string;
    checkInDateTime?: string;
    checkInPortCode?: string;
}

export { ICheckInInfo as default, ICheckInInfo }