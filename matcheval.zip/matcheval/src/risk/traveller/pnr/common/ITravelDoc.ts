import ITravelDocInfo from "../../iat/common/ITravelDocInfo";

interface ITravelDoc {
    TravelDocInfo?: ITravelDocInfo;
    TravelDocDBT?: number;
}

export { ITravelDoc as default, ITravelDoc }