import ITravelDoc from "./ITravelDoc";
import IPersonInfo from "../../iat/common/IPersonInfo";

interface IIATTraveller {
    IATTravellerId?: string;
    TravelDoc?: ITravelDoc;
    Biographic?: IPersonInfo;
    MatchedTravelDoc?: ITravelDoc;
}

export { IIATTraveller as default, IIATTraveller }