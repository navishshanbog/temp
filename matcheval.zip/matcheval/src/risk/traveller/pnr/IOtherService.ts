interface IOtherService {
    PassengerTattoo?: number;
    SegmentTattoo?: number;
    OSICode?: string;
    FreeTextValue?: string;
}

export { IOtherService as default, IOtherService }