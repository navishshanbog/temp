import IPayment from "./IPayment";

interface IListOfPayment {
    Payment?: IPayment[];
}

export { IListOfPayment as default, IListOfPayment }