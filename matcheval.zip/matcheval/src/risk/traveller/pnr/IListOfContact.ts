import IContact from "./IContact";

interface IListOfContact {
    Contact?: IContact[];
}

export { IListOfContact as default, IListOfContact }