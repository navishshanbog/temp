import IOtherService from "./IOtherService";

interface IListOfOtherService {
    OtherService?: IOtherService[];
}

export { IListOfOtherService as default, IListOfOtherService }