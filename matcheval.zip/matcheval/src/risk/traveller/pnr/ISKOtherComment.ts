interface ISKOtherComment {
    PassengerTattoo?: number;
    SegmentTattoo?: number;
    Type?: string;
    Code?: string;
    FreeTextValue?: string;
}

export { ISKOtherComment as default, ISKOtherComment }