import * as React from "react";
import Router from "roota/lib/Router";
import { exactPath } from "@twii/common/lib/RouterUtils";
const r = new Router();

r.use("/traveller/pnr/GetCurrentBookingData", exactPath(req => {
    return import("./traveller/pnr/component/GetCurrentBookingDataApplet").then(m => {
        return <m.GetCurrentBookingDataApplet host={req.app} />;
    });
}));
r.use("/traveller/pnr/GetHistoricalBookingData", exactPath(req => {
    return import("./traveller/pnr/component/GetHistoricalBookingDataApplet").then(m => {
        return <m.GetHistoricalBookingDataApplet host={req.app} />;
    });
}));
r.use("/traveller/cru/GetCurrentCruBookingData", exactPath(req => {
    return import("./traveller/cru/component/GetCurrentCruBookingDataApplet").then(m => {
        return <m.GetCurrentBookingDataApplet host={req.app} />;
    });
}));
r.use("/traveller/profilematch/GetProfileMatches", exactPath(req => {
    return import("./traveller/profilematchdataservice/component/GetProfileMatchesApplet").then(m => {
        return <m.GetHistoricalBookingDataApplet host={req.app} />;
    });
}));
r.use("/traveller/iat/GetTravellerHistory", exactPath(req => {
    return "TODO: IAT Get Traveller History";
}));

export { r as default, r as RiskRouter }