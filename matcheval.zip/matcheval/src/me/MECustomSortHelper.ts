import * as getValue from "get-value";
import * as SortUtils from "@twii/common/lib/util/Sort";

const convertNullToEmptyString = (text: string) => {
    return text ? text : "";
}

const toSortValue = (item: any, field: string) => {
    if (item) {
        return getValue(item,field);
    }
};

const compare = (a: any, b: any, sortBy: string) => {
    let r = SortUtils.compare(toSortValue(a, sortBy), toSortValue(b, sortBy));
    return r;
};

const sort = (items: any[], sortBy: string) => {
    return items && sortBy ? items.sort((a, b) => compare(a, b, sortBy)) : items;
};

export {
    convertNullToEmptyString,
	sort
};
    