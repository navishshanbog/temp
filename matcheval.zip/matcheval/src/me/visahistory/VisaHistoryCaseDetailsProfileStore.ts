import {VisaHistoryCaseDetailsProfileModel} from "./VisaHistoryCaseDetailsProfileModel";

const VisaHistoryCaseDetailsProfileStore = new VisaHistoryCaseDetailsProfileModel();

export { VisaHistoryCaseDetailsProfileStore };