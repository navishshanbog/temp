import {IEntityProfileInformation} from "./IEntityProfileInformation";
import {ICaseNotes} from "./ICaseNotes";

interface ICaseDetailsActivity {
    caseId?: string;
    urgency?: string;
    status?: string;
    caseNotes?: ICaseNotes[];
    entityProfileInformation?: IEntityProfileInformation[];
}

export { ICaseDetailsActivity }













