
import {IReferralActivity} from "./IReferralActivity";

interface IProfileMatchDetailsActivity {
    outcome?: string;
    treatmentAdvice?: string;
    additionalTreatmentAdvice?: string[];
    additionalTreatmentText?: string;
    dismissalReason?: string[];
    additionalDismissalText?: string;
    assessmentFinidings?: string;
    actionedUserId?: string;
    actionDateTime?: string;
    referral?: IReferralActivity[];
}

export { IProfileMatchDetailsActivity }