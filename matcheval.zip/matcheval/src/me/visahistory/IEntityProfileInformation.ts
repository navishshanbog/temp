import {IBioInfoActivity} from "./IBioInfoActivity";
import {ITypeNDescription} from "./ICaseActivity";
import {ITargetSystemsActivity} from "./ITargetSystemsActivity";
import {IProfileMatchActivity} from "./IProfileMatchActivity";
import {IVisas} from "./IVisas";

interface IEntityProfileInformation {
    bioInfo?: IBioInfoActivity[];
    clientLocation?: string;
    travelDocs?: ITypeNDescription[];
    targetSystems?: ITargetSystemsActivity[];
    additionalSearchTerms?: string;
    profileMatches?: IProfileMatchActivity[];
    visas?: IVisas[];
}

export { IEntityProfileInformation }