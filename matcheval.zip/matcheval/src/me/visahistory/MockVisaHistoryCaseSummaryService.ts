import { IVisaHistoryService, IVisaHistoryCaseSummaryRequest, IVisaHistoryCaseDetailsRequest, IVisaHistoryGetProfileDetailsRequest } from "./IVisaHistoryService";
import {ICaseActivity} from "./ICaseActivity";
import {ICaseDetailsActivity} from "./ICaseDetailsActivity";
import {IProfileMatchDetailsActivity} from "./IProfileMatchDetailsActivity";

class MockVisaHistoryCaseSummaryService implements IVisaHistoryService {
    getMatchEvalVisaHistoryCaseSummary : ICaseActivity[] = [{
        "caseId": "VME-2646",
        "domain": "VISA",
        "caseStatus": "Pending-DefineTreatment",
        "caseCreated": "2018-07-05T05:19:49.624+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19980721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Unlikely"
        }
        ]
    }, {
        "caseId": "VME-2666",
        "domain": "VISA",
        "caseStatus": "Pending-DefineTreatment",
        "caseCreated": "2018-07-06T00:40:54.084+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Likely"
        }
        ]
    }, {
        "caseId": "VME-2670",
        "domain": "VISA",
        "caseStatus": "Pending-DefineTreatment",
        "caseCreated": "2018-07-06T04:53:52.111+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Likely"
        }
        ]
    }, {
        "caseId": "VME-2642",
        "domain": "VISA",
        "caseStatus": "Pending-Search",
        "caseCreated": "2018-07-05T04:29:28.473+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": null,
            "outcome": null
        }
        ]
    }, {
        "caseId": "VME-2552",
        "domain": "VISA",
        "caseStatus": "Resolved-Treated",
        "caseCreated": "2018-06-26T06:26:35.558+10:00",
        "caseClosed": "2018-06-27T02:40:07.851+10:00",
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Unlikely"
        }, {
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": null,
            "outcome": null
        }
        ]
    }, {
        "caseId": "VME-2648",
        "domain": "VISA",
        "caseStatus": "Pending-DefineTreatment",
        "caseCreated": "2018-07-05T05:28:19.609+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Unlikely"
        }
        ]
    }, {
        "caseId": "VME-2499",
        "domain": "VISA",
        "caseStatus": "Pending-DefineTreatment",
        "caseCreated": "2018-06-25T23:37:19.337+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": null,
            "outcome": null
        }
        ]
    }, {
        "caseId": "VME-2649",
        "domain": "VISA",
        "caseStatus": "Pending-DefineTreatment",
        "caseCreated": "2018-07-05T05:32:00.045+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Unlikely"
        }
        ]
    }, {
        "caseId": "VME-2668",
        "domain": "VISA",
        "caseStatus": "Pending-DefineTreatment",
        "caseCreated": "2018-07-06T03:14:47.835+10:00",
        "caseClosed": null,
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["PAKISTAN", "JAPAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["PAKISTAN", "JAPAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Likely"
        }, {
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": null,
            "outcome": null
        }
        ]
    }, {
        "caseId": "VME-2554",
        "domain": "VISA",
        "caseStatus": "Resolved-Treated",
        "caseCreated": "2018-06-26T07:07:51.891+10:00",
        "caseClosed": "2018-06-27T02:39:35.858+10:00",
        "bioInfo": [{
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "ICSE",
            "id": "94650026493",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }, {
            "givenName": "Colton",
            "familyName": "COWARD",
            "sexCd": "Female",
            "dateOfBirth": "19940721",
            "sourceSystem": "TRIPS",
            "id": "1471478",
            "countryOfBirth": ["JAPAN"],
            "countryOfCitizenship": ["JAPAN", "PAKISTAN"]
        }
        ],
        "visas": [{
            "visaStreamCode": null,
            "visaSubClass": "Maritime Crew (Temporary)",
            "visaStatus": "Granted - In Effect"
        }
        ],
        "profile": [{
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": null,
            "outcome": null
        }, {
            "profileName": "VRA_988_MCV_FRAUD",
            "profileTier": null,
            "threats": ["Application fraud"],
            "treatmentType": "Default Threat Treatment",
            "outcome": "Highly Likely"
        }
        ]
    }
    ];

    getMatchEvalVisaHistoryCaseDetails: ICaseDetailsActivity = {
        "caseId":"VME-2415",
        "urgency":"56",
        "status":"Pending-DefineTreatment",
        "caseNotes":[{
            "notes":"ME offload and ME history Testing purpose for AnDe team",
            "userId":"SD72UP",
            "userName":"",
            "noteDtTime":"2018-07-25T03:05:13.03+10:00"
        }],
        "entityProfileInformation":[{
            "clientLocation":"Offshore",
            "additionalSearchTerms":null,
            "bioInfo":[{
                "givenName":"Ganya Gaarfield",
                "familyName":"KEISEER",
                "sexCd":"Female",
                "dateOfBirth":"19880910",
                "sourceSystem":"ICSE",
                "id":"49924027252",
                "countryOfBirth":["JAPAN","PAKISTAN"],
                "countryOfCitizenship":["JAPAN","PAKISTAN"]
            }, {
                "givenName":"Ganya Garfield",
                "familyName":"KEISER",
                "sexCd":"Female",
                "dateOfBirth":"19880910",
                "sourceSystem":"TRIPS",
                "id":"1471569",
                "countryOfBirth":["JAPAN","PAKISTAN"],
                "countryOfCitizenship":["PAKISTAN","JAPAN"]}],
            "travelDocs":[{
                "type":"Passport",
                "description":"YJ8962544"}
            ],
            "targetSystems":[
                {
                    "targetSystemsType":"NIS\/IMTEL<br\/><br\/>{COWARD, Colton (Female) 21JUL1994} or {COWARD, Colton (Female) 21JUL1994}<br\/><br\/>-----------------------------------<br\/><br\/>ACID\/ALEIN (ACIC)<br\/><br\/>COWARD AND Colton AND 21\/JUL\/1994 or COWARD AND Colton AND 21\/JUL\/1994<br\/><br\/>-----------------------------------"
                }
            ],
            "profileMatches":[{
                "name":"VRA_988_MCV_FRAUD",
                "tier":null,
                "threat":[
                    "threatType","AAC"
                ],
                "reasonForMatch":"Matched",
                "matchDate":"2018-07-06T00:40:52.136+10:00"}
            ],
            "visas":[
                {"visaStreamCode":null,
                    "visaSubClass":"Maritime Crew (Temporary)",
                    "visaStatus":"Granted - In Effect"
                }
            ]
        }
        ]
    };



    getMatchEvalVisaHistoryCaseProfileDetails: IProfileMatchDetailsActivity = {
        "referral": [{
            "notificationRecipient": "Unknown",
            "notificationAgency": "CBI",
            "sentReferralUserId": "Trump",
            "referralDateTime": "11 Dec 2017 10:12:23 (AEST)",
            "emailAddress": "trump.john@google.com",
            "emailSubject": "RE: John Smith",
            "emailContent": "All is well",
            "toAddress":["abcd@gmail.com"],
            "ccAddress":["abcdcc@gmail.com"],
            "bccAddress":["abcdbcc@gmail.com"],
            "attachments":[{"fileName":"abcd.pdf"},{"fileName":"efgh.xls"}]
        }, {
            "notificationRecipient": "Visa Citizen",
            "notificationAgency": "SBI",
            "sentReferralUserId": "Jackson",
            "referralDateTime": "16 Nov 2019 12:12:23 (AEST)",
            "emailAddress": "contact.sbi@google.com",
            "emailSubject": "RE: Jane Smith",
            "emailContent": "All is may be well",
            "toAddress":["pqrs@gmail.com","efgh@gmail.com"],
            "ccAddress":["pqrdcc@gmail.com","efgh@gmail.com"],
            "bccAddress":["pqrsbcc@gmail.com","efgh@gmail.com"],
            "attachments":[{"fileName":"pqrs.pdf"},{"fileName":"qres.xls"}]
        }, {
            "notificationRecipient": "Offshore",
            "notificationAgency": "MBI",
            "sentReferralUserId": "Jack Jane",
            "referralDateTime": "01 Oct 2013 01:12:23 (AEST)",
            "emailAddress": "jack.jane@google.com",
            "emailSubject": "RE: Apple Smith",
            "emailContent": "All is not well",
            "toAddress":["mnop@gmail.com","pqrs@gmail.com","efgh@gmail.com"],
            "ccAddress":["mnopcc@gmail.com", "pqrdcc@gmail.com","efgh@gmail.com"],
            "bccAddress":["mnopbcc@gmail.com", "pqrsbcc@gmail.com","efgh@gmail.com"],
            "attachments":[{"fileName":"mnop.pdf"},{"fileName":"55484.xls"}]
        }],


        "outcome": "Highly Likely",
        "treatmentAdvice": "Standard Treatment advice 1",
        "additionalTreatmentAdvice": ["Additional supportin text added by target assessor may be displayed here. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content", "Additional supportin text added by target assessor may be displayed here. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content"],
        "additionalTreatmentText": "Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. Additional supportin text added by target assessor may be displayed here. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories.",
        "dismissalReason": ["Standard Dismissal Reason 1","Standard Dismissal Reason 31", "Standard Dismissal Reason 13","Standard Dismissal Reason 14"],
        "additionalDismissalText": "The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories. Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content. Additional supportin text added by target assessor may be displayed here. The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories.",
        "assessmentFinidings": "Additional supportin text added by target assessor may be displayed here.The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories.Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content.The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories.Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content.The Pivot control and related tabs pattern are used for navigating frequently accessed, distinct content categories.Pivots allow for navigation between two or more content views and relies on text headers to articulate the different sections of content ",
        "actionedUserId": "PRABCD",
        "actionDateTime": "2016-07-06T00:40:52.136+10:00"

    };

    caseSummaryRequest: IVisaHistoryCaseSummaryRequest[] = [];
    getVisaHistoryCaseSummary(request : IVisaHistoryCaseSummaryRequest) : Promise<ICaseActivity[]> {
        this.caseSummaryRequest.push(request);
        return Promise.resolve(this.getMatchEvalVisaHistoryCaseSummary);
    }

    caseDetailsRequest: IVisaHistoryCaseDetailsRequest[] = []
    getVisaHistoryCaseDetails(request : IVisaHistoryCaseDetailsRequest) : Promise<ICaseDetailsActivity> {
        this.caseDetailsRequest.push(request);
        return Promise.resolve(this.getMatchEvalVisaHistoryCaseDetails);
    }

    caseProfileDetailsRequest: IVisaHistoryGetProfileDetailsRequest[] = [];
    getVisaHistoryProfileDetails(request : IVisaHistoryGetProfileDetailsRequest) : Promise<IProfileMatchDetailsActivity> {
        this.caseProfileDetailsRequest.push(request);
        return Promise.resolve(this.getMatchEvalVisaHistoryCaseProfileDetails);
    }
}

export { MockVisaHistoryCaseSummaryService };