import { observable, action } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import {IVisaHistoryCaseDetails} from "./IVisaHistoryCaseDetails";
import {ICaseDetailsActivity} from "./ICaseDetailsActivity";
import {IVisaHistoryCaseDetailsRequest} from "./IVisaHistoryService";
import {VisaHistoryServiceContext} from "./VisaHistoryServiceContext";
import {ICaseActivity} from "./ICaseActivity";
import {selectedProfileDetails} from "./MEVisaHistoryActions";
import {IEntityProfileInformation} from "./IEntityProfileInformation";
import {IProfileMatchActivity} from "./IProfileMatchActivity";



class VisaHistoryCaseDetailsModel implements IVisaHistoryCaseDetails {
    @observable sync: ISyncModel = new SyncModel();
    @observable selectedCase: ICaseActivity = {};
    @observable caseItems: ICaseActivity[] = [];

    @observable selectedCaseDetails: ICaseDetailsActivity = {};

    @observable selectedEntityDetailsIndex: number = 0;
    @observable selectedEntity: IEntityProfileInformation = {};
    @observable caseEntities?: IEntityProfileInformation[] = [];

    @observable selectedProfileIndex: number = 0;
    @observable selectedProfile : IProfileMatchActivity = {};
    @observable entityProfiles?: IProfileMatchActivity[] = [];


    //visaHistoryCaseDetailsSubModel: VisaHistoryCaseDetailsSubModel = VisaHistoryCaseDetailsSubStore;
    private visaHistoryCaseDetailsRequest: IVisaHistoryCaseDetailsRequest;


    @action
    refresh(): Promise<any> {
        const syncId = this.selectedCase.caseId;
        this.sync.syncStart({id: syncId});
         return VisaHistoryServiceContext.value.getVisaHistoryCaseDetails(this.visaHistoryCaseDetailsRequest)
             .then((caseDetailsResponse) => {
                 this.selectedCaseDetails = caseDetailsResponse;
                 this.caseEntities = [];
                 if (this.selectedCaseDetails.entityProfileInformation.length >0) {
                     this.caseEntities = this.selectedCaseDetails.entityProfileInformation;
                     this.selectedEntityDetailsIndex = 0;
                     this.selectedEntity = this.selectedCaseDetails.entityProfileInformation[0];
                     this.entityProfiles = this.selectedEntity.profileMatches;
                     this.selectedProfileIndex  = 0;
                     this.selectedProfile = this.entityProfiles[this.selectedProfileIndex];
                     selectedProfileDetails(this.selectedProfile, this.selectedCase.caseId);
                 }
                 this.sync.syncEnd();
             }).catch((error) => {
                 if (syncId === this.sync.id) {
                     this.selectedCaseDetails = {};
                     this.sync.syncError(error);
                 }
             });
    }

    updateSelectedEntityIndex(selectedEntityDetailsIndex: number) : void {
        console.log("-------------- before -------------");
        console.log("selected entity details index ", this.selectedEntityDetailsIndex);
        console.log("selected entity  ", this.selectedEntity);
        if(this.caseEntities.length>0) {
            this.selectedEntity = this.caseEntities[selectedEntityDetailsIndex];
            this.selectedEntityDetailsIndex = selectedEntityDetailsIndex;
            this.entityProfiles = this.selectedEntity.profileMatches;
            this.selectedProfileIndex = 0;
        }
        console.log("-------------- After -------------");
        console.log("selected entity details index ", this.selectedEntityDetailsIndex);
        console.log("selected entity  ", this.selectedEntity);
    }

    updateSelectedProfileIndex(selectedProfileIndex: number) : void {
        this.selectedProfileIndex = selectedProfileIndex;
        this.selectedProfile = this.entityProfiles[selectedProfileIndex];
        selectedProfileDetails(this.selectedProfile, this.selectedCase.caseId);
    }

    retrieveProfile(profile: IProfileMatchActivity) {
        selectedProfileDetails(profile, this.selectedCase.caseId);
    }

    @action
    loadSelectedCaseDetails(selectedCase: ICaseActivity, caseItems: ICaseActivity[]): Promise<any> {
        const syncId = selectedCase.caseId;
        if(syncId !== this.sync.id) {
            this.visaHistoryCaseDetailsRequest = {
                caseId: this.selectedCase.caseId
            };
            return this.refresh();
        }
        return Promise.resolve();
    }

    setSelectedCase(selectedCase: ICaseActivity, caseItems: ICaseActivity[]) : void {
        console.log("Selected case for which details need to be fetched ", selectedCase);
        this.caseItems = caseItems;
        this.selectedCase = selectedCase;
        this.loadSelectedCaseDetails(this.selectedCase, this.caseItems);
    }


}

export { VisaHistoryCaseDetailsModel }