import ISyncModel from "@twii/common/lib/ISyncModel";
import {IProfileMatchActivity} from "./IProfileMatchActivity";
import {ICaseActivity} from "./ICaseActivity";
import {IProfileMatchDetailsActivity} from "./IProfileMatchDetailsActivity";

interface IVisaHistoryCaseDetailsProfile {
    visible: boolean;
    sync: ISyncModel;
    items: IProfileMatchDetailsActivity;
    selectedProfile : IProfileMatchActivity;
    emailContent: string;
    retrieveProfileDetails(profile: IProfileMatchActivity, selectedCase: string) :  Promise<any>;
    setVisible(visible: boolean) : void;
    loadEMailContent(emailContent: string): void;
}

export { IVisaHistoryCaseDetailsProfile };