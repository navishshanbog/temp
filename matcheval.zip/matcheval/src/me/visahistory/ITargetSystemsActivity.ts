interface ITargetSystemsActivity {
    targetSystemsType? : string;
    targetSystemsId? : string;
}
export { ITargetSystemsActivity }