// this profile is for case summary

interface IProfile {
    profileName?: string;
    profileTier?: string;
    threats?: string[];
    treatmentType?: string;
    outcome?: string;
}


export { IProfile }