import {VisaHistoryCaseSummaryModel} from "./VisaHistoryCaseSummaryModel";

const VisaHistoryCaseSummaryStore = new VisaHistoryCaseSummaryModel();

export { VisaHistoryCaseSummaryStore };