import ISyncModel from "@twii/common/lib/ISyncModel";
import {ICaseActivity} from "./ICaseActivity";
import {IMECase} from "../IMECase";
//import { IVisaHistoryCaseDetailsModel } from "./IVisaHistoryCaseDetailsModel";
import ISortableListModel from "@twii/common/lib/ISortableListModel";
import {IClientRiskCheck} from "@twii/riskresume/lib/IClientRiskCheck";

interface IVisaHistoryCaseSummary extends ISortableListModel<ICaseActivity>{
    sync: ISyncModel;
    refresh(): Promise<any>;
    loadCaseSummary(meCase: IMECase) : Promise<any>;
    entityBioDetails: any;
    updateSelectedCaseIndex(selectedCaseIndex: number) : void;
    vraResponse: IClientRiskCheck;
    selectedCase: ICaseActivity;
    selectedCaseIndex: number;
}

export { IVisaHistoryCaseSummary };