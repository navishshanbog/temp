import axios, { AxiosRequestConfig } from 'axios';
import { IVisaHistoryService,
    IVisaHistoryCaseSummaryRequest,
    IVisaHistoryCaseDetailsRequest,
    IVisaHistoryGetProfileDetailsRequest
} from "./IVisaHistoryService";
import {ICaseActivity} from "./ICaseActivity";
import {ICaseDetailsActivity} from "./ICaseDetailsActivity";
import AbstractRestDataService from "../../common/AbstractRestDataService";
import * as DefaultHttpErrorHandler from "@twii/common/lib/HttpErrorHandler";
import {IProfileMatchDetailsActivity} from "./IProfileMatchDetailsActivity";

interface GetVisaHistoryCaseSummaryRestResponse {
    errors?: any;
    getMatchEvalVisaHistoryCaseSummary?: ICaseActivity[];
}
interface GetVisaHistoryCaseDetailsRestResponse {
    errors?: any;
    getMatchEvalVisaHistoryCaseDetails?: ICaseDetailsActivity;
}

interface GetVisaHistoryProfileDetailsResponse {
    errors?: any;
    getMatchEvalVisaHistoryCaseProfileDetails?: IProfileMatchDetailsActivity;

}

class RestVisaHistoryService extends AbstractRestDataService implements IVisaHistoryService {
    getVisaHistoryCaseSummary(request : IVisaHistoryCaseSummaryRequest) : Promise<ICaseActivity[]> {
        //const internalRequest = Object.assign({}, request);
        const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/VRAService/v1/resources/MatchEvalVisaHistoryCaseSummary`, req).then((value) => {
            const response = value.data as GetVisaHistoryCaseSummaryRestResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getMatchEvalVisaHistoryCaseSummary;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
    }

    getVisaHistoryCaseDetails(request : IVisaHistoryCaseDetailsRequest) : Promise<ICaseDetailsActivity> {
        const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/VRAService/v1/resources/MatchEvalVisaHistoryCaseDetails`, req).then((value) => {
            const response = value.data as GetVisaHistoryCaseDetailsRestResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getMatchEvalVisaHistoryCaseDetails;
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }

    getVisaHistoryProfileDetails(request : IVisaHistoryGetProfileDetailsRequest) : Promise<IProfileMatchDetailsActivity> {
        const req: AxiosRequestConfig = {
            params: request
        }
         return axios.get(`${this.config.baseUrl}/VRAService/v1/resources/MatchEvalVisaHistoryCaseProfileDetails`, req).then((value) => {
            const response = value.data as GetVisaHistoryProfileDetailsResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getMatchEvalVisaHistoryCaseProfileDetails;
        }).catch(DefaultHttpErrorHandler.handleAxiosError);

    }
}


export { RestVisaHistoryService };