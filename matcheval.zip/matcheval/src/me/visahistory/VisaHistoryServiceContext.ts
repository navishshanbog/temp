import Context from "@twii/common/lib/Context";
import {IVisaHistoryService}  from "./IVisaHistoryService";
import {RestVisaHistoryService} from "./RestVisaHistoryService";

const VisaHistoryServiceContext = new Context<IVisaHistoryService>({
    factory: () => {
        return new RestVisaHistoryService();
    }
});

export { VisaHistoryServiceContext };