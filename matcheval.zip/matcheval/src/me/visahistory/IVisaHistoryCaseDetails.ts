import ISyncModel from "@twii/common/lib/ISyncModel";
import {ICaseDetailsActivity} from "./ICaseDetailsActivity";
import {ICaseActivity} from "./ICaseActivity";
import {IEntityProfileInformation} from "./IEntityProfileInformation";
import {IProfileMatchActivity} from "./IProfileMatchActivity";


interface IVisaHistoryCaseDetails {
    sync: ISyncModel;
    selectedCase: ICaseActivity;
    caseItems: ICaseActivity[];
    selectedCaseDetails: ICaseDetailsActivity;
    selectedEntityDetailsIndex: number;
    selectedEntity: IEntityProfileInformation;
    caseEntities?: IEntityProfileInformation[];
    refresh(): Promise<any>;
    loadSelectedCaseDetails(selectedCase: ICaseActivity, caseItems?: ICaseActivity[]): Promise<any>;
    selectedProfile: IProfileMatchActivity;
    selectedProfileIndex: number;
    updateSelectedEntityIndex(selectedEntityDetailsIndex: number) : void;
    updateSelectedProfileIndex(selectedProfileIndex: number) : void;
    //setSelectedEntity(selectedEntity: IEntityProfileInformation, selectedCaseDetails: ICaseDetailsActivity): void;
    //selectedEntity?: IEntityProfileInformation;
    //selectedEntityIndex?: number;
    entityProfiles?: IProfileMatchActivity[];

    //visaHistoryCaseDetailsSubModel: VisaHistoryCaseDetailsSubModel;
    //resetSelectedCaseIndex(caseItems: ICaseActivity[]): void;
}
export { IVisaHistoryCaseDetails };