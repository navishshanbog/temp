import {ITypeNDescription} from "./ICaseActivity";

interface IBioInfoActivity {
    familyName? : string;
    givenName? : string;
    sexCd? : string;
    dateOfBirth? : string;
    countryOfBirth? : string[];
    countryOfCitizenship? : string[];
    sourceSystem?: string;
    id?: string;
}

export { IBioInfoActivity  };