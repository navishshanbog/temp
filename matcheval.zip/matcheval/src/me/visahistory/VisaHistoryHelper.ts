import {IBioInfoActivity} from "./IBioInfoActivity";
import {IProfile} from "./IProfile";


const getEntityColumnText = (bioInfo: IBioInfoActivity[]): string => {
    let cellValue: string = "";
    if(bioInfo && bioInfo.length > 0) {
        let tempBD = [];
        let tempSourceSys = [];
        bioInfo.map((t, idx) => {
            let entity = "";
            entity = t.familyName? t.familyName.toUpperCase() : "";
            entity = t.givenName? entity ? entity+" ,"+t.givenName: t.givenName: entity;
            entity = (t.dateOfBirth && t.sexCd)? entity ? entity+" ("+t.dateOfBirth+", "+t.sexCd+")":
                "("+t.dateOfBirth+", "+t.sexCd+")" : t.dateOfBirth? " ("+t.dateOfBirth+")" : " ("+t.sexCd+")";
            cellValue = cellValue + entity;
        });
    }
    return cellValue ? cellValue : "";
};

const getProfileColumnText = (profile: IProfile[]): string => {
    let threatProfiles;
    if(profile && profile.length > 0) {
        threatProfiles = profile.map((p: IProfile, idx) => {
            let threat = "";
            threat = p.profileName? p.profileTier? `${p.profileName} ( ${p.profileTier})`: `${p.profileName}`: threat;
            if (p.threats && p.threats.length>0) {
                let t = "";
                p.threats.map((th, idx) => {
                    t = t? th? `${t} , ${th}`: t: th? th: th;
                });
                threat = threat ? t? `${threat} | ${t}`: threat: t? t: t;
            }
            threat = threat ? p.treatmentType? `${threat} | ${p.treatmentType}`: p.treatmentType: p.treatmentType? p.treatmentType: p.treatmentType;
            return threat
        });

    }
    return threatProfiles ? String(threatProfiles) : "";
};



export {getEntityColumnText, getProfileColumnText}