interface IVisas {
    visaStreamCode?: string;
    visaSubClass?: string;
    visaStatus?: string;
}

export { IVisas }