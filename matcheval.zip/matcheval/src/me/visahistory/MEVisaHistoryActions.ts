import { action, IAction } from "mobx";
import {ICaseActivity} from "./ICaseActivity";
import {ICaseDetailsActivity} from "./ICaseDetailsActivity";
import {VisaHistoryCaseDetailsStore} from "./VisaHistoryCaseDetailsStore";
import {IProfileMatchActivity} from "./IProfileMatchActivity";
import {VisaHistoryCaseDetailsProfileStore} from "./VisaHistoryCaseDetailsProfileStore";
import {IEntityProfileInformation} from "./IEntityProfileInformation";
//import {VisaHistoryEntityProfileStore} from "./VisaHistoryEntityProfileStore";


const selectedProfileDetails = action((profile?: IProfileMatchActivity, caseId?: string) => {
    VisaHistoryCaseDetailsProfileStore.retrieveProfileDetails(profile, caseId);
});

const selectedCaseDetails = action((selectedCase?: ICaseActivity, caseItems?: ICaseActivity[]) => {
    VisaHistoryCaseDetailsStore.setSelectedCase(selectedCase, caseItems);
});


// const selectedEntityDetails = action((selectedEntity?: IEntityProfileInformation, selectedCaseDetails?: ICaseDetailsActivity) => {
//     VisaHistoryCaseDetailsStore.setSelectedEntity(selectedEntity, selectedCaseDetails);
// });
export { selectedProfileDetails, selectedCaseDetails }