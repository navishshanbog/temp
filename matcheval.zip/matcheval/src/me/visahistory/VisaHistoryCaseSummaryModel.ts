import { observable, action, computed } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import {IVisaHistoryCaseSummary} from "./IVisaHistoryCaseSummary";
import {IMECase, VRAIdnetifiersForME} from "../IMECase";
import * as StringUtils from "@twii/common/lib/util/String";
import {ClientRiskCheckServiceContext} from "@twii/riskresume/lib/ClientRiskCheckServiceContext";
import {IClientRiskOverviewServiceReq} from "@twii/riskresume/lib/RestClientRiskCheckService";
import {IClientRiskCheck} from "@twii/riskresume/lib/IClientRiskCheck";
import {IVisaHistoryCaseSummaryRequest} from "./IVisaHistoryService";
import {selectedCaseDetails} from "./MEVisaHistoryActions";
import {ICaseActivity} from "./ICaseActivity";
import {MEGenderCd} from "../ref/MEGenderCd";
import * as RiskUtils from "@twii/riskresume/lib/RiskUtils";
import {VisaHistoryServiceContext} from "./VisaHistoryServiceContext";
import ListModel from "@twii/common/lib/ListModel";
import SortModel from "@twii/common/lib/SortModel";
import * as SortUtils from "@twii/common/lib/util/Sort";
import {getEntityColumnText, getProfileColumnText} from "./VisaHistoryHelper";
import {CaseCreated, CaseClosed, BioInfo, Visas, Profile} from "../../me/component/visahistory/VisaHistoryCaseSummaryColumns";



class VisaHistoryCaseSummaryModel extends ListModel<ICaseActivity> implements IVisaHistoryCaseSummary {
    //@observable sync: ISyncModel = new SyncModel();
    @observable sort = new SortModel();
    @observable selectedCase: ICaseActivity;
    private meCase: IMECase;
    private visaHistoryCaseSummaryRequest: IVisaHistoryCaseSummaryRequest;
    @observable  vraResponse: IClientRiskCheck;
    private tripsValue: string = "";
    private icseValue: string = "";
    private caseIdValue: string = "";

    @action
    refresh() : Promise<any> {
        const syncId = this.caseIdValue || this.tripsValue || this.icseValue;
        this.sync.syncStart({id: syncId});

        return VisaHistoryServiceContext.value.getVisaHistoryCaseSummary(this.visaHistoryCaseSummaryRequest)
            .then((caseResponse) => {
                //this.setItems(caseResponse);
                this.sort.setSort("caseId", true);
                this.setItems(SortUtils.sort(caseResponse, this.sort, this._toSortValue));
                //this.caseItems = caseResponse;
                // pick the first case always to show the full case details
                this.selectedCase = (this.items && this.items.length > 0) ? this.items[0] : {};
                // this.selectedCaseIndex = 0;
                this.loadEntityDetails();
                this.sync.syncEnd();
                selectedCaseDetails(this.selectedCase, this.items);
            }).catch((error) => {
            });
    }

    loadEntityDetails() : Promise<any> {
        if(StringUtils.isNotBlank(this.icseValue) || StringUtils.isNotBlank(this.tripsValue)) {
            let vraRequest: IClientRiskOverviewServiceReq = {
                icseId: this.icseValue,
                tripsId: this.tripsValue,
                caller: "MatchEval"
            };
            return ClientRiskCheckServiceContext.value.getClientRiskChecks(vraRequest).then((vraResponse) => {
                this.vraResponse = vraResponse;
            }).catch((error) => {
            });
        }
    }

    @action
    loadCaseSummary(meCase: IMECase) : Promise<any> {
        const syncId = "";
        this.meCase = meCase;
        if(this.meCase.Identifiers && this.meCase.Identifiers.length >0) {
            this.meCase.Identifiers.forEach((identifier) => {
                this.tripsValue = StringUtils.equalsIgnoreCase(identifier.Type, VRAIdnetifiersForME.TRIPS_PID)? identifier.Value : this.tripsValue;
                this.icseValue = StringUtils.equalsIgnoreCase(identifier.Type, VRAIdnetifiersForME.ICSE_CID)? identifier.Value : this.icseValue;
                this.caseIdValue = StringUtils.equalsIgnoreCase(identifier.Type, VRAIdnetifiersForME.CASE_ID)? identifier.Value : this.caseIdValue;
            });
        }
        if(StringUtils.isNotBlank(this.icseValue) || StringUtils.isNotBlank(this.tripsValue)) {
            this.caseIdValue = "";
        }
        this.visaHistoryCaseSummaryRequest = {icseId: this.icseValue, tripsId: this.tripsValue, caseId: this.caseIdValue };
        return this.refresh();
    }

    @computed
    get selectedCaseIndex() {
        return this.itemsView.indexOf(this.selectedCase);
    }


    @computed
    get itemsView() {
        return this.items;
        
        //return SortUtils.sort(this.items, this.sort, this._toSortValue);
    }

    private _toSortValue = (item : ICaseActivity, field: string) => {
        if(item) {
            if(field === CaseCreated.fieldName) {
                return item.caseCreated;
            }
            if(field === CaseClosed.fieldName) {
                return item.caseClosed;
            }
            if(field === BioInfo.fieldName) {
                return getEntityColumnText(item.bioInfo);
            }
            if(field === Visas.fieldName) {
                return item.visas;
            }
            if(field === Profile.fieldName) {
                return getProfileColumnText(item.profile);
            }
            return item[field];
        }
    };



    @action
    updateSelectedCaseIndex(selectedCaseIndex: number) : void {
        if(selectedCaseIndex!=this.selectedCaseIndex) {
            this.selectedCase = this.itemsView[selectedCaseIndex];
            //this.setSelectionIndex(selectedCaseIndex);
            //this.selectedCaseIndex = selectedCaseIndex;
            selectedCaseDetails(this.selectedCase, this.items);
        }
    }

    @computed
    get entityBioDetails(): any {
        if(this.vraResponse && this.vraResponse.clientPrimaryBios && this.vraResponse.clientPrimaryBios.length > 0){
            return this.vraResponse.clientPrimaryBios ?
                this.vraResponse.clientPrimaryBios.map((d, i) => {
                    let firstName = d.firstName || "";
                    let lastName = d.lastName || "";
                    let dob = RiskUtils.dataServicesDtToRiskResumeDt(d.dob);
                    let gender = MEGenderCd.getDesc(d.genderCode);
                    let source = d.sourceSystemCode || "";
                    let titleStr = lastName+", "+ firstName+" ("+dob+", "+gender+") ("+source+") ";
                    return i>0? `\xa0\xa0  | \xa0\xa0 ${titleStr}` : titleStr;
                }): null;
        }
        return null;
    }
}


export { VisaHistoryCaseSummaryModel }