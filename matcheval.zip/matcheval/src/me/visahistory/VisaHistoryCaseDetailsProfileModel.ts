import { observable, action } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import {IVisaHistoryCaseDetailsProfile} from "./IVisaHistoryCaseDetailsProfile";
import {IProfileMatchActivity} from "./IProfileMatchActivity";
import {IVisaHistoryGetProfileDetailsRequest} from "./IVisaHistoryService";
import {VisaHistoryServiceContext} from "./VisaHistoryServiceContext";
import * as StringUtils from "@twii/common/lib/util/String";
import {IProfileMatchDetailsActivity} from "./IProfileMatchDetailsActivity";

class VisaHistoryCaseDetailsProfileModel implements IVisaHistoryCaseDetailsProfile {
    @observable visible: boolean = false;
    @observable sync: ISyncModel = new SyncModel();
    @observable items: IProfileMatchDetailsActivity = {};
    private visaHistoryGetProfileDetailsRequest: IVisaHistoryGetProfileDetailsRequest;
    @observable selectedProfile: IProfileMatchActivity = {};
    private caseId: string;
    @observable emailContent: string = "";

    @action
    refresh(): Promise<any> {
        const syncId = this.caseId;
        this.sync.syncStart({id: syncId});
        this.items = {};
         return VisaHistoryServiceContext.value.getVisaHistoryProfileDetails(this.visaHistoryGetProfileDetailsRequest)
             .then((profileResponse) => {
                 this.items = profileResponse;
                 this.sync.syncEnd();
             }).catch((error) => {
                 if (syncId === this.sync.id) {
                     this.items = {};
                     this.sync.syncError(error);
                 }
             });
    }

    @action
    retrieveProfileDetails(profile: IProfileMatchActivity, caseId: string): Promise<any> {
        this.items={};
        if(profile) {

            this.caseId = caseId ? caseId : "";
            const syncId = this.caseId;
            if (StringUtils.isNotBlank(this.caseId)) {
                this.selectedProfile = profile;
                this.visaHistoryGetProfileDetailsRequest = {
                    profileId: `${this.selectedProfile.name}`,
                    caseId: this.caseId
                };
                return this.refresh();
            }
        }
        return Promise.resolve();
    }

    @action
    setVisible(visible: boolean) {
        this.visible = visible;
    }

    loadEMailContent(emailContent: string) {
        this.emailContent = emailContent;
    }

}

export { VisaHistoryCaseDetailsProfileModel }