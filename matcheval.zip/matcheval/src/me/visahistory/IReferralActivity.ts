
interface IReferralActivity {
    notificationRecipient?: string;
    notificationAgency?: string;
    sentReferralUserId?: string;
    referralDateTime?: string;
    emailAddress?: string;
    emailSubject?: string;
    emailContent?: string;
    attachments?: IAttachments[];
    toAddress?: string[];
    ccAddress?: string[];
    bccAddress?: string[];
}

interface IAttachments {
    fileName?: string;
}

export { IReferralActivity, IAttachments }