
interface ICaseNotes {
    notes?: string;
    userId?: string;
    noteDtTime?: string;
    userName?: string;
}

export { ICaseNotes }