interface IAlertActivity {
    reference: string;
    typeCategory?: string;
    createdUserId?: string;
    createdDateTime?: string;
    emailAddress?: string;
    emailSubject?: string;
    emailContent?: string;
}

export { IAlertActivity }