
// Profile for case details - entity

interface IProfileMatchActivity {
    name?: string;
    tier?: string;
    threat?: string[];
    reasonForMatch?: string;
    matchDate?: string;
}
export { IProfileMatchActivity }