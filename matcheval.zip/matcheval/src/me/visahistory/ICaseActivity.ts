import {IBioInfoActivity} from "./IBioInfoActivity";
import {IVisas} from "./IVisas";
import {IProfile} from "./IProfile";


interface ICaseActivity {
    // this is mandatory even though we have made it optional
    caseId?: string;
    domain?: string;
    bioInfo?: IBioInfoActivity[],
    profile?: IProfile[],
    caseStatus?: string;
    caseUrgency?: string;
    caseCreated?: string;
    caseClosed?: string;
    visas?:IVisas[];
}

interface ITypeNDescription {
    type: string;
    description: string;
}


export { ICaseActivity, ITypeNDescription };







