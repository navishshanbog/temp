import {VisaHistoryCaseDetailsModel} from "./VisaHistoryCaseDetailsModel";

const VisaHistoryCaseDetailsStore = new VisaHistoryCaseDetailsModel();

export { VisaHistoryCaseDetailsStore };