import { ICaseActivity } from "./ICaseActivity";
import { ICaseDetailsActivity} from "./ICaseDetailsActivity";
import {IProfileMatchDetailsActivity} from "./IProfileMatchDetailsActivity";

interface IVisaHistoryCaseSummaryRequest {
    tripsId?: string;
    icseId?: string;
    caseId?: string;
}
interface IVisaHistoryCaseDetailsRequest {
   caseId: string;
}

interface IVisaHistoryGetProfileDetailsRequest {
    profileId : string;
    caseId: string;
}

interface IVisaHistoryService {
    getVisaHistoryCaseSummary(request : IVisaHistoryCaseSummaryRequest) : Promise<ICaseActivity[]>;
    getVisaHistoryCaseDetails(request : IVisaHistoryCaseDetailsRequest) : Promise<ICaseDetailsActivity>;
    getVisaHistoryProfileDetails(request : IVisaHistoryGetProfileDetailsRequest) : Promise<IProfileMatchDetailsActivity>;
}

export { IVisaHistoryService,
    IVisaHistoryCaseSummaryRequest,
    IVisaHistoryCaseDetailsRequest,
    IVisaHistoryGetProfileDetailsRequest };