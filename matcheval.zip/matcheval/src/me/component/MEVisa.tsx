import * as React from 'react';
import { observer } from "mobx-react";
import {IMECase} from "../IMECase";
import { Pivot, PivotItem, IPivotItemProps } from 'office-ui-fabric-react/lib/Pivot';
import "./MEAirTraveller.scss";
import MEHeader from "./MEHeader";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { IVisaHistoryCaseSummary } from "../visahistory/IVisaHistoryCaseSummary";
import {VisaHistory} from "./visahistory/VisaHistory";


interface IMEVisaProps {
    meVisa: IVisaHistoryCaseSummary;
    meCase: IMECase;
}


@observer
class MEVisa extends React.Component<IMEVisaProps, any> {
    private _onRefresh = () => {
        this.props.meVisa.refresh();
    }
    render() {
        let headerDetails = this.props.meCase;
        let meSummaryContentHeader = <MEHeader headerDetails = {headerDetails}
                                               onRefresh={this._onRefresh}
                                               icon={<Icon iconName='World'/>} />

        let pivotArray: React.ReactElement<IPivotItemProps>[] = [];
        pivotArray.push( <PivotItem linkText='Match Evaluation History' itemKey="0" key="0">
             <div className="me-booking-summary">
                 <VisaHistory model={this.props.meVisa} />
             </div>
         </PivotItem>);


        let meSummaryContent = <div>
            {meSummaryContentHeader}
            <Pivot selectedKey="0" >
                {pivotArray}
            </Pivot>
        </div>

        return (
            <div className="me-summary">
                {meSummaryContent}
            </div>
        );
    }
}
export { MEVisa, IMEVisaProps }
