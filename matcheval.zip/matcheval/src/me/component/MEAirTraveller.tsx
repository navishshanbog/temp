import * as React from "react";
import { Pivot, PivotItem, IPivotItemProps } from 'office-ui-fabric-react/lib/Pivot';
import {PurchaseInfo} from "./traveller/air/PurchaseInfo";
import BagExamsResultSummary from "./traveller/common/BagExamsResultSummary";
import ProfileMatchesDetails from "./traveller/common/ProfileMatchesDetailsList";
import TravellerSummary from "./traveller/air/TravellerSummary";
import ActiveItinerary from "./traveller/air/ActiveItinerary";
import TravellerContact from "./traveller/air/TravellerContact";
import CheckIn from "./traveller/air/CheckIn";
import BaggageDetails from "./traveller/air/BaggageDetails";
import Payments from "./traveller/air/Payments";
import PushHistory from "./traveller/air/PushHistory";
import TravelAgents from "./traveller/air/TravelAgents";
import HistoricalPNR from "./traveller/air/HistoricalPNR";
import MovementHistory from "./traveller/common/MovementHistory";
import BioDataHistory from "./traveller/common/BioDataHistory";
import PassportHistory from "./traveller/common/PassportHistory";
import AirVisaHistory from "./traveller/common/AirVisaHistory";
import AlertHistorySummary from "./traveller/common/AlertHistorySummary";
import GroupInfo from "./traveller/air/GroupInfo";
import { observer } from "mobx-react";
import IMEAirTravellerModel from "../traveller/IMEAirTravellerModel";
import AlertInfoSummary from "./traveller/common/AlertInfoSummary";
import SpecialServiceRequest from "./traveller/air/SpecialServiceRequest";
import OtherServiceInformation from "./traveller/air/OtherServiceInformation";
import OtherComment from "./traveller/air/OtherComment";
import PNRHistorySummary from "./traveller/air/PNRHistorySummary";
import ItineraryInfo from "./traveller/air/ItineraryInfo";
import TicketingInfo from "./traveller/air/TicketingInfo";
import {AirProfileMatchColumns} from "./traveller/common/ProfileMatchColumns";
import {AirBioDataHistoryColumns} from "./traveller/common/BioDataHistoryColumns";
import {AirPassportHistoryColumns} from "./traveller/common/PassportHistoryColumns";
import {AirMovementHistoryColumns} from "./traveller/common/MovementsHistoryColumns";
import {AirAlertInfoColumns} from "./traveller/common/AlertInfoColumns";
import {AirBagExamsResultColumns} from "./traveller/common/BagExamsResultColumns";
import {AirAlertHistoryColumns} from "./traveller/common/AlertHistoryColumns";
import "./MEAirTraveller.scss";
import MEHeader from "./MEHeader";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { MEBusinessDomainType } from "../IMECase";
import * as StringUtils from "@twii/common/lib/util/String";


interface IMEAirCaseDetailContainerProps {
    model: IMEAirTravellerModel;
    businessDomainType: string;
}

@observer
class MEAirCaseDetailContainer extends React.Component<IMEAirCaseDetailContainerProps, any> {
    private _onRefresh = () => {
        this.props.model.refresh();
    }
    render() {
        let headerDetails = this.props.model.meCase
        let pnrSource = StringUtils.equalsIgnoreCase(MEBusinessDomainType.Traveller, this.props.model.meCase.BusinessDomain) ? this.props.model.summaryModel?
            this.props.model.summaryModel.bookingSummary?
                this.props.model.summaryModel.bookingSummary.BookingRecordInfo ? this.props.model.summaryModel.bookingSummary.BookingRecordInfo: {}
                : {}
            : {} : {};
        let headerIcon = StringUtils.equalsIgnoreCase(MEBusinessDomainType.Traveller, this.props.model.meCase.BusinessDomain) ? 'AirplaneSolid' : 'World';

        let meSummaryContentHeader = <MEHeader headerDetails = {headerDetails}
        pnrSource = {pnrSource}
        onRefresh={this._onRefresh}
        icon={<Icon iconName={headerIcon}/>} />

        let pivotArray: React.ReactElement<IPivotItemProps>[] = [];

        if(this.props.businessDomainType === MEBusinessDomainType.Traveller) {
            pivotArray.push(<PivotItem linkText='Traveller & Booking Summary' itemKey="0" key="0">
                <div className="me-booking-summary">
                    <div className="me-booking-summary-mini-container ms-Grid ms-sm12 ms-md12 ms-lg12">
                        <div className="me-booking-summary-mini-container-for-purchase ms-Grid-col ms-md4 ms-lg4">
                            <PurchaseInfo model={this.props.model.summaryModel}/>
                        </div>
                        <div className="me-booking-summary-mini-container-for-itinerary ms-Grid-col ms-md4 ms-lg4">
                            <ItineraryInfo model={this.props.model.summaryModel}
                                           vesselModel={this.props.model.vesselScheduleModel}/>
                        </div>
                        <div className="me-booking-summary-mini-container-for-group ms-Grid-col ms-md4 ms-lg4">
                            <GroupInfo model={this.props.model.summaryModel}/>
                        </div>
                        <br className="me-booking-summary-clear-style"/>
                    </div>
                    <ProfileMatchesDetails model={this.props.model.profileMatchModel}
                                           profileColumns={AirProfileMatchColumns} showCurrentProfiles={true}/>
                    <TravellerSummary model={this.props.model.summaryModel}/>
                    {/*<FlightSchedule model={this.props.model.vesselScheduleModel} />*/}
                    <ActiveItinerary model={this.props.model.summaryModel}/>
                    <CheckIn model={this.props.model.summaryModel}/>
                    {/*<BoardingDetails model={this.props.model.summaryModel} />*/}
                    <BaggageDetails model={this.props.model.summaryModel}/>
                    <TicketingInfo model={this.props.model.summaryModel}/>
                    <TravelAgents model={this.props.model.summaryModel}/>
                    <Payments model={this.props.model.summaryModel}/>
                    <PushHistory model={this.props.model.summaryModel}/>
                    <TravellerContact model={this.props.model.summaryModel}/>
                    <BioDataHistory model={this.props.model.travellerHistoryModel}
                                    bioDataColumns={AirBioDataHistoryColumns}/>
                    <PassportHistory model={this.props.model.travellerHistoryModel}
                                     passportDataColumns={AirPassportHistoryColumns}/>
                    <AirVisaHistory model={this.props.model.travellerHistoryModel}/>
                    <MovementHistory model={this.props.model.travellerHistoryModel}
                                     movementDataColumns={AirMovementHistoryColumns}/>
                    <HistoricalPNR model={this.props.model.historicalPNRnIATModel}/>

                </div>
            </PivotItem>);

            pivotArray.push(<PivotItem linkText='Reservation History' itemKey="1" key="1">
                <div className="me-booking-summary">
                    <SpecialServiceRequest model={this.props.model.summaryModel}/>
                    <OtherServiceInformation model={this.props.model.summaryModel}/>
                    <OtherComment model={this.props.model.summaryModel}/>
                    <PNRHistorySummary model={this.props.model.summaryModel}/>
                </div>
            </PivotItem>);

            pivotArray.push(<PivotItem linkText='Alert, Profile, Exam History' itemKey="2" key="2">
                <div className="me-booking-summary">
                    <AlertInfoSummary model={this.props.model.travellerHistoryModel}
                                      alertDataColumns={AirAlertInfoColumns}/>
                    <AlertHistorySummary model={this.props.model.travellerHistoryModel}
                                         alertHistoryDataColumns={AirAlertHistoryColumns}/>
                    <ProfileMatchesDetails model={this.props.model.profileMatchModel}
                                           profileColumns={AirProfileMatchColumns} showHistoricalProfiles={true}
                                           showCurrentProfiles={true}/>
                    <BagExamsResultSummary model={this.props.model.travellerHistoryModel}
                                           bagsExamDataColumns={AirBagExamsResultColumns}/>
                </div>
            </PivotItem>);

        }
        let meSummaryContent = <div>
            {meSummaryContentHeader}
                <Pivot selectedKey="0" >
                    {pivotArray}
                </Pivot>
        </div>

        return (
            <div className="me-summary">
                {meSummaryContent}
            </div>
        );
    }
}
export { MEAirCaseDetailContainer as default, MEAirCaseDetailContainer, IMEAirCaseDetailContainerProps }
