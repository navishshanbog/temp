import * as React from "react";
import {MEVisa} from "./MEVisa";
import IAppHost from "@twii/common/lib/IAppHost";
import {IMECase, MEBusinessDomainType} from "../IMECase";
import {IVisaHistoryCaseSummary} from "../visahistory/IVisaHistoryCaseSummary";
import {VisaHistoryCaseSummaryModel} from "../visahistory/VisaHistoryCaseSummaryModel";
import "@twii/common/lib/component/AppWrapper.scss";

interface IMEVisaAppletProps {
    meCase: IMECase;
    host: IAppHost;
}

class MEVisaApplet extends React.Component<IMEVisaAppletProps, any> {
    get meVisa() : IVisaHistoryCaseSummary {
        const host = this.props.host;
        let meVisa : IVisaHistoryCaseSummary = host.state.meVisa;
        if(!meVisa) {
            meVisa = new VisaHistoryCaseSummaryModel();
            host.setState({ meVisa: meVisa });
        }
        return meVisa;
    }
    componentWillMount() {
        const meCase : IMECase = this.props.meCase;
        if(meCase) {
            let title = "Visa Info";
            this.props.host.setTitle(`${meCase.CaseID}  ${title} `);
            this.meVisa.loadCaseSummary(meCase);
        } else {
            // TODO: clear the model
        }
    }
    render() {
        return (
            <MEVisa meVisa={this.meVisa} meCase={this.props.meCase}/>
        );
    }
}

export { MEVisaApplet, IMEVisaAppletProps }