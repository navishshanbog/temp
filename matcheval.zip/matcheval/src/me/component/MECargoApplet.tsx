import * as React from "react";
import {MEVisa} from "./MEVisa";
import IAppHost from "@twii/common/lib/IAppHost";
import {IMECase, MEBusinessDomainType} from "../IMECase";
import {IMECargoModel} from "../cargo/IMECargoModel";
import {MECargo} from "./MECargo";
import {MECargoModel} from "../cargo/MECargoModel";
import "@twii/common/lib/component/AppWrapper.scss";


interface IMECargoAppletProps {
    meCase: IMECase;
    host: IAppHost;
}

class MECargoApplet extends React.Component<IMECargoAppletProps, any> {
    get meCargo() : IMECargoModel {
        const host = this.props.host;
        let meCargo : IMECargoModel = host.state.meCargo;
        if(!meCargo) {
            meCargo = new MECargoModel();
            host.setState({ meCargo: meCargo });
        }
        return meCargo;
    }
    componentWillMount() {
        const meCase : IMECase = this.props.meCase;
        if(meCase) {
            let title = "Cargo Info";
            this.props.host.setTitle(`${meCase.CaseID}  ${title} `);
            this.meCargo.load(meCase);
        } else {
            // TODO: clear the model
        }
    }
    render() {
        return (
            <MECargo meCargo={this.meCargo} meCase={this.props.meCase}/>
        );
    }
}

export { MECargoApplet, IMECargoAppletProps }