import * as React from "react";
import {MEVisaHistory} from "./MEVisaHistory";
import IAppHost from "@twii/common/lib/IAppHost";
import {IMECase, MEBusinessDomainType, MEVisaHistoryIdentiferHeaders} from "../IMECase";
import {IVisaHistoryCaseSummary} from "../visahistory/IVisaHistoryCaseSummary";
import {VisaHistoryCaseSummaryModel} from "../visahistory/VisaHistoryCaseSummaryModel";
import "@twii/common/lib/component/AppWrapper.scss";
import * as StringUtils from "@twii/common/lib/util/String";
import {SystemIdTypeRefList} from "../search/SystemIdTypeRefList";

interface IMEVisaHistoryAppletProps {
    meCase: IMECase;
    host: IAppHost;
}

class MEVisaHistoryApplet extends React.Component<IMEVisaHistoryAppletProps, any> {
    get meVisaHistory() : IVisaHistoryCaseSummary {
        const host = this.props.host;
        let meVisaHistory : IVisaHistoryCaseSummary = host.state.meVisaHistory;
        if(!meVisaHistory) {
            meVisaHistory = new VisaHistoryCaseSummaryModel();
            host.setState({ meVisaHistory: meVisaHistory });
        }
        return meVisaHistory;
    }

    private _getTitleInfo(): string {
        let value: string;
        if(StringUtils.isNotBlank(this.props.meCase.CaseID)) value = `Case Id: ${this.props.meCase.CaseID}`;
        else if(this.props.meCase.Identifiers && this.props.meCase.Identifiers.length>0) {
            this.props.meCase.Identifiers.forEach((ident, idx) => {
                value = ident.Type ? value ? `${value} | ${SystemIdTypeRefList.getItemByKey(ident.Type).text}: ${ident.Value}` :
                    `${SystemIdTypeRefList.getItemByKey(ident.Type).text}: ${ident.Value}` : value;
            });
        }

        return value;
    }


    componentWillMount() {
        const meCase : IMECase = this.props.meCase;
        if(meCase) {
            let title = "Visa History Info";
            this.props.host.setTitle( `${this._getTitleInfo()}  ${title} `);
            this.meVisaHistory.loadCaseSummary(meCase);
        } else {
            // TODO: clear the model
        }
    }
    render() {
        return (
            <MEVisaHistory meVisaHistory={this.meVisaHistory} meCase={this.props.meCase}/>
        );
    }
}

export { MEVisaHistoryApplet, IMEVisaHistoryAppletProps }