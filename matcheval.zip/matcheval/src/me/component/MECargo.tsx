import * as React from 'react';
import { observer } from "mobx-react";
import {IMECase, MEDomainType} from "../IMECase";
import {MEAirCargo} from "./cargo/aircargo/MEAirCargo";
import { MESeaCargo } from "./cargo/seacargo/MESeaCargo";
import * as StringUtils from "@twii/common/lib/util/String";
import {IMECargoModel} from "../cargo/IMECargoModel";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";

interface IMECargoProps {
    meCargo: IMECargoModel;
    meCase: IMECase;
}

@observer
class MECargo extends React.Component<IMECargoProps, any> {
    render() {
        let content;
        if(StringUtils.equalsIgnoreCase(this.props.meCase.DomainType, MEDomainType.Air)) {
            content = <MEAirCargo cargoModel={this.props.meCargo.air} meCase={this.props.meCase} />;
        } else if (StringUtils.equalsIgnoreCase(this.props.meCase.DomainType, MEDomainType.Sea)) {
            content = <MESeaCargo cargoModel={this.props.meCargo.sea} meCase={this.props.meCase} />;
        } else {
            content = <MessageBar messageBarType={MessageBarType.warning}>No Cargo Information Available</MessageBar>;
             
        }
        return content;
    }
}

export { MECargo, IMECargoProps }
