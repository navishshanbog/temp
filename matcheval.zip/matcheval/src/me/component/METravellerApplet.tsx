import * as React from "react";
import METraveller from "./METraveller";
import IAppHost from "@twii/common/lib/IAppHost";
import {IMECase, MEBusinessDomainType} from "../IMECase";
import IMETravellerModel from "../traveller/IMETravellerModel";
import METravellerModel from "../traveller/METravellerModel";
import "@twii/common/lib/component/AppWrapper.scss";
import * as StringUtils from "@twii/common/lib/util/String";

interface IMETravellerAppletProps {
    meCase: IMECase;
    host: IAppHost;
}

class METravellerApplet extends React.Component<IMETravellerAppletProps, any> {
    get meTraveller() : IMETravellerModel {
        const host = this.props.host;
        let meTraveller : IMETravellerModel = host.state.meTraveller;
        if(!meTraveller) {
            meTraveller = new METravellerModel();
            host.setState({ meTraveller: meTraveller });
        }
        return meTraveller;
    } 
    componentWillMount() {
        const meCase : IMECase = this.props.meCase;
        if(meCase) {
            let title = "Traveller Info";
            this.props.host.setTitle(`${meCase.CaseID}  ${title} `);
            this.meTraveller.load(meCase);
        } else {
            // TODO: clear the model
        }
    }
    render() {
        return (
            <METraveller meTraveller={this.meTraveller} meCase={this.props.meCase}/>
        );
    }
}

export { METravellerApplet as default, METravellerApplet, IMETravellerAppletProps }