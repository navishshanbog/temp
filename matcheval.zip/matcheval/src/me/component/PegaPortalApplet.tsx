import * as React from "react";
import { PegaPortal, IPegaPortalProps } from "./PegaPortal";
import AppHostWrapper from "@twii/common/lib/component/AppHostWrapper";
import AppContext from "@twii/common/lib/AppContext";
import {IMECase, VRAIdnetifiersForME, MEBusinessDomainType, IIdentifiers} from "../IMECase";
import * as StringUtils from "@twii/common/lib/util/String";
import { openValueSearch } from "@twii/entity/lib/search/EntitySearchActions";
import { ISearchField } from "@twii/common/lib/search/ISearchField";

const Action_Search_Systems = "OPEN_SEARCH_SYSTEMS";
// Change from VRA to IRP
const Action_Open_IRP = "OPEN_IRP";
const Action_Open = "OPEN";

class PegaPortalApplet extends React.Component<IPegaPortalProps, any> {

    getPreferredIdentifier(identifiers: IIdentifiers[]) {
        let tripsPID = "";
        let icseCID = "";
        if(identifiers) {
            identifiers.map((ident:IIdentifiers) => {
               if(StringUtils.equalsIgnoreCase(ident.Type, VRAIdnetifiersForME.TRIPS_PID)) {
                   tripsPID = ident.Value;
                   // TRIPS is 10 digit number.. padding 0 to make it 10
                   while(tripsPID.length < 10) tripsPID = "0"+tripsPID;
               }
               else if(StringUtils.equalsIgnoreCase(ident.Type, VRAIdnetifiersForME.ICSE_CID))
                   icseCID = ident.Value;
            });
        }

        return StringUtils.isNotBlank(tripsPID) ? tripsPID : StringUtils.isNotBlank(icseCID) ? icseCID : tripsPID;
    }

    private _onMessage = (meCase : IMECase) => {
        console.log("-- message ", meCase);
        if(StringUtils.equalsIgnoreCase(meCase.Action, Action_Open)) {
            const windowFeatures = `menubar=no,location=no,resizable=yes,scrollbars=yes,status=yes,channelmode=yes`;
            if(StringUtils.equalsIgnoreCase(meCase.BusinessDomain, MEBusinessDomainType.Traveller)) {
                let customWindow = window.open(AppContext.value.rootAppHost.getUrl({
                        path: "/me/traveller",
                        query: meCase
                    }),
                    meCase.CaseID, windowFeatures);
            }
            if(StringUtils.equalsIgnoreCase(meCase.BusinessDomain, MEBusinessDomainType.Visa)) {
                let customWindow1 = window.open(AppContext.value.rootAppHost.getUrl({
                        path: "/me/visa",
                        query: meCase
                    }),
                    meCase.CaseID, windowFeatures);
            }
            if(StringUtils.equalsIgnoreCase(meCase.BusinessDomain, MEBusinessDomainType.Cargo)) {
                let customWindow = window.open(AppContext.value.rootAppHost.getUrl({
                        path: "/me/cargo",
                        query: meCase
                    }),
                    meCase.CaseID, windowFeatures);
            }
        } else if(StringUtils.equalsIgnoreCase(meCase.Action, Action_Search_Systems)) {
            if(meCase.Identifiers && meCase.Identifiers.length > 0) {
                let identifiers = meCase.Identifiers;
                let value = this.getPreferredIdentifier(identifiers);
                // 31st May 2018: as advised by CIE, the credential Type for ICSE/TRIPS is always TRIPS_PID".
                let iSField: ISearchField = {name: "STNDRDSD_CRDNTL.TRIPS_PID", searchString: value}
                openValueSearch(this.props.host, iSField, "matchEval");
            }
        } else if(StringUtils.equalsIgnoreCase(meCase.Action, Action_Open_IRP)) {
            if(meCase.Identifiers && meCase.Identifiers.length > 0) {
                let identifiers = meCase.Identifiers;
                let icseId = "";
                let tripsId = "";
                identifiers.forEach((type) => {
                    icseId = StringUtils.equalsIgnoreCase(type.Type, VRAIdnetifiersForME.ICSE_CID) ?  type.Value : icseId;
                    tripsId = StringUtils.equalsIgnoreCase(type.Type, VRAIdnetifiersForME.TRIPS_PID) ?  type.Value : tripsId;
                });
                // Change from VRA to IRP
                if(StringUtils.isBlank(icseId)) {
                    this.props.host.open({path: `/irp`, params: {pid: tripsId, caller: 'matcheval', sourcesystem: "TRIPS"}});
                } else {
                    this.props.host.open({path: `/irp`, params: {cid: icseId, caller: 'matcheval', sourcesystem: "ICSE"}});
                }
            }
        }
  }
    componentWillMount() {
        this.props.host.setTitle("ME Case Management");
    }
    render() {
        return (
            <AppHostWrapper host={this.props.host} title="ME Case Management - Pega Portal">
                <PegaPortal {...this.props} onMessage={this.props.onMessage || this._onMessage} />
            </AppHostWrapper>
        );
    }
}

export { PegaPortalApplet as default, PegaPortalApplet }