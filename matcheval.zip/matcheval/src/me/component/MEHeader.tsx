import * as React from "react";
import { observer } from "mobx-react";
import "./MEHeader.scss";
import {IMECase, MEBusinessDomainType, VRAIdnetifiersForME, MEVisaHistoryIdentiferHeaders} from "../IMECase";
import IBookingRecordInfo from "../../risk/traveller/pnr/IBookingRecordInfo";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as StringUtils from "@twii/common/lib/util/String";

interface MEHeaderProps {
    headerDetails?: IMECase;
    pnrSource?: IBookingRecordInfo;
    onRefresh?: () => void;
    icon?: JSX.Element;
}

@observer
class MEHeader extends React.Component<MEHeaderProps, any> {

    getLeftHeader():string {
        let header = "";
        let tripsId: string = "";
        let icseId: string = "";

        header = this.props.headerDetails.CaseID ? `Case Id: ${this.props.headerDetails.CaseID}` : "";
        if(this.props.headerDetails.Identifiers && this.props.headerDetails.Identifiers.length >0) {
            this.props.headerDetails.Identifiers.forEach((identifier) => {
                tripsId = StringUtils.equalsIgnoreCase(identifier.Type, VRAIdnetifiersForME.TRIPS_PID)? identifier.Value : tripsId;
                icseId = StringUtils.equalsIgnoreCase(identifier.Type, VRAIdnetifiersForME.ICSE_CID)? identifier.Value : icseId;
            });
        }
        header = StringUtils.isNotBlank(tripsId) ? StringUtils.isNotBlank(header) ? ` ${header} | ${MEVisaHistoryIdentiferHeaders.TRIPS_PID}: ${tripsId}` : `${MEVisaHistoryIdentiferHeaders.TRIPS_PID}: ${tripsId}` : header;
        header = StringUtils.isNotBlank(icseId) ? StringUtils.isNotBlank(header) ? ` ${header} | ${MEVisaHistoryIdentiferHeaders.ICSE_CID}: ${icseId}` : `${MEVisaHistoryIdentiferHeaders.ICSE_CID}: ${icseId}` : header;

        // Add for
        // CASE_ID = "Case Id",
        // TRAVEL_DOC_NUMBER = "Travel Doc Number",
        // FULL_NAME: "Name"
        return header;
    }
    getCargoHeader():string {
        let header = "";
        let consignmentNbr: string = "";
        let originalMsgId: string = "";
        header = this.props.headerDetails.CaseID ? `Case Id: ${this.props.headerDetails.CaseID}` : "";
        consignmentNbr = this.props.headerDetails.consignmentNbr;
        originalMsgId = this.props.headerDetails.originalMsgId;
        header = StringUtils.isNotBlank(consignmentNbr)? StringUtils.isNotBlank(header) ? ` ${header} | ${`Consignment Number`}: ${ consignmentNbr}` :  header: "";
        header = StringUtils.isNotBlank(originalMsgId) ? ` ${header} | ${`Original Message Id`}: ${originalMsgId}` :header;
        return header;
    }

    render() {
        let leftHeader = "";
       // let leftHeader = StringUtils.equalsIgnoreCase(this.props.headerDetails.BusinessDomain, MEBusinessDomainType.Visa)? this.getLeftHeader() : "";
       if(StringUtils.equalsIgnoreCase(this.props.headerDetails.BusinessDomain, MEBusinessDomainType.Visa)) {
            leftHeader = this.getLeftHeader();
       }
       else if (StringUtils.equalsIgnoreCase(this.props.headerDetails.BusinessDomain, MEBusinessDomainType.Cargo)){
           leftHeader = this.getCargoHeader();
       }
        let pnrSource = this.props.pnrSource? this.props.pnrSource.PNRSource ?  this.props.pnrSource.PNRSource : "" : "";
        let booking = this.props.headerDetails.BookingSystemCode ? "("+this.props.headerDetails.BookingSystemCode +")": "";
        let pnrRecord = this.props.headerDetails.RecordLocator ? this.props.headerDetails.RecordLocator : "";
        let creationTs = this.props.headerDetails.CreationTs ? DateUtils.dateAsStringFromMatchEvaluationHeaderDataText(this.props.headerDetails.CreationTs) : "";
        if (pnrSource) {
            leftHeader+=pnrSource;
        }
        if (pnrRecord) {
            if (pnrSource ) {
                leftHeader+=" | " + pnrRecord;
            }
            else {
                leftHeader+=pnrRecord;
            }
        }
        if (booking) {
            if(pnrSource || pnrRecord) {
                leftHeader+=" | " + booking;
            }
            else {
                leftHeader+=booking;
            }
        }

        if (creationTs) {
            if (pnrSource || booking|| pnrRecord) {
                leftHeader += " | " + creationTs;
            }
            else {
                leftHeader += creationTs;
            }
        }
        return (
            <div className="me-header">
                <div>
                    {this.props.icon}
                    {leftHeader}
                </div>

                <div className="header-security-classification">
                    PROTECTED
                </div>
                <div >
                    {this.props.onRefresh && (
                        <IconButton className="header-refresh" title="Refresh" ariaLabel="Refresh" iconProps={{ iconName: "Refresh" }} onClick={this.props.onRefresh} />
                    )}
                    
                </div>
            </div>
        );
    }
}

export { MEHeader as default, MEHeader, MEHeaderProps }