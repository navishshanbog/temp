import * as React from 'react';
import { observer } from "mobx-react";
import "./VisaHistoryCaseSummary.scss";
import { IVisaHistoryCaseSummary } from "../../visahistory/IVisaHistoryCaseSummary";
import { css } from "office-ui-fabric-react/lib/Utilities";
import {
    DetailsList,
    DetailsListLayoutMode,
    CheckboxVisibility,
    DetailsRow,
    ConstrainMode,
    SelectionMode,
    IColumn,
    Selection
} from "office-ui-fabric-react/lib/DetailsList";
import * as ColumnSortHelper from '@twii/common/lib/component/ColumnSortHelper';
import {caseSummaryColumns} from "./VisaHistoryCaseSummaryColumns";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Details from "@twii/common/lib/component/Details";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";


interface IVisaHistoryCaseSummaryProps {
    model?: IVisaHistoryCaseSummary;
    urgency?: string;
    status?: string;
}

@observer
class VisaHistoryCaseSummaryCommandBar extends React.Component<IVisaHistoryCaseSummaryProps, any> {

    private _loadPreviousCaseDetails = () => {
        this.props.model.updateSelectedCaseIndex(this.props.model.selectedCaseIndex - 1);
    };
    private _loadNextCaseDetails = () => {
        this.props.model.updateSelectedCaseIndex(this.props.model.selectedCaseIndex + 1);
    }
    render() {
        let disableLeft: boolean = true;
        let disableRight: boolean = true;
        disableLeft = this.props.model.selectedCaseIndex == 0;
        disableRight = this.props.model.selectedCaseIndex == this.props.model.itemsView.length-1;

        let caseId:string = this.props.model.selectedCase ? this.props.model.selectedCase.caseId : "";

        const items : IContextualMenuItem[] = [
            {
                key: "LA",
                name: "",
                iconProps: { iconName: "ChevronLeft" },
                disabled: disableLeft,
                className: css(`visa-case-details-left-chevron`),
                onClick: this._loadPreviousCaseDetails
            },
            {
                key: caseId,
                name: `${caseId}`,
                className: css(`visa-case-details-title`)
            },
            {
                key: "RA",
                name: "",
                iconProps: { iconName: "ChevronRight" },
                className: css(`visa-case-details-right-chevron`),
                disabled: disableRight,
                onClick: this._loadNextCaseDetails
            }
        ];

        const farItems: IContextualMenuItem[] = [
            {
                key: "urgency",
                name: `Urgency: ${this.props.urgency}`,
                className: css(`visa-case-details-urgency`),
            },
            {
                key: "status",
                name: `Status: ${this.props.status}`,
                className: css(`visa-case-details-status`),
            }
        ];

        return <CommandBar key={"caseId"} className="case-history-command-bar" items={items}  farItems={farItems}/>;
    }
}


@observer
class VisaHistoryCaseSummary extends React.Component<IVisaHistoryCaseSummaryProps, any> {

    private _selection: Selection;
    private _suppressModelUpdate : boolean = false;

    constructor(props: {}) {
        super(props);
        this._selection = new Selection({ onSelectionChanged: this._updateModelFromSelection });
    }

    private _updateModelFromSelection = () => {
        if(!this._suppressModelUpdate) {
            this.props.model.updateSelectedCaseIndex(this.props.model.itemsView.indexOf(this._selection.getSelection()[0] as any));
        }
    }

    private _updateSelectionFromModel = () => {
        const s = this._selection;
        let items:any[] = this.props.model.itemsView;
        s.setChangeEvents(false, true);
        s.setItems(items, true);
        //const selectedIndexes = this.props.model.selectedCaseIndex;
        // selectedIndexes.forEach(si => {
        s.setIndexSelected(this.props.model.selectedCaseIndex, true, false);
        // });
        s.setChangeEvents(true, false);
    }

    componentWillReact() {
        this._suppressModelUpdate = true;
    }

    private _onShouldVirtualize = () => {
        return this.props.model.itemsView.length > 200;
    }

    componentDidUpdate() {
        this._updateSelectionFromModel();
        this._suppressModelUpdate = false;
    }

    private _onColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        this.props.model.sort.toggleSort(column.fieldName);
    };

    render() {
        let visaHistoryCaseSummaryBar=<div></div>;
        console.log("== slected index ", this.props.model.selectedCaseIndex);
        console.log("== slected case ", this.props.model.selectedCase);
        let content  = <Spinner label="Loading ..." className="load-spinner" />;
        if (this.props.model.sync.error) {
            content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if (this.props.model.sync.hasSynced) {
            let columns = ColumnSortHelper.applySort(caseSummaryColumns, this.props.model.sort);
            content =  <DetailsList columns={columns}
                                    compact={true}
                                    onColumnHeaderClick={this._onColumnHeaderClick}
                                    checkboxVisibility={CheckboxVisibility.hidden}
                                    items={this.props.model.itemsView}
                                    layoutMode={DetailsListLayoutMode.justified}
                                    skipViewportMeasures={false}
                                    selectionMode={SelectionMode.single}
                                    constrainMode={ConstrainMode.unconstrained}
                                    selection={this._selection}
                                    selectionPreservedOnEmptyClick={true}
                                    enterModalSelectionOnTouch={true}
                                    onShouldVirtualize={this._onShouldVirtualize}/>
            visaHistoryCaseSummaryBar = <VisaHistoryCaseSummaryCommandBar {...this.props} />
        }
        return (<div className={css("case-history-section")}>
                <span className={css("visa-history-header")}>{this.props.model.entityBioDetails}</span>
                <Details className={css("case-history-details")}
                         summary={"Case History"}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("me-visa-history-case-summary-ribbon")}>
                    {content}
                </Details>
                {visaHistoryCaseSummaryBar}
            </div>
        );
    }
}
export { VisaHistoryCaseSummary, IVisaHistoryCaseSummaryProps }