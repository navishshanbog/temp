import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import {IAttachments} from "../../visahistory/IReferralActivity";
import {dateWithTZForVisaCases} from "../../MENameUtils";
import {IReferralActivity} from "../../visahistory/IReferralActivity"
import {VisaHistoryCaseDetailsProfileStore} from "../../visahistory/VisaHistoryCaseDetailsProfileStore";
import { Link } from "office-ui-fabric-react/lib/Link";
import * as StringUtils from "@twii/common/lib/util/String";


const NotificationRecipient : IColumn = {
    key: "notificationRecipient",
    ariaLabel: "Notification Recipient",
    name: "Notification Recipient",
    fieldName: "notificationRecipient",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150
};

const NotificationAgency : IColumn = {
    key: "notificationAgency",
    ariaLabel: "Notification Agency",
    name: "Notification Agency",
    fieldName: "notificationAgency",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150
};

const SentReferralUserId : IColumn = {
    key: "sentReferralUserId",
    ariaLabel: "Sent Referral UserId",
    name: "Sent Referral UserId",
    fieldName: "sentReferralUserId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150
    
};
const ReferralDateTime : IColumn = {
    key: "referralDateTime",
    ariaLabel: "Referral DateTime",
    name: "Referral DateTime",
    fieldName: "referralDateTime",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: (item: IReferralActivity) => {
        return dateWithTZForVisaCases(item.referralDateTime);
    }
    
};

const EmailAddress : IColumn = {
    key: "emailAddress",
    ariaLabel: "Email Address",
    name: "Email Address",
    fieldName: "emailAddress",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,
};

const EmailContent : IColumn = {
    key: "emailContent",
    ariaLabel: "Email Content",
    name: "Email Content",
    fieldName: "emailContent",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,


    onRender: (item : IReferralActivity) => {
        let _handleClick = (ev : React.MouseEvent<HTMLElement>) => {
            ev.stopPropagation();
            let emailContent = item.emailContent.replace(/(<br\s*\/?>*)/gi, '<br/>');
            emailContent = emailContent.replace(/(<table\s*\/?>*)/gi, '');
            emailContent = emailContent.replace(/(<tr\s*\/?>*)/gi, '');
            emailContent = emailContent.replace(/(<td\s*\/?>*)/gi, '');
            /*
            QUICK FIX NEEDS TO WORK ON ABOVE
            */
            VisaHistoryCaseDetailsProfileStore.loadEMailContent(emailContent);
            VisaHistoryCaseDetailsProfileStore.setVisible(true);
        }
        let content;
        if (item.emailContent) {

            content = <Link onClick={_handleClick}>eMail content</Link>;
        }
        return content;
    }


/*    onRender: (item: IReferralActivity) => {
        // 3 indicates how many brs should we remove from stirng
        return <div dangerouslySetInnerHTML={{__html: item.emailContent.replace(/(<br\s*\/?>){3,}/gi, '<br>') }}/>
    }*/

};

const EmailSubject : IColumn = {
    key: "emailSubject",
    ariaLabel: "Email Subject",
    name: "Email Subject",
    fieldName: "emailSubject",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150

};

const ToAddress : IColumn = {
    key: "toAddress",
    ariaLabel: "To Address",
    name: "To Address",
    fieldName: "toAddress",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: (item : IReferralActivity) => {
        let toAddress = item.toAddress ? StringUtils.join(item.toAddress, toAdd => toAdd.toString(),"; ") : "";
        return toAddress;
    }
};

const CCAddress : IColumn = {
    key: "ccAddress",
    ariaLabel: "CC Address",
    name: "CC Address",
    fieldName: "ccAddress",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: (item : IReferralActivity) => {
        let ccAddress = item.ccAddress ? StringUtils.join(item.ccAddress, ccAdd => ccAdd.toString(),"; ") : "";
        return ccAddress;
    }

};

const BCCAddress : IColumn = {
    key: "bccAddress",
    ariaLabel: "BCC Address",
    name: "BCC Address",
    fieldName: "bccAddress",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: (item : IReferralActivity) => {
        let bccAddress = item.bccAddress ? StringUtils.join(item.bccAddress, bccAdd => bccAdd.toString(),"; ") : "";
        return bccAddress;
    }

};

const Attachments : IColumn = {
    key: "attachments",
    ariaLabel: "Attachments",
    name: "Attachments",
    fieldName: "attachments",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: (item: IReferralActivity) => {
        let fileName = item.attachments ? StringUtils.join(item.attachments, attachment => attachment.fileName.toString(),"; ") : "";
        return fileName;
    }

};

const profileReferralsColumns : IColumn[] = [
    NotificationRecipient,
    NotificationAgency,
    SentReferralUserId,
    ReferralDateTime,
    ToAddress,
    CCAddress,
    BCCAddress,
    EmailAddress,
    EmailSubject,
    EmailContent,
    Attachments
];

export {
    profileReferralsColumns,
    NotificationRecipient,
    NotificationAgency,
    SentReferralUserId,
    ReferralDateTime,
    ToAddress,
    CCAddress,
    BCCAddress,
    EmailAddress,
    EmailSubject,
    EmailContent,
    Attachments
};


