import * as React from 'react';
import { observer } from "mobx-react";
import "./SystemsSearched.scss";
import * as StringUtils from "@twii/common/lib/util/String";
import Details from "@twii/common/lib/component/Details";
import {IVisaHistoryCaseDetails} from "../../visahistory/IVisaHistoryCaseDetails";


interface ISystemsSearchedProps {
    model?: IVisaHistoryCaseDetails;
}

const SystemSearchedTargetSystems = "Target Systems";
const SystemSearchedAdditionalSearchedItems = "Additional Searched Terms";

@observer
class SystemsSearched extends React.Component<ISystemsSearchedProps, any> {
    render() {
        console.log("selected entity: ", this.props.model.selectedEntity.targetSystems );
        let targetSystems = "";
        if(this.props.model.selectedEntity && this.props.model.selectedEntity.targetSystems && this.props.model.selectedEntity.targetSystems.length > 0) {
            this.props.model.selectedEntity.targetSystems.forEach((ts) => {
                if (StringUtils.isNotBlank(ts.targetSystemsType)) {
                    targetSystems = StringUtils.isNotBlank(targetSystems) ? targetSystems + " | " + ts.targetSystemsType : ts.targetSystemsType;
                    // 1 indicates how many brs should we remove from stirng
                    targetSystems = targetSystems.replace(/(<br\s*\/?>){1,}/gi, '<br>');
                }
            });
        }
        let content = <div className="ms-Grid ms-Grid-col ms-sm12 ms-md6">
            <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-md6 ms-sm12 ms-lg4">
                    <span className="details-attribute-label">{SystemSearchedTargetSystems}</span>
                </div>
                <div className="ms-Grid-col ms-md6 ms-sm12 ms-lg8">

                    <div dangerouslySetInnerHTML={{__html: targetSystems}} />
                </div>
            </div>
            <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-md6 ms-sm12 ms-lg4">
                    <span className="details-attribute-label">{SystemSearchedAdditionalSearchedItems}</span>
                </div>
                <div className="ms-Grid-col ms-md6 ms-sm12 ms-lg8">
                    <span>{this.props.model.selectedEntity.additionalSearchTerms ? this.props.model.selectedEntity.additionalSearchTerms : "-"}</span>
                </div>
            </div>
        </div>
        return ( <Details className="systems-searched"
                          summary="Systems Searched"
                          open={true}
                          controlOnHeaderClick={true}
                          headerClassName="systems-searched-ribbon">
                {content}
            </Details>
        );
    }
}
export { SystemsSearched, ISystemsSearchedProps }