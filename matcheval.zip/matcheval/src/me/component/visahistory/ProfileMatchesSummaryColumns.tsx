import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import {IProfileMatchActivity} from "../../visahistory/IProfileMatchActivity";
import {ITypeNDescription} from "../../visahistory/ICaseActivity";
import {dateWithTZForVisaCases} from "../../MENameUtils";

interface IDisplayItems {
    item: ITypeNDescription;
}

class DisplayVisaItem extends React.Component<IDisplayItems, any> {
    render() {
        return (  <span> {this.props.item.type? this.props.item.type : "" } {this.props.item.description? "("+this.props.item.description+")" : "" } </span>  )
    }
}
class DisplayItems extends React.Component<IDisplayItems, any> {
    render() {

        return (
            <div className="ms-Grid ms-Grid-row "><DisplayVisaItem {...this.props} /></div>
        )
    }
}

const Name : IColumn = {
    key: "name",
    ariaLabel: "Name",
    name: "Name",
    fieldName: "name",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150
};

const Tier : IColumn = {
    key: "tier",
    ariaLabel: "Tier",
    name: "Tier",
    fieldName: "tier",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120
};


const Threat : IColumn = {
    key: "threat",
    ariaLabel: "Threat Type",
    name: "Threat Type",
    fieldName: "threat",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150,
    onRender: (item: IProfileMatchActivity) => {
        let threat;
        if(item.threat.length>0) {
            threat = item.threat.map((t, idx) => {
                return <div key={idx}>{t}</div>
            });
        }
        return <div key={new Date().getTime()}>{threat}</div>;
    }
};

const ReasonForMatch : IColumn = {
    key: "reasonForMatch",
    ariaLabel: "Reason For Match",
    name: "Reason For Match",
    fieldName: "reasonForMatch",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 200,
    maxWidth: 300
};

const MatchDate : IColumn = {
    key: "matchDate",
    ariaLabel: "Match Date",
    name: "Match Date",
    fieldName: "matchDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150,
    data: {
        getText: (item : IProfileMatchActivity) => {
            return dateWithTZForVisaCases(item.matchDate);
        }
    },
    onRender: (item: IProfileMatchActivity) => {
        return dateWithTZForVisaCases(item.matchDate);
    }
};

const profileMatchesSummaryColumns : IColumn[] = [
    Name,
    Tier,
    Threat,
    ReasonForMatch,
    MatchDate
];

export {
    profileMatchesSummaryColumns,
    Name,
    Tier,
    Threat,
    ReasonForMatch,
    MatchDate
};


