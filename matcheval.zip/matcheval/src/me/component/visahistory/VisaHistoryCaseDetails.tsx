import * as React from 'react';
import { observer } from "mobx-react";

//import "./VisaHistoryCaseSummary.scss";
import "./VisaHistoryCaseDetails.scss";
import {IVisaHistoryCaseDetails} from "../../visahistory/IVisaHistoryCaseDetails";
import {VisaHistoryCaseNotes} from "./VisaHistoryCaseNotes";
import {ProfileSummary} from "./ProfileSummary";
import {EntityInformation} from "./EntityInformation";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Details from "@twii/common/lib/component/Details";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
//import {VisaHistoryEntityProfileModel} from "../../visahistory/VisaHistoryEntityProfileModel";
//import {VisaHistoryEntityProfileStore} from "../../visahistory/VisaHistoryEntityProfileStore";


interface IVisaHistoryCaseDetailsProps {
    model?: IVisaHistoryCaseDetails;
}

@observer
// class VisaHistoryCaseSummaryCommandBar extends React.Component<IVisaHistoryCaseSummaryProps, any> {
//
//     private _loadPreviousCaseDetails = () => {
//         this.props.model.updateSelectedCaseIndex(this.props.model.selectedCaseIndex - 1);
//     };
//     private _loadNextCaseDetails = () => {
//         this.props.model.updateSelectedCaseIndex(this.props.model.selectedCaseIndex + 1);
//     }
//     render() {
//         let disableLeft: boolean = true;
//         let disableRight: boolean = true;
//         disableLeft = this.props.model.selectedCaseIndex == 0;
//         disableRight = this.props.model.selectedCaseIndex == this.props.model.caseItems.length-1;
//
//         let caseId:string = this.props.model.selectedCase ? this.props.model.selectedCase.caseId : "";
//
//         const items : IContextualMenuItem[] = [
//             {
//                 key: "LA",
//                 name: "",
//                 iconProps: { iconName: "ChevronLeft" },
//                 disabled: disableLeft,
//                 className: css(`visa-case-details-left-chevron`),
//                 onClick: this._loadPreviousCaseDetails
//             },
//             {
//                 key: caseId,
//                 name: `${caseId}`,
//                 className: css(`visa-case-details-title`)
//             },
//             {
//                 key: "RA",
//                 name: "",
//                 iconProps: { iconName: "ChevronRight" },
//                 className: css(`visa-case-details-right-chevron`),
//                 disabled: disableRight,
//                 onClick: this._loadNextCaseDetails
//             }
//         ];
//
//         return <CommandBar key={"caseId"} className="visa-history-case-summary-command-bar" items={items} />;
//     }
// }


@observer
class VisaHistoryCaseDetails extends React.Component<IVisaHistoryCaseDetailsProps, any> {

    render() {
        let content = <MessageBar messageBarType={MessageBarType.info}>No data available to display</MessageBar>;
        if (this.props.model.sync.syncing) {
            content = <Spinner label="Loading ..." className="load-spinner" />;
        } else if (this.props.model.sync.error) {
            content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if (this.props.model.sync.hasSynced && this.props.model.selectedCaseDetails) {
            content = <div className={"case-details-section"}>
                <VisaHistoryCaseNotes model={this.props.model.selectedCaseDetails} />
                <EntityInformation model={this.props.model} />
                <ProfileSummary {...this.props} />
            </div>;

        }

        let parentContent;

        parentContent = <div key={this.props.model.selectedCaseDetails.urgency || this.props.model.selectedCaseDetails.status}
                             className="me-visa-history-detailed-section">
            {/*<VisaHistoryCommandBar {...this.props} />*/}
            {content}
        </div>

        return (parentContent);
    }
}
export { VisaHistoryCaseDetails, IVisaHistoryCaseDetailsProps }