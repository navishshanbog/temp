import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import {ICaseActivity} from "../../visahistory/ICaseActivity";
import "./VisaHistoryCaseSummary.scss";
import {IProfile} from "../../visahistory/IProfile";
import {IVisas} from "../../visahistory/IVisas";
import * as DateUtils from "@twii/common/lib/util/Date";
import refDataVisaStreamCd from '@twii/riskresume/lib/RefDataVisaStreamCd';
import refDataVisaSubclassCd from '@twii/riskresume/lib/RefDataVisaSubclassCd';
import {defaultDOBFormatForVisa, dateWithTZForVisaCases} from "../../MENameUtils";


const CaseId : IColumn = {
    key: "caseId",
    ariaLabel: "Case ID",
    name: "Case ID",
    fieldName: "caseId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 50,
    maxWidth: 100,
    isSortedDescending: true,
    isSorted: true
};

const Domain : IColumn = {
    key: "domain",
    ariaLabel: "Domain",
    name: "Domain",
    fieldName: "domain",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 50,
    maxWidth: 100
};

const getEntityDetails = (item : ICaseActivity) => {
    let bioDetails;
    if(item.bioInfo && item.bioInfo.length > 0) {
        let tempBD = [];
        let tempSourceSys = [];
        item.bioInfo.map((t, idx) => {
            let entity = "";
            entity = t.familyName? t.familyName.toUpperCase() : "";
            entity = t.givenName? entity ? entity+", "+t.givenName: t.givenName: entity;

            entity = (t.dateOfBirth && t.sexCd)? entity ? entity+" ("+defaultDOBFormatForVisa(t.dateOfBirth)+", "+t.sexCd+")":
                "("+defaultDOBFormatForVisa(t.dateOfBirth)+", "+t.sexCd+")" : t.dateOfBirth? " ("+defaultDOBFormatForVisa(t.dateOfBirth)+")" : " ("+t.sexCd+")";
            if(tempBD.indexOf(entity)<0) {tempBD.push(entity); tempSourceSys.push(t.sourceSystem)}
            //<div key={idx}>{entity} ({t.sourceSystem})</div>;
            //tempBD.push(entity);
            return bioDetails;
        });
        if(tempBD.length>1) {
            bioDetails = tempBD.map((tdb, idx) => {
                return <div key={idx}>{tdb} {tempSourceSys[idx]}</div>;
            });
        } else {
            bioDetails = <div key={tempBD.length}>{tempBD[0]}</div>;
        }
    }
    return <div>{bioDetails}</div>;
}

const BioInfo : IColumn = {
    key: "BioInfo",
    ariaLabel: "BioInfo",
    name: "Entity",
    fieldName: "BioInfo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 250,
    maxWidth: 300,
    isMultiline: true,
    data: {
        getText: (item : ICaseActivity) => {
            return getEntityDetails(item);
        }
    },
    onRender: (item: ICaseActivity) => {
        return getEntityDetails(item);
    }
};


const getVisas = (item : ICaseActivity, forRender: boolean) => {
    let visas;
    if(item.visas && item.visas.length > 0) {
        visas = item.visas.map((v: IVisas, idx) => {
            let vsa = "";
            vsa = v.visaStreamCode? `${refDataVisaStreamCd.getDesc(v.visaStreamCode)}`: vsa;
            vsa = v.visaSubClass ? `${vsa} ${refDataVisaSubclassCd.getDesc(v.visaSubClass)}` : `${vsa}`;
            vsa = v.visaStatus? `${vsa}  (${v.visaStatus})`: `${vsa}`;
            if(forRender)
                return <div key={idx}>{vsa}</div>
            return {vsa}
        });

    }
    if(forRender)
        return <div>{visas}</div>;
    return {visas}
}

const Visas : IColumn = {
    key: "Visas",
    ariaLabel: "Visas",
    name: "Visas",
    fieldName: "Visas",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 350,
    isMultiline: true,
     data: {
         getText: (item : ICaseActivity) => {
             console.log("-- get text for viass", getVisas(item, false));
             return getVisas(item, false);
         }
     },
    onRender: (item: ICaseActivity) => {
        return getVisas(item, true);
    }
};

const getThreatProfiles = (item : ICaseActivity) => {
    let threatProfiles;
    if(item.profile && item.profile.length > 0) {
        threatProfiles = item.profile.map((p: IProfile, idx) => {
            let threat = "";
            threat = p.profileName? p.profileTier? `${p.profileName} ( ${p.profileTier})`: `${p.profileName}`: threat;

            if (p.threats && p.threats.length>0) {
                let t = "";
                p.threats.map((th, idx) => {
                   t = t? th? `${t} , ${th}`: t: th? th: th;
                });
                threat = threat ? t? `${threat} | ${t}`: threat: t? t: t;
            }
            threat = threat ? p.outcome? `${threat} | ${p.outcome}`: `${threat}`: p.outcome? p.outcome: p.outcome;
            return <div key={idx}>{threat}</div>
        });

    }
    return <div>{threatProfiles}</div>;
}


const Profile : IColumn = {
    key: "profile",
    ariaLabel: "Profile",
    name: "Profile | Threat | Outcome",
    fieldName: "profile",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 200,
    maxWidth: 400,
    isMultiline: true,
    onRender: (item: ICaseActivity) => {
        return getThreatProfiles(item);
    }
};

const CaseCreated : IColumn = {
    key: "caseCreated",
    ariaLabel: "Case Created",
    name: "Case Created",
    fieldName: "caseCreated",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150,
    isMultiline: true,
    data: {
        getText: (item : ICaseActivity) => {
            return dateWithTZForVisaCases(item.caseCreated);
        }
    },
    onRender: (item: ICaseActivity) => {
        return dateWithTZForVisaCases(item.caseCreated);
    }
};

const CaseClosed : IColumn = {
    key: "caseClosed",
    ariaLabel: "Case Closed",
    name: "Case Closed",
    fieldName: "caseClosed",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150,
    isMultiline: true,
    data: {
        getText: (item : ICaseActivity) => {
            return dateWithTZForVisaCases(item.caseClosed);
        }
    },
    onRender: (item: ICaseActivity) => {
        return dateWithTZForVisaCases(item.caseClosed);
    }
};

const CaseStatus : IColumn = {
    key: "caseStatus",
    ariaLabel: "Case Status",
    name: "Case Status",
    fieldName: "caseStatus",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    isMultiline: true,
};


const caseSummaryColumns : IColumn[] = [
    CaseId,
    Domain,
    BioInfo,
    Profile,
    Visas,
    CaseStatus,
    CaseCreated,
    CaseClosed
];

export {
    caseSummaryColumns,
    CaseId,
    Domain,
    BioInfo,
    Profile,
    Visas,
    CaseStatus,
    CaseCreated,
    CaseClosed
};


