import * as React from 'react';
import { observer } from "mobx-react";
import "./VisaHistoryCaseNotes.scss";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { css } from "office-ui-fabric-react/lib/Utilities";
import Details from "@twii/common/lib/component/Details";
import {ICaseDetailsActivity} from "../../visahistory/ICaseDetailsActivity";

interface IVisaHistoryCaseNotesProps {
    model?: ICaseDetailsActivity;
}

interface MEVisaHistorySingleNoteProps {
    infoStr?: string;
    note?: string;
    numberOfNotes?: number;
    index?: number;
}

class SingleNote extends React.Component<MEVisaHistorySingleNoteProps, any> {

    getMoreTextDiv() {
        return <div className="case-notes-panel"> {this.props.note} </div>;
    }

    render() {
        var expandedDiv = this.getMoreTextDiv();
        return (<div>
            <div key={this.props.note} className="case-notes-note">
                <a href={`#show${this.props.index}`} className={css(`show btn`)} id={`show${this.props.index}`}>View more </a>
                <a href={`#hide${this.props.index}`} className={css(`hide btn`)} id={`hide${this.props.index}`}>View less </a>
                <p className="case-note">{this.props.infoStr}</p> { expandedDiv }
            </div>
            <div className="fade"></div>
            {(this.props.index == this.props.numberOfNotes ? <span />: <hr />)}
            </div>
        )
    }
}

@observer
class VisaHistoryCaseNotes extends React.Component<IVisaHistoryCaseNotesProps, any> {

    render() {
        let content;
        if(this.props.model.caseNotes.length>0) {
            content = this.props.model.caseNotes.map((note, idx) => {
                let infoStr: string = "";
                infoStr = note.noteDtTime ? note.noteDtTime : infoStr;
                infoStr = note.userId ? infoStr ? infoStr + " " +note.userId : note.userId : infoStr;
                infoStr = note.userName ? infoStr ? infoStr + " " +note.userName : note.userName : infoStr;
                return (
                    <SingleNote key={infoStr} infoStr={infoStr} note={note.notes ? note.notes : ""} numberOfNotes={this.props.model.caseNotes.length-1} index={idx} />
                )
            });
        } else {
            content = <div key={"ke"}>No Case Notes found</div>
        }
        return ( <Details className="case-notes"
                          summary="Case Notes"
                          open={true}
                          controlOnHeaderClick={true}
                          headerClassName="case-notes-ribbon">
            {content}
            </Details>
        );
    }
}
export { VisaHistoryCaseNotes, IVisaHistoryCaseNotesProps }