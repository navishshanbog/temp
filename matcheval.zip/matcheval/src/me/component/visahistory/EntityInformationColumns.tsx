import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import {IEntityProfileInformation} from "../../visahistory/IEntityProfileInformation";
import * as StringUtils from "@twii/common/lib/util/String";
import {defaultDOBFormatForVisa} from "../../MENameUtils";


const getEntityDetails = (item : IEntityProfileInformation) => {
    let bioDetails;
    if(item.bioInfo && item.bioInfo.length > 0) {
        let tempBD = [];
        let tempSourceSys = [];
        item.bioInfo.map((t, idx) => {
            let entity = "";
            entity = t.familyName? t.familyName.toUpperCase() : "";
            entity = t.givenName? entity ? entity+", "+t.givenName: t.givenName: entity;

            entity = (t.dateOfBirth && t.sexCd)? entity ? entity+" ("+defaultDOBFormatForVisa(t.dateOfBirth)+", "+t.sexCd+")":
                "("+defaultDOBFormatForVisa(t.dateOfBirth)+", "+t.sexCd+")" : defaultDOBFormatForVisa(t.dateOfBirth)? " ("+defaultDOBFormatForVisa(t.dateOfBirth)+")" : " ("+t.sexCd+")";
            if(tempBD.indexOf(entity)<0) {tempBD.push(entity); tempSourceSys.push(t.sourceSystem)}
            //<div key={idx}>{entity} ({t.sourceSystem})</div>;
            //tempBD.push(entity);
            return bioDetails;
        });
        if(tempBD.length>1) {
            bioDetails = tempBD.map((tdb, idx) => {
                return <div key={idx}>{tdb} {tempSourceSys[idx]}</div>;
            });
        } else {
            bioDetails = <div key={tempBD.length}>{tempBD[0]}</div>;
        }
    }
    return <div>{bioDetails}</div>;
}

const BioInfo : IColumn = {
    key: "bioInfo",
    ariaLabel: "BioInfo",
    name: "Entity",
    fieldName: "BioInfo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 350,
    maxWidth: 360,
    isMultiline: true,
    onRender: (item: IEntityProfileInformation) => {
        return getEntityDetails(item);
    }
};


const getAllIdentifiers = (item : IEntityProfileInformation) => {
    let idents;
    if(item.bioInfo && item.bioInfo.length > 0) {
        idents = item.bioInfo.map((bi, idx) => {
            let sourceSys;
            sourceSys = bi.id? bi.id: sourceSys;
            sourceSys = bi.sourceSystem? sourceSys? `${sourceSys} (${bi.sourceSystem})`:`(${bi.sourceSystem})`: sourceSys;
            return <div key={idx}>{sourceSys}</div>;
        });
    }
    return <div>{idents}</div>;
}

const ID : IColumn = {
    key: "identifiers",
    ariaLabel: "ID",
    name: "ID",
    fieldName: "identifiers",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 200,
    onRender: (item: IEntityProfileInformation) => {
        return getAllIdentifiers(item);
    }
};

const checkIfExists = (child: string[], parent: string[]) => {
    var foundItem: boolean = false;
    parent.map((p: any, idx) => {
        if(JSON.stringify(p)==JSON.stringify(child)) foundItem = true;
    })
    return foundItem;
}

const getCountryOfBirthDetails = (item : IEntityProfileInformation) => {
    let cobs;
    let allCOBs:string[] = [];
    if(item.bioInfo && item.bioInfo.length > 0) {
        cobs = item.bioInfo.map((bi, idx) => {
            let tempCobs;
            if(bi.countryOfBirth && bi.countryOfBirth.length>0) {
                tempCobs = bi.countryOfBirth.map((cBirth, idx) => {
                    return idx==0  ? idx!=bi.countryOfBirth.length-1 ? `${cBirth}, ` : idx!=bi.countryOfBirth.length-1 ? `${cBirth}, `: `${cBirth}`: `${cBirth}`;
                });

                if(!checkIfExists(tempCobs, allCOBs)) {
                    allCOBs.push(tempCobs);
                    return <div key={idx}>{tempCobs}</div>
                }
            }
        });
    }
    return <div>{cobs}</div>;
}


const COB : IColumn = {
    key: "countryOfBirth",
    ariaLabel: "Country of Birth",
    name: "Country of Birth",
    fieldName: "countryOfBirth",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 150,
    onRender: (item: IEntityProfileInformation) => {
        return getCountryOfBirthDetails(item);
    }
};


const getCountryOfCitizenshipDetails = (item : IEntityProfileInformation) => {
    let countryOfCitzs;
    let allCOCs:string[] = [];
    let tempCountryOfCitzs;
    if(item.bioInfo && item.bioInfo.length > 0) {
        countryOfCitzs = item.bioInfo.map((bi, idx) => {

            if(bi.countryOfCitizenship && bi.countryOfCitizenship.length>0) {
                tempCountryOfCitzs = bi.countryOfCitizenship.map((cCitizen, idx) => {
                    return idx==0  ? idx!=bi.countryOfCitizenship.length-1 ? `${cCitizen}, ` : idx!=bi.countryOfCitizenship.length-1 ? `${cCitizen}, `: `${cCitizen}`: `${cCitizen}`;
                });
                if(!checkIfExists(tempCountryOfCitzs, allCOCs)) {
                    allCOCs.push(tempCountryOfCitzs);
                    return <div key={idx}>{tempCountryOfCitzs}</div>
                }
            }
        });
    }
    return <div>{countryOfCitzs}</div>;
}

const COC : IColumn = {
    key: "countryOfCitizenship",
    ariaLabel: "Country of Citizenship",
    name: "Country of Citizenship",
    fieldName: "countryOfCitizenship",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 150,
    onRender: (item: IEntityProfileInformation) => {
        return getCountryOfCitizenshipDetails(item);
    }
};

const getTravelDocs = (item : IEntityProfileInformation) => {
    let travelDocs;
    if(item.travelDocs && item.travelDocs.length > 0) {
        travelDocs = item.travelDocs.map((td, idx) => {
            let tDoc = "";
            tDoc = td.type? td.type : "";
            tDoc = td.description? tDoc ? `${td.description} (${tDoc})`: `${td.description}`: tDoc;
            return <div key={idx}>{tDoc}</div>;
        });
    }
    return <div>{travelDocs}</div>;
}

const TD : IColumn = {
    key: "travelDocs",
    ariaLabel: "Travel Documents",
    name: "Travel Documents",
    fieldName: "travelDocs",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 110,
    maxWidth: 250,
    onRender: (item: IEntityProfileInformation) => {
        return getTravelDocs(item);
    }
 };

const getVisaDetails = (item : IEntityProfileInformation) => {
    let visaDetails;
    if(item.visas && item.visas.length > 0) {
        visaDetails = item.visas.map((vs, idx) => {
            let visa = "";
            visa = vs.visaStreamCode? vs.visaStreamCode : "";
            visa = vs.visaSubClass? visa? `${visa} ${vs.visaSubClass}`: vs.visaSubClass: visa;
            visa = vs.visaStatus? visa ? `${visa} (${vs.visaStatus})`: `(${vs.visaStatus})`: visa;
            return <div key={idx}>{visa}</div>;
        });
    }
    return <div>{visaDetails}</div>;
}

const Visas : IColumn = {
    key: "visas",
    ariaLabel: "Visas",
    name: "Visas",
    fieldName: "visas",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 250,
    onRender: (item: IEntityProfileInformation) => {
        return getVisaDetails(item);
    }
};

const Location : IColumn = {
    key: "clientLocation",
    ariaLabel: "Client Location",
    name: "Client Location",
    fieldName: "clientLocation",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 150,
    
};

const entityInformationColumns : IColumn[] = [
        BioInfo,
        ID,
        COB,
        COC,
        TD,
        Visas,
        Location
];

export {
    entityInformationColumns,
       BioInfo,
       ID,
       COB,
       COC,
       TD,
       Visas,
       Location
};


