import * as React from 'react';
import { observer } from "mobx-react";
import "./ProfileAssessmentEmailDialog.scss";
import {IVisaHistoryCaseDetailsProfile} from "../../visahistory/IVisaHistoryCaseDetailsProfile";
import { Dialog, DialogType } from 'office-ui-fabric-react/lib/Dialog';


interface ProfileAssessmentEmailDialogProps {
    model?: IVisaHistoryCaseDetailsProfile;
}

@observer
class ProfileAssessmentEmailDialog extends React.Component<ProfileAssessmentEmailDialogProps, any> {
    private _handleDialogClose = () => {
        this.props.model.setVisible(false);
    }

    render() {
        return (
            <Dialog hidden={false} onDismiss={this._handleDialogClose}
                    dialogContentProps={{ type: DialogType.normal, title: 'Email Content' }}
                    modalProps={{ isBlocking: false, className: "me-visa-history-email-content-dialog" }}>
                <div className="me-visa-history-email-content-dialog-body" dangerouslySetInnerHTML={{__html: this.props.model.emailContent}} />
            </Dialog>
        );
    }
}
export { ProfileAssessmentEmailDialog }