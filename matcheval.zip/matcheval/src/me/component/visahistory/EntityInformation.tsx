import * as React from 'react';
import { observer } from "mobx-react";
import "./EntityInformation.scss";
import {entityInformationColumns} from "./EntityInformationColumns";
import {IVisaHistoryCaseDetails} from "../../visahistory/IVisaHistoryCaseDetails";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import Details from "@twii/common/lib/component/Details";
import {
    DetailsList,
    DetailsListLayoutMode,
    CheckboxVisibility,
    ConstrainMode,
    SelectionMode,
    Selection
} from "office-ui-fabric-react/lib/DetailsList";
import * as StringUtils from "@twii/common/lib/util/String";
import {SystemsSearched} from "./SystemsSearched";


interface IEntityInformationProps {
    model?: IVisaHistoryCaseDetails;
}

 @observer
 class VisaHistoryEntityCommandBar extends React.Component<IEntityInformationProps, any> {
      private entity: string = "";
      private _loadPreviousEntityDetails = () => {
         this.props.model.updateSelectedEntityIndex(this.props.model.selectedEntityDetailsIndex - 1);
      };
      private _loadNextEntityDetails = () => {
         this.props.model.updateSelectedEntityIndex(this.props.model.selectedEntityDetailsIndex + 1);
      }
      render() {
          let disableLeft: boolean = true;
          let disableRight: boolean = true;
          disableLeft = this.props.model.selectedEntityDetailsIndex == 0;
          disableRight = this.props.model.selectedEntityDetailsIndex == this.props.model.caseEntities.length-1;

          let bioInfo:string = "";
          if(this.props.model.selectedEntity.bioInfo && this.props.model.selectedEntity.bioInfo.length >0) {
             let curFName: string;
             let curGName: string;
              this.props.model.selectedEntity.bioInfo.map((bInfo, idx) => {
                  curFName = bInfo.familyName? bInfo.familyName.toUpperCase() :"";
                  curGName = bInfo.givenName? bInfo.givenName :"";
                  bioInfo = StringUtils.equalsIgnoreCase(bioInfo, curFName+", "+curGName) ? bioInfo : StringUtils.isBlank(bioInfo) ? curFName+", "+curGName : bioInfo+" | "+curFName+", "+curGName;
              });
          }
          const items : IContextualMenuItem[] = [
              {
                  key: "LA",
                  name: "",
                  iconProps: { iconName: "ChevronLeft" },
                  disabled: disableLeft,
                  className: css(`visa-case-details-left-chevron`),
                  onClick: this._loadPreviousEntityDetails
              },
              {
                  key: bioInfo,
                  name: `${bioInfo}`,
                  className: css(`visa-case-details-title`)
              },
              {
                  key: "RA",
                  name: "",
                  iconProps: { iconName: "ChevronRight" },
                  className: css(`visa-case-details-right-chevron`),
                  disabled: disableRight,
                  onClick: this._loadNextEntityDetails
              }
          ];

          return <CommandBar key={"selectedCaseDetails"} className="entity-info-command-bar" items={items} />;
     }
 }

@observer
class EntityInformation extends React.Component<IEntityInformationProps, any> {

    private _selection: Selection;
    private _suppressModelUpdate : boolean = false;
    constructor(props: {}) {
        super(props);
        this._selection = new Selection({ onSelectionChanged: this._updateModelFromSelection });
    }

    private _updateModelFromSelection = () => {
        if(!this._suppressModelUpdate) {
            this.props.model.updateSelectedEntityIndex(this.props.model.caseEntities.indexOf(this._selection.getSelection()[0] as any));
        }
    }

    private _updateSelectionFromModel = () => {
        const s = this._selection;
        let items:any[] = this.props.model.caseEntities;
        s.setChangeEvents(false, true);
        s.setItems(items, true);
        //const selectedIndexes = this.props.model.selectedEntityDetailsIndex;
        // selectedIndexes.forEach(si => {
        s.setIndexSelected(this.props.model.selectedEntityDetailsIndex, true, false);
        // });
        s.setChangeEvents(true, false);
    }

/*    componentWillReact() {
        this._suppressModelUpdate = true;
    }*/

/*    private _onSelectionChange = () => {
        if(this._selection.getSelectedCount() > 0) {
            this.props.model.updateSelectedEntityIndex(this.props.model.selectedCaseDetails.entityProfileInformation.indexOf(this._selection.getSelection()[0] as any));
            //this.props.model.setSelectedEntity(this._selection.getSelection()[0] as IEntityInformation, null);
        }
    }*/

    private _onShouldVirtualize = () => {
        return this.props.model.caseEntities.length > 200;
    }


    componentWillUpdate() {
        this._suppressModelUpdate = true;
    }

    componentDidMount() {
        this._updateSelectionFromModel();
    }


    componentDidUpdate() {
        this._updateSelectionFromModel();
        this._suppressModelUpdate = false;
    }

/*    private _setRow = (item, index) => {
        if(this._selection)   {
            let items:any[] = this.props.model.selectedCaseDetails.entityProfileInformation;
            this._selection.setItems(items, true);
            // set the first row selected when the component loads for the first time
            this._selection.setIndexSelected(this.props.model.selectedEntityDetailsIndex, true, true)
        }
    }*/

/*    componentDidUpdate() {
        let items:any[] = this.props.model.selectedCaseDetails.entityProfileInformation;
        this._selection.setItems(items, true);
        // set the first row selected when the component loads for the first time
        this._selection.setIndexSelected(this.props.model.selectedEntityDetailsIndex, true, true)
    }*/

    render() {

        console.log("-------------- before from entity info rnder -------------");
        console.log("selected entity details index ", this.props.model.selectedEntityDetailsIndex);
        console.log("selected entity  ", this.props.model.selectedEntity);


        let content;
        if (this.props.model.sync.syncing) {
            content = <Spinner label="Loading ..." className="load-spinner" />;
        } else if (this.props.model.sync.error) {
            content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if(this.props.model.sync.hasSynced && this.props.model.caseEntities) {
                content = <DetailsList columns={entityInformationColumns}
                                       compact={true}
                                       checkboxVisibility={CheckboxVisibility.hidden}
                                       items={this.props.model.caseEntities}
                                       layoutMode={DetailsListLayoutMode.justified}
                                       skipViewportMeasures={false}
                                       selectionMode={SelectionMode.single}
                                       constrainMode={ConstrainMode.unconstrained}
                                       selection={this._selection}
                                       selectionPreservedOnEmptyClick={true}
                                       enterModalSelectionOnTouch={true}
                                       onShouldVirtualize={this._onShouldVirtualize}/>
        }
        return (<div>
            <Details className={css("entity-information")}
                     summary="Entity Information"
                     open={true}
                     controlOnHeaderClick={true}
                     headerClassName={css(`entity-information-ribbon`)}>
                     {content}
            </Details>
                <VisaHistoryEntityCommandBar {...this.props} />
                <SystemsSearched {...this.props} />
            </div>
        );
    }
}
export { EntityInformation, IEntityInformationProps }

