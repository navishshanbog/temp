import * as React from 'react';
import { observer } from "mobx-react";
//import "./VisaHistoryCaseSummary.scss";
import "./VisaHistory.scss";
import { IVisaHistoryCaseSummary } from "../../visahistory/IVisaHistoryCaseSummary";
import { VisaHistoryCaseSummary } from "./VisaHistoryCaseSummary";
import {VisaHistoryCaseDetails} from "./VisaHistoryCaseDetails";
import {ProfileAssessment} from "./ProfileAssessment";
import {VisaHistoryCaseDetailsStore} from "../../visahistory/VisaHistoryCaseDetailsStore";
import {VisaHistoryCaseDetailsModel} from "../../visahistory/VisaHistoryCaseDetailsModel";
import {VisaHistoryCaseDetailsProfileStore} from "../../visahistory/VisaHistoryCaseDetailsProfileStore";
import {VisaHistoryCaseDetailsProfileModel} from "../../visahistory/VisaHistoryCaseDetailsProfileModel";

interface IVisaHistoryProps {
    model?: IVisaHistoryCaseSummary;
}

@observer
class VisaHistory extends React.Component<IVisaHistoryProps, any> {

    visaHistoryCaseDetails: VisaHistoryCaseDetailsModel = VisaHistoryCaseDetailsStore;
    visaHistoryCaseDetailsProfileAssessment: VisaHistoryCaseDetailsProfileModel = VisaHistoryCaseDetailsProfileStore;

    render() {
        let urgency: string = "";
        let status: string = "";
        urgency = (this.visaHistoryCaseDetails.selectedCaseDetails && this.visaHistoryCaseDetails.selectedCaseDetails.urgency) ?
            this.visaHistoryCaseDetails.selectedCaseDetails.urgency: "";
        status = (this.visaHistoryCaseDetails.selectedCaseDetails && this.visaHistoryCaseDetails.selectedCaseDetails.status) ?
            this.visaHistoryCaseDetails.selectedCaseDetails.status: "";
        console.log("-- visa details ", this.visaHistoryCaseDetails.selectedCaseDetails);
        return (<div className="me-visa-history-details">
                <VisaHistoryCaseSummary model={this.props.model} urgency={urgency} status={status}/>
                <VisaHistoryCaseDetails model={this.visaHistoryCaseDetails} />
                <ProfileAssessment model={this.visaHistoryCaseDetailsProfileAssessment} />
            </div>
        );
    }
}
export { VisaHistory, IVisaHistoryProps }