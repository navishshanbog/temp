import * as React from 'react';
import { observer } from "mobx-react";
import "./ProfileAssessment.scss";
import * as StringUtils from "@twii/common/lib/util/String";
import Details from "@twii/common/lib/component/Details";
import {IVisaHistoryCaseDetailsProfile} from "../../visahistory/IVisaHistoryCaseDetailsProfile";
import {
    DetailsList,
    DetailsListLayoutMode,
    CheckboxVisibility,
    ConstrainMode,
    SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { profileReferralsColumns } from "./profileReferralsColumns";
import { css } from "office-ui-fabric-react/lib/Utilities";
import {MEVisaHistoryProfileAssessmentAttribute} from "./MEVisaHistoryProfileAssessmentAttribute";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import {dateWithTZForVisaCases} from "../../MENameUtils";
import {ProfileAssessmentEmailDialog} from "./ProfileAssessmentEmailDialog";

const OutcomeType1: string[] = ["HIGHLY LIKELY", "LIKELY", "POSSIBLE"];

const ProfileAssessmentOutcome1 = [
    {
        key: "treatmentAdvice",
        name: "Treatment Advice",
        onRender: (source: any, field: any) => {
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                                  key={field.key} value={source.treatmentAdvice ? source.treatmentAdvice : ""}/>
        }
    },  {
        key: "additionalTreatmentAdvice",
        name: "Additional Treatment Advice",
        onRender: (source: any, field: any) => {
            let addTreatAdv = StringUtils.join(source.additionalTreatmentAdvice, addTreatAdv => addTreatAdv.toString()," | ");
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                                  key={field.key} value={addTreatAdv ? addTreatAdv : ""}/>
        }
    },  {
        key: "additionalTreatmentText",
        name: "Additional information to support treatment advice",
        onRender: (source: any, field: any) => {
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                                  key={field.key} value={source.additionalTreatmentText ? source.additionalTreatmentText : ""}/>
        }
    }
];

const ProfileAssessmentOutcome2 = [
    {
        key: "dismissalReason",
        name: "Dismissal Reason",
        onRender: (source: any, field: any) => {
            let dismissalReason = StringUtils.join(source.dismissalReason, dissMissText => dissMissText.toString()," | ");
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                                            key={field.key} value={dismissalReason ? dismissalReason : ""}/>
        }
    },  {
        key: "additionalDismissalText",
        name: "Additional Dismissal Text",
        onRender: (source: any, field: any) => {
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                                  key={field.key} value={source.additionalDismissalText ? source.additionalDismissalText : ""}/>
        }
    }
];

const ProfileAssessmentColumns1 = [
    {
        key: "outcome",
        name: "Outcome",
        onRender: (source: any, field: any) => {
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                       key={field.key} value={source.outcome? source.outcome : ""} />
        }
    }
];

const ProfileAssessmentColumns2 = [
    {
        key: "assessmentFinidings",
        name: "Assessment Findings",
        onRender: (source: any, field: any) => {
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                       key={field.key} value={source.assessmentFinidings ? source.assessmentFinidings : ""}/>
        }
    },  {
        key: "actionedUserId",
        name: "Actioned UserId",
        onRender: (source: any, field: any) => {
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                       key={field.key} value={source.actionedUserId ? source.actionedUserId : ""}/>
        }
    },  {
        key: "actionDateTime",
        name: "Action DateTime",
        onRender: (source: any, field: any) => {
            return <MEVisaHistoryProfileAssessmentAttribute label={field.name}
                                       key={field.key} value={source.actionDateTime ? dateWithTZForVisaCases(source.actionDateTime) : ""}/>
        }
    }
];

interface MEVisaHistoryCaseDetailsProfileProps {
    model?: IVisaHistoryCaseDetailsProfile;
}

@observer
class ProfileAssessment extends React.Component<MEVisaHistoryCaseDetailsProfileProps, any> {
    render() {
        let assesment = <div></div>
        let referrals = <div></div>;
        let emailContent = this.props.model.visible ? <ProfileAssessmentEmailDialog model={this.props.model}/> : undefined;
        if (this.props.model.sync.syncing) {
            assesment = <Spinner label="Loading ..." className="load-spinner" />;
        } else if (this.props.model.sync.error) {
            assesment = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if (this.props.model.sync.hasSynced) {
            let content;
            if (this.props.model.items && StringUtils.isNotBlank(this.props.model.items.outcome)) {
                let oCome = this.props.model.items.outcome;
                var matchc = OutcomeType1.find((item) => StringUtils.equalsIgnoreCase(item, oCome));
                let ProfileAssessmentColumns = ProfileAssessmentColumns1;
                ProfileAssessmentColumns = matchc ? ProfileAssessmentColumns.concat(ProfileAssessmentOutcome1, ProfileAssessmentColumns2) :
                    ProfileAssessmentColumns.concat(ProfileAssessmentOutcome2, ProfileAssessmentColumns2);
                content = ProfileAssessmentColumns.map((field: any) => {
                    if (field.onRender) {
                        return field.onRender(this.props.model.items, field);
                    }
                });
                assesment = <Details className="profile-assessment"
                                     summary="Assessment"
                                     open={true}
                                     controlOnHeaderClick={true}
                                     headerClassName="profile-assessment-ribbon">
                    {content}
                </Details>
            } else {
                assesment = <div> No Assessments found</div>
            }

            if(this.props.model.items.referral) {
                referrals =<Details className={css("profile-referrals")}
                             summary="Referrals"
                             open={true}
                             controlOnHeaderClick={true}
                             headerClassName={css(`profile-referrals-ribbon`)}>
                        <DetailsList columns={profileReferralsColumns}
                                     compact={true}
                                     checkboxVisibility={CheckboxVisibility.hidden}
                                     items={this.props.model.items.referral || []}
                                     layoutMode={DetailsListLayoutMode.justified}
                                     skipViewportMeasures={false}
                                     selectionMode={SelectionMode.single}
                                     constrainMode={ConstrainMode.unconstrained}/>
                    </Details>

            } else {
                referrals = <div> No Referrals found</div>
            }
        }



        return ( <div className={"profile-details-section"} key={new Date().getTime()}>
                {assesment}
                {referrals}
                {emailContent}
             </div>
        );
    }
}
export { ProfileAssessment, MEVisaHistoryCaseDetailsProfileProps }