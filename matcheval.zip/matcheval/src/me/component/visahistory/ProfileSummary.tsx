import * as React from 'react';
import { observer } from "mobx-react";
import {IVisaHistoryCaseDetails} from "../../visahistory/IVisaHistoryCaseDetails";
import "./ProfileSummary.scss";
import {profileMatchesSummaryColumns} from "./ProfileMatchesSummaryColumns";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import Details from "@twii/common/lib/component/Details";
import {
    DetailsList,
    DetailsListLayoutMode,
    CheckboxVisibility,
    ConstrainMode,
    SelectionMode,
    Selection
} from "office-ui-fabric-react/lib/DetailsList";

interface IProfileSummaryProps {
    model?: IVisaHistoryCaseDetails;
}

 @observer
 class ProfileSummaryCommandBar extends React.Component<IProfileSummaryProps, any> {
      private profile: string = "";
      private _loadPreviousEntityProfileDetails = () => {
         this.props.model.updateSelectedProfileIndex(this.props.model.selectedProfileIndex - 1);
      };
      private _loadNextEntityProfileDetails = () => {
         this.props.model.updateSelectedProfileIndex(this.props.model.selectedProfileIndex + 1);
      }
      render() {
          let disableLeft: boolean = true;
          let disableRight: boolean = true;
          disableLeft = this.props.model.selectedProfileIndex == 0;
          disableRight = this.props.model.selectedProfileIndex == this.props.model.entityProfiles.length-1;

          if(this.props.model.selectedProfile) {
              this.profile = this.props.model.selectedProfile.name ? this.props.model.selectedProfile.name : "";
              this.profile = this.props.model.selectedProfile.tier ? `${this.profile} (${this.props.model.selectedProfile.tier})` : this.profile;
          }
          const items : IContextualMenuItem[] = [
              {
                  key: "LA",
                  name: "",
                  iconProps: { iconName: "ChevronLeft" },
                  disabled: disableLeft,
                  className: css(`visa-case-details-left-chevron`),
                  onClick: this._loadPreviousEntityProfileDetails
              },
              {
                  key: this.profile,
                  name: `${this.profile}`,
                  className: css(`visa-case-details-title`)
              },
              {
                  key: "RA",
                  name: "",
                  iconProps: { iconName: "ChevronRight" },
                  className: css(`visa-case-details-right-chevron`),
                  disabled: disableRight,
                  onClick: this._loadNextEntityProfileDetails
              }
          ];

          return <CommandBar key={"selectedCaseDetails"} className="profile-summary-command-bar" items={items} />;
     }
 }

@observer
class ProfileSummary extends React.Component<IProfileSummaryProps, any> {

    private _selection: Selection;
    private _suppressModelUpdate : boolean = false;

    constructor(props: {}) {
        super(props);
        this._selection = new Selection({ onSelectionChanged: this._updateModelFromSelection });
    }

    private _updateModelFromSelection = () => {
        if(!this._suppressModelUpdate) {
            if(this.props.model.entityProfiles.length>0) {
                this.props.model.updateSelectedProfileIndex(this.props.model.entityProfiles.indexOf(this._selection.getSelection()[0] as any));
            }
        }
    }

    private _updateSelectionFromModel = () => {
        const s = this._selection;
        let items:any[] = this.props.model.entityProfiles;
        s.setChangeEvents(false, true);
        s.setItems(items, true);
        //const selectedIndexes = this.props.model.selectedCaseIndex;
        // selectedIndexes.forEach(si => {
        s.setIndexSelected(this.props.model.selectedProfileIndex, true, false);
        // });
        s.setChangeEvents(true, false);
    }

    componentWillUpdate() {
        this._suppressModelUpdate = true;
    }

    componentDidMount() {
        this._updateSelectionFromModel();
    }

/*    private _onSelectionChange = () => {
        if(this._selection.getSelectedCount() > 0) {
           console.log("-- selected enttiyt ", this._selection.getSelection()[0]);
            this.props.model.updateSelectedProfileIndex(this.props.model.entityProfiles.indexOf(this._selection.getSelection()[0] as any));
            //this.props.model.setSelectedEntity(this._selection.getSelection()[0] as IEntityInformation, null);
        }
    }*/

    private _onShouldVirtualize = () => {
        return this.props.model.entityProfiles.length > 200;
    }

    componentDidUpdate() {
        this._updateSelectionFromModel();
        this._suppressModelUpdate = false;
    }

/*    private _setRow = (item, index) => {
        if(this._selection)   {
            let items:any[] = this.props.model.entityProfiles;
            this._selection.setItems(items, true);
            // set the first row selected when the component loads for the first time
            this._selection.setIndexSelected(this.props.model.selectedProfileIndex, true, true)
        }
    }

    componentDidUpdate() {
        let items:any[] = this.props.model.entityProfiles;
        this._selection.setItems(items, true);
        // set the first row selected when the component loads for the first time
        this._selection.setIndexSelected(this.props.model.selectedProfileIndex, true, true)
    }*/

    render() {
        console.log("-- profile summary selectedProfileIndex ", this.props.model.selectedProfileIndex);
        let content = <MessageBar messageBarType={MessageBarType.info}>No data available to display</MessageBar>;
        if(this.props.model.entityProfiles && this.props.model.entityProfiles.length >= 0) {
                content = <DetailsList columns={profileMatchesSummaryColumns}
                                       compact={true}
                                       checkboxVisibility={CheckboxVisibility.hidden}
                                       items={this.props.model.entityProfiles}
                                       layoutMode={DetailsListLayoutMode.justified}
                                       skipViewportMeasures={false}
                                       selectionMode={SelectionMode.single}
                                       constrainMode={ConstrainMode.unconstrained}
                                       selection={this._selection}
                                       selectionPreservedOnEmptyClick={true}
                                       enterModalSelectionOnTouch={true}
                                       onShouldVirtualize={this._onShouldVirtualize}/>
        }
        return (<div>
            <Details className={css("profile-summary")}
                     summary="Profile Summary"
                     open={true}
                     controlOnHeaderClick={true}
                     headerClassName={css(`profile-summary-ribbon`)}>
                     {content}
            </Details>
                <ProfileSummaryCommandBar {...this.props} />
            </div>
        );
    }
}
export { ProfileSummary, IProfileSummaryProps }

