import * as React from "react";
import { observer } from "mobx-react";
import IMECruiseModel from "../traveller/cruise/IMECruiseModel";
import { Pivot,PivotItem } from 'office-ui-fabric-react/lib/Pivot';
import CruiseBookingSummary from "./CruiseBookingSummary";
import ProfileMatchesDetails from "./traveller/common/ProfileMatchesDetailsList";
import AlertInfoSummary from "./traveller/common/AlertInfoSummary";
import BagExamsResultSummary from "./traveller/common/BagExamsResultSummary";
import BioDataHistory from "./traveller/common/BioDataHistory";
import PassportHistory from "./traveller/common/PassportHistory";
import CruiseVisaHistory from "./traveller/common/CruiseVisaHistory";
import MovementHistory from "./traveller/common/MovementHistory";
import {CruiseProfileMatchColumns} from "./traveller/common/ProfileMatchColumns";
import {CruiseBioDataHistoryColumns} from "./traveller/common/BioDataHistoryColumns";
import {CruisePassportHistoryColumns} from "./traveller/common/PassportHistoryColumns";
import {CruiseMovementHistoryColumns} from "./traveller/common/MovementsHistoryColumns";
import {CruiseAlertInfoColumns} from "./traveller/common/AlertInfoColumns";
import {CruiseBagExamsResultColumns} from "./traveller/common/BagExamsResultColumns";
import {CruiseAlertHistoryColumns} from "./traveller/common/AlertHistoryColumns";
import AlertHistorySummary from "./traveller/common/AlertHistorySummary";
import "./CruiseBooking.scss";
import MEHeader from "./MEHeader";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import CruiseBookingSummaryWrapper from "./traveller/cruise/CruiseBookingSummaryWrapper";
import CruisePassengers from "./traveller/cruise/CruisePassengers";
import CruisePassengerTravelDocs from "./traveller/cruise/CruisePassengerTravelDocs";
import CruiseBookingItinerary from "./traveller/cruise/CruiseBookingItinerary";
import CruiseBookingTravelAgents from "./traveller/cruise/CruiseBookingTravelAgents";

interface ICruiseBookingProps {
    model: IMECruiseModel;
}

@observer
class CruiseBooking extends React.Component<ICruiseBookingProps, any> {
    private _onRefresh = () => {
        this.props.model.refresh();
    }
    render() {
        return (
            <div className="cruise-booking">

                <MEHeader headerDetails = {this.props.model.meCase}
                          pnrSource = {this.props.model.bookingModel ?
                              this.props.model.bookingModel.booking ?
                                  this.props.model.bookingModel.booking.BookingRecordInfo : {}
                              : {}}
                          onRefresh={this._onRefresh}
                          icon={<Icon iconName='FerrySolid'/>} />
                <Pivot>
                    <PivotItem linkText={`${this.props.model.meCase.CaseID} - Summary`} itemKey="summary">
                        <CruiseBookingSummaryWrapper model={this.props.model.bookingModel}/>
                        <CruisePassengers model={this.props.model.bookingModel}/>
                        <CruisePassengerTravelDocs model={this.props.model.bookingModel}/>
                        <CruiseBookingItinerary model = {this.props.model.bookingModel}/>
                        <CruiseBookingTravelAgents model = {this.props.model.bookingModel}/>
                        <ProfileMatchesDetails model={this.props.model.profileMatchModel} profileColumns={CruiseProfileMatchColumns} showCurrentProfiles = {true} />
                        <BioDataHistory model={this.props.model.travellerHistoryModel} bioDataColumns={CruiseBioDataHistoryColumns}/>
                        <PassportHistory model={this.props.model.travellerHistoryModel} passportDataColumns={CruisePassportHistoryColumns}/>
                        <CruiseVisaHistory model={this.props.model.travellerHistoryModel}/>
                        <MovementHistory model={this.props.model.travellerHistoryModel} movementDataColumns = {CruiseMovementHistoryColumns}/>
                    </PivotItem>
                    <PivotItem linkText='Alert, Profile, Exam History' itemKey="alerts">
                        <AlertInfoSummary model={this.props.model.travellerHistoryModel} alertDataColumns = {CruiseAlertInfoColumns}/>
                        <AlertHistorySummary model={this.props.model.travellerHistoryModel} alertHistoryDataColumns = {CruiseAlertHistoryColumns}/>
                        <ProfileMatchesDetails model={this.props.model.profileMatchModel} profileColumns={CruiseProfileMatchColumns} showHistoricalProfiles={true} showCurrentProfiles={true}/>
                        <BagExamsResultSummary model={this.props.model.travellerHistoryModel} bagsExamDataColumns = {CruiseBagExamsResultColumns}/>
                    </PivotItem>
                </Pivot>
            </div>
        );
    }
}

export { CruiseBooking as default, CruiseBooking, ICruiseBookingProps }