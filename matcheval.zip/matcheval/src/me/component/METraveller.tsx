import * as React from "react";
import { observer } from "mobx-react";
import { MEDomainType } from "../IMECase";
import CruiseBooking from "./CruiseBooking";
import { css } from "office-ui-fabric-react/lib/Utilities";
import Details from "@twii/common/lib/component/Details";
import MEAirTraveller from "./MEAirTraveller";
import IMETravellerModel from "../traveller/IMETravellerModel";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECase} from "../IMECase";

interface IMEPortalProps {
    meTraveller: IMETravellerModel;
    meCase: IMECase;
}

@observer
class METraveller extends React.Component<IMEPortalProps, any> {
    render() {
        let content;
        if(this.props.meTraveller.air) {
            content = <MEAirTraveller model={this.props.meTraveller.air} businessDomainType={this.props.meCase.BusinessDomain} />;
        } else if(this.props.meTraveller.sea) {
            content = <CruiseBooking model={this.props.meTraveller.sea} />;
        } else {
            //console.log("this.props.meTraveller = ", this.props.meTraveller);
            content = <MessageBar messageBarType={MessageBarType.warning}>No Traveller Information Available</MessageBar>;
        }
        return content;
    }
}

export { METraveller as default, METraveller, IMEPortalProps }