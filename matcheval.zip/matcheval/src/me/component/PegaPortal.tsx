import * as React from "react";
import Details from "@twii/common/lib/component/Details"
import {IMECase} from "../IMECase";
import IAppHost from "@twii/common/lib/IAppHost";
import "./PegaPortal.scss";

interface IPegaPortalProps {
    url?: string;
    host?: IAppHost;
    onMessage?: (meCase : IMECase) => void;
}

class PegaPortal extends React.Component<IPegaPortalProps, any> {
    private _frameRef : HTMLIFrameElement;
    private _reloadFrame : boolean = false;
    private _containerRef : HTMLDivElement;
    private _onMessage = (e : MessageEvent) => {
        // !IMPORTNAT
        // DO NOT DELETE THE BELOW CONSOLE.LOG
        // !IMPORTANT
        console.log("-- The Message ", e);
        let parseJson;
        if(this.props.onMessage) {
            if (typeof e.data === "string") {
                parseJson = JSON.parse(e.data)
            }
            else {
                parseJson = e.data;
            }
            this.props.onMessage(parseJson);
        }
    }
    private _onHostResize = () => {
        const bounds = this._containerRef.getBoundingClientRect();
        if(bounds.height > 0) {
            if(this._reloadFrame) {
                this._reloadFrame = false;
                this._frameRef.src = this.props.url || "/prweb/PRServletContainerAuth";
            }
        } else {
            this._frameRef.src = "about:blank";
            this._reloadFrame = true;
        }
        this._frameRef.width = String(bounds.width);
        this._frameRef.height = String(bounds.height);
    }
    componentDidMount() {
        // we shouldn't be using this - this should only be using the frame instance
        if (window.addEventListener) {
            window.addEventListener("message", this._onMessage);
        }
        if(this.props.host) {
            this.props.host.addEventListener("resize", this._onHostResize);
            this._onHostResize();
        }
    }
    componentWillUnmount() {
        if(window.removeEventListener) {
            window.removeEventListener("message", this._onMessage);
        }
        if(this.props.host) {
            this.props.host.removeEventListener("resize", this._onHostResize);
        }
        if(this._frameRef) {
            this._frameRef.src = "about:blank";
        }
        this._reloadFrame = false;
    }

    private _onFrameRef = (ref : HTMLIFrameElement) => {
        this._frameRef = ref;
    };
    private _onContainerRef = (ref : HTMLDivElement) => {
        this._containerRef = ref;
    }
    private _onFrameLoaded = (e : React.SyntheticEvent<HTMLIFrameElement>) => {
         const frame = e.target as HTMLIFrameElement;
         frame.contentWindow.addEventListener("message", this._onMessage);
    };
    render() {
        return (
            <div className="me-portal" ref={this._onContainerRef}>
                <iframe className="me-portal-frame" src={this.props.url || "/prweb/PRServletContainerAuth"} width={"100%"} height={400} ref={this._onFrameRef} onLoad={this._onFrameLoaded} />
            </div>
        );
    }
}


export { PegaPortal as default, PegaPortal, IPegaPortalProps }