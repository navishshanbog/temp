import * as React from 'react';
import { observer } from "mobx-react";
import "./VisaHistory.scss";
import ITravellerHistoryModel from "../../../traveller/travelhistory/ITravellerHistoryModel";
import METravellerDetailsList from "../../METravellerDetailsList";
import {AirVisaDataHistoryColumns} from "./VisaHistoryColumns";

interface IMEHistoricalIATTravellersProps {
    model: ITravellerHistoryModel;
}


@observer
class AirVisaHistory extends React.Component<IMEHistoricalIATTravellersProps, any> {

    render() {
        return(
            <METravellerDetailsList
                           label="Visa History"
                           className="visas"
                           columns={AirVisaDataHistoryColumns}
                           items={this.props.model.visas}
                           sync={this.props.model.sync}/>
        );
    }
}
export {AirVisaHistory as default, AirVisaHistory, IMEHistoricalIATTravellersProps}