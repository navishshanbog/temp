import {
    IColumn, 
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import IAlertMovementInfo from "../../../../risk/traveller/iat/IAlertMovementInfo";
import * as DateUtils from "@twii/common/lib/util/Date";

const LocalScheduledDate: IColumn = {
    key: "localScheduledDate",
    ariaLabel: "Local Scheduled Date",
    name: "Local Scheduled Date",
    fieldName: "localScheduledDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120,
    onRender: (item: IAlertMovementInfo) => {
        return DateUtils.dateToOutputText(item.localScheduledDate);
    }
};

const LocalPortCode: IColumn = {
    key: "localPortCode",
    ariaLabel: "Local Port Code",
    name: "Local Port Code",
    fieldName: "localPortCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 100
};

const AlertNumber: IColumn = {
    key: "alertNumber",
    ariaLabel: "Alert Number",
    name: "Alert Number",
    fieldName: "alertNumber",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120
};

const MatchCategoryCode: IColumn = {
    key: "matchCategoryCode",
    ariaLabel: "Match Category Code",
    name: "Match Category Code",
    fieldName: "matchCategoryCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120
};

const BIDSelectStatus: IColumn = {
    key: "BIDSelectStatus",
    ariaLabel: "BID Select Status",
    name: "BID Select Status",
    fieldName: "BIDSelectStatus",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120
};

const FIDSelectStatus: IColumn = {
    key: "FIDSelectStatus",
    ariaLabel: "FID Select Status",
    name: "FID Select Status",
    fieldName: "FIDSelectStatus",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120
};

const ExpectedMovementIndicator: IColumn = {
    key: "ExpectedMovementIndicator",
    ariaLabel: "Expected Movement Indicator",
    name: "Expected Movement Indicator",
    fieldName: "ExpectedMovementIndicator",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 130,
    maxWidth: 150
};


const IATTravellerId : IColumn = {
    key: "iatTravellerId",
    ariaLabel: "IAT Traveller ID",
    name: "IAT Traveller ID",
    fieldName: "iatTravellerId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120,
};

const AirAlertHistoryColumns : IColumn[] = [
    LocalScheduledDate,
    LocalPortCode,
    AlertNumber,
    MatchCategoryCode,
    BIDSelectStatus,
    FIDSelectStatus,
    ExpectedMovementIndicator
];

const CruiseAlertHistoryColumns : IColumn[] = [
    IATTravellerId,
    LocalScheduledDate,
    LocalPortCode,
    AlertNumber,
    MatchCategoryCode,
    BIDSelectStatus,
    FIDSelectStatus,
    ExpectedMovementIndicator
];

export {
    AirAlertHistoryColumns,
    CruiseAlertHistoryColumns,
    IATTravellerId,
    LocalScheduledDate,
    LocalPortCode,
    AlertNumber,
    MatchCategoryCode,
    BIDSelectStatus,
    FIDSelectStatus,
    ExpectedMovementIndicator

 };