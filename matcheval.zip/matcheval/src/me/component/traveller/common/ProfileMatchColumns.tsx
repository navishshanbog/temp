import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import * as DateUtils from "@twii/common/lib/util/Date";
import {IProfileMatchData} from "../../../traveller/profilematch/ProfileMatchModel";
import {formatToNISName, defaultDOBFormatForVisa} from "../../../MENameUtils";
import {ProfileActionIndicators} from "../../../ref/ProfileActionIndicator";
import * as StringUtils from "@twii/common/lib/util/String";

const PassengerTattoo : IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "Passenger tattoo",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 30,
    maxWidth: 30,
};

const PassengerNumber : IColumn = {
    key: "PassengerNumber",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerNumber",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 60,
};

const ActionInd: IColumn = {
    key: "ActionInd",
    ariaLabel: "Action Ind Desc",
    name: "Action Ind Desc",
    fieldName: "ActionInd",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 60,
    isMultiline : true,
    onRender: (item: IProfileMatchData) => {
        return StringUtils.isNotBlank(item.ActionInd) ?
            StringUtils.isNotBlank(item.ActionUserId) ? `${item.ActionUserId} - ${item.ActionInd}`: item.ActionInd :
        StringUtils.isNotBlank(item.ActionUserId) ? item.ActionUserId : "";
    }
};

const BioInformation: IColumn = {
    key: "BiographicBirthDate",
    ariaLabel: "Bio Information",
    name: "Bio Information",
    fieldName: "BiographicBirthDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 250,
    maxWidth: 250,
    isMultiline : true,
    onRender: (item: IProfileMatchData) => {
        let bioinfo;
        bioinfo = formatToNISName(item.BiographicFamilyName.toUpperCase(),
            item.BiographicGivenName, "",
            item.BiographicSexCode, "");
        bioinfo = item.BiographicBirthDate ? bioinfo.concat(defaultDOBFormatForVisa(item.BiographicBirthDate)) : bioinfo;
        return bioinfo;
    }
};

const Direction: IColumn = {
    key: "Direction",
    ariaLabel: "Direction",
    name: "Direction",
    fieldName: "Direction",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80
};

const AirRouteId: IColumn = {
    key: "RouteId",
    ariaLabel: "Flight",
    name: "Flight",
    fieldName: "RouteId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80
};

const CruiseRouteId: IColumn = {
    key: "RouteId",
    ariaLabel: "Route ID",
    name: "Route ID",
    fieldName: "RouteId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80
};


const LocalScheduleDate: IColumn = {
    key: "LocalScheduleDate",
    ariaLabel: "Date",
    name: "Date",
    fieldName: "LocalScheduleDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    onRender: (item: IProfileMatchData) => {
        return DateUtils.dateToOutputText(item.LocalScheduleDate);
    }
};

const LocalPortCode: IColumn = {
    key: "LocalPortCode",
    ariaLabel: "Port",
    name: "Port",
    fieldName: "LocalPortCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80
};

const ProfileName: IColumn = {
    key: "ProfileName",
    ariaLabel: "Profile Name",
    name: "Profile Name",
    fieldName: "ProfileName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 200,
    maxWidth: 200,
    isMultiline : true
};

const ProfileNote: IColumn = {
    key: "ProfileNote",
    ariaLabel: "Profile Notes",
    name: "Profile Notes",
    fieldName: "ProfileNote",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 400,
    maxWidth: 500
};

const ResultId: IColumn = {
    key: "ResultId",
    ariaLabel: "Result ID",
    name: "Result ID",
    fieldName: "ResultId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 200,
    maxWidth: 200
};


const IATTravellerID: IColumn = {
    key: "IATTravellerID",
    ariaLabel: "IAT Traveller ID",
    name: "IAT Traveller ID",
    fieldName: "IATTravellerID",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100
};

const ReasonForMatch: IColumn = {
    key: "ReasonForMatch",
    ariaLabel: "Reason For Match",
    name: "Reason For Match",
    fieldName: "ReasonForMatch",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 500,
    maxWidth: 500,
    isMultiline : true
};

const BioDiffInd: IColumn = {
    key: "BioDiffInd",
    ariaLabel: "Bio Diff",
    name: "Bio Diff",
    fieldName: "BioDiffInd",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 150,
    isMultiline : true
};

const DismissalReason: IColumn = {
    key: "DismissalReason",
    ariaLabel: "Dismissal Reason",
    name: "Dismissal Reason",
    fieldName: "DismissalReason",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100
};

const AirProfileMatchColumns : IColumn[] = [
    PassengerTattoo,
    ActionInd,
    BioInformation,
    Direction,
    AirRouteId,
    LocalScheduleDate,
    LocalPortCode,
    ProfileName,
    ResultId,
    IATTravellerID,
    DismissalReason,
    ReasonForMatch
];

const CruiseProfileMatchColumns : IColumn[] = [
    PassengerNumber,
    IATTravellerID,
    ActionInd,
    BioInformation,
    Direction,
    CruiseRouteId,
    LocalScheduleDate,
    LocalPortCode,
    ProfileName,
    ResultId,
    BioDiffInd,
    DismissalReason,
    ReasonForMatch
];

export {
    AirProfileMatchColumns,
    CruiseProfileMatchColumns,
    PassengerTattoo,
    PassengerNumber,
    ActionInd,
    BioInformation,
    Direction,
    CruiseRouteId,
    LocalScheduleDate,
    LocalPortCode,
    ProfileName,
    AirRouteId,
    BioDiffInd,
    IATTravellerID,
    DismissalReason,
    ReasonForMatch
};