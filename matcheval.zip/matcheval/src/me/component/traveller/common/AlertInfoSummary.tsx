import * as React from 'react';
import { observer } from "mobx-react";
import ITravellerHistoryModel from "../../../traveller/travelhistory/ITravellerHistoryModel";
import "./AlertInfoDetailsList.scss";
import METravellerDetailsList from "../../METravellerDetailsList";

interface MEAlertInfoSummaryProps {
    model: ITravellerHistoryModel;
    alertDataColumns?: any;
}


@observer
class MEAlertInfoSummary extends React.Component<MEAlertInfoSummaryProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Alerts"
                           className="alert-info"
                           columns={this.props.alertDataColumns}
                           items={this.props.model.alerts}
                           sync={this.props.model.sync}/>
        );
    }

}

export { MEAlertInfoSummary as default, MEAlertInfoSummary, MEAlertInfoSummaryProps }