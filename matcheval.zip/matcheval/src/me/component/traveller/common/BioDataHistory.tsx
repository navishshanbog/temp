import * as React from 'react';
import { observer } from "mobx-react";
import "./BioDataHistory.scss";
import ITravellerHistoryModel from "../../../traveller/travelhistory/ITravellerHistoryModel";
import METravellerDetailsList from "../../METravellerDetailsList";

interface IBioDataViewProps {
    model: ITravellerHistoryModel;
    bioDataColumns?: any;
}


@observer
class BioDataHistory extends React.Component<IBioDataViewProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Bio Data History"
                           className="bio-data"
                           columns={this.props.bioDataColumns}
                           items={this.props.model.bioDataItems}
                           sync={this.props.model.sync}/>
        );
    }
}
export {BioDataHistory as default, BioDataHistory, IBioDataViewProps}