import * as React from 'react';
import { observer } from "mobx-react";
import ITravellerHistoryModel from "../../../traveller/travelhistory/ITravellerHistoryModel";
import "./BagExamsResultDetailsList.scss";
import METravellerDetailsList from "../../METravellerDetailsList";

interface MEBagExamsResultSummaryProps {
    model: ITravellerHistoryModel;
    bagsExamDataColumns?: any;
}


@observer
class BagExamsResultSummary extends React.Component<MEBagExamsResultSummaryProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Exams History"
                           className="bags-exams"
                           columns={this.props.bagsExamDataColumns}
                           items={this.props.model.bagsExamResults}
                           sync={this.props.model.sync} />
        );
    }
}

export { BagExamsResultSummary as default, BagExamsResultSummary, MEBagExamsResultSummaryProps }