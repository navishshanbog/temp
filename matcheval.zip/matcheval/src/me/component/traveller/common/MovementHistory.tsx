import * as React from 'react';
import { observer } from "mobx-react";
import "./MovementHistory.scss";
import METravellerDetailsList from "../../METravellerDetailsList";
import ITravellerHistoryModel from "../../../traveller/travelhistory/ITravellerHistoryModel";

interface IMovementsProps {
    model: ITravellerHistoryModel;
    movementDataColumns?: any;
}

@observer
class MovementsHistory extends React.Component<IMovementsProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Movement History"
                           className="movements"
                           columns={this.props.movementDataColumns}
                           items={this.props.model.movementItems}
                           sync={this.props.model.sync}/>
        );
    }
}
export {MovementsHistory as default, MovementsHistory, IMovementsProps}