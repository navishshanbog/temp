import * as React from "react";
import { Link } from "office-ui-fabric-react/lib/Link";
import IPNRRecordKey from "../../../../risk/traveller/pnr/IPNRRecordKey";
import * as StringUtils from "@twii/common/lib/util/String";
import { Label } from 'office-ui-fabric-react/lib/Label';
import AppContext from "@twii/common/lib/AppContext";
import { IMECase, MEDomainType, AD_GENERATED_CASE, MEBusinessDomainType } from "../../../IMECase";
import * as DateUtils from "@twii/common/lib/util/Date";
import "./LinkedPNRItem.scss";

const mapLinkItemToMECase = function(item: any): IMECase {
    var meCase:IMECase = {
        "CaseID": item.RecordLocator,
        "DomainType": MEDomainType.Air,  // No PNR links for SEA/Cruise.
        "BookingSystemCode": item.BookingSystemCode,
        "CreationTs": DateUtils.dateToTimestampDataText(item.PNRCreationTimeStamp, false).substring(0,19),
        "RecordLocator": item.RecordLocator,
        "BusinessDomain" : MEBusinessDomainType.Traveller,
        "CaseType": "",
        "DirectionCode": "",
        "IATTravellerID": "",
        "LocalPortCode": "",
        "LocalScheduleDate": "",
        "ParentRouteId": "",
        "RouteId": "",
        "TravelDocCntryCode": "",
        "TravelDocId": "",
        "Type": "",
        "Action": AD_GENERATED_CASE
    };
    return meCase;
};

interface ILinkedPNRItemProps {
    linkedPNR?: IPNRRecordKey;
    index?: number;
}

class LinkedPNRItem extends React.Component<ILinkedPNRItemProps, any> {

    _handleClick = (ev : React.MouseEvent<HTMLElement>) => {
        ev.stopPropagation();
        var meCase = mapLinkItemToMECase(this.props.linkedPNR);
        let customHeight = window.innerHeight;
        let customWidth = window.outerWidth - 5;
        const windowFeatures = `menubar=no,location=no,resizable=yes,scrollbars=yes,status=yes,width=`+customWidth+`,height=`+customHeight+`,left=200`;
        let customWindow = window.open(AppContext.value.rootAppHost.getUrl({ path: "/me/traveller", query: meCase }), meCase.CaseID, windowFeatures);
        customWindow.moveTo(0,0);
    };

    render() {
        let customHeight = window.innerHeight;
        let customWidth = window.outerWidth - 5;
        let content;
        if ((StringUtils.isNotBlank(this.props.linkedPNR.RecordLocator))
            && (StringUtils.isNotBlank(this.props.linkedPNR.BookingSystemCode))) {
            if (this.props.linkedPNR.PNRCreationTimeStamp && StringUtils.isNotBlank(this.props.linkedPNR.PNRCreationTimeStamp.toDateString())) {
                if (this.props.index > 0) {
                    content = <span className="linked-pnr-item"> | <Link className="linked-pnr-inline" key={this.props.linkedPNR.RecordLocator + this.props.linkedPNR.BookingSystemCode + this.props.linkedPNR.PNRCreationTimeStamp}
                                                                         onClick={this._handleClick }>{" "+ this.props.linkedPNR.RecordLocator + "(" + this.props.linkedPNR.BookingSystemCode + ") "}
                    </Link></span>
                } else {
                    content = <span className="linked-pnr-item"><Link className="linked-pnr-inline" key={this.props.linkedPNR.RecordLocator + this.props.linkedPNR.BookingSystemCode + this.props.linkedPNR.PNRCreationTimeStamp}
                                                                      onClick={this._handleClick }>{" "+ this.props.linkedPNR.RecordLocator + "(" + this.props.linkedPNR.BookingSystemCode + ") "}
                    </Link></span>
                }
            } else {
                if (this.props.index > 0) {
                    content =
                        <span className="linked-pnr-item"> | <Label  className="linked-pnr-inline">{" "+ this.props.linkedPNR.RecordLocator + "(" + this.props.linkedPNR.BookingSystemCode + ") "}</Label> </span>
                } else {
                    content =
                        <span className="linked-pnr-item"><Label  className="linked-pnr-inline">{" "+ this.props.linkedPNR.RecordLocator + "(" + this.props.linkedPNR.BookingSystemCode + ") "}</Label></span>
                }
            }
        } else {
            if ((StringUtils.isNotBlank(this.props.linkedPNR.RecordLocator))) {
                if (this.props.index > 0) {
                    content = <span className="linked-pnr-item"> | <Label  className="linked-pnr-inline">{" "+ this.props.linkedPNR.RecordLocator +" "}</Label> </span>
                } else {
                    content = <span className="linked-pnr-item"><Label  className="linked-pnr-inline">{" "+ this.props.linkedPNR.RecordLocator +" "}</Label></span>
                }
            } else {
                if (this.props.index > 0) {
                    content = <span className="linked-pnr-item"> | <Label  className="linked-pnr-inline">{" "+ this.props.linkedPNR.BookingSystemCode +" "}</Label> </span>
                } else {
                    content = <span className="linked-pnr-item"><Label  className="linked-pnr-inline">{" "+ this.props.linkedPNR.BookingSystemCode + " "}</Label></span>
                }
            }
        }
        return (content);
    }
}

export { LinkedPNRItem as default, LinkedPNRItem, ILinkedPNRItemProps };