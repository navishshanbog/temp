import * as React from "react";
import { observer } from "mobx-react";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import otherCommentColumns from "./OtherCommentColumns";
import "./OtherComment.scss";
import METravellerDetailsList from "../../METravellerDetailsList";

interface SKSummaryProps {
    model: IMESummaryModel;
}


@observer
class MEOtherComment extends React.Component<SKSummaryProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="SK - Other Comments"
                            className="other-comment"
                            columns={otherCommentColumns}
                            items={this.props.model.otherCommentInfo}
                            sync={this.props.model.sync} />
        );

    }
}

export { MEOtherComment as default, MEOtherComment, SKSummaryProps }