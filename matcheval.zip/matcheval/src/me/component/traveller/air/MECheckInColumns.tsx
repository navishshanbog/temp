import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import ICheckinBoarding from "../../../../risk/traveller/pnr/ICheckinBoarding";
import IItinerary from "../../../../risk/traveller/pnr/IItinerary";
import * as DateUtils from "@twii/common/lib/util/Date";

const PT : IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 40,
};

const ST : IColumn = {
    key: "ST",
    ariaLabel: "ST",
    name: "ST",
    fieldName: "ST",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 40,
    onRender: (item: ICheckinBoarding) => {
        return item.SegmentTattoo;
    }

};

const Route : IColumn = {
    key: "Route",
    ariaLabel: "Route",
    name: "Route",
    fieldName: "Route",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 100,
};

const RouteId : IColumn = {
    key: "RouteId",
    ariaLabel: "Route ID",
    name: "Route ID",
    fieldName: "RouteId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const DepartureLocal : IColumn = {
    key: "DepartureTimeStamp",
    ariaLabel: "Departure (Local)",
    name: "Departure (Local)",
    fieldName: "DepartureTimeStamp",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 140
};

const CheckinSurname : IColumn = {
    key: "familyName",
    ariaLabel: "Check-in Surname",
    name: "Check-in Surname",
    fieldName: "familyName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120,
    onRender: (item: ICheckinBoarding) => {
        return item.CheckInInfo.personInfo.familyName;
    }
};

const CheckinGivenNames : IColumn = {
    key: "givenName",
    ariaLabel: "Check-in Given Names",
    name: "Check-in Given Names",
    fieldName: "givenName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 140,
    onRender: (item: ICheckinBoarding) => {
        return item.CheckInInfo.personInfo.givenName;
    }
};

const CISeq : IColumn = {
    key: "CheckinSequence",
    ariaLabel: "Check-in Sequence",
    name: "Check-in Sequence",
    fieldName: "CheckinSequence",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 90,
    maxWidth: 100,
    onRender: (item: ICheckinBoarding) => {
        return item.CheckInInfo.CheckinSequence;
    }
};

const CheckinDateTime : IColumn = {
    key: "CheckinDateTime",
    ariaLabel: "Check-in Date Time",
    name: "Check-in Date Time",
    fieldName: "CheckinDateTime",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120,
    onRender: (item: ICheckinBoarding) => {
        return (item.CheckInInfo && item.CheckInInfo.checkInDateTime) ? item.CheckInInfo.checkInDateTime : "";
    }
};

const CheckinAgent : IColumn = {
    key: "checkInAgent",
    ariaLabel: "Check-in Agent",
    name: "Check-in Agent",
    fieldName: "checkInAgent",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 100,
    onRender: (item: ICheckinBoarding) => {
        return item.CheckInInfo.checkInAgent? item.CheckInInfo.checkInAgent : "";
    }
};

const CheckinCity : IColumn = {
    key: "checkInPortCode",
    ariaLabel: "Check-in City",
    name: "Check-in City",
    fieldName: "checkInPortCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120,
    onRender: (item: ICheckinBoarding) => {
        return item.CheckInInfo.checkInPortCode? item.CheckInInfo.checkInPortCode : "";
    }
};

const AllocSeat : IColumn = {
    key: "AllocatedSeat",
    ariaLabel: "Alloc Seat",
    name: "Alloc Seat",
    fieldName: "AllocatedSeat",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const SeatReq : IColumn = {
    key: "RequestedSeat",
    ariaLabel: "Seat Request",
    name: "Seat Request",
    fieldName: "RequestedSeat",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const CabinClass : IColumn = {
    key: "CabinClass",
    ariaLabel: "Cabin Class",
    name: "Cabin Class",
    fieldName: "CabinClass",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};
const SepSeat : IColumn = {
    key: "SeparateSeatInd",
    ariaLabel: "Sep Seat",
    name: "Sep Seat",
    fieldName: "SeparateSeatInd",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 50,
    maxWidth: 80,
};

const SeatBoard : IColumn = {
    key: "SeatBoardingPort",
    ariaLabel: "Seat Board",
    name: "Seat Board",
    fieldName: "SeatBoardingPort",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const SeatDest : IColumn = {
    key: "SeatDestinationPort",
    ariaLabel: "Seat Dest",
    name: "Seat Dest",
    fieldName: "SeatDestinationPort",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 90,
    maxWidth: 90,
};

const BoardingStatus : IColumn = {
    key: "BoardingStatus",
    ariaLabel: "Boarding Status",
    name: "Boarding Status",
    fieldName: "BoardingStatus",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const GOSHO : IColumn = {
    key: "GoShowInd",
    ariaLabel: "GOSHO",
    name: "GOSHO",
    fieldName: "GoShowInd",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const NOSHO : IColumn = {
    key: "NoShowInd",
    ariaLabel: "NOSHO",
    name: "NOSHO",
    fieldName: "NoShowInd",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

// For Booking Summary - Check In
const checkInColumns : IColumn[] = [
    PT,
    ST,
    Route,
    RouteId,
    DepartureLocal,
    CheckinSurname,
    CheckinGivenNames,
    CISeq,
    CheckinDateTime,
    CheckinAgent,
    CheckinCity,
    AllocSeat,
    SeatReq,
    CabinClass,
    SepSeat,
    SeatBoard,
    SeatDest,
    BoardingStatus,
    GOSHO,
    NOSHO
];

export {
    checkInColumns as default,
    checkInColumns,
    PT,
    ST,
    Route,
    RouteId,
    DepartureLocal,
    CheckinSurname,
    CheckinGivenNames,
    CISeq,
    CheckinDateTime,
    CheckinAgent,
    CheckinCity,
    AllocSeat,
    SeatReq,
    CabinClass,
    SepSeat,
    SeatBoard,
    SeatDest,
    BoardingStatus,
    GOSHO,
    NOSHO
};