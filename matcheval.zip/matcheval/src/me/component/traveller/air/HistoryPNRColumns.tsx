import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import IHistoricalPNRRecord from "../../../../risk/traveller/pnr/IHistoricalPNRRecord";
import AppContext from "@twii/common/lib/AppContext";
import * as DateUtils from "@twii/common/lib/util/Date";
import { IMECase, MEDomainType, AD_GENERATED_CASE, MEBusinessDomainType } from "../../../IMECase";
import { Link } from "office-ui-fabric-react/lib/Link";
import {formatToNISName, defaultDOBFormat} from "../../../MENameUtils";


const mapLinkItemToMECase = function(item: any): IMECase {
    var meCase:IMECase = {
        "CaseID": item.RecordLocator,
        "DomainType": MEDomainType.Air,  // No PNR links for SEA/Cruise.
        "BookingSystemCode": item.Carrier,
        "CreationTs": DateUtils.dateToTimestampDataText(item.CreationTimeStamp, false).substring(0,19),
        "RecordLocator": item.RecordLocator,
        "BusinessDomain" : MEBusinessDomainType.Traveller,
        "CaseType": "",
        "DirectionCode": item.DirectionCode,
        "IATTravellerID": "",
        "LocalPortCode": item.LocalPortCode,
        "LocalScheduleDate": item.LocalScheduledDate,
        "ParentRouteId": "",
        "RouteId": item.RouteId,  // Note: this is not parentRouteId
        "TravelDocCntryCode": "", // can get this from historial pnr, but not mapped
        "TravelDocId": "", // can get this from historial pnr, but not mapped
        "Type": "",
        "Action": AD_GENERATED_CASE
    };
    return meCase;
};


const RESBio : IColumn = {
    key: "RESBio",
    ariaLabel: "Res Bio",
    name: "Res Bio",
    fieldName: "RESBio",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 180,
    onRender: (item: IHistoricalPNRRecord) => {
        if (item.PNRTraveller && item.PNRTraveller.Biographic) {
            let biographic = item.PNRTraveller.Biographic;
            var resBio = formatToNISName(biographic.familyName.toUpperCase(),
                biographic.givenName, "",
                biographic.sexCode, "");
            resBio = biographic.birthDate ? resBio.concat(defaultDOBFormat(biographic.birthDate)) : resBio;
            resBio = biographic.countryOfCitizenship ? resBio+" - "+(biographic.countryOfCitizenship) : resBio;
        }
        return resBio;
    }
};

const PT : IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 80,
    onRender: (item: IHistoricalPNRRecord) => {
        return item.PNRTraveller ? item.PNRTraveller.PassengerTattoo ? item.PNRTraveller.PassengerTattoo : "" :"";
    }
};

const Carrier : IColumn = {
    key: "Carrier",
    ariaLabel: "Host Airline",
    name: "Host Airline",
    fieldName: "Carrier",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const PNRPushCount : IColumn = {
    key: "PNRPushCount",
    ariaLabel: "Number of Pushes",
    name: "Number of Pushes",
    fieldName: "PNRPushCount",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100,
};

const LastReceivedTimeStamp : IColumn = {
    key: "LastReceivedTimeStamp",
    ariaLabel: "Last Received Date",
    name: "Last Received Date",
    fieldName: "LastReceivedTimeStamp",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 150,
    onRender: (item: IHistoricalPNRRecord) => {
        return DateUtils.dateToTimestampOutputText(item.LastReceivedTimeStamp);
    }

};

const RouteId : IColumn = {
    key: "RouteId",
    ariaLabel: "Route ID",
    name: "Route ID",
    fieldName: "RouteId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 100,
};

const DirectionCode : IColumn = {
    key: "DirectionCode",
    ariaLabel: "Direction",
    name: "Direction",
    fieldName: "DirectionCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const LocalPortCode : IColumn = {
    key: "LocalPortCode",
    ariaLabel: "Local Port",
    name: "Local Port",
    fieldName: "LocalPortCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150,
};

const LocalScheduledDate : IColumn = {
    key: "LocalScheduledDate",
    ariaLabel: "Local Scheduled Date",
    name: "Local Scheduled Date",
    fieldName: "LocalScheduledDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 150,
    onRender: (item: IHistoricalPNRRecord) => {
        return DateUtils.dateToOutputText(item.LocalScheduledDate);
    }
};

const RecordLocator : IColumn = {
    key: "RecordLocator",
    ariaLabel: "Record Locator",
    name: "Record Locator",
    fieldName: "RecordLocator",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120,
    onRender: (item : IHistoricalPNRRecord) => {
        let _handleClick = (ev : React.MouseEvent<HTMLElement>) => {
            ev.stopPropagation();
            var meCase = mapLinkItemToMECase(item);
            let customHeight = window.innerHeight;
            let customWidth = window.outerWidth - 5;
            const windowFeatures = `menubar=no,location=no,resizable=yes,scrollbars=yes,status=yes,width=`+customWidth+`,height=`+customHeight+`,left=200`;
            let customWindow = window.open(AppContext.value.rootAppHost.getUrl({ path: "/me/traveller", query: meCase }), meCase.CaseID, windowFeatures);
            customWindow.moveTo(0,0);
        };
        return <Link onClick={_handleClick}>{ String(item.RecordLocator) }</Link>;
    }
};

const CreationTimeStamp : IColumn = {
    key: "CreationTimeStamp",
    ariaLabel: "PNR Creation Timestamp",
    name: "PNR Creation Timestamp",
    fieldName: "CreationTimeStamp",
    minWidth: 120,
    maxWidth: 150,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    onRender: (item: IHistoricalPNRRecord) => {
        return DateUtils.dateToTimestampOutputText(item.CreationTimeStamp);
    }
};

// For History PNR - Traveller Summary
const historyPNRColumns : IColumn[] = [
    PT,
    RESBio,
    Carrier,
    RecordLocator,
    CreationTimeStamp,
    LocalScheduledDate,
    LocalPortCode,
    DirectionCode,
    RouteId,
    LastReceivedTimeStamp,
    PNRPushCount
];

export {
    historyPNRColumns as default,
    historyPNRColumns,
    PT,
    RESBio,
    Carrier,
    RecordLocator,
    CreationTimeStamp,
    LocalScheduledDate,
    LocalPortCode,
    DirectionCode,
    RouteId,
    LastReceivedTimeStamp,
    PNRPushCount
};