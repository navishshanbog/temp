import * as React from 'react';
import { observer } from "mobx-react";
import "./CheckIn.scss";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import checkInColumns from "./MECheckInColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface IActiveItineraryProps {
    model: IMESummaryModel;
}


@observer
class CheckIn extends React.Component<IActiveItineraryProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Check-in + Boarding"
                           className="checkin"
                           columns={checkInColumns}
                           items={this.props.model.checkinNboardingItems}
                           sync={this.props.model.sync} />
        );
    }
}
export {CheckIn as default, CheckIn, IActiveItineraryProps}