import * as React from 'react';
import { observer } from "mobx-react";
import "./BaggageDetails.scss";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import baggageDetailsColumns from "./BaggageDetailsColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface IBaggageDetailsProps {
    model: IMESummaryModel;
}

@observer
class MEBaggageDetails extends React.Component<IBaggageDetailsProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Baggage"
                           className="baggage-details"
                           columns={baggageDetailsColumns}
                           items={this.props.model.checkinNboardingItems}
                           sync={this.props.model.sync} />
        );
    }
}
export {MEBaggageDetails as default, MEBaggageDetails, IBaggageDetailsProps}