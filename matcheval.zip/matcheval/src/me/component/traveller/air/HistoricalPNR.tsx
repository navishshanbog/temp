import * as React from 'react';
import { observer } from "mobx-react";
import "./HistoricalPNR.scss";
import IMETSPNRModel from "../../../traveller/travellersummary/IMETSPNRModel";
import historyPNRColumns from "./HistoryPNRColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface IHistoricalDataProps {
    model: IMETSPNRModel;
}

@observer
class HistoricalPNR extends React.Component<IHistoricalDataProps, any> {

    render() {
        let displayPanel;
            displayPanel = <METravellerDetailsList
                                          label="Historical PNR"
                                          className="historical-pnr"
                                          columns={historyPNRColumns}
                                          items={this.props.model.pnrRecords}
                                          sync={this.props.model.sync}/>
        return ( displayPanel );
    }

}


export {HistoricalPNR as default, HistoricalPNR, IHistoricalDataProps}
