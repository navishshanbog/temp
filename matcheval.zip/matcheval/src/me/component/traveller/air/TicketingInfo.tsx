import * as React from 'react';
import { observer } from "mobx-react";
import "./TicketingInfo.scss";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import ticketingInfoColumns from "./TicketingInfoColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface ITicketingInfoProps {
    model: IMESummaryModel;
}


@observer
class TicketingInfo extends React.Component<ITicketingInfoProps, any> {
    render() {
        return (<METravellerDetailsList label= "Ticketing"
                       className="ticketing-info"
                       columns={ticketingInfoColumns}
                       items={this.props.model.ticketingInfo}
                       sync={this.props.model.sync} />
        );
    }
}
export {TicketingInfo as default, TicketingInfo, ITicketingInfoProps}