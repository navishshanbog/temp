import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import * as DateUtils from "@twii/common/lib/util/Date";
import IPNRHistory from "../../../../risk/traveller/pnr/IPNRHistory";
import PNRHistoryActionCd from "../../../ref/PNRHistoryActionCd";
import PNRHistoryElementCd from "../../../ref/PNRHistoryElementCd";

const Prev: IColumn = {
    key: "PrevPNREnvelopeNum",
    ariaLabel: "Prev",
    name: "Prev",
    fieldName: "Prev",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100
};

const Current: IColumn = {
    key: "NewPNREnvelopeNum",
    ariaLabel: "Current",
    name: "Current",
    fieldName: "NewPNREnvelopeNum",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150
};

const Action: IColumn = {
    key: "Action",
    ariaLabel: "Action",
    name: "Action",
    fieldName: "Action",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: function(item: IPNRHistory) {
        return item.Action? PNRHistoryActionCd.getDesc(item.Action): "";
    }
};

const Element: IColumn = {
    key: "Element",
    ariaLabel: "Element",
    name: "Element",
    fieldName: "Element",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: function(item: IPNRHistory) {
        return item.Element? PNRHistoryElementCd.getDesc(item.Element): "";
    }
};

const HistoryData: IColumn = {
    key: "HistoryData",
    ariaLabel: "PNR History",
    name: "PNR History",
    fieldName: "HistoryData",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 800,
    maxWidth: 1000,
};

const CreatorIATACode: IColumn = {
    key: "CreatorIATACode",
    ariaLabel: "IATA Code",
    name: "IATA Code",
    fieldName: "CreatorIATACode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 100
};

const CreatorId: IColumn = {
    key: "CreatorId",
    ariaLabel: "Agent",
    name: "Agent",
    fieldName: "CreatorId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150
};

const CreationTimeStamp: IColumn = {
    key: "CreationTimeStamp",
    ariaLabel: "Creation Date Time (Z)",
    name: "Creation Date Time (Z)",
    fieldName: "CreationTimeStamp",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: (item: IPNRHistory) => {
        return DateUtils.dateToTimestampOutputText(item.CreationTimeStamp);
    }
};

const CreatorCityCode: IColumn = {
    key: "CreatorCityCode",
    ariaLabel: "City",
    name: "City",
    fieldName: "CreatorCityCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150
};

const CreatorCompanyId: IColumn = {
    key: "CreatorCompanyId",
    ariaLabel: "Coy",
    name: "Coy",
    fieldName: "CreatorCompanyId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 200,
    maxWidth: 200
};

const pnrHistoryColumns : IColumn[] = [

    Action,
    Element,
    HistoryData,
    CreatorIATACode,
    CreatorId,
    CreationTimeStamp,
    CreatorCityCode,
    CreatorCompanyId
];

export {
    pnrHistoryColumns as default,
    pnrHistoryColumns,
    Action,
    Element,
    HistoryData,
    CreatorIATACode,
    CreatorId,
    CreationTimeStamp,
    CreatorCityCode,
    CreatorCompanyId
};