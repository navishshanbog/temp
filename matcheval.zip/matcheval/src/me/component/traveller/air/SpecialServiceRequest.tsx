import * as React from "react";
import { observer } from "mobx-react";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import specialServiceRequestColumns from "./SpecialServiceRequestColumns";
import "./SpecialServiceRequest.scss";
import METravellerDetailsList from "../../METravellerDetailsList";

interface SSRSummaryProps {
    model: IMESummaryModel;
}


@observer
class SpecialServiceRequest extends React.Component<SSRSummaryProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="SSR-Special Service Request"
                           className="special-service-request"
                           columns={specialServiceRequestColumns}
                           items={this.props.model.specialServiceReqInfo}
                           sync={this.props.model.sync}/>

        );
    }
}



export { SpecialServiceRequest as default, SpecialServiceRequest, SSRSummaryProps }