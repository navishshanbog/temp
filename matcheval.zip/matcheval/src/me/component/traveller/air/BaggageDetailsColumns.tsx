import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import ICheckinBoarding from "../../../../risk/traveller/pnr/ICheckinBoarding";
import * as DateUtils from "@twii/common/lib/util/Date";

const PT : IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 40,
    onRender: (item: ICheckinBoarding) => {
        return item.PassengerTattoo;
    }
};

const ST : IColumn = {
    key: "ST",
    ariaLabel: "ST",
    name: "ST",
    fieldName: "ST",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 40,
    onRender: (item: ICheckinBoarding) => {
        return item.SegmentTattoo;
    }
};

const Route : IColumn = {
    key: "Route",
    ariaLabel: "Route",
    name: "Route",
    fieldName: "Route",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 100,
};

const RouteId : IColumn = {
    key: "RouteId",
    ariaLabel: "Route Id",
    name: "Route Id",
    fieldName: "RouteId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const DepartureLocal : IColumn = {
    key: "DepartureTimeStamp",
    ariaLabel: "Departure (Local)",
    name: "Departure (Local)",
    fieldName: "DepartureTimeStamp",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 100
};

const CheckinSurname : IColumn = {
    key: "CheckinSurname",
    ariaLabel: "Check-in Surname",
    name: "Check-in Surname",
    fieldName: "CheckinSurname",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 120,
    onRender: (item: ICheckinBoarding) => {
        return item.CheckInInfo.personInfo.familyName;
    }
};

const CheckinGivenNames : IColumn = {
    key: "CheckinGivenNames",
    ariaLabel: "Check-in Given Names",
    name: "Check-in Given Names",
    fieldName: "CheckinGivenNames",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 120,
    onRender: (item: ICheckinBoarding) => {
        return item.CheckInInfo.personInfo.givenName;
    }
};

const Bags : IColumn = {
    key: "BagsCount",
    ariaLabel: "Bags",
    name: "Bags",
    fieldName: "BagsCount",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 60,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.BagsCount;
    }
};

const TotalWeight : IColumn = {
    key: "TotalWeight",
    ariaLabel: "Total Weight",
    name: "Total Weight",
    fieldName: "TotalWeight",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 60,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.TotalWeight;
    }
};

const AverageWeight : IColumn = {
    key: "AvgWeight",
    ariaLabel: "Average Weight",
    name: "Average Weight",
    fieldName: "AvgWeight",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 60,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.AvgWeight;
    }
};

const Bagtags : IColumn = {
    key: "Tags",
    ariaLabel: "Bagtags",
    name: "Bagtags",
    fieldName: "Tags",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 160,
    maxWidth: 160,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.Tags;
    }
};

const BagBoard : IColumn = {
    key: "BoardingPort",
    ariaLabel: "Bag Board",
    name: "Bag Board",
    fieldName: "BoardingPort",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.BoardingPort
    }
};

const BagDest : IColumn = {
    key: "DestinationPort",
    ariaLabel: "Bag Dest",
    name: "Bag Dest",
    fieldName: "DestinationPort",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.DestinationPort
    }
};

const Interline : IColumn = {
    key: "InterlineInd",
    ariaLabel: "Interline",
    name: "Interline",
    fieldName: "InterlineInd",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 60,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.InterlineInd
    }
};

const Pool : IColumn = {
    key: "PoolId",
    ariaLabel: "Pool",
    name: "Pool",
    fieldName: "PoolId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 120,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.PoolId
    }
};

const PooledPax : IColumn = {
    key: "PooledPax",
    ariaLabel: "Pooled Pax",
    name: "Pooled Pax",
    fieldName: "PooledPax",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 120,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.TravellerInPoolCount
    }

};

const HOP : IColumn = {
    key: "HOPInd",
    ariaLabel: "HOP",
    name: "HOP",
    fieldName: "HOPInd",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
    onRender: (item: ICheckinBoarding) => {
        return item.BaggageInfo.HOPInd
    }
};

const baggageDetailsColumns : IColumn[] = [
    PT,
    ST,
    Route,
    RouteId,
    DepartureLocal,
    CheckinSurname,
    CheckinGivenNames,
    Bags,
    TotalWeight,
    AverageWeight,
    Bagtags,
    BagBoard,
    BagDest,
    Interline,
    Pool,
    PooledPax,
    HOP
];

export {
    baggageDetailsColumns as default,
    baggageDetailsColumns,
    PT,
    ST,
    Route,
    RouteId,
    DepartureLocal,
    CheckinSurname,
    CheckinGivenNames,
    Bags,
    TotalWeight,
    AverageWeight,
    Bagtags,
    BagBoard,
    BagDest,
    Interline,
    Pool,
    PooledPax,
    HOP
};