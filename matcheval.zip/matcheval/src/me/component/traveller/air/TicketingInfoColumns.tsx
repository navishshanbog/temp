import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import ITicketing from "../../../../risk/traveller/pnr/ITicketing";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as StringUtils from "@twii/common/lib/util/String";


const PT : IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 30,
};


const ST : IColumn = {
    key: "SegmentTattoo",
    ariaLabel: "ST",
    name: "ST",
    fieldName: "SegmentTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 30,
};

const TicketType : IColumn = {
    key: "TicketType",
    ariaLabel: "Ticket Type",
    name: "Ticket Type",
    fieldName: "TicketType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 40,
};

const TicketNumber : IColumn = {
    key: "TicketNumber",
    ariaLabel: "Ticket Number",
    name: "Ticket Number",
    fieldName: "TicketNumber",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 70,
};

const familyName : IColumn = {
    key: "FamilyName",
    ariaLabel: "Family Name",
    name: "Family Name",
    fieldName: "FamilyName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
    onRender: (item:ITicketing) => {
        let familyName = "";
        if(item.ReservationName) {
            familyName = item.ReservationName.familyName ?  item.ReservationName.familyName : "";
        }
        return familyName;
    }
};

const givenName : IColumn = {
    key: "givenName",
    ariaLabel: "Given Name",
    name: "Given Name",
    fieldName: "givenName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 180,
    onRender: (item:ITicketing) => {
        let givenName = "";
        if(item.ReservationName) {
            givenName = item.ReservationName ?  item.ReservationName.givenName : "";
        }
        return givenName;
    }
};



const ticketingInfoColumns : IColumn[] = [
    PT,
    ST,
    familyName,
    givenName,
    TicketType,
    TicketNumber
];

export {
    ticketingInfoColumns as default,
    ticketingInfoColumns,
    PT,
    ST,
    familyName,
    givenName,
    TicketType,
    TicketNumber
};


