import * as React from "react";
import { observer } from "mobx-react";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import otherServiceInformationColumns from "./OtherServiceInformationColumns";
import "./OtherServiceInformation.scss";
import METravellerDetailsList from "../../METravellerDetailsList";

interface OSISummaryProps {
    model: IMESummaryModel;
}


@observer
class OtherServiceInformation extends React.Component<OSISummaryProps, any> {

    render() {
        return (
            <METravellerDetailsList
                       label="OSI-Other Service Information"
                       className="other-service-information"
                       columns={otherServiceInformationColumns}
                       items={this.props.model.otherServiceInfo}
                       sync={this.props.model.sync}/>

        );
    }
}

export { OtherServiceInformation as default, OtherServiceInformation, OSISummaryProps }