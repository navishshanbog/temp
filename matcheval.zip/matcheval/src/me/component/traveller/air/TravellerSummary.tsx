import * as React from 'react';
import { observer } from "mobx-react";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import "./TravellerSummary.scss";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Error from "@twii/common/lib/component/Error";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import {travellerSummaryColumns1} from "./TravelSummaryColumns1";
import {travellerSummaryColumns2} from "./TravelSummaryColumns2";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {
    DetailsList,
    CheckboxVisibility,
    SelectionMode,
    DetailsRow,
    IDetailsRowProps,
} from "office-ui-fabric-react/lib/DetailsList";
import {createItemIndexColumn, getActionDisabledVariant} from "@twii/common/lib/component/ColumnHelper";

interface ITravellerSummaryProps {
    model: IMESummaryModel;
}


@observer
class TravellerSummary extends React.Component<ITravellerSummaryProps, any> {

    private _onRenderRow = (props : IDetailsRowProps) => {
        const row = <DetailsRow {...props} />;
        return <div className={css("traveller-summary-rows")}>{row}</div>;
    };

    private _addColumnIndexValue = (item: any) => {
        // May be something more tomorrow
    }

    render() {
        let customColumns1 = travellerSummaryColumns1;
        customColumns1 = [createItemIndexColumn(this._addColumnIndexValue)]
            .concat(getActionDisabledVariant(customColumns1));

        let customColumns2 = travellerSummaryColumns2;
        customColumns2 = [createItemIndexColumn(this._addColumnIndexValue)]
            .concat(getActionDisabledVariant(customColumns2));

        let content = <MessageBar messageBarType={MessageBarType.info}>No data available to display </MessageBar>;
        let content1 = <MessageBar messageBarType={MessageBarType.info}>No data available to display </MessageBar>;

        if(this.props.model.sync.syncing) {
            content = <Spinner label="Loading ..." className="load-spinner"/>;
        } else if(this.props.model.sync.error) {
            console.log("-- error ", this.props.model.sync.error);
            content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if(this.props.model.sync.hasSynced) {
            if (this.props.model.travelSummaryItems.length > 0) {
                    content = <DetailsList columns={customColumns1}
                                   compact={true}
                                   onRenderRow={this._onRenderRow}
                                   checkboxVisibility={CheckboxVisibility.hidden}
                                   selectionMode={SelectionMode.none}
                                   items={this.props.model.travelSummaryItems}/>
                    content1 =   <DetailsList columns={customColumns2}
                                      compact={true}
                                      onRenderRow={this._onRenderRow}
                                      checkboxVisibility={CheckboxVisibility.hidden}
                                      selectionMode={SelectionMode.none}
                                      items={this.props.model.travelSummaryItems}/>
            }
        }
            return(
            <Details className={css("traveller-summary", "me-section")}
                     summary="Traveller Summary"
                     open={true}
                     controlOnHeaderClick={true}
                     headerClassName={css("traveller-summary-ribbon")}>
                {content}
                {content1}
            </Details>

        );
    }
}
export {TravellerSummary as default, TravellerSummary, ITravellerSummaryProps}

