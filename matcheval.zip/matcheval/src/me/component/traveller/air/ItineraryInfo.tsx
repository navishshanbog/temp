import * as React from 'react';
import { observer } from "mobx-react";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import "./ItineraryInfo.scss";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import {MEDetailsAttribute} from "../../common/MEDetailsAttribute";
import Error from "@twii/common/lib/component/Error";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import * as DateUtils from "@twii/common/lib/util/Date";
import IPNRRecord from "../../../../risk/traveller/pnr/IPNRRecord";
import  IVesselScheduleModel  from "../../../traveller/IVesselScheduleModel";
import IVesselItinerary from "../../../../risk/traveller/vessel/response/IVesselItinerary";

interface IItineraryInfoProps {
    model?: IMESummaryModel;
    vesselModel: IVesselScheduleModel;

}

const ItineraryInfoFields = [
    {
        key: "OriginalPortCode",
        name: "Original Port",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.OriginalPortCode ? source.BookingSummaryInfo.OriginalPortCode : "-": "-"} />
        }
    },
    {
        key: "OriginalCountryCode",
        name: "Original Country",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.OriginalCountryCode ? source.BookingSummaryInfo.OriginalCountryCode : "-": "-"} />
        }
    },

    {
        key: "DestinationPortCode",
        name: "Destination Port",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.DestinationPortCode ? source.BookingSummaryInfo.DestinationPortCode : "-": "-"} />
        }
    },
    {
        key: "DestinationCountryCode",
        name: "Destination Country",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.DestinationCountryCode ? source.BookingSummaryInfo.DestinationCountryCode : "-": "-"} />
        }
    },
    {
        key: "TotalLengthOfTrip",
        name: "Total Length Of Trip",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.TotalLengthOfTrip ? source.BookingSummaryInfo.TotalLengthOfTrip.toLocaleString() : "-": "-"} />
        }

    },
    {
        key: "TotalIntendedLengthOfTrip",
        name: "Intended Length of Trip",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.TotalIntendedLengthOfTrip ? source.BookingSummaryInfo.TotalIntendedLengthOfTrip.toLocaleString() : "-": "-"} />
        }

    },
    {
        key: "TotalLengthOfStay",
        name: "Total Length Of Stay",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.TotalLengthOfStay ? source.BookingSummaryInfo.TotalLengthOfStay.toLocaleString() : "-": "-"} />
        }

    },
    {
        key: "IntendedLengthOfStay",
        name: "Intended Length of Stay",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.IntendLengthOfStay ? source.BookingSummaryInfo.IntendLengthOfStay.toLocaleString() : "-": "-"} />
        }

    },
    /*
    Removed on request from Susan Campbell - 2
    {
        key: "OverallLengthOfStay",
        name: "Overall Length of Stay",
        onRender: (source: any, flightSource: any, field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.IntendLengthOfStay ? source.BookingSummaryInfo.IntendLengthOfStay : "-": "-"} />
        }

    },  */
    {
        key: "MostTimeSpentPort",
        name: "Most Time Spent Port",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.MostTimeSpentPort ? source.BookingSummaryInfo.MostTimeSpentPort : "-": "-"} />
        }

    },
    {
        key: "MostTimeSpentCountry",
        name: "Most Time Spent Country",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.MostTimeSpentCountry ? source.BookingSummaryInfo.MostTimeSpentCountry : "-": "-"} />
        }

    },
    {
        key:"MostTimeSpentDays",
        name: "Most Time Spent Days",
        onRender: (source:IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo? source.BookingSummaryInfo.MostTimeSpentDays ? source.BookingSummaryInfo.MostTimeSpentDays.toLocaleString() : "-": "-"} />
        }
    },
    {
        key:"IntentToTravelDate",
        name: "Intent to Travel",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            var intentTravelDt = source.BookingSummaryInfo ? DateUtils.dateToOutputText(source.BookingSummaryInfo.IntentToTravelDate)? DateUtils.dateToOutputText(source.BookingSummaryInfo.IntentToTravelDate) : "-": "-";
            return <MEDetailsAttribute label={field.name} key={field.key}  value={intentTravelDt}/>;
        }
    },
    {
        key: "ActiveSegmentCount",
        name: "Active Segment",
        headerClassName:"group-info-list-header",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo ? source.BookingSummaryInfo.ActiveSegmentCount? source.BookingSummaryInfo.ActiveSegmentCount.toLocaleString() : "0" : "0"}/>;
        }
    }, {
        key: "CancelledSegmentCount",
        name: "Cancelled Segment",
        headerClassName:"group-info-list-header",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value={source.BookingSummaryInfo ? source.BookingSummaryInfo.CancelledSegmentCount? source.BookingSummaryInfo.CancelledSegmentCount.toLocaleString() : "0" : "0"}/>;
        }
    }, {
        key: "CanberraArrivalDateTime",
        name: "Canberra Arrival Date & Time",
        headerClassName:"group-info-list-header",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            let cbrArrDt;
            if(flightSource) {
                flightSource.forEach((vSchedule) => {
                    cbrArrDt = vSchedule.CanberraArrivalDateTime;
                });
            }
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value = {cbrArrDt ? DateUtils.dateToTimestampOutputText(cbrArrDt) : "-"}/>;
        }
    }, {
        key: "CanberraDepartureDateTime",
        name: "Canberra Departure Date & Time",
        headerClassName:"group-info-list-header",
        onRender: (source: IPNRRecord, flightSource: IVesselItinerary[], field: any) => {
            let cbrDepDt;
            // there exists only one.. even though the services says its an array.
            if(flightSource) {
                flightSource.forEach((vSchedule) => {
                    cbrDepDt = vSchedule.CanberraDepartureDateTime;
                });
            }
            return <MEDetailsAttribute label={field.name} key={field.key}
                                       value = {cbrDepDt ? DateUtils.dateToTimestampOutputText(cbrDepDt) : "-"}/>;
        }
    }

]

@observer
class ItineraryInfo extends React.Component<IItineraryInfoProps, any> {
    render() {

        let content: any = <div> No data available to display </div>;

        if(this.props.model.sync.syncing) {
            content = <Spinner label="Loading ..." className="load-spinner"/>;
        } else if(this.props.model.sync.error) {
            console.log("-- error ", this.props.model.sync.error);
            content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if(this.props.model.sync.hasSynced) {
            if (this.props.model.bookingSummary!=null && this.props.model.bookingSummary!=undefined) {
                content = ItineraryInfoFields.map((field: any) => {
                    if (field.onRender) {
                        return field.onRender(this.props.model.bookingSummary, this.props.vesselModel.vesselSchedule, field);
                    }
                });
            }
        }
        return (
            <Details className={css("me-itinerary-info-details", "me-section")}
                     summary=" Itinerary Information "
                     open={true}
                     controlOnHeaderClick={true}
                     headerClassName={css("me-itinerary-info-details-header", "me-itinerary-info-ribbon")}
                     bodyClassName="me-itinerary-info-body">
                <div className="me-itinerary-info">
                    <div className="itinerary-info ms-Grid me-itinerary-info-details-section">
                        {content}
                    </div>
                </div>
            </Details>
        );
    }
}

export {ItineraryInfo as default, ItineraryInfo, IItineraryInfoProps}
