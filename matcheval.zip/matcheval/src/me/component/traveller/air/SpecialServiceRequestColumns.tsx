import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import ISpecialServiceRequest from "../../../../risk/traveller/pnr/ISpecialServiceRequest";

const PassengerTattoo: IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150,
};

const SegmentTattoo: IColumn = {
    key: "SegmentTattoo",
    ariaLabel: "ST",
    name: "ST",
    fieldName: "SegmentTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150,
};

const SSRCode: IColumn = {
    key: "SSRCode",
    ariaLabel: "SSR Code",
    name: "SSR Code",
    fieldName: "SSRCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150
};

const FreeTextValue: IColumn = {
    key: "FreeTextValue",
    ariaLabel: "SSR Free Text",
    name: "SSR Free Text",
    fieldName: "FreeTextValue",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 800,
    maxWidth: 800,
    isMultiline : true
};


const specialServiceRequestColumns : IColumn[] = [
    PassengerTattoo,
    SegmentTattoo,
    SSRCode,
    FreeTextValue,
];

export {
    specialServiceRequestColumns as default,
    specialServiceRequestColumns,
    PassengerTattoo,
    SegmentTattoo,
    SSRCode,
    FreeTextValue,
};

