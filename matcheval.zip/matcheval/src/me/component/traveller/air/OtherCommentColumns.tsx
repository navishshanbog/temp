import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";

const PassengerTattoo: IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150,
};

const SegmentTattoo: IColumn = {
    key: "SegmentTattoo",
    ariaLabel: "ST",
    name: "ST",
    fieldName: "SegmentTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150
};

const Type: IColumn = {
    key: "Type",
    ariaLabel: "SK Type",
    name: "SK Type",
    fieldName: "Type",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150
};

const Code: IColumn = {
    key: "Code",
    ariaLabel: "SK Code",
    name: "SK Code",
    fieldName: "Code",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 150,
    maxWidth: 150
};

const FreeTextValue: IColumn = {
    key: "FreeTextValue",
    ariaLabel: "SK Free Text",
    name: "SK Free Text",
    fieldName: "FreeTextValue",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 800,
    maxWidth: 800,
    isMultiline : true
};

const otherCommentColumns : IColumn[] = [
    PassengerTattoo,
    SegmentTattoo,
    Type,
    Code,
    FreeTextValue
];

export {
    otherCommentColumns as default,
    otherCommentColumns,
    PassengerTattoo,
    SegmentTattoo,
    Type,
    Code,
    FreeTextValue
};

