import * as React from 'react';
import { observer } from "mobx-react";
import "./TravellerContact.scss";
import METravellerDetailsList from "../../METravellerDetailsList";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import travellersContactColumns from "./TravellersContactColumns";

interface ITravellerContactProps {
    model: IMESummaryModel;
}


@observer
class TravellerContact extends React.Component<ITravellerContactProps, any> {

    render() {
        return(
            <METravellerDetailsList
                           label="Contacts"
                           className="traveller-contacts"
                           columns={travellersContactColumns}
                           items={this.props.model.travelContacts}
                           sync={this.props.model.sync}/>
        );
    }
}
export {TravellerContact as default, TravellerContact, ITravellerContactProps}