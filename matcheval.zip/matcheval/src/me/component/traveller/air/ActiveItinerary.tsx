import * as React from 'react';
import { observer } from "mobx-react";
import "./ActiveItinerary.scss";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import activeItineraryColumns from "./ActiveItineraryColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface IActiveItineraryProps {
    model: IMESummaryModel;
}


@observer
class ActiveItinerary extends React.Component<IActiveItineraryProps, any> {
    render() {
        return (<METravellerDetailsList
                       label="Active Itinerary"
                       className="active-itinerary"
                       columns={activeItineraryColumns}
                       items={this.props.model.activeItineraryItems}
                       sync={this.props.model.sync}/>
        );
    }
}
export {ActiveItinerary as default, ActiveItinerary, IActiveItineraryProps}