import * as React from "react";
import { observer } from "mobx-react";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import pnrHistoryColumns from "./PNRHistoryColumns";
import "./PNRHistorySummary.scss";
import METravellerDetailsList from "../../METravellerDetailsList";

interface PNRHistorySummaryProps {
    model: IMESummaryModel;
}


@observer
class PNRHistorySummary extends React.Component<PNRHistorySummaryProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="PNR History"
                           className="pnr-history-summary"
                           columns={pnrHistoryColumns}
                           items={this.props.model.pnrHistoryItems}
                           sync={this.props.model.sync}/>

        );
    }
}

export { PNRHistorySummary as default, PNRHistorySummary, PNRHistorySummaryProps }