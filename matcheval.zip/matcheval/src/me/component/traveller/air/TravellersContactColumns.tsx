import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";

const PassengerTattoo : IColumn = {
    key: "PassengerTattoo",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 40,
};
const ST : IColumn = {
    key: "SegmentTattoo",
    ariaLabel: "ST",
    name: "ST",
    fieldName: "SegmentTattoo",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 20,
    maxWidth: 40,
};
const Type : IColumn = {
    key: "Type",
    ariaLabel: "Contact Type",
    name: "Contact Type",
    fieldName: "Type",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 200,
    maxWidth: 250,
};

const FreeTextValue : IColumn = {
    key: "FreeTextValue",
    ariaLabel: "Contact Details",
    name: "Contact Details",
    fieldName: "FreeTextValue",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 200,
    maxWidth: 300,
};


const travellersContactColumns : IColumn[] = [
    PassengerTattoo,
    ST,
    Type,
    FreeTextValue
];

export {
    travellersContactColumns as default,
    travellersContactColumns,
    PassengerTattoo,
    ST,
    Type,
    FreeTextValue
};
