import * as React from 'react';
import { observer } from "mobx-react";
import "./Payments.scss";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import paymentColumns from "./PaymentsColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface IMEBookingSummaryProps {
    model: IMESummaryModel;
}


@observer
class Payments extends React.Component<IMEBookingSummaryProps, any> {

    render() {
        return(
        <METravellerDetailsList
                       label="Payment"
                       className="payments"
                       columns={paymentColumns}
                       items={this.props.model.paymentItems}
                       sync={this.props.model.sync} />
        );
    }
}
export {Payments as default, Payments, IMEBookingSummaryProps}