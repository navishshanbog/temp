import * as React from 'react';
import { observer } from "mobx-react";
import "./TravelAgents.scss";
import IMESummaryModel from "../../../traveller/summary/IMESummaryModel";
import travelAgentsColumns from "./TravelAgentsColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface IMEBookingSummaryProps {
    model: IMESummaryModel;
}


@observer
class MEBSTravelAgents extends React.Component<IMEBookingSummaryProps, any> {

    render() {

        return(
            <METravellerDetailsList
                           label="Travel Agents"
                           className="travel-agents"
                           columns={travelAgentsColumns}
                           items={this.props.model.travelAgents}
                           sync={this.props.model.sync}/>
        );
    }
}
export {MEBSTravelAgents as default, MEBSTravelAgents, IMEBookingSummaryProps}