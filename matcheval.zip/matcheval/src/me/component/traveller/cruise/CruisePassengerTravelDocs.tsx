import * as React from 'react';
import { observer } from "mobx-react";
import "./CruisePassengersTravelDocs.scss";
import ICruiseBookingModel from "../../../traveller/ICruiseBookingModel";
import cruisePassengerTravelDocColumns from "./CruisePassengerTravelDocColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface ICruiseDetailsProps {
    model?: ICruiseBookingModel;
}


@observer
class CruisePassengerTravelDocs extends React.Component<ICruiseDetailsProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Passenger Travel Documents"
                           className="passenger-travel-docs"
                           columns={cruisePassengerTravelDocColumns}
                           items={this.props.model.cruiseTravellerTravelDocs}
                           sync={this.props.model.sync} />
        );
    }
}
export {CruisePassengerTravelDocs as default, CruisePassengerTravelDocs, ICruiseDetailsProps}