import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import * as StringUtils from "@twii/common/lib/util/String";
import {IICruiseTraveller} from "../../../traveller/ICruiseBookingModel";

const PassengerNumber : IColumn = {
    key: "PassengerNumber",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerNumber",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 60,
    onRender: (item: IICruiseTraveller) => {
        return item.PassengerNumber;
    }
};

const familyName : IColumn = {
    key: "familyName",
    ariaLabel: "Family Name",
    name: "Family Name",
    fieldName: "familyName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic.familyName;
    }
};

const givenName: IColumn = {
    key: "givenName",
    ariaLabel: "Given Name",
    name: "Given Name",
    fieldName: "givenName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic.givenName;
    }
};

const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

const birthDate: IColumn = {
    key: "birthDate",
    ariaLabel: "DOB",
    name: "DOB",
    fieldName: "birthDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic.birthDate;
    }
};

const placeOfBirth: IColumn = {
    key: "placeOfBirth",
    ariaLabel: "Place of Birth",
    name: "Place of Birth",
    fieldName: "placeOfBirth",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic.placeOfBirth;
    }
};

const Email: IColumn = {
    key: "Email",
    ariaLabel: "Email",
    name: "Email",
    fieldName: "Email",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 200,
    maxWidth: 200,
    onRender: (item: IICruiseTraveller) => {
        let emails = "";
        let allEmails = [];
        if(item.Contacts) {
            if (item.Contacts.Contact) {
                item.Contacts.Contact.forEach((contactDetail) => {
                    if(contactDetail.Email) {
                        if(StringUtils.isNotBlank(contactDetail.Email) && allEmails.indexOf(contactDetail.Email.trim()) < 0) {
                            emails = StringUtils.isNotBlank(emails)? emails +" | "+contactDetail.Email.trim() : contactDetail.Email.trim();
                            allEmails.push(contactDetail.Email.trim())
                        }
                    }
                });
            }
        }
        return emails;
    }
};

const Phones: IColumn = {
    key: "HomePhoneNumber",
    ariaLabel: "Phone Numbers",
    name: "Phone Numbers",
    fieldName: "HomePhoneNumber",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150,
    onRender: (item: IICruiseTraveller) => {
        let phones = "";
        let allPhones = [];
        if(item.Contacts) {
            if (item.Contacts.Contact != null) {
                item.Contacts.Contact.forEach((contactDetail) => {
                    if(StringUtils.isNotBlank(contactDetail.HomePhoneNumber)) {
                        if(allPhones.indexOf(contactDetail.HomePhoneNumber.trim()) < 0) {
                            phones = StringUtils.isNotBlank(phones) ? phones + " | " + contactDetail.HomePhoneNumber.trim() : contactDetail.HomePhoneNumber.trim();
                            allPhones.push(contactDetail.HomePhoneNumber.trim())
                        }
                    }
                });
            }
        }
        return phones;
    }
};

const Address: IColumn = {
    key: "Address",
    ariaLabel: "Addresses",
    name: "Addresses",
    fieldName: "Address",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 300,
    maxWidth: 550,
    onRender: (item: IICruiseTraveller) => {
        let address = "";
        let allAddresses = [];
        if(item.Addresses) {
            if (item.Addresses.Address != null) {
                item.Addresses.Address.forEach((addressDetail) => {
                    var temp = addressDetail.Line1 ? addressDetail.Line1.trim() : "";
                    temp += addressDetail.PostCode ? addressDetail.PostCode.trim() : "";
                    temp += addressDetail.City ? addressDetail.City.trim() : "";
                    temp += addressDetail.State ? addressDetail.State.trim() : "";
                    if(allAddresses.indexOf(temp) < 0) {
                        address = StringUtils.isNotBlank(address) ? address + " | " + temp : temp;
                        allAddresses.push(temp)
                    }
                });
            }
        }
        return address;
    }
};

/*
const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

const sexCode: IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTraveller) => {
        return item.Biographic ? item.Biographic.sexCode ? item.Biographic.sexCode : "" : "";
    }
};

*/

const cruisePassengerColumns : IColumn[] = [
    PassengerNumber,
    familyName,
    givenName,
    sexCode ,
    birthDate,
    placeOfBirth,
    Email,
    Phones,
    Address
];


export {
    cruisePassengerColumns as default,
    cruisePassengerColumns,
    PassengerNumber,
    familyName,
    givenName,
    sexCode,
    birthDate,
    placeOfBirth,
    Email,
    Phones,
    Address
};