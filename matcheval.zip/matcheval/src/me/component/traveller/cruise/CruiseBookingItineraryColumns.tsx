import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import * as DateUtils from "@twii/common/lib/util/Date";
import ICruiseBookingItineraryType from "../../../../risk/traveller/cru/common/ICruiseBookingItinerary";


const CruiseItineraryNumber : IColumn = {
    key: "CruiseItineraryNumber",
    ariaLabel: "Itinerary Number",
    name: "Itinerary Number",
    fieldName: "CruiseItineraryNumber",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.CruiseItineraryNumber;
    }
};


const ArrivalDateTime : IColumn = {
    key: "ArrivalDateTime",
    ariaLabel: "Arrival DateTime",
    name: "Arrival DateTime",
    fieldName: "ArrivalDateTime",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100,
    onRender: (item: ICruiseBookingItineraryType) => {
        return DateUtils.dateToOutputText(item.ArrivalDateTime);
    }
};

const ArrivalPortCode : IColumn = {
    key: "ArrivalPortCode",
    ariaLabel: "Arrival Port Cd",
    name: "Arrival Port Cd",
    fieldName: "ArrivalPortCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.ArrivalPortCode;
    }
};

const ArrivalPortName : IColumn = {
    key: "ArrivalPortName",
    ariaLabel: "Arrival Port Name",
    name: "Arrival Port Name",
    fieldName: "ArrivalPortName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.ArrivalPortName;
    }
};

const ArrivalPortCountryCode: IColumn = {
    key: "ArrivalPortCountryCode",
    ariaLabel: "Arrival Port Country Cd",
    name: "Arrival Port Country Cd",
    fieldName: "ArrivalPortCountryCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.ArrivalPortCountryCode;
    }
};

const BoardingDateTime: IColumn = {
    key: "BoardingDateTime",
    ariaLabel: "Boarding DateTime",
    name: "Boarding DateTime",
    fieldName: "BoardingDateTime",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.BoardingDateTime;
    }
};

const DepartureDateTime: IColumn = {
    key: "DepartureDateTime",
    ariaLabel: "Departure DateTime",
    name: "Departure DateTime",
    fieldName: "DepartureDateTime",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.DepartureDateTime;
    }
};

const DeparturePortCode: IColumn = {
    key: "DeparturePortCode",
    ariaLabel: "Departure Port Code",
    name: "Departure Port Code",
    fieldName: "DeparturePortCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.DeparturePortCode;
    }
};

const DeparturePortName: IColumn = {
    key: "DeparturePortName",
    ariaLabel: "Departure Port Name",
    name: "Departure Port Name",
    fieldName: "DeparturePortName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ICruiseBookingItineraryType) => {
        return item.DeparturePortName;
    }
};

const cruiseBookingItineraryColumns : IColumn[] = [
    ArrivalDateTime,
    ArrivalPortCode,
    ArrivalPortName,
    ArrivalPortCountryCode ,
    BoardingDateTime,
    DepartureDateTime,
    DeparturePortCode,
    DeparturePortName
];


export {
    cruiseBookingItineraryColumns as default,
    cruiseBookingItineraryColumns,
    ArrivalDateTime,
    ArrivalPortCode,
    ArrivalPortName,
    ArrivalPortCountryCode ,
    BoardingDateTime,
    DepartureDateTime,
    DeparturePortCode,
    DeparturePortName
};

