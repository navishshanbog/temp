import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import * as StringUtils from "@twii/common/lib/util/String";
import * as DateUtils from "@twii/common/lib/util/Date";
import {IICruiseTravellerTravelDocs} from "../../../traveller/ICruiseBookingModel";

const PassengerNumber : IColumn = {
    key: "PassengerNumber",
    ariaLabel: "PT",
    name: "PT",
    fieldName: "PassengerNumber",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 60,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.PassengerNumber;
    }
};

const familyName : IColumn = {
    key: "familyName",
    ariaLabel: "Family Name",
    name: "Family Name",
    fieldName: "familyName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.Biographic.familyName;
    }
};

const givenName: IColumn = {
    key: "givenName",
    ariaLabel: "Given Name",
    name: "Given Name",
    fieldName: "givenName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.Biographic.givenName;
    }
};

const travelDocId: IColumn = {
    key: "travelDocId",
    ariaLabel: "Travel Doc Id",
    name: "Travel Doc Id",
    fieldName: "travelDocId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.travelDoc ? item.travelDoc.travelDocId ? item.travelDoc.travelDocId : "" : "";
    }
};

const travelDocCountryCode: IColumn = {
    key: "travelDocCountryCode",
    ariaLabel: "Travel Doc Country Cd",
    name: "Travel Doc Country Cd",
    fieldName: "travelDocCountryCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 120,
    maxWidth: 120,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.travelDoc ? item.travelDoc.travelDocCountryCode ? item.travelDoc.travelDocCountryCode : "" : "";
    }
};

const issueCountryCode: IColumn = {
    key: "issueCountryCode",
    ariaLabel: "Issue Country Cd",
    name: "Issue Country Cd",
    fieldName: "issueCountryCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.travelDoc ? item.travelDoc.issueCountryCode ? item.travelDoc.issueCountryCode : "" : "";
    }
};

const travelDocExpiryDate: IColumn = {
    key: "travelDocExpiryDate",
    ariaLabel: "Travel Doc Exp Dt",
    name: "Travel Doc Exp Dt",
    fieldName: "travelDocExpiryDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 80,
    maxWidth: 150,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return DateUtils.dateToOutputText(item.travelDoc.travelDocExpiryDate);
    }
};

const ImmigrationDeptCountryCode: IColumn = {
    key: "ImmigrationDeptCountryCode",
    ariaLabel: "Immigration Dept Country Cd",
    name: "Immigration Dept Country Cd",
    fieldName: "ImmigrationDeptCountryCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 180,
    maxWidth: 180,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.travelDoc ? item.travelDoc.ImmigrationDeptCountryCode ? item.travelDoc.ImmigrationDeptCountryCode : "" : "";
    }
};

const TravelDocPlaceOfIssue: IColumn = {
    key: "TravelDocPlaceOfIssue",
    ariaLabel: "Travel Doc Place Of Issue",
    name: "Travel Doc Place Of Issue",
    fieldName: "TravelDocPlaceOfIssue",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 80,
    maxWidth: 150,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.travelDoc ? item.travelDoc.TravelDocPlaceOfIssue ? item.travelDoc.TravelDocPlaceOfIssue : "" : "";
    }
};

const TravelDocNationality: IColumn = {
    key: "TravelDocNationality",
    ariaLabel: "Travel Doc Nationality",
    name: "Travel Doc Nationality",
    fieldName: "TravelDocNationality",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 80,
    maxWidth: 150,
    onRender: (item: IICruiseTravellerTravelDocs) => {
        return item.travelDoc ? item.travelDoc.TravelDocNationality ? item.travelDoc.TravelDocNationality : "" : "";
    }
};


const cruisePassengerTravelDocColumns : IColumn[] = [
    PassengerNumber,
    familyName,
    givenName,
    travelDocId ,
    travelDocCountryCode,
    issueCountryCode,
    travelDocExpiryDate,
    ImmigrationDeptCountryCode,
    TravelDocPlaceOfIssue,
    TravelDocNationality
];


export {
    cruisePassengerTravelDocColumns as default,
    cruisePassengerTravelDocColumns,
    PassengerNumber,
    familyName,
    givenName,
    travelDocId ,
    travelDocCountryCode,
    issueCountryCode,
    travelDocExpiryDate,
    ImmigrationDeptCountryCode,
    TravelDocPlaceOfIssue,
    TravelDocNationality
};