import * as React from 'react';
import { observer } from "mobx-react";
import "./CruisePassengers.scss";
import ICruiseBookingModel from "../../../traveller/ICruiseBookingModel";
import cruisePassengerColumns from "./CruisePassengerColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface ICruiseDetailsProps {
    model?: ICruiseBookingModel;
}


@observer
class CruisePassengers extends React.Component<ICruiseDetailsProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Passenger Details"
                           className="passenger-details"
                           columns={cruisePassengerColumns}
                           items={this.props.model.cruiseTravellers}
                           sync={this.props.model.sync} />
        );
    }
}
export {CruisePassengers as default, CruisePassengers, ICruiseDetailsProps}