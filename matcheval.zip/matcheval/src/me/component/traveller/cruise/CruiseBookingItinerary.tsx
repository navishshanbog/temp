import * as React from 'react';
import { observer } from "mobx-react";
import "./CruiseBookingItinerary.scss";
import ICruiseBookingModel from "../../../traveller/ICruiseBookingModel";
import cruiseBookingItineraryColumns from "./CruiseBookingItineraryColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface ICruiseDetailsProps {
    model?: ICruiseBookingModel;
}


@observer
class CruiseBookingItinerary extends React.Component<ICruiseDetailsProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Cruise Booking Itinerary"
                           className="cruise-booking-itinerary"
                           columns={cruiseBookingItineraryColumns}
                           items={this.props.model.cruiseBookingItineraries}
                           sync={this.props.model.sync} />
        );
    }
}
export {CruiseBookingItinerary as default, CruiseBookingItinerary, ICruiseDetailsProps}