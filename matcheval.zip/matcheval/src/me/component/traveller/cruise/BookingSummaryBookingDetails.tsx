import * as React from 'react';
import { observer } from "mobx-react";
import "./CruiseBookingSummary.scss";
import "./CruiseBookingSummaryItemAttribute.scss";
import ICruiseBookingData from "../../../../risk/traveller/cru/ICruiseBookingData";
import IBookingSummary  from "../../../../risk/traveller/cru/IBookingSummary";
import * as DateUtils from "@twii/common/lib/util/Date";
import CruiseBookingSummaryItemAttribute from "./CruiseBookingSummaryItemAttribute";
import * as StringUtils from "@twii/common/lib/util/String";

interface IBookingDetailsProps {
    model?: ICruiseBookingData;
}
const getBookingSummaryValue = (booking: ICruiseBookingData,
                                selector: (summary: IBookingSummary) => string) : string => {
    return booking && booking.CruiseBooking && booking.CruiseBooking.BookingSummaryInfo
        ? selector(booking.CruiseBooking.BookingSummaryInfo) : undefined;
};
const Fields = [
    {
        key: "BoardingDate",
        name: "Boarding Date",
        onRender: function(booking: ICruiseBookingData) {
            let boardingDate = getBookingSummaryValue(booking, summary => DateUtils.dateToOutputText(summary.InitialBoardingDate));
            return <CruiseBookingSummaryItemAttribute key={this.key} label={this.name} value={boardingDate? boardingDate :"-"}/>;
        }
    },  {
        key: "BoardingPort",
        name: "Boarding Port",
        onRender: function(booking: ICruiseBookingData) {
            let boardingPort = getBookingSummaryValue(booking, summary => summary.InitialBoardingPortCode);
            return <CruiseBookingSummaryItemAttribute key={this.key} label={this.name} value={boardingPort? boardingPort :"-"}/>;
        }
    },  {
        key: "BoardingCountry",
        name: "Boarding Country",
        onRender: function(booking: ICruiseBookingData) {
            let boardingCountry = '-';
            return <CruiseBookingSummaryItemAttribute key={this.key} label={this.name} value={boardingCountry? boardingCountry :"-"}/>;
        }
    },
    {
        key: "FlightConnection",
        name: "Flight Connection",
        onRender: function(booking: ICruiseBookingData) {
            let flightConnection = '-';
            return <CruiseBookingSummaryItemAttribute key={this.key} label={this.name} value={flightConnection? flightConnection : "-"}/>;
        }
    },  {
        key: "DisembarkingDate",
        name: "Disembarking Date",
        onRender: function(booking: ICruiseBookingData) {
            let disembarkingDate = getBookingSummaryValue(booking, summary => DateUtils.dateToOutputText(summary.LastDisembarkingDate));
            return <CruiseBookingSummaryItemAttribute key={this.key} label={this.name} value={disembarkingDate? disembarkingDate :"-"}/>;
        }
    },  {
        key: "DisembarkingPort",
        name: "Disembarking Port",
        onRender: function(booking: ICruiseBookingData) {
            let disembarkingPort = getBookingSummaryValue(booking, summary => summary.LastDisembarkingPortCode);
            return <CruiseBookingSummaryItemAttribute key={this.key} label={this.name} value={disembarkingPort? disembarkingPort :"-"}/>;
        }
    },  {
        key: "DisembarkingCountry",
        name: "Disembarking Country",
        onRender: function(booking: ICruiseBookingData) {
            let disembarkingCountry = getBookingSummaryValue(booking, summary => summary.DisembarkingCountryCode);
            return <CruiseBookingSummaryItemAttribute key={this.key} label={this.name} value={disembarkingCountry? disembarkingCountry :"-"}/>;
        }

    },

];

@observer
class BookingSummaryBookingDetails extends React.Component<IBookingDetailsProps, any> {
    render() {
        let content = Fields.map((field: any) => {
            return field.onRender(this.props.model, field);
        });

        return (content);
    }
}
export {BookingSummaryBookingDetails as default, BookingSummaryBookingDetails, IBookingDetailsProps}
