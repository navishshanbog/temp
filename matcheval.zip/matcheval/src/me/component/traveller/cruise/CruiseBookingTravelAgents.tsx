import * as React from 'react';
import { observer } from "mobx-react";
import "./CruiseBookingTravelAgents.scss";
import ICruiseBookingModel from "../../../traveller/ICruiseBookingModel";
import cruiseBookingTravelAgentsColumns from "./CruiseBookingTravelAgentColumns";
import METravellerDetailsList from "../../METravellerDetailsList";

interface ICruiseDetailsProps {
    model?: ICruiseBookingModel;
}


@observer
class CruiseBookingTravelAgents extends React.Component<ICruiseDetailsProps, any> {

    render() {
        return (
            <METravellerDetailsList
                           label="Cruise Booking Travel Agents"
                           className="cruise-booking-travel-agents"
                           columns={cruiseBookingTravelAgentsColumns}
                           items={this.props.model.cruiseTravelAgents}
                           sync={this.props.model.sync} />
        );
    }
}
export {CruiseBookingTravelAgents as default, CruiseBookingTravelAgents, ICruiseDetailsProps}