import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import * as StringUtils from "@twii/common/lib/util/String";
import ITravelAgent from "../../../../risk/traveller/cru/ITravelAgent";


const IATAAgentCode : IColumn = {
    key: "IATAAgentCode",
    ariaLabel: "IATA Agent Code",
    name: "IATA Agent Code",
    fieldName: "IATAAgentCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100,
    onRender: (item: ITravelAgent) => {
        return item.IATAAgentCode;
    }
};

const AgentName : IColumn = {
    key: "AgentName",
    ariaLabel: "Agent Name",
    name: "Agent Name",
    fieldName: "AgentName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100,
    onRender: (item: ITravelAgent) => {
        return item.AgentName;
    }
};

const ABN : IColumn = {
    key: "ABN",
    ariaLabel: "ABN",
    name: "ABN",
    fieldName: "ABN",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ITravelAgent) => {
        return item.ABN;
    }
};

const AssociationCode : IColumn = {
    key: "AssociationCode",
    ariaLabel: "Association Code",
    name: "Association Code",
    fieldName: "AssociationCode",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ITravelAgent) => {
        return item.AssociationCode;
    }
};

const StatusCOde: IColumn = {
    key: "StatusCOde",
    ariaLabel: "Status Cd",
    name: "Status Cd",
    fieldName: "StatusCOde",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ITravelAgent) => {
        return item.StatusCOde;
    }
};

const Address: IColumn = {
    key: "Address",
    ariaLabel: "Address",
    name: "Address",
    fieldName: "Address",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 80,
    onRender: (item: ITravelAgent) => {
        let address = "";
        let allAddresses = [];
        if(item.Addresses) {
            if (item.Addresses.Address != null) {
                item.Addresses.Address.forEach((addressDetail) => {
                    var temp = addressDetail.Line1 ? addressDetail.Line1.trim() + " " : "";
                    temp += addressDetail.Line2 ? addressDetail.Line2.trim()+ " " : "";
                    temp += addressDetail.Line3 ? addressDetail.Line3.trim()+ " " : "";
                    temp += addressDetail.Line4 ? addressDetail.Line4.trim()+ " " : "";
                    temp += addressDetail.Line5 ? addressDetail.Line5.trim()+ " " : "";
                    temp += addressDetail.PostCode ? addressDetail.PostCode.trim()+ " " : "";
                    temp += addressDetail.City ? addressDetail.City.trim()+ " " : "";
                    temp += addressDetail.State ? addressDetail.State.trim()+ " " : "";
                    temp += addressDetail.CountryCode ? addressDetail.CountryCode.trim() : "";
                    if(allAddresses.indexOf(temp) < 0) {
                        address = StringUtils.isNotBlank(address) ? address + " | " + temp : temp;
                        allAddresses.push(temp)
                    }
                });
            }
        }
        return address;
    }
};


const cruiseBookingTravelAgentsColumns : IColumn[] = [
    IATAAgentCode,
    AgentName,
    ABN,
    AssociationCode ,
    StatusCOde,
    Address
];


export {
    cruiseBookingTravelAgentsColumns as default,
    cruiseBookingTravelAgentsColumns,
    IATAAgentCode,
    AgentName,
    ABN,
    AssociationCode ,
    StatusCOde,
    Address
};

