import * as React from 'react';
import { observer } from "mobx-react";
import {IMECase} from "../IMECase";
import { Pivot, PivotItem, IPivotItemProps } from 'office-ui-fabric-react/lib/Pivot';
import "./MEVisaHistory.scss";
import MEHeader from "./MEHeader";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { IVisaHistoryCaseSummary } from "../visahistory/IVisaHistoryCaseSummary";
import {VisaHistory} from "./visahistory/VisaHistory";


interface IMEVisaHistoryProps {
    meVisaHistory: IVisaHistoryCaseSummary;
    meCase: IMECase;
}


@observer
class MEVisaHistory extends React.Component<IMEVisaHistoryProps, any> {
    private _onRefresh = () => {
        this.props.meVisaHistory.refresh();
    }
    render() {
        let headerDetails = this.props.meCase;
        let meVisaHistoryContentHeader = <MEHeader headerDetails = {headerDetails}
                                               onRefresh={this._onRefresh}
                                               icon={<Icon iconName='World'/>} />

        let pivotArray: React.ReactElement<IPivotItemProps>[] = [];
        pivotArray.push( <PivotItem linkText='ME Visa History' itemKey="0" key="0">
                 <VisaHistory model={this.props.meVisaHistory} />
         </PivotItem>);


        let meVisaHistoryContent = <div>
            {meVisaHistoryContentHeader}
            <Pivot selectedKey="0" >
                {pivotArray}
            </Pivot>
        </div>

        return (
            <div className="me-visa-history">
                {meVisaHistoryContent}
            </div>
        );
    }
}
export { MEVisaHistory, IMEVisaHistoryProps }
