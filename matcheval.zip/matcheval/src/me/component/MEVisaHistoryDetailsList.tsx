import * as React from "react";
import { observer } from "mobx-react";
import { IColumn } from "office-ui-fabric-react/lib/DetailsList";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import { css } from "office-ui-fabric-react/lib/Utilities";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import ISyncModel from "@twii/common/lib/ISyncModel";
import Error from "@twii/common/lib/component/Error";
import Details from "@twii/common/lib/component/Details";
import "./METravellerDetailsList.scss";
import {
    DetailsList,
    DetailsListLayoutMode,
    CheckboxVisibility,
    ConstrainMode,
    SelectionMode,
    Selection
} from "office-ui-fabric-react/lib/DetailsList";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import {createItemIndexColumn, getActionDisabledVariant} from "@twii/common/lib/component/ColumnHelper";

interface MEVisaHistoryDetailsListProps {
    icon?: JSX.Element;
    label: string;
    className: string;
    columns: IColumn[];
    sync: ISyncModel;
    items: any[];
    setSelectedItem?: (selectedItem: any) => void;
    enableNextPrev?: boolean;
}

@observer
class MEVisaHistoryDetailsList extends React.Component<MEVisaHistoryDetailsListProps, any> {

    private _selection : Selection;
    constructor(props : MEVisaHistoryDetailsListProps) {
        super(props);
        if(this.props.setSelectedItem)
        this._selection = new Selection({ onSelectionChanged: this._onSelectionChange });

    }

    private _onSelectionChange = () => {
        if(this._selection.getSelectedCount() > 0) {
            this.props.setSelectedItem(this._selection.getSelection()[0]);
        }
    }

    private _onShouldVirtualize = () => {
        return false;
    }
    private _addColumnIndexValue = (item: any) => {
        // May be something more tomorrow
    }

    private _onColumnClick = (event: React.MouseEvent<HTMLElement>, column: IColumn): void => {
        console.log("-- column to be sorted ", column);
    }

    render() {
        if(this.props.setSelectedItem && (this.props.items && this.props.items.length > 0) && (this._selection && this._selection.getSelectedCount() == 0)) {
            this._selection.setItems(this.props.items);
            this._selection.setIndexSelected(0, true, true);
        }

        let customColumns = this.props.columns;
        let content = <MessageBar messageBarType={MessageBarType.info}>No data available to display</MessageBar>;
        if(this.props.sync.syncing) {
            content = <Spinner label="Loading ..." className="load-spinner"/>;
        } else if(this.props.sync.error) {
            console.log("-- error ", this.props.sync.error);
            content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if(this.props.sync.hasSynced) {
            if(this.props.items.length > 0) {
                content = <DetailsList className="me-visa-history-section"
                                       columns={customColumns}
                                       compact={true}
                                       checkboxVisibility={CheckboxVisibility.hidden}
                                       items={this.props.items.slice(0)}
                                       layoutMode={DetailsListLayoutMode.justified}
                                       skipViewportMeasures={false}
                                       selectionMode={SelectionMode.single}
                                       constrainMode={ConstrainMode.unconstrained}
                                       selection={ this._selection }
                                       selectionPreservedOnEmptyClick={ true }
                                       onColumnHeaderClick={ this._onColumnClick }
                                       onShouldVirtualize={this._onShouldVirtualize}/>
            }
        }
        return (
            <Details className={css(this.props.className, "me-visa-history")}
                     summary={<div>{this.props.label}</div>}
                     open={true}
                     controlOnHeaderClick={true}
                     headerClassName={css(`${this.props.className}-ribbon`)}>
                     {content}
            </Details>
        );
    }
}

export { MEVisaHistoryDetailsList, MEVisaHistoryDetailsListProps  }