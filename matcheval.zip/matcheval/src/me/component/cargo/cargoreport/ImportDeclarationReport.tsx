import * as React from 'react';
import { observer } from "mobx-react";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import {MECargoFidReport} from "./fid/MECargoFIDReport";
import {MECargoImportDeclarationModel } from "../../../cargo/cargoreport/fid/MECargoImportDeclarationModel";
import {MECargoImportDeclarationStore } from "../../../cargo/cargoreport/fid/MECargoImportDeclarationStore";
import MECargoExamsDetails from "../cargoreport/exams/MECargoExamsDetails";
import {MECargoExamsModel} from "../../../cargo/cargoreport/exams/MECargoExamsModel";
import {MECargoExamsStore} from "../../../cargo/cargoreport/exams/MECargoExamsStore";
import {MECargoSacReport} from "../cargoreport/sac/MECargoSacReport";
import {IMECargoImportDeclarationModel } from "../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";

interface IImportDecProps {
    model?: IMECargoImportDeclarationModel;
}

@observer
class ImportDeclarationReport extends React.Component<IImportDecProps, any> {
    render() {
        let importDocType;
        if (this.props.model) {
            console.log("import doc type: ", this.props.model.importDocType);
            if (this.props.model.importDocType==="FID" || this.props.model.importDocType==="Fid" ) {
                importDocType =  <MECargoFidReport model={this.props.model} />
            }
            else if (this.props.model.importDocType==="SAC" || this.props.model.importDocType==="Sac" ) {
                importDocType =  <MECargoSacReport model={this.props.model} />
            }
            else {
                importDocType = <div></div>
            }
        }
        return (
            <div className="import-dec">
                {importDocType}
            </div>
        );
    }
}

export {ImportDeclarationReport, IImportDecProps}

