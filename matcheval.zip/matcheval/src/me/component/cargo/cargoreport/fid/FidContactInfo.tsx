import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECargoFidReport} from "../../../../cargo/cargoreport/fid/IMECargoFidReport";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
//import {IAirCargoFidModel} from "../../../../cargo/aircargo/fid/IAirCargoFidModel";
//import {IMEAirCargoModel} from "../../../../cargo/aircargo/IMEAirCargoModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./FidContactInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{  
    key: "importerID",
    name: "Importer ID:",
    fieldName: "importerID",
    minWidth: 50,
    isMultiline: true
},
    {
        key: "importerName",
        name: "Importer Name:",
        fieldName: "importerName",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "brokerReference",
        name: "Broker Reference:",
        fieldName: "brokerReference",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "importerReference",
        name: "Importer Reference:",
        fieldName: "importerReference",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "importerBranch",
        name: "Importer Branch:",
        fieldName: "importerBranch",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "brokerPhoneNo",
        name: "Broker Phone No:",
        fieldName: "brokerPhoneNo",
        minWidth: 50,
        isMultiline: true
    },
    {
       key: "nomineeBrokerLicenseNo",
        name: "Nominee Broker LicenseNo:",
        fieldName: "nomineeBrokerLicenseNo",
        minWidth: 50,
        isMultiline: true

    }];


interface IMECargoFidContactDetailsProps {
    model?: IMECargoImportDeclarationModel;
}

const MECargoFidContactDetailsViewPrefsStore = new ViewPreferencesModel("MECargoFidContactDetails");

class MECargoFidContactDetails extends React.Component<IMECargoFidContactDetailsProps , any> {
    render() {
        let content;
        if(this.props.model) {
            content = <DetailsItem model={this.props.model.importDecItems.fid} attrConfig={Fields} viewPrefModel={MECargoFidContactDetailsViewPrefsStore}/>;
           
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="fid-contact-info">{content}</div>;
    }
}

class MECargoFidContactDetailsContainer extends React.Component<IMECargoFidContactDetailsProps, any> {
    private _onRenderDone = () => {
        return <MECargoFidContactDetails {...this.props} />;
    }
    render() {
       return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading ME Cargo Fid Contact Information..." />;
    }
}

class MECargoFidContactDetailsList extends React.Component<IMECargoFidContactDetailsProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Contact Information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("fid-contact-info-header")}
                         bodyClassName="fid-contact-info-body">
                         <MECargoFidContactDetailsContainer {...this.props} />
           </Details>
        );
    }
}

export {
    MECargoFidContactDetailsList as default,
    MECargoFidContactDetailsList,
    MECargoFidContactDetails,
    IMECargoFidContactDetailsProps,
    Fields as FidContactDetailsFields,
    MECargoFidContactDetailsViewPrefsStore
};