import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECargoImportDeclarationDetails} from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationDetails";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./FidDecDetails.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{  
    key: "declarationID",
    name: "Declaration ID:",
    fieldName: "declarationID",
    minWidth: 50,
    isMultiline: true
},
  {
        key: "declarationStatus",
        name: "Declaration Status:",
        fieldName: "declarationStatus",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "paymentStatus",
        name: "Payment Status:",
        fieldName: "paymentStatus",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "quarantineHeld",
        name: "Quarantine Held:",
        fieldName: "quarantineHeld",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "consolidatedCargoStatus",
        name: "Consolidated Cargo Status:",
        fieldName: "consolidatedCargoStatus",
        minWidth: 50,
        isMultiline: true
    },
    {
       key: "modeOfPayment",
        name: "Mode of Payment:",
        fieldName: "modeOfPayment",
        minWidth: 50,
        isMultiline: true

    },
    {
        key: "gstDeclarationResponse",
        name: "GST Declaration Response:",
        fieldName: "gstDeclarationResponse",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "lodgedDate",
        name: "Lodged Date:",
        fieldName: "lodgedDate",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "modeOfReceipt",
        name: "Mode of Receipt:",
        fieldName: "modeOfReceipt",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "documentAdviceSent",
        name: "Document Advice Sent:",
        fieldName: "documentAdviceSent",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "borderHold",
        name: "Border Hold:",
        fieldName: "borderHold",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "goodDescription",
        name: "Goods Description:",
        fieldName: "goodDescription",
        minWidth: 80,
        isMultiline: true
    },
    /*
    {
        key: "goodsDelivered",
        name: "Goods Delivered:",
        fieldName: "goodsDelivered",
        minWidth: 50,
        isMultiline: true
    },
    */
    {
        key: "paidUnderProtest",
        name: "Paid Under Protest:",
        fieldName: "paidUnderProtest",
        minWidth: 50,
        isMultiline: true
    }  
   ];


interface IMECargoFidDecDetailsProps {
    model?: IMECargoImportDeclarationModel;
}

const MECargoFidDecDetailsViewPrefsStore = new ViewPreferencesModel("MECargoFidDecDetails");

class MECargoFidDeclarationDetails extends React.Component<IMECargoFidDecDetailsProps, any> {
    render() {
       console.log("Fid DeclarationID", this.props.model.importDecItems.declarationID);
        let content;
        if(this.props.model)
         {
             content = <DetailsItem  model={this.props.model.importDecItems.fid} attrConfig={Fields} viewPrefModel={MECargoFidDecDetailsViewPrefsStore}/>;
           
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="fid-dec-details">{content}</div>;
    }
}

class MECargoFidDeclarationContainer extends React.Component<IMECargoFidDecDetailsProps, any> {
    private _onRenderDone = () => {
        return <MECargoFidDeclarationDetails {...this.props} />;
    }
    render() {
        console.log("sync=", this.props.model.sync);
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading ME Cargo Fid Declaration Details..." />;
    }
}

class MECargoFidDeclarationList extends React.Component<IMECargoFidDecDetailsProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Declaration Details'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("fid-dec-details-report-header")}
                         bodyClassName="fid-dec-details-report-body">
                         <MECargoFidDeclarationContainer {...this.props} />
           </Details>
        );
    }
}

export {
    MECargoFidDeclarationList as default,
   MECargoFidDeclarationList,
     MECargoFidDeclarationDetails,
    IMECargoFidDecDetailsProps,
    Fields as FidDecDetailsCargoFields,
    MECargoFidDecDetailsViewPrefsStore
};