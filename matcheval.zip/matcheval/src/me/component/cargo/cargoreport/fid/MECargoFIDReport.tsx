import * as React from 'react';
import { observer } from "mobx-react";
//import {IMECargoFidModel} from "../../../../cargo/MEcargo/fid/IMECargofidModel";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import MECargoFidDeclarationList from "./FidDecDetails";
//import {IMEMECargoModel} from "../../../../cargo/MEcargo/IMEMECargoModel";
import { Link } from "office-ui-fabric-react/lib/Link";
import MECargoFidDocDetailsList from "./FidDocumentDetails";
import  MECargoFidContactDetailsList from "./FidContactInfo";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import "./MECargoFIDReport.scss";

interface IMECargoFidDetailsProps {
    model?: IMECargoImportDeclarationModel ;
    //model?: IMEMECargoModel;
}

@observer
class MECargoFidCommandBar extends React.Component<IMECargoFidDetailsProps, any> {
     private reportText: string = "Ver: ";
     private version: number =  this.props.model.versionNo;
     
     private _loadPreviousFidReport = () => {
         this.version = this.version - 1;
         this.props.model. updateSelectedImportDocumentVersion(this.props.model.selectedReport, this.version);
         
      };

      private _loadNextFidReport = () => {
         this.version = this.version + 1;
         this.props.model. updateSelectedImportDocumentVersion(this.props.model.selectedReport, this.version);
      }
      
      render() {
        let disableLeft: boolean = true;
        let disableRight: boolean = true;
        let lastVersion:number = this.props.model.importDecItems ? this.props.model.importDecItems.lastVersion : 0;
        let matchStatus:string = this.props.model.importDecItems ? this.props.model.importDecItems.matchStatus : "";
       
        disableLeft = this.version == 1;
        disableRight = this.version == lastVersion;
        console.log("versionNo + lastVersion + disableRight: ", this.version, lastVersion, disableRight);

        const items : IContextualMenuItem[] = [
            {
                key: "name",
                name: "IMPORT DECLARATION",
                className:"fid-left-menu-item"
            }
           
        ];

        const farItems: IContextualMenuItem[] = [
            {
                key: "matchStatus",
                name: `Match Status: ${matchStatus}`,
                className:"fid-match-status-far-item" 
            },
             {
                key: "LA",
                name: "",
                iconProps: { iconName: "ChevronLeft" },
                disabled: disableLeft,
                className: css(`fid-left-chevron`),
                onClick: this._loadPreviousFidReport
            },
            {
                key: this.reportText,
                name: `${this.reportText} ${this.version}`,
                className: css(`cargo-report-title`)
            },
            {
                key: "RA",
                name: "",
                iconProps: { iconName: "ChevronRight" },
                className: css(`fid-right-chevron`),
                disabled: disableRight,
                onClick: this._loadNextFidReport 
            }
           
        ];
    
        return <CommandBar key={"version"} className="import-dec-command-bar" items={items} farItems={farItems} />;   
    }
}

@observer
class MECargoFidReport extends React.Component<IMECargoFidDetailsProps, any> {
    _handleClick() {
        alert("Open next Fid...");
    }
   
    render() {
       
       return (
              <div className="import-dec-section">
               
                <div>{<MECargoFidCommandBar {...this.props} />} </div>
                    <div>
                        {<MECargoFidDeclarationList  {...this.props} />}
                    </div>
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<MECargoFidDocDetailsList {...this.props} />}
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<MECargoFidContactDetailsList {...this.props} />}
                        </div>
                    </div>
                
             </div>
         );
    }

}

export {MECargoFidReport, IMECargoFidDetailsProps}