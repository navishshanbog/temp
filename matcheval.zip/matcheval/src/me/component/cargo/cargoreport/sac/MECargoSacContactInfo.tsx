import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECargoSacReport} from "../../../../cargo/cargoreport/sac/IMECargoSacReport";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./MECargoSacContactInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{
        key: "importerID",
        name: "Importer ID:",
        fieldName: "importerID",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "importerName",
        name: "Importer Name:",
        fieldName: "importerName",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "communicatorRef",
        name: "Communicator Reference:",
        fieldName: "communicatorRef",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "sacCommunicator",
        name: "Sac Communicator:",
        fieldName: "sacCommunicator",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "supplierName",
        name: "Supplier Name:",
        fieldName: "supplierName",
        minWidth: 50,
        isMultiline: true 
    },
    {
         key: "vendorId",
        name: "Vendor ID:",
        fieldName: "vendorId",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "importerReference",
        name: "Importer Reference:",
        fieldName: "importerReference",
        minWidth: 50,
        isMultiline: true 
    },
    {
       key: "importerAddress",
        name: "Importer Address:",
        fieldName: "importerAddress",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "contactPhoneNo",
        name: "Contact Phone No:",
        fieldName: "contactPhoneNo",
        minWidth: 50,
        isMultiline: true 
    },
    
    {
        key: "aqisInspectionLoc",
        name: "AQIS Inspection Location:",
        fieldName: "aqisInspectionLoc",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "supplierId",
        name: "Supplier ID:",
        fieldName: "supplierId",
        minWidth: 50,
        isMultiline: true 
    }];


interface ICargoSacContactInfoProps {
    model?: IMECargoImportDeclarationModel ;
}

const CargoSacContactInfoViewPrefsStore = new ViewPreferencesModel("CargoSacContactInfo");

class CargoSacContactInfo extends React.Component<ICargoSacContactInfoProps , any> {
    render() {
        let content;
        if(this.props.model.importDecItems.sac) {
            content = <DetailsItem model={this.props.model.importDecItems.sac} attrConfig={Fields} viewPrefModel={CargoSacContactInfoViewPrefsStore}/>;
              
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="sac-contact-info">{content}</div>;
    }
}

class CargoSacContactInfoContainer extends React.Component<ICargoSacContactInfoProps, any> {
    private _onRenderDone = () => {
        return <CargoSacContactInfo {...this.props} />;
    }
    render() {
       return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sac Contact Information..." />;
    }
}

class CargoSacContactInfoList extends React.Component<ICargoSacContactInfoProps , any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Contact Information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("sac-contact-info-header")}
                         bodyClassName="sac-contact-info-body">
                         <CargoSacContactInfoContainer {...this.props} />
           </Details>
        );
    }
}

export {
    CargoSacContactInfoList  as default,
    CargoSacContactInfoList ,
    CargoSacContactInfo,
    ICargoSacContactInfoProps,
    Fields as SacContactInfoFields,
    CargoSacContactInfoViewPrefsStore
};