import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECargoSacReport} from "../../../../cargo/cargoreport/sac/IMECargoSacReport";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./MECargoSacGoodsInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";

const Fields: IColumn[] = [{
        key: "modeOfTransport",
        name: "Mode Of Transport:",
        fieldName: "modeOfTransport",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "destinationPort",
        name: "Destination Port:",
        fieldName: "destinationPort",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "masterBillNbr",
        name: "Master ME Waybill:",
        fieldName: "masterBillNbr",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "consignmentRef",
        name: "Consignment Reference:",
        fieldName: "consignmentRef",
        minWidth: 50,
        isMultiline: true 
    },
        
    {
        key: "grossWeight",
        name: "Gross Weight (unit):",
        /*
        onRender: function (item: IMECargoSacReport) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.grossWeight) + (" ") + (item.grossWeightUnit)}/>;
        },
        data: {getText: (item: IMECargoSacReport) => `${item.grossWeight} ${item.grossWeightUnit}`},
        */
        fieldName: "grossWeight",
        minWidth: 50,
        isMultiline: true 
    },
    {
       key: "dischargePort",
        name: "Discharge Port:",
        fieldName: "dischargePort",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "arrivalDate",
        name: "Arrival Date:",
        fieldName: "arrivalDate",
        minWidth: 50,
        isMultiline: true 
    },
    
    {
        key: "houseBillOfLading",
        name: "House ME Waybill:",
        fieldName: "houseBillOfLading",
        minWidth: 50,
        isMultiline: true 
    },
    
    {
        key: "deliveryAddress",
        name: "Delivery Address:",
        fieldName: "deliveryAddress",
        minWidth: 50,
        isMultiline: true 
    },
    {
        key: "goodDescription?",
        name: "Good Description:",
        fieldName: "goodDescription?",
        minWidth: 50,
        isMultiline: true 
    }];


interface IMECargoSacGoodsInfoProps {
    model?: IMECargoImportDeclarationModel;
}

const MECargoSacGoodsInfoViewPrefsStore = new ViewPreferencesModel("MECargoSacGoodsInfo");

class MECargoSacGoodsInfo extends React.Component<IMECargoSacGoodsInfoProps , any> {
    render() {
        let content;
        if(this.props.model.importDecItems.sac) {
            content = <DetailsItem model={this.props.model.importDecItems.sac} attrConfig={Fields} viewPrefModel={MECargoSacGoodsInfoViewPrefsStore}/>;
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="sac-goods-info">{content}</div>;
    }
}

class MECargoSacGoodsInfoContainer extends React.Component<IMECargoSacGoodsInfoProps, any> {
    private _onRenderDone = () => {
        return <MECargoSacGoodsInfo {...this.props} />;
    }
    render() {
       return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sac Goods and Voyage Information..." />;
    }
}

class MECargoSacGoodsInfoList extends React.Component<IMECargoSacGoodsInfoProps , any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Goods and voyage information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("sac-goods-info-header")}
                         bodyClassName="sac-goods-info-body">
                         <MECargoSacGoodsInfoContainer {...this.props} />
           </Details>
        );
    }
}

export {
    MECargoSacGoodsInfoList as default,
    MECargoSacGoodsInfoList,
    MECargoSacGoodsInfo,
    IMECargoSacGoodsInfoProps,
    Fields as SacGoodsInfoFields,
    MECargoSacGoodsInfoViewPrefsStore
};