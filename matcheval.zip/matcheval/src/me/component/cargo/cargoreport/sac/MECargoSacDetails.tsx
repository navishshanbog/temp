import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECargoSacReport} from "../../../../cargo/cargoreport/sac/IMECargoSacReport";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./MECargoSacDetails.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{  
    key: "declarationID",
    name: "Declaration ID:",
    fieldName: "declarationID",
    minWidth: 50,
    isMultiline: true
},
{
        key: "status",
        name: "Status:",
        fieldName: "status",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "branch",
        name: "Branch:",
        fieldName: "branch",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "consolidatedCargoStatus",
        name: "Consolidated Cargo Status:",
        fieldName: "consolidatedCargoStatus",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "lodgedDate",
        name: "Lodged Date:",
        fieldName: "lodgedDate",
        minWidth: 50,
        isMultiline: true
    },
    
    {
        key: "BrokerageLicenseNo",
        name: "Brokerage License No:",
        fieldName: "BrokerageLicenseNo",
        minWidth: 50,
        isMultiline: true
    },
        
    {
       key: "departmentBoxNo",
        name: "Department Box No:",
        fieldName: "departmentBoxNo",
        minWidth: 50,
        isMultiline: true

    }];


interface IMECargoSacDetailsProps {
    model?: IMECargoImportDeclarationModel;
}

const MECargoSacDetailsViewPrefsStore = new ViewPreferencesModel("MECargoSacDetails");

class MECargoSacDetails extends React.Component<IMECargoSacDetailsProps , any> {
    render() {
        let content;
        if(this.props.model.importDecItems.sac) {
            content = <DetailsItem model={this.props.model.importDecItems.sac} attrConfig={Fields} viewPrefModel={MECargoSacDetailsViewPrefsStore}/>;
           console.log("Sac= ", this.props.model.importDecItems.sac.declarationID);
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="sac-details">{content}</div>;
    }
}

class MECargoSacDetailsContainer extends React.Component<IMECargoSacDetailsProps, any> {
    private _onRenderDone = () => {
        return <MECargoSacDetails {...this.props} />;
    }
    render() {
       return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading ME Cargo Sac Details..." />;
    }
}

class MECargoSacDetailsList extends React.Component<IMECargoSacDetailsProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'SAC details'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("sac-details-header")}
                         bodyClassName="sac-details-body">
                         <MECargoSacDetailsContainer {...this.props} />
           </Details>
        );
    }
}

export {
    MECargoSacDetailsList as default,
    MECargoSacDetailsList,
    MECargoSacDetails,
    IMECargoSacDetailsProps,
    Fields as SacDetailsFields,
    MECargoSacDetailsViewPrefsStore
};