import * as React from 'react';
import { observer } from "mobx-react";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import {MECargoSacDetailsList} from "./MECargoSacDetails";
import {MECargoSacGoodsInfoList } from "./MECargoSacGoodsInfo";
import {CargoSacContactInfoList } from "./MECargoSacContactInfo";
import "./MECargoSacReport.scss";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";

 interface ICargoSacDetailsProps {
     
     model?: IMECargoImportDeclarationModel ;
    
 }
@observer
 class CargoSacCommandBar extends React.Component<ICargoSacDetailsProps, any> {
     private reportText: string = "Ver: ";
     private version: number =  this.props.model.versionNo;
     private lastVersion:number = 2;
     private  matchStatus:string = "MATCHED";
      
      private _loadPreviousSacReport = () => {
         this.version = this.version - 1;
         this.props.model. updateSelectedImportDocumentVersion(this.props.model.selectedReport, this.version);
         
      };
      private _loadNextSacReport = () => {
         this.version = this.version + 1;
         this.props.model. updateSelectedImportDocumentVersion(this.props.model.selectedReport, this.version);
      }
    render() {
        let disableLeft: boolean = true;
        let disableRight: boolean = false;
       
       if (this.props.model.importDecItems.sac) {
            this.lastVersion= this.props.model.importDecItems.lastVersion;
            this.matchStatus = this.props.model.importDecItems.matchStatus ;
        }
       
        disableLeft = this.version == 1;
        disableRight = this.version == this.lastVersion;

        const items : IContextualMenuItem[] = [
            {
                 key: "name",
                 name: "SELF ASSESSED CLEARANCE",
                 className:"sac-left-menu-item"
            }
           
        ];

        const farItems: IContextualMenuItem[] = [
            {
                key: "matchStatus",
                name: `Match Status: ${this.matchStatus}`,
                className:"sac-match-status-item"

            },
             {
                key: "LA",
                name: "",
                iconProps: { iconName: "ChevronLeft" },
                disabled: disableLeft,
                className: css(`sac-left-chevron`),
                onClick: this._loadPreviousSacReport
            },
            {
                key: this.reportText,
                name: `${this.reportText} ${this.version}`,
                className: css(`sac-report-title`)
            },
            {
                key: "RA",
                name: "",
                iconProps: { iconName: "ChevronRight" },
                className: css(`sac-right-chevron`),
                disabled: disableRight,
                onClick: this._loadNextSacReport 
            }
        ];
    
         return <CommandBar key={"sac"} className="import-dec-command-bar" items={items} farItems={farItems} />;   
    }
 }

@observer
class MECargoSacReport extends React.Component<ICargoSacDetailsProps, any> {
     
       render(){
       return (
              <div className="import-dec-section">
                    <div>{<CargoSacCommandBar {...this.props} />} </div>
                    <div className="ms-Grid-row">
                         <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                             {<MECargoSacDetailsList  {...this.props} />}
                         </div>
                         <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                             {<MECargoSacGoodsInfoList {...this.props} />}
                        </div>
                    </div>
                   <div >
                          {<CargoSacContactInfoList {...this.props} />}
                   </div>
                        
                    
              </div>
         );
    }

}

export {MECargoSacReport, ICargoSacDetailsProps}