import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECargoFidNSacInformation} from "../../../../cargo/cargoreport/fidNsac/IMECargoFidNSacInformation";
import {IMECargoFidNSacModel } from "../../../../cargo/cargoreport/fidNsac/IMECargoFidNSacModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./FidDocDetails.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{  
    key: "modeOfTransport",
    name: "Mode of Transport:",
    fieldName: "modeOfTransport",
    minWidth: 50,
    isMultiline: true
},
 {
        key: "loadingPort",
        name: "Loading Port:",
        fieldName: "loadingPort",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "destinationPortID",
        name: "Destination Port ID:",
        fieldName: "destinationPortID",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "firstArrivalPort",
        name: "First Arrival Port:",
        fieldName: "firstArrivalPort",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "grossWeight",
        name: "Gross Weight:",
        fieldName: "grossWeight",
        minWidth: 50,
        isMultiline: true
    },
    {
         key: "airlineCode",
        name: "Airline Code:",
        fieldName: "airlineCode",
        minWidth: 50,
        isMultiline: true

    },
     {
        key: "dischargePort",
        name: "Discharge Port:",
        fieldName: "dischargePort",
        minWidth: 50,
        isMultiline: true
    },
         
    {
        key: "arrivalDate",
        name: "Arrival Date:",
        fieldName: "arrivalDate",
        minWidth: 50,
        isMultiline: true
    },
    {
         key: "firstArrivalDate",
        name: "First Arrival Date:",
        fieldName: "firstArrivalDate",
        minWidth: 50,
        isMultiline: true
    },
       
    {
       key: "deliveryAddress",
        name: "Delivery Address:",
        fieldName: "deliveryAddress",
        minWidth: 50,
        isMultiline: true

    /*
    {
        key: "modeOfReceipt",
        name: "Mode of Receipt:",
        fieldName: "modeOfReceipt",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "vesselNo",
        name: "Vessel No:",
        fieldName: "vesselNo",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "voyageNo",
        name: "Voyage No:",
        fieldName: "voyageNo",
        minWidth: 50,
        isMultiline: true
    */
       
    }];

interface IMECargoFidDocumentDetailsProps {
    model?: IMECargoFidNSacModel;
    
}

const MECargoFidDocDetailsViewPrefsStore = new ViewPreferencesModel("CargoFidDocDetails");

class CargoFidDocumentDetails extends React.Component<IMECargoFidDocumentDetailsProps, any> {
    render() {
        let content;
        if(this.props.model) {
            console.log("From Fid Doc details: ",  this.props.model.importDecItems, this.props.model.importDecItems);
            content = <DetailsItem model={this.props.model.importDecItems} attrConfig={Fields} viewPrefModel={MECargoFidDocDetailsViewPrefsStore}/>;
            
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="fid-document-details">{content}</div>;
    }
}

class CargoFidDocDetailsContainer extends React.Component<IMECargoFidDocumentDetailsProps, any> {
    private _onRenderDone = () => {
        return <CargoFidDocumentDetails {...this.props} />;
    }
    render() {
        console.log("sync=", this.props.model.sync);
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading ME Cargo Fid Document Details..." />;
    }
}

class CargoFidDocDetailsList extends React.Component<IMECargoFidDocumentDetailsProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Document Details'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("fid-doc-details-header")}
                         bodyClassName="fid-document-details-body">
                         <CargoFidDocDetailsContainer {...this.props} />
           </Details>
        );
    }
}

export {
    CargoFidDocDetailsList as default,
    CargoFidDocDetailsList,
    CargoFidDocumentDetails,
    IMECargoFidDocumentDetailsProps,
    Fields as FidDocDetailsFields,
    MECargoFidDocDetailsViewPrefsStore
};