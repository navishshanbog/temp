import * as React from 'react';
import { observer } from "mobx-react";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import FidDeclarationList from "./FidDeclarationDetails";
import { Link } from "office-ui-fabric-react/lib/Link";
import CargoFidDocDetailsList from "./FidDocDetails";
import  CargoFidContactDetailsList from "./FidContactDetails";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import "./CargoFIDReport.scss";

interface IMECargoFidDetailsProps {
    model?: IMECargoImportDeclarationModel ;
}

@observer
class CargoFidReportCommandBar extends React.Component<IMECargoFidDetailsProps, any> {
     private reportText: string = "Ver: ";
     private version: number =  this.props.model.versionNo;
     
     private _loadPreviousFidReport = () => {
         this.version = this.version - 1;
         this.props.model. updateSelectedImportDocumentVersion(this.props.model.selectedReport, this.version);
         
      };

      private _loadNextFidReport = () => {
         this.version = this.version + 1;
         this.props.model. updateSelectedImportDocumentVersion(this.props.model.selectedReport, this.version);
      }
      
      render() {
        let disableLeft: boolean = true;
        let disableRight: boolean = true;
        let lastVersion:number = this.props.model.importDecItems ? this.props.model.importDecItems.lastVersion : 0;
        let matchStatus:string = this.props.model.importDecItems ? this.props.model.importDecItems.matchStatus : "";
       
        disableLeft = this.version == 1;
        disableRight = this.version == lastVersion;
        //console.log("versionNo + lastVersion + disableRight: ", this.version, lastVersion, disableRight);

        const items : IContextualMenuItem[] = [
            {
                key: "name",
                name: "New IMPORT DECLARATION",
                className:"fid-left-menu-item"
            }
           
        ];

        const farItems: IContextualMenuItem[] = [
            {
                key: "matchStatus",
                name: `Match Status: ${matchStatus}`,
                className:"fid-match-status-far-item" 
            },
             {
                key: "LA",
                name: "",
                iconProps: { iconName: "ChevronLeft" },
                disabled: disableLeft,
                className: css(`fid-left-chevron`),
                onClick: this._loadPreviousFidReport
            },
            {
                key: this.reportText,
                name: `${this.reportText} ${this.version}`,
                className: css(`cargo-report-title`)
            },
            {
                key: "RA",
                name: "",
                iconProps: { iconName: "ChevronRight" },
                className: css(`fid-right-chevron`),
                disabled: disableRight,
                onClick: this._loadNextFidReport 
            }
           
        ];
    
        return <CommandBar key={"version"} className="import-dec-command-bar" items={items} farItems={farItems} />;   
    }
}

@observer
class CargoFidReport extends React.Component<IMECargoFidDetailsProps, any> {
    _handleClick() {
        alert("Open next Fid...");
    }
   
    render() {
       
       return (
              <div className="import-dec-section">
               
                <div>{<CargoFidReportCommandBar {...this.props} />} </div>
                    <div>
                        {<FidDeclarationList  {...this.props} />}
                    </div>
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<CargoFidDocDetailsList {...this.props} />}
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<CargoFidContactDetailsList {...this.props} />}
                        </div>
                    </div>
                    
             </div>
         );
    }

}

export {CargoFidReport, IMECargoFidDetailsProps}