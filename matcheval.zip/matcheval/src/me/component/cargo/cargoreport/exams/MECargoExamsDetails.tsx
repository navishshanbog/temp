import * as React from 'react';
import { observer } from "mobx-react";
//import "./VisaHistoryCaseSummary.scss";
import { IMECargoExamsModel } from "../../../../cargo/cargoreport/exams/IMECargoExamsModel";
import { css } from "office-ui-fabric-react/lib/Utilities";
import {
    DetailsList,
    DetailsListLayoutMode,
    CheckboxVisibility,
    DetailsRow,
    ConstrainMode,
    SelectionMode,
    IColumn,
    Selection
} from "office-ui-fabric-react/lib/DetailsList";

import {MECargoExamsColumns} from "./MECargoExamsColumns";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Details from "@twii/common/lib/component/Details";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import "./MECargoExamsDetails.scss";
import ConsigneeHistoryList from "./ExamsConsigneeHistory";

interface IMECargoExamsDetailsProps{
    model?: IMECargoExamsModel;
}

@observer
class MECargoExamsDetails extends React.Component<IMECargoExamsDetailsProps, any> {
render() {
    let content  = <Spinner label="Loading ..." className="load-spinner" />;
    let examsColumns = MECargoExamsColumns;
    if (this.props.model.sync.error) {
            content = <div> Error occurred while retrieving the data. Please try again! </div>;
    } else {
        if(this.props.model.examsItems.length > 0 ) {
             content = <DetailsList columns={examsColumns}
                                   compact={true}
                                   checkboxVisibility={CheckboxVisibility.hidden}
                                   selectionMode={SelectionMode.none}
                                   items={this.props.model.examsItems}/>
        }
            
    }
    return (
        <div className="exams-report-section">
            <div className="exams-report-header"> EXAMS </div>
            <ConsigneeHistoryList model={this.props.model} />
            <Details className={css("exams-details")}
                         summary={"EXAMS in the last 12 months"}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("exams-details-ribbon")}>
                    {content}
            </Details>
        </div>       
            
    );

}

}

export {MECargoExamsDetails as default, MECargoExamsDetails, IMECargoExamsDetailsProps}