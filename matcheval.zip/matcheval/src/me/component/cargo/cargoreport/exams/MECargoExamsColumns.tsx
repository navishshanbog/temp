import * as React from "react";
import {
    IColumn,
    ColumnActionsMode
} from "office-ui-fabric-react/lib/DetailsList";
import {IMECargoExamsReport} from "../../../../cargo/cargoreport/exams/IMECargoExamsReport";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as StringUtils from "@twii/common/lib/util/String";

const ExamsDate : IColumn = {
    key: "examsDate",
    ariaLabel: "Exams Date",
    name: "Exams Date",
    fieldName: "examsDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 120,
    
};

const CargoType : IColumn = {
    key: "cargoType",
    ariaLabel: "Cargo Type",
    name: "Cargo Type",
    fieldName: "cargoType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 80,
    
};

const MasterBillNbr : IColumn = {
    key: "masterBillNbr",
    ariaLabel: "Master Bill/Ocean",
    name: "Master Bill/Ocean",
    fieldName: "masterBillNbr",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150,
};


const HouseBillNbr : IColumn = {
    key: "houseBillNbr",
    ariaLabel: "House Bill",
    name: "House Bill",
    fieldName: "houseBillNbr",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 150,
};


const Role : IColumn = {
    key: "entityExaminationRoleType",
    ariaLabel: "Entity Examination Role Type",
    name: "Entity Examination Role Type",
    fieldName: "entityExaminationRoleType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 100,
};

const ExamsId : IColumn = {
    key: "examsId",
    ariaLabel: "Exams ID",
    name: "Exams ID",
    fieldName: "examsId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100,
    
};

const BillType : IColumn = {
    key: "billType",
    ariaLabel: "Bill Type",
    name: "Bill Type",
    fieldName: "billType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 100,
};

const GoodDesc : IColumn = {
    key: "goodDescription",
    ariaLabel: "Good Description",
    name: "Good Description",
    fieldName: "goodDescription",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 120,
};


const ConsigneeName : IColumn = {
    key: "consigneeName",
    ariaLabel: "Consignee Name",
    name: "Consignee Name",
    fieldName: "Consignee Name",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 120,
};

const ConsigneeAddress : IColumn = {
    key: "consigneeAddress",
    ariaLabel: "Consignee Address",
    name: "Consignee Address",
    fieldName: "consigneeAddress",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 200,
};

const ConsignorName : IColumn = {
    key: "consignorName",
    ariaLabel: "Consignor Name",
    name: "Consignor Name",
    fieldName: "consignorName",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 120,
};
const ConsignorAddress : IColumn = {
    key: "consignorAddress",
    ariaLabel: "Consignor Address",
    name: "Consignor Address",
    fieldName: "consignorAddress",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 200,
};
const CriteriaDesc : IColumn = {
    key: "selectionCriteriaDesc",
    ariaLabel: "Selection Criteria Desc",
    name: "Selection Criteria Desc",
    fieldName: "selectionCriteriaDesc",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 100,
};

const ExamsStatus: IColumn = {
    key: "examsStatus",
    ariaLabel: "Exams Status",
    name: "Exams Status",
    fieldName: "examsStatus",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 80,
    maxWidth: 100,
    
};

const PriorityType : IColumn = {
    key: "priorityType",
    ariaLabel: "Priority Type",
    name: "Priority Type",
    fieldName: "priorityType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
    
};

const ExamPort : IColumn = {
    key: "examPort",
    ariaLabel: "Exam Port",
    name: "Exam Port",
    fieldName: "examPort",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const FindType: IColumn = {
    key: "findType",
    ariaLabel: "Find Type",
    name: "Find Type",
    fieldName: "findType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const ToolUsed: IColumn = {
    key: "toolUsed",
    ariaLabel: "Tool Used",
    name: "Tool Used",
    fieldName: "toolUsed",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 60,
    maxWidth: 80,
};

const MECargoExamsColumns : IColumn[] = [
    ExamsDate,
CargoType,
MasterBillNbr,
HouseBillNbr,
Role,
ExamsId,
BillType,
GoodDesc,
ConsigneeName,
ConsigneeAddress,
ConsignorName,
ConsignorAddress,
CriteriaDesc,
ExamsStatus,
PriorityType,
ExamPort,
FindType,
ToolUsed
];

export {
    MECargoExamsColumns as default,
    MECargoExamsColumns,
    ExamsDate,
CargoType,
MasterBillNbr,
HouseBillNbr,
Role,
ExamsId,
BillType,
GoodDesc,
ConsigneeName,
ConsigneeAddress,
ConsignorName,
ConsignorAddress,
CriteriaDesc,
ExamsStatus,
PriorityType,
ExamPort,
FindType,
ToolUsed
};


