import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMECargoExamsReport} from "../../../../cargo/cargoreport/Exams/IMECargoExamsReport";
import {IMECargoExamsModel } from "../../../../cargo/cargoreport/exams/IMECargoExamsModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./ExamsInventionHistory.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{  
    key: "nbrOfMatch",
    name: "Number of Matches:",
    fieldName: "nbrOfMatch",
    minWidth: 50,
    isMultiline: true
},
   
    {
        key: "nbrOfExams",
        name: "Importer Name:",
        fieldName: "Number of EXAMS:",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "nbrOfFinds",
        name: "Number of finds:",
        fieldName: "nbrOfFinds",
        minWidth: 50,
        isMultiline: true
    },

    {
        key: "nbrOfSignificantFinds",
        name: "Number of significant find:",
        fieldName: "nbrOfSignificantFinds",
        minWidth: 50,
        isMultiline: true
    
       }];


interface IConsigneeHistoryProps {
    model?: IMECargoExamsModel ;
}

const ConsigneeHistoryViewPrefsStore = new ViewPreferencesModel("ConsigneeHistory");

class ConsigneeHistory extends React.Component<IConsigneeHistoryProps  , any> {
    render() {
        let content;
        if(this.props.model) {
           content = <DetailsItem model={this.props.model.examsItems[0]} attrConfig={Fields} viewPrefModel={ConsigneeHistoryViewPrefsStore}/>;
            //content = this.props.model.examsItems.map((detail: IMECargoExamsReport, idx: number) => {
                
            //    return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={ConsigneeHistoryViewPrefsStore}/>;
           // });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="Exams-details">{content}</div>;
    }
}

class ConsigneeHistoryContainer extends React.Component<IConsigneeHistoryProps, any> {
    private _onRenderDone = () => {
        return <ConsigneeHistory {...this.props} />;
    }
    render() {
       return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading consignee history..." />;
    }
}

class ConsigneeHistoryList extends React.Component< IConsigneeHistoryProps , any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Consignee invention history'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("Exams-details-header")}
                         bodyClassName="Exams-details-body">
                         <ConsigneeHistoryContainer {...this.props} />
           </Details>
        );
    }
}

export {
    ConsigneeHistoryList as default,
    ConsigneeHistoryList,
    ConsigneeHistory,
    IConsigneeHistoryProps,
    Fields as ExamsDetailsFields,
    ConsigneeHistoryViewPrefsStore
};