import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
//import ISeaCargoActivityDetail from "@twii/entity/lib/cargo/sea/ISeaCargoActivityDetail";
//import {IMESeaCargoModel} from "../../../cargo/seacargo/IMESeaCargoModel";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import {IMECargoReportDetails} from "../../../cargo/cargoreport/IMECargoReportDetails";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./SCRContactInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";

const Fields:  IColumn[] = [{ //IDetailsAttributeConfig<ISeaCargoActivityDetail>[] = [{
    key: "consignee",
    name: "Consignee:",
    fieldName: "consignee",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consigneePhone",
    name: "Consignee Phone:",
    fieldName: "consigneePhone",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consignor",
    name: "Consignor:",
    fieldName: "consignor",
    minWidth: 80,
    isMultiline: true
},
{
    key: "reportingClient",
    name: "Reporting Client:",
    fieldName: "reportingClient",
    minWidth: 80,
    isMultiline: true
},
{
    key: "reponsible",
    name: "Responsible:",
    fieldName: "reponsible",
    minWidth: 80,
    isMultiline: true
},
{
    key: "notify",
    name: "Notify:",
    fieldName: "notify",
    minWidth: 50,
    isMultiline: true
},
{
    key:"principalAgent",
    name: "Principal Agent:",
    fieldName: "principalAgent",
    minWidth: 50,
    isMultiline: true
},
{
    key:"importerId",
    name: "Importer (ID):",
    fieldName: "importerId",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consigneeAddress",
    name: "Consignee Address:",
    fieldName: "consigneeAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consignorAddress",
    name: "Consignor Address:",
    fieldName: "consignorAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "reportingAddress",
    name: "Reporting Address:",
    fieldName: "reportingAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "responsibleClientAddress",
    name: "Responsible Client Address:",
    fieldName: "responsibleClientAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "notifyAddress",
    name: "Notify Address:",
    fieldName: "notifyAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "principalAgentAddress",
    name: "Principal Agent Address:",
    fieldName: "principalAgentAddress",
    minWidth: 50,
    isMultiline: true
 },
 {
    key:"supplierId",
    name: "Supplier ID:",
    fieldName: "supplierId",
    minWidth: 50,
    isMultiline: true 
 }];

 interface ISeaCargoActivityDetailsContactInfoProps {
     model?: IMECargoReportModel;
 }

 const SeaCargoActivityDetailsContactInfoViewPrefStore = new ViewPreferencesModel("seaCargoActivityDetailsContactInfo");

 class SeaCargoActivityDetailsContactInfo extends React.Component<ISeaCargoActivityDetailsContactInfoProps, any> {
    render() {
        let content;
        if(this.props.model) {
            content = <DetailsItem  model={this.props.model.items.contactInformation} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsContactInfoViewPrefStore}/>
            /*
            content = <DetailsItem  model={this.props.model.selectedReport.cargoReport} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsContactInfoViewPrefStore}/>
            
            content = this.props.model.items.map((detail: IMECargoReportInformation, idx: number) => {
                return <DetailsItem key={idx} model={detail.contactInformation} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsContactInfoViewPrefStore  }/>;
            }); 
            */          
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load contact infomation details</MessageBar>;
        }
        return <div className="sea-cargo-activity-details-contact-info">{content}</div>;

    
    }   
 }

class SeaCargoActivityDetailsContactInfoContainer extends React.Component<ISeaCargoActivityDetailsContactInfoProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetailsContactInfo {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea cargo Details contact information..." />;

    }

}  

@observer

class SeaCargoReportContactInfoList extends React.Component<ISeaCargoActivityDetailsContactInfoProps, any> {
    render() {
        console.log("Enter SCR contact info list");
        return (
            <Details className={css("details-panel")}
                        summary={<div>{"Contact Information"}</div>}
                        open={true}
                        controlOnHeaderClick={true}
                        headerClassName={css("sea-cargo-activity-details-contact-info-header")}
                        bodyClassName={css("sea-cargo-activity-details-contact-info-body")}>
                        
                        <SeaCargoActivityDetailsContactInfoContainer {...this.props} />

            </Details>
        );
    }

}

export {
    SeaCargoReportContactInfoList as default,
    SeaCargoReportContactInfoList,
    SeaCargoActivityDetailsContactInfoContainer,
    SeaCargoActivityDetailsContactInfo,
    ISeaCargoActivityDetailsContactInfoProps,
    Fields as SeaCargoContactInfoFields,
    SeaCargoActivityDetailsContactInfoViewPrefStore

}   