import * as React from 'react';
import { observer } from "mobx-react";
//import {IMESeaCargoModel} from "../../../cargo/seacargo/IMESeaCargoModel";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import SeaCargoReportInformationList from "./SCRInformation";
import SeaCargoReportContactInfoList from "./SCRContactInfo";
import SeaCargoReportGoodsInfoList from "./SCRGoodsInfo";
import SeaCargoReportGoodsIndList from "./SCRGoodsIndicator";
import SeaCargoReportExamsInfoList from "./SCRExamsInfo";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import "../seacargo/MESeaCargoReport.scss";

interface IMECargoDetailsProps {
    model?: IMECargoReportModel;
}

 @observer
class SeaCargoReportCommandBar extends React.Component<IMECargoDetailsProps, any> {
      private reportText: string = "Ver: ";
      private version:number = this.props.model.versionNo;
      private _loadPreviousReport = () => {
       this.props.model.updateSelectedReportVersion(this.props.model.versionNo - 1);
       this.version = this.version - 1; 
    };
    private _loadNextReport = () => {
       this.version = this.version + 1;
       console.log("this.props.model.versionNo= ", this.props.model.versionNo, this.props.model.versionNo + 1)
       this.props.model.updateSelectedReportVersion(this.version);
       console.log("next version =",this.props.model.versionNo, this.version);
    }
    render() {
      
        let disableLeft: boolean = true;
        let disableRight: boolean = true;
    
        let lastVersion:number = this.props.model.items ? this.props.model.items.lastVersion : 0;
        let matchStatus:string = this.props.model.items ? this.props.model.items.matchStatus : "";
        disableLeft = this.version == 1;
        disableRight = this.version == lastVersion;
    
        const items : IContextualMenuItem[] = [
            {
                key: "name",
                name: "SEA CARGO REPORT",
                className: "sea-cargo-report-left-item"
            }
           
        ];

        const farItems: IContextualMenuItem[] = [
            {
                key: "matchStatus",
                name: `Match Status: ${matchStatus}`,
                className:"sea-cargo-match-status-far-item"
            },
             {
                key: "LA",
                name: "",
                iconProps: { iconName: "ChevronLeft" },
                disabled: disableLeft,
                className: css(`cargo-report-left-chevron`),
                onClick: this._loadPreviousReport
            },
            {
                key: this.reportText,
                name: `${this.reportText} ${this.version}`,
                className: css(`cargo-report-title`)
            },
            {
                key: "RA",
                name: "",
                iconProps: { iconName: "ChevronRight" },
                className: css(`cargo-report-right-chevron`),
                disabled: disableRight,
                onClick: this._loadNextReport 
            }
           
        ];
    
        return <CommandBar key={"version"} className="cargo-report-command-bar" items={items} farItems={farItems}/>;   
    }
}


@observer
class MESeaCargoReport extends React.Component<IMECargoDetailsProps, any> {
    render() {
        console.log("sae cargo model: ", this.props.model.items);
        return (
            <div className="cargo-report-section">
               
                <div>{<SeaCargoReportCommandBar {...this.props} />} </div>
                <div className="ms-Grid">
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<SeaCargoReportInformationList {...this.props} />}
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {< SeaCargoReportGoodsIndList {...this.props} />}
                           
                        </div>
                    </div>
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<SeaCargoReportContactInfoList {...this.props} />}
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<SeaCargoReportGoodsInfoList {...this.props} />}
                        </div>
                    </div>
                    
                     <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {/*<SeaCargoReportExamsInfoList {...this.props} />*/}
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {/*<AirCargoActivityDetailGoodsIndContainer {...this.props} />*/}
                        </div>
                    </div>
                    
                </div>
            </div>
        );
    }
}

export {MESeaCargoReport, IMECargoDetailsProps}

