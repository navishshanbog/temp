import * as React from "react";
import "./MECargoBramAttribute.scss";

interface BramAttributeProps {
    label: string;
    value: string | JSX.Element;
}

class MECargoBramAttribute extends React.Component<BramAttributeProps, any> {
    render() {
        return (

            <div className="ms-Grid ms-Grid-col ms-sm12 ms-md12 profile-assessment-wrapper">
                <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-sm6 ms-md3 attribute-label">
                        <span className="attribute-label">{this.props.label}</span>
                    </div>
                    <div className="ms-Grid-col ms-sm6 ms-md9">
                        <span>{this.props.value}</span>
                    </div>
                </div>
            </div>
        )
    }
}

export { MECargoBramAttribute,BramAttributeProps };