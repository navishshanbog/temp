import * as React from 'react';
import { observer } from "mobx-react";
import {IMECargoImportDeclarationModel } from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import {IMECargoBramModel} from  "../../../../cargo/cargoreport/bram/IMECargoBramModel";
import { CargoBramDetails } from "./MECargoBramDetails";
import { MECargoBramScoreAndMatch } from "./MECargoBramScoreAndMatch";
import "./MECargoBramReport.scss";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";

 interface ICargoBramReportProps {
         model?: IMECargoBramModel;
 }

 @observer
 class CargoReportBramCommandBar extends React.Component<ICargoBramReportProps, any> {
      private reportText: string = "Ver: ";
      private version: number =  this.props.model.versionNo;
      private lastVersion:number = 2;
      private  matchStatus:string = "MATCHED";

      render() {
         let disableLeft: boolean = true;
         let disableRight: boolean = false;
             
        if (this.props.model) {
            this.lastVersion= this.props.model.bramItems.lastVersion;
           
        }
       
        disableLeft = this.version == 1;
        disableRight = this.version == this.lastVersion;


        const items : IContextualMenuItem[] = [
            {
                key: "name",
                name: "BRAM",
                className:"bram-report-title"
            }
           
        ];

        return <CommandBar key={"version"} className="bram-command-bar" items={items}  />;   
    }
}

class MECargoBramReport extends React.Component<ICargoBramReportProps, any> {     
       render() {
       return (
              <div className="bram-section">
                    <div>{<CargoReportBramCommandBar {...this.props} />} </div>
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<CargoBramDetails  {...this.props} />}
                        </div>
                         <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<MECargoBramScoreAndMatch {...this.props} />}
                        </div>
                        
                    </div>
              </div>
         );
    }

}

export {MECargoBramReport, ICargoBramReportProps}