import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IBramReport} from "../../../../cargo/seacargo/bram/IBramReport";
import {IMECargoImportDeclarationModel} from "../../../../cargo/cargoreport/fid/IMECargoImportDeclarationModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./MECargoBramScoreAndMatch.scss";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import {IMECargoFidReport} from "../../../../cargo/cargoreport/fid/IMECargoFidReport";
import {IMECargoBramModel } from "../../../../cargo/cargoreport/bram/IMECargoBramModel";
import * as StringUtils from "@twii/common/lib/util/String";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import {MECargoBramAttribute} from "./MECargoBramAttribute" ;

const BramScoreAndMatchColumn= [
    {  
        key: "overallScore",
        name: "Overall Score:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.scoreAndMatchDetails.overallScore ? source.scoreAndMatchDetails.overallScore : ""}/>
        }
    },
    {
        key: "riskTypeAndScore",
        name: "Risk Types & Score:",
        onRender: (source: any, field: any) => {
            let riskAss;
            if(source.scoreAndMatchDetails.riskTypeAndScore && source.scoreAndMatchDetails.riskTypeAndScore.length > 0) {
                riskAss = source.scoreAndMatchDetails.riskTypeAndScore.map((ra, idx) => {
                let riskScore = "";
                riskScore = ra.type? ra.type : "";
                riskScore = ra.score? riskScore ? `${riskScore} [${ra.score}]`: `${ra.score}`: riskScore;
                return <div key={idx}>{riskScore}</div>;
            });
        }
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={riskAss}/>
        }
    },
    {
        key: "matchStatus",
        name: "Match Status:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.scoreAndMatchDetails.matchStatus ? source.scoreAndMatchDetails.matchStatus : ""}/>
        }
    },
    {
        key: "matchValue",
        name: "Matches Values:",
        onRender: (source: any, field: any) => {
            let allValues:string[] = [] ;
            let mVal;
            if(source.scoreAndMatchDetails.matchValue.length>0){
                mVal = source.scoreAndMatchDetails.matchValue.map((mv, idx) => {
                            return <div key={idx}>{mv}</div>;
                });
            }
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={mVal}/>
        }
    },
    {
        key: "actionOrOutcome",
        name: "Action/Outcome:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.scoreAndMatchDetails.actionOrOutcome ? source.scoreAndMatchDetails.actionOrOutcome : ""}/>
        }
    }
   ];

interface IMECargoBramScoreAndMatchProps {
    model?: IMECargoBramModel;
}

const MECargoBramScoreAndMatchViewPrefsStore = new ViewPreferencesModel("MECargoBramScoreAndMatch");

@observer
class MECargoBramScoreAndMatch extends React.Component< IMECargoBramScoreAndMatchProps , any> {
    render() {
        let content;
        if(this.props.model.sync.syncing) {
             content = <Spinner label="Loading ..." className="load-spinner" />;
           
        } else if (this.props.model.sync.error) {
             content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if (this.props.model.sync.hasSynced) {
            if (this.props.model.bramItems) {
                let items;
                items = BramScoreAndMatchColumn.map((field: any) => {
                    if (field.onRender) {
                        return field.onRender(this.props.model.bramItems, field);
                    }
                });
                content = <Details className={css("bram-score")}
                                     summary={"Score and Match Details"}
                                     open={true}
                                     controlOnHeaderClick={true}
                                     bodyClassName={("bram-score-body")}
                                     headerClassName={css("bram-score-header")}>
                    {items}
                </Details>
            } else {
                content=  <div> No Bram Score and match found</div>
            }
        }
        return <div className="bram-score-details">{content}</div>;
    }
}


export {
    MECargoBramScoreAndMatch as default,
    MECargoBramScoreAndMatch,
    IMECargoBramScoreAndMatchProps,
    MECargoBramScoreAndMatchViewPrefsStore
};