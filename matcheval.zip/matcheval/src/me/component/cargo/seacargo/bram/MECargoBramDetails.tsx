import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IBramReport} from "../../../../cargo/seacargo/bram/IBramReport";
import {IMECargoFidReport} from "../../../../cargo/cargoreport/fid/IMECargoFidReport";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import {IMECargoBramModel } from "../../../../cargo/cargoreport/bram/IMECargoBramModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./MECargoBramDetails.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import {MECargoBramAttribute} from "./MECargoBramAttribute" ;

const BramDetailsColumn = [{  
    key: "declarationId",
    name: "Declaration ID:",
    onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.declarationId ? source.bramScore.declarationId: ""}/>
    }
},
    {
        key: "vesselId",
        name: "Vessel Id:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.vesselId ? source.bramScore.vesselId: ""}/>
        }   
    },
    {
        key: "importerName",
        name: "Importer Name:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.importerName ? source.bramScore.importerName: ""}/>
        }
    },
    {
        key: "deliveryClientName",
        name: "Delivery Client Name:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.deliveryClientName ? source.bramScore.deliveryClientName: ""}/>
        }
    },
    {
        key: "documentType",
        name: "Document Type:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.documentType ? source.bramScore.documentType: ""}/>
        }
    },
    {
        key: "vesselName",
        name: "Vessel Name:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.vesselName ? source.bramScore.vesselName: ""}/>
        }
    },
    {
        key: "importerABN",
        name: "Importer ABN:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.importerABN ? source.bramScore.importerABN: ""}/>
        }

    },
    {
        key: "originalLodgedDate",
        name: "Original Lodged Date:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.originalLodgedDate ? source.bramScore.originalLodgedDate: ""}/>
        }
    },
    {
        key: "transportType",
        name: "Transport Type:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.transportType ? source.bramScore.transportType: ""}/>
        }
    },
    {
        key: "brokerName",
        name: "Broker Name:",
        onRender: (source: any, field: any) => {
            return <MECargoBramAttribute label={field.name}
                                                            key={field.key} value={source.bramScore.brokerName ? source.bramScore.brokerName: ""}/>
        }
}];

interface ICargoBramDetailsProps {
    model?: IMECargoBramModel;
}

const CargoBramDetailsViewPrefsStore = new ViewPreferencesModel("CargoBramDetails");
@observer
class CargoBramDetails extends React.Component<ICargoBramDetailsProps , any> {
   render() {
        let content;
        if(this.props.model.sync.syncing) {
             content = <Spinner label="Loading ..." className="load-spinner" />;
           
        } else if (this.props.model.sync.error) {
             content = <div> Error occurred while retrieving the data. Please try again! </div>;
        } else if (this.props.model.sync.hasSynced) {
            if (this.props.model.bramItems) {
                let items;
                items = BramDetailsColumn.map((field: any) => {
                    if (field.onRender) {
                        return field.onRender(this.props.model.bramItems, field);
                    }
                });
                content = <Details className={css("bram-item-details")}
                                     summary={"Bram Details"}
                                     open={true}
                                     controlOnHeaderClick={true}
                                     bodyClassName={css("bram-details-body")}
                                     headerClassName={css("bram-details-header")}>
                    {items}
                </Details>
            } else {
                content=  <div> No Bram Score and match found</div>
            }
        }
        return <div className="bram-details">{content}</div>;
    }
}

export {
    CargoBramDetails, CargoBramDetails as default,
    ICargoBramDetailsProps,
    CargoBramDetailsViewPrefsStore
};