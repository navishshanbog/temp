import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
//import {ISeaCargoActivityDetail} from "@twii/entity/lib/cargo/sea/ISeaCargoActivityDetail";
//import {IMESeaCargoModel} from "../../../cargo/seacargo/IMESeaCargoModel";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./SCRInformation.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
const Fields: IColumn[] = [{  // IDetailsAttributeConfig<ISeaCargoActivityDetail>[] = [{
    key: "documentType",
    name: "Document Type:",
    fieldName: "documentType",
    /*
    onRender: () => {
        return <DetailsAttribute key={this.key} label={this.name} value={"SCR"}/>;
    },
    */
    minWidth: 50,
    isMultiline: true

},
    {
        key: "clearanceType",
        name: "Clearance Type:",
        fieldName: "clearanceType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "houseBill",
        name: "Housebill:",
        fieldName: "houseBill",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "parentBillNo",
        name: "Parent Bill Number:",
        fieldName: "parentBillNo",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "lineNo",
        name: "Line Number & Count:",
        fieldName: "lineNoAndCount",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "date",
        name: "Date:",
        fieldName: "date",
        minWidth: 50,
        isMultiline: true
    },
   
    {
        key: "oceanBill",
        name: "Oceanbill:",
        fieldName: "oceanBill",
        minWidth: 50,
        isMultiline: true
    }
   ];

interface ISeaCargoActivityDetailCargoReportProps {
      model?: IMECargoReportModel;
}

const SeaCargoActivityDetailsViewPrefsStore = new ViewPreferencesModel("seaCargoActivityDetails");

class SeaCargoActivityDetails extends React.Component<ISeaCargoActivityDetailCargoReportProps, any> {
    render() {
        let content;
        if(this.props.model) {
            content = <DetailsItem  model={this.props.model.items.cargoReport} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsViewPrefsStore}/>;
             
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="sea-cargo-details-report">{content}</div>;
    }
}

class SeaCargoActivityDetailsContainer extends React.Component<ISeaCargoActivityDetailCargoReportProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetails {...this.props} />;
    }
    render() {
         console.log("sync=", this.props.model);
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea Cargo Details..." />;
    }
}

@observer
class SeaCargoReportInformationList extends React.Component<ISeaCargoActivityDetailCargoReportProps, any> {
    render() {
        return (
               <Details className={css("details-panel")}
                         summary={<div>{'Sea Cargo report information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("sea-cargo-activity-details-header")}
                         bodyClassName="sea-cargo-details-report-body">
                         <SeaCargoActivityDetailsContainer {...this.props} />
                </Details>
        );
    }
}

export {
    SeaCargoReportInformationList as default,
    SeaCargoReportInformationList,
    SeaCargoActivityDetailsContainer,
    SeaCargoActivityDetails,
    ISeaCargoActivityDetailCargoReportProps, Fields as SeaCargoActivityDetailCargoFields,
    SeaCargoActivityDetailsViewPrefsStore
};