import * as React from 'react';
import { observer } from "mobx-react";
import { Pivot, PivotItem, IPivotItemProps } from 'office-ui-fabric-react/lib/Pivot';
import {IMECase} from "../../../IMECase";
import {IMESeaCargoModel} from "../../../cargo/seacargo/IMESeaCargoModel";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import {MEHeader} from "../../MEHeader";
import {MESeaCargoReport} from "./MESeaCargoReport";
import "../seacargo/MESeaCargo.scss";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import {MECargoFidReport} from "../cargoreport/fid/MECargoFIDReport";
import {MECargoImportDeclarationModel } from "../../../cargo/cargoreport/fid/MECargoImportDeclarationModel";
import {MECargoImportDeclarationStore } from "../../../cargo/cargoreport/fid/MECargoImportDeclarationStore";
import MECargoExamsDetails from "../cargoreport/exams/MECargoExamsDetails";
import {MECargoExamsModel} from "../../../cargo/cargoreport/exams/MECargoExamsModel";
import {MECargoExamsStore} from "../../../cargo/cargoreport/exams/MECargoExamsStore";
import { MECargoBramReport } from "./bram/MECargoBramReport";
import {MECargoBramModel} from "../../../cargo/cargoreport/bram/MECargoBramModel";
import {MECargoBramStore} from "../../../cargo/cargoreport/bram/MECargoBramStore";
import {MECargoSacReport} from "../cargoreport/sac/MECargoSacReport";
import {ImportDeclarationReport} from "../cargoreport/ImportDeclarationReport";


interface IMESeaCargoProps {
    //cargoModel: IMESeaCargoModel;
    cargoModel: IMECargoReportModel;
    meCase: IMECase;
}

@observer
class MESeaCargo extends React.Component<IMESeaCargoProps, any> {
      private _onRefresh = () => {
        
    }
    ExamsModel: MECargoExamsModel = MECargoExamsStore;
    importDecDetails: MECargoImportDeclarationModel = MECargoImportDeclarationStore;
    BramDetails: MECargoBramModel = MECargoBramStore;
    render() {
        let headerDetails = this.props.meCase;
        let meSummaryContentHeader = <MEHeader headerDetails = {headerDetails}
                                               onRefresh={this._onRefresh}
                                               icon={<Icon iconName='Ferry'/>} />

        let pivotArray: React.ReactElement<IPivotItemProps>[] = [];
        if(this.importDecDetails.importDocType==="FID" || this.importDecDetails.importDocType==="Fid") {
            pivotArray.push( <PivotItem linkText='ME Sea Cargo' itemKey="0" key="0">
             <div className="me-boking-summary">
                 <MESeaCargoReport model={this.props.cargoModel} />
                 <ImportDeclarationReport model={this.importDecDetails} />
                 <MECargoBramReport model={this.BramDetails} />   
                 <MECargoExamsDetails model={this.ExamsModel} />
             </div>
        </PivotItem>);
        
        }
        else {
              pivotArray.push( <PivotItem linkText='Sea Cargo' itemKey="0" key="0">
             <div className="me-boking-summary">
                 <MESeaCargoReport model={this.props.cargoModel} />
                 <ImportDeclarationReport model={this.importDecDetails} />
                 <MECargoExamsDetails model={this.ExamsModel} />
             </div>
        </PivotItem>);
        }
        let meSummaryContent = <div>
            {meSummaryContentHeader}
            <Pivot selectedKey="0" >
                {pivotArray}
            </Pivot>
        </div>

        return (
            <div className="me-summary">
                {meSummaryContent}
            </div>
        );
    }
}
export { MESeaCargo, IMESeaCargoProps }
