import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
//import ISeaCargoActivityDetail from "@twii/entity/lib/cargo/sea/ISeaCargoActivityDetail";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./SCRGoodsIndicator.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";


const getFullValText = (item: string) => {
	let fullValText;
	if (item === "Y") {
            fullValText = "Yes";
        }
        else if (item === "N") {
            fullValText = "No";
        }
        else {
            fullValText = item;
        }
	return fullValText;
}

const Fields: IColumn[] = [{ // IDetailsAttributeConfig<ISeaCargoActivityDetail>[] = [{
    key: "freightForward",
    name: "Freight forward:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.freightForwardInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.freightForwardInd)},
    */
    fieldName: "freightForward",
    minWidth: 50,
    isMultiline: true
},
{
    key: "lowestBill",
    name: "Lowest Bill:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.lowestBill)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.lowestBill)},
    */
    fieldName: "lowestBill",
    minWidth: 50,
    isMultiline: true
},
{
    key: "perishableGoods",
    name: "Perishable Goods:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.perishableGoodsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.perishableGoodsInd)},
    */
    fieldName: "perishableGoods",
    minWidth: 50,
    isMultiline: true
},
{
    key: "reportableDocuments",
    name: "Reportable Documents:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.reportableDocumentsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.reportableDocumentsInd)},
    */
    fieldName: "reportableDocuments",
    minWidth: 50,
    isMultiline: true
},
{
    key: "shipperOwned",
    name: "Shipper Owned:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.shipperOwnedInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.shipperOwnedInd)},
    */
    fieldName: "shipperOwned",
    minWidth: 50,
    isMultiline: true
},
 {
        key: "transhipment",
        name: "Transhipment:",
        fieldName: "transhipment",
        minWidth: 50,
        isMultiline: true,

    
},
{
    key: "x-rayRequiements",
    name: "X-ray Requirement:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.xraySendRequirermentInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.xraySendRequirermentInd)},
    */
    fieldName: "x-rayRequiements",
    minWidth: 50,
    isMultiline: true
},
{
    key: "hazardousGoods",
    name: "Hazardous Goods:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.hazardousGoodsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.hazardousGoodsInd)},
    */
    fieldName: "hazardousGoods",
    minWidth: 50,
    isMultiline: true
},
{
    key: "personnelEffects",
    name: "Personal Effects:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.personalEffectsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.personalEffectsInd)},
    */
    fieldName: "personnelEffects",
    minWidth: 50,
    isMultiline: true
},
{
    key: "selfAssessedClearance",
    name: "Self-Assessed Clearance:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.selfAssessedClearanceInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.selfAssessedClearanceInd)},
    */
    fieldName: "selfAssessedClearance",
    minWidth: 50,
    isMultiline: true
},
{
    key: "positiveExamFind",
    name: "Positive Exam Find:",
    /*
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.positiveFindInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.positiveFindInd)},
    */
    fieldName: "positiveExamFind",
    minWidth: 50,
    isMultiline: true,
},
{
    key:"transit",
    name:"Transit:",
    fieldName:"transit",
    minWidth: 50,
    isMultiline: true,
}];

interface ISeaCargoActivityDetailGoodsIndProps {
    //model?: IMESeaCargoModel;
    model?: IMECargoReportModel;
}

const SeaCargoActivityDetailGoodsIndViewPrefsStore = new ViewPreferencesModel("seaCargoActivityDetailGoodInd");

class  SeaCargoActivityDetailGoodsInd extends React.Component<ISeaCargoActivityDetailGoodsIndProps, any> {
    render() {
        let content;
        if(this.props.model) {
            content = <DetailsItem  model={this.props.model.items.goodsIndicator} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailGoodsIndViewPrefsStore}/>;
              //content = <DetailsItem  model={this.props.model.selectedReport.cargoReport} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailGoodsIndViewPrefsStore}/>;
            //content = <DetailsItem  model={this.props.model.items} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailGoodsIndViewPrefsStore} />;
          /*
            content = this.props.model.items.map((detail: IMECargoReportInformation, idx: number) => {
                return <DetailsItem key={idx} model={detail.goodsIndicator} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailGoodsIndViewPrefsStore }/>;
             });
             */
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load detail</MessageBar>;
        }
        return <div className="sea-cargo-activity-details-goods-ind">{content} </div>;
    }
} 

class SeaCargoActivityDetailGoodsIndContainer extends React.Component<ISeaCargoActivityDetailGoodsIndProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetailGoodsInd {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea Cargo Details Goods Indicator information..." />;
    }
}
@observer

class SeaCargoReportGoodsIndList extends React.Component<ISeaCargoActivityDetailGoodsIndProps, any> {
    render() {
        return (
             <Details className={css("details-panel")}
                        summary={<div>{"Goods Indicators"}</div>}
                        open={true}
                        controlOnHeaderClick={true}
                        headerClassName={css("sea-cargo-activity-details-goods-ind-header")}
                        bodyClassName={css("sea-cargo-activity-details-goods-ind-body")}>
                        <SeaCargoActivityDetailGoodsIndContainer {...this.props} />
             </Details>
        );
    }
}

export { 
    SeaCargoReportGoodsIndList as default,
    SeaCargoReportGoodsIndList,
    SeaCargoActivityDetailGoodsIndContainer,
    SeaCargoActivityDetailGoodsInd,
    ISeaCargoActivityDetailGoodsIndProps,
    Fields as SeaCargoDetailGoodsIndFields,
    SeaCargoActivityDetailGoodsIndViewPrefsStore
};