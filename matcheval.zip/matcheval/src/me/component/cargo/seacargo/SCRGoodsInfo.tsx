import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import ISeaCargoActivityDetail from "@twii/entity/lib/cargo/sea/ISeaCargoActivityDetail";
//import {IMESeaCargoModel} from "../../../cargo/seacargo/IMESeaCargoModel";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./SCRGoodsInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";

const Fields: IColumn[] = [{  // IDetailsAttributeConfig<ISeaCargoActivityDetail> [] = [{
    key: "goodsDescription",
    name: "Goods description:",
    fieldName: "goodsDescription",
    minWidth: 50,
    isMultiline: true
},
    {
        key: "vessel",
        name: "Vessel & Voyage:",
        /*
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.vesselName) + (" (ID: ") + (item.vesselId) + ("), ") + (item.voyageNbr)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.vesselName} (ID: ${item.vesselId}), ${item.voyageNbr}`},
        */
        fieldName: "vessel",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "cargoType",
        name: "Cargo Type:",
        fieldName: "cargoType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "sealNo",
        name: "Seal number:",
        fieldName: "sealNo",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "originalLoadingPort",
        name: "Original Loading Port:",
        fieldName: "originalLoadingPort",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "lastOverseasPort",
        name: "Last Overseas Port:",
        fieldName: "lastOverseasPort",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "dischargeLocation",
        name: "Discharge location:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.dischargePortCode) + (", ") + (item.discharge_AUStateCode)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.dischargePortCode} , ${item.discharge_AUStateCode}`},
        fieldName: "dischargeLocation",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "estimatedFirstPortArrival",
        name: "Estimated first port arrival (AEST):",
        fieldName: "estimatedFirstPortArrival",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "arrivalBerth",
        name: "Arrival Berth:",
        fieldName: "arrivalBerth",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "freightMethodOfPayment",
        name: "Freight method of payment:",
        fieldName: "methodOfPayment",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "grossWeightAndUnit",
        name: "Gross Weight:",
        fieldName: "grossWeightAndUnit",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "withdraw",
        name: "Withdrawn:",
        fieldName: "withdraw",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "containerNo",
        name: "Container Number and Type:",
        fieldName: "containerNo",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "goodsOrigin",
        name: "Goods origin:",
        fieldName: "goodsOrigin",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "originPort",
        name: "Origin Port:",
        fieldName: "originPort",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "destination",
        name: "Destination:",
        fieldName: "destination",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "packageCountAndType",
        name: "Package Count & Type:",
        fieldName: "packageCountAndType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "actualArrivalTime",
        name: "Actual arrival time (AEST):",
        fieldName: "actualArrivalTime",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "transhipmentNo",
        name: "Transhipment number:",
        fieldName: "transhipmentNo",
        minWidth: 50,
        isMultiline: true
    }
    
   ];

interface ISeaCargoActivityDetailsGoodsInfoProps {
    //model?: IMESeaCargoModel;
    model?: IMECargoReportModel;
}

const SeaCargoActivityDetailsGoodsInfoViewPrefStore = new ViewPreferencesModel("seaCargoActivityDetailsGoodsInfo");

class SeaCargoActivityDetailsGoodsInfo extends React.Component<ISeaCargoActivityDetailsGoodsInfoProps, any> {
    render() {
        let content;
        if(this.props.model) {
            content = <DetailsItem  model={this.props.model.items.goodsAndVoyageInfo} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsGoodsInfoViewPrefStore}/>;
            /*
            content = <DetailsItem  model={this.props.model.selectedReport.cargoReport} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsGoodsInfoViewPrefStore}/>;
            
             content = this.props.model.items.map((detail: IMECargoReportInformation, idx: number) => {
                return <DetailsItem key={idx} model={detail.goodsAndVoyageInfo} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsGoodsInfoViewPrefStore }/>;
             });
             */
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}> Failed to load details</MessageBar>;

        }
        return <div className="sea-cargo-activity-details-goods-info"> {content} </div>;

    }
}

class SeaCargoActivityDetailsGoodsInfoContainer extends React.Component<ISeaCargoActivityDetailsGoodsInfoProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetailsGoodsInfo {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea Cargo Details Goods and voyage information..." />;
    }

}

@observer
class SeaCargoReportGoodsInfoList extends React.Component<ISeaCargoActivityDetailsGoodsInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Goods and voyage information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("sea-cargo-activity-details-goods-info-header")}
                         bodyClassName="sea-cargo-activity-details-goods-info-body">
                         <SeaCargoActivityDetailsGoodsInfoContainer {...this.props} />
            </Details>
        );
    }
}

export {
    SeaCargoReportGoodsInfoList as default,
    SeaCargoReportGoodsInfoList,
    SeaCargoActivityDetailsGoodsInfoContainer,
    SeaCargoActivityDetailsGoodsInfo,
    ISeaCargoActivityDetailsGoodsInfoProps,
    Fields as SeaCargoGoodsInfoFields,
    SeaCargoActivityDetailsGoodsInfoViewPrefStore

}