import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./ACRGoodsInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{// IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "goodsDescription",
    name: "Goods description:",
    fieldName: "goodsDescription",
    minWidth: 50,
    isMultiline: true
    },

    {
        key: "flight",
        name: "Flight:",
        fieldName: "flight",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "declareValue",
        name: "Declared Value (AUD amount):",
        fieldName: "declareValue",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "originalLoadingPort",
        name: "Original loading Port:",
        fieldName: "originalLoadingPort",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "dischargeLocation",
        name: "Discharge Location:",
        fieldName: "dischargeLocation",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "estimatedFirstPortArrival",
        name: "Estimated first port arrival (AEST):",
        fieldName: "estimatedFirstPortArrival",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "actualArrivalTime",
        name: "Actual arrival time (AEST):",
        fieldName: "actualArrivalTime",
        minWidth: 50
    },
     {
        key: "grossWeightAndUnit",
        name: "Gross Weight:",
        fieldName: "grossWeightAndUnit",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "withdraw",
        name: "Withdrawn:",
        fieldName: "withdraw",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "lastOverseasPort",
        name: "Last Overseas Port:",
        fieldName: "lastOverseasPort",
        minWidth: 50,
        isMultiline: true
    },  
     {
        key: "originPort",
        name: "Origin Port:",
        fieldName: "originPort",
        minWidth: 50,
        isMultiline: true
    },  
    {
        key: "destination",
        name: "Destination:",
        fieldName: "destination",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "packageCountAndType",
        name: "Package Count & Type:",
        fieldName: "packageCountAndType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "freightMethodOfPayment",
        name: "Freight method of payment:",
        fieldName: "freightMethodOfPayment",
        minWidth: 50,
        isMultiline: true
    } 
   
    ];

interface IAirCargoActivityDetailGoodsInfoProps {
    model?: IMECargoReportModel;
}

const AirCargoActivityDetailGoodsInfoViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetailsGoodsInfo");

class AirCargoActivityDetailGoodsInfo extends React.Component<IAirCargoActivityDetailGoodsInfoProps, any> {
    render() {
        let content;
        if(this.props.model) {
            content = <DetailsItem  model={this.props.model.items.goodsAndVoyageInfo} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailGoodsInfoViewPrefsStore}/>;
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="air-cargo-details-goods-info">{content}</div>;
    }
}

class AirCargoActivityDetailGoodsInfoContainer extends React.Component<IAirCargoActivityDetailGoodsInfoProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetailGoodsInfo {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details Goods and voyage information..." />;
    }
}

@observer
class AirCargoReportGoodsInfoList extends React.Component<IAirCargoActivityDetailGoodsInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Goods and voyage information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-goods-info-header")}
                         bodyClassName="air-cargo-details-goods-info-body">
                         <AirCargoActivityDetailGoodsInfoContainer {...this.props} />
            </Details>    
        );
    }
}

export { 
    AirCargoReportGoodsInfoList as default,
    AirCargoReportGoodsInfoList,
    AirCargoActivityDetailGoodsInfoContainer,
    AirCargoActivityDetailGoodsInfo,
    IAirCargoActivityDetailGoodsInfoProps,
    Fields as AirCargoGoodsInfoFields,
    AirCargoActivityDetailGoodsInfoViewPrefsStore
};