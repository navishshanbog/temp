import * as React from 'react';
import { observer } from "mobx-react";
import { Pivot, PivotItem, IPivotItemProps } from 'office-ui-fabric-react/lib/Pivot';
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import {MEHeader} from "../../MEHeader";
import {IMECase} from "../../../IMECase";
import {MEAirCargoReport} from "./MEAirCargoReport";
import {MECargoImportDeclarationModel } from "../../../cargo/cargoreport/fid/MECargoImportDeclarationModel";
import {MECargoImportDeclarationStore } from "../../../cargo/cargoreport/fid/MECargoImportDeclarationStore";
import MECargoExamsDetails from "../cargoreport/exams/MECargoExamsDetails";
import {MECargoExamsModel} from "../../../cargo/cargoreport/exams/MECargoExamsModel";
import {MECargoExamsStore} from "../../../cargo/cargoreport/exams/MECargoExamsStore";
import {MECargoSacReport} from "../cargoreport/sac/MECargoSacReport";
import {ImportDeclarationReport} from "../cargoreport/ImportDeclarationReport";
import {MECargoFidNSacModel} from "../../../cargo/cargoreport/fidNsac/MECargoFidNSacModel";
import {MECargoFidNSacStore} from "../../../cargo/cargoreport/fidNsac/MECargoFidNSacStore";
//import {CargoFidReport} from "../cargoreport/fidNsac/CargoFidReport";

import "./MEAirCargo.scss";

interface IMEAirCargoProps {
    cargoModel:IMECargoReportModel;
    meCase: IMECase;
}

@observer
class MEAirCargo extends React.Component<IMEAirCargoProps, any> { 
    private _onRefresh = () => {
        //this.props.meVisa.refresh();
    }
    ExamsModel: MECargoExamsModel = MECargoExamsStore;
    importDecDetails: MECargoImportDeclarationModel = MECargoImportDeclarationStore;
    FidNSacInformation: MECargoFidNSacModel = MECargoFidNSacStore;
    render() {
        let headerDetails = this.props.meCase;
        let meSummaryContentHeader = <MEHeader headerDetails = {headerDetails}
                                               onRefresh={this._onRefresh}
                                               icon={<Icon iconName='Airplane'/>} />   

        let pivotArray: React.ReactElement<IPivotItemProps>[] = [];
        pivotArray.push( <PivotItem linkText='ME Air Cargo' itemKey="0" key="0">
            <div className="me-booking-summary">
                <MEAirCargoReport model={this.props.cargoModel} />
                <ImportDeclarationReport model={this.importDecDetails} />
                <MECargoExamsDetails model={this.ExamsModel} />
            </div>
        </PivotItem>);

        let meSummaryContent = <div>
            {meSummaryContentHeader}
            <Pivot selectedKey="0" >
                {pivotArray}
            </Pivot>
        </div>

        return (
            <div className="me-summary">
                {meSummaryContent}
            </div>
        );
    }
}
export { MEAirCargo, IMEAirCargoProps }


