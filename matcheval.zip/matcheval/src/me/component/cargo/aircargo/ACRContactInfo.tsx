import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./ACRContactInfo.scss";

import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{  // IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "consignee",
    name: "Consignee:",
    fieldName: "consignee",
    minWidth: 50,
    isMultiline: true
    },
    {
        key: "consigneePhone",
        name: "Consignee Phone:",
        fieldName: "consigneePhone",
        minWidth: 50,
        isMultiline: true
       
    },
    {
        key: "consignor",
        name: "Consignor:",
        fieldName: "consignor",
        minWidth: 50,
        isMultiline: true
        
    },
    {
        key: "reportingClient",
        name: "Reporting Client:",
        fieldName: "reportingClient",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "reponsible",
        name: "Responsible:",
        fieldName: "reponsible",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "notify",
        name: "Notify:",
        fieldName: "notify",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "importerId",
        name: "Importer (ID):",
        fieldName: "importerId",
        minWidth: 50,
        isMultiline: true
    },

    {
        key: "consigneeAddress",
        name: "Consignee Address:",
        fieldName: "consigneeAddress",
        minWidth: 50,
        isMultiline: true
        
    },
    {
        key: "consignorAddress",
        name: "Consignor Address:",
        fieldName: "consignorAddress",
        minWidth: 50,
        isMultiline: true
                      
    },
     {
        key: "reportingAddress",
        name: "Reporting Address:",
         fieldName: "reportingAddress",
         minWidth: 50,
         isMultiline: true
    },
     {
        key: "reponsibleClientAddress",
        name: "Responsible Client Address:",
         fieldName: "reponsibleClientAddress",
         minWidth: 50,
         isMultiline: true
        
    },
    {
        key: "notifyAddress",
        name: "Notify Address:",
        fieldName: "notifyAddress",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "supplierId",
        name: "Supplier (ID):",
        fieldName: "supplierId",
        minWidth: 50,
        isMultiline: true
    
           
}];

interface IAirCargoActivityDetailContactInfoProps {
    model?: IMECargoReportModel;
}

const AirCargoActivityDetailsViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetailsContactInfo");

class AirCargoActivityDetailContactInfo extends React.Component<IAirCargoActivityDetailContactInfoProps, any> {
    render() {
        let content;
        if(this.props.model) {
            content = <DetailsItem  model={this.props.model.items.contactInformation} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailsViewPrefsStore }/>;
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load contact infomation details</MessageBar>;
        }
        return <div className="air-cargo-details-contact-info">{content}</div>;
    }
}

class AirCargoActivityDetailContactInfoContainer extends React.Component<IAirCargoActivityDetailContactInfoProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetailContactInfo {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details contact information..." />;
    }
}

@observer
class AirCargoReportContactInfoList extends React.Component<IAirCargoActivityDetailContactInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Contact Information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-contact-info-header")}
                         bodyClassName="air-cargo-details-contact-info-body">
                         <AirCargoActivityDetailContactInfoContainer {...this.props} />
           </Details>
        );
    }
}

export { 
    AirCargoReportContactInfoList as default,
    AirCargoReportContactInfoList,
    AirCargoActivityDetailContactInfoContainer,
    AirCargoActivityDetailContactInfo,
    IAirCargoActivityDetailContactInfoProps,
    Fields as AirCargoActivityDetailContactInfoFields,
    AirCargoActivityDetailsViewPrefsStore as AirCargoActivityDetailsContactsInfoViewPrefsStore
};

