import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./ACRInformation.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const Fields: IColumn[] = [{  // IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "documentType",
    name: "Document Type:",
    fieldName: "documentType",
    minWidth: 50,
    isMultiline: true
},
    {
        key: "clearanceType",
        name: "Clearance Type:",
        fieldName: "clearanceType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "masterBill",
        name: "Master Bill",
        fieldName: "masterBillr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "date",
        name: "Date:",
        fieldName: "date",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "houseBill",
        name: "Housebill:",
        fieldName: "houseBill",
        minWidth: 50,
        isMultiline: true
    },
        
    {
        key: "parentBillNo",
        name: "Parent Bill Number:",
        fieldName: "parentBillNo",
        minWidth: 50,
        isMultiline: true

    }];


interface IAirCargoActivityDetailCargoReportProps {
    model?: IMECargoReportModel;
}

const AirCargoActivityDetailsViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetails");

class AirCargoActivityDetails extends React.Component<IAirCargoActivityDetailCargoReportProps, any> {
    render() {
        let content;
        console.log("ACR data: ", this.props.model.items.cargoReport)
        if(this.props.model) {
            content = <DetailsItem  model={this.props.model.items.cargoReport} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailsViewPrefsStore }/>;
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="air-cargo-details-cargo-report">{content}</div>;
    }
}

class AirCargoActivityDetailsContainer extends React.Component<IAirCargoActivityDetailCargoReportProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetails {...this.props} />;
    }
    render() {
        console.log("sync=", this.props.model.sync);
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details..." />;
    }
}

class AirCargoReportInformationList extends React.Component<IAirCargoActivityDetailCargoReportProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Cargo Report Information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-cargo-report-header")}
                         bodyClassName="air-cargo-details-cargo-report-body">
                         <AirCargoActivityDetailsContainer {...this.props} />
           </Details>
        );
    }
}



export {
    AirCargoReportInformationList as default,
    AirCargoReportInformationList,
    AirCargoActivityDetails,
    IAirCargoActivityDetailCargoReportProps,
    Fields as AirCargoActivityDetailCargoFields,
    AirCargoActivityDetailsViewPrefsStore
};