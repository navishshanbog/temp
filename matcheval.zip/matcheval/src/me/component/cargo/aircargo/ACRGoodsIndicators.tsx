import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IMECargoReportInformation } from "../../../cargo/cargoreport/IMECargoReportInformation";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./ACRGoodsIndicators.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";

const getFullValText = (item: string) => {
	let fullValText;
	if (item === "Y") {
            fullValText = "Yes";
        }
        else if (item === "N") {
            fullValText = "No";
        }
        else {
            fullValText = item;
        }
	return fullValText;
}

const Fields: IColumn[] = [{ 
    key: "freightForward",
    name: "Freight forward:",
    fieldName: "freightForward",
    minWidth: 50,
    isMultiline: true
},

    {
        key: "lowestBill",
        name: "Lowest Bill:",
        fieldName: "lowestBill",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "highRiskMovement",
        name: "High Risk Movement:",
       
        fieldName: "highRiskMovement",
        minWidth: 50,
        isMultiline: true

    },
    {
        key: "examPerformed",
        name: "Exam performed:",
        
        fieldName: "examPerformed",
        minWidth: 50,
        isMultiline: true

    },
    {
        key: "suppressed",
        name: "Suppressed:",
        
        fieldName: "suppressed",
        minWidth: 50,
        isMultiline: true
    },
     {
        key: "transit",
        name: "Transit:",
        
        fieldName: "transit",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "personnelEffects",
        name: "Personal Effects:",
       
        fieldName: "personnelEffects",
        minWidth: 50,
        isMultiline: true
    },

    {
        key: "selfAssessedClearance",
        name: "Self-Assessed Clearance:",
        
        fieldName: "selfAssessedClearance",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "partShipment",
        name: "Part Shipment:",
       
        fieldName: "partShipmentd",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "positiveExamFind",
        name: "Positive Exam Find:",
        
        fieldName: "positiveExamFind",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "transhipment",
        name: "Transhipment:",
        
        fieldName: "transhipment",
        minWidth: 50,
        isMultiline: true
    }];

interface IAirCargoActivityDetailGoodsIndProps {
    model?: IMECargoReportModel;
}

const AirCargoActivityDetailGoodsInfoViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetailsGoodInd");

class AirCargoActivityDetailGoodsInd extends React.Component<IAirCargoActivityDetailGoodsIndProps, any> {
    render() {
        let content;
        if(this.props.model) {
           content = <DetailsItem  model={this.props.model.items.goodsIndicator} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailGoodsInfoViewPrefsStore}/>;
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load goods indicator details</MessageBar>;
        }
        return <div className="air-cargo-details-goods-indicators">{content}</div>;
    }
}

class AirCargoActivityDetailGoodsIndContainer extends React.Component<IAirCargoActivityDetailGoodsIndProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetailGoodsInd {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details Goods indicator information..." />;
    }
}

@observer
class AirCargoReportGoodIndList extends React.Component<IAirCargoActivityDetailGoodsIndProps, any> {
    render() {
        return(
            <Details className={css("details-panel")}
                         summary={<div>{'Goods Indicators'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-goods-indicators-header")}
                         bodyClassName="air-cargo-details-goods-indicators-body">
                        <AirCargoActivityDetailGoodsIndContainer {...this.props} />
            </Details>    
        );
    }

}

export { 
    
    AirCargoReportGoodIndList as default,
    AirCargoReportGoodIndList,
    AirCargoActivityDetailGoodsIndContainer,
    AirCargoActivityDetailGoodsInd,
    IAirCargoActivityDetailGoodsIndProps,
    Fields as AirCargoDetailGoodsIndFields
};