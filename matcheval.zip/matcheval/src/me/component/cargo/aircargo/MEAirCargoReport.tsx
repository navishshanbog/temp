import * as React from 'react';
import { observer } from "mobx-react";
import {IMECargoReportModel} from "../../../cargo/cargoreport/IMECargoReportModel";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import AirCargoReportGoodsInfoList from "./ACRGoodsInfo";
import AirCargoReportContactInfoList from "./ACRContactInfo";
import AirCargoReportGoodIndList from "./ACRGoodsIndicators";
import AirCargoReportInformationList from "./ACRInformation";
import "./MEAirCargoReport.scss";


interface IMECargoDetailsProps {
    model?: IMECargoReportModel;
}

  @observer
class AirCargoReportCommandBar extends React.Component<IMECargoDetailsProps, any> {
      private reportText: string = "Ver: ";
      private version:number = this.props.model.versionNo;

      private _loadPreviousReport = () => {
            this.props.model.updateSelectedReportVersion(this.props.model.versionNo - 1);
            this.version = this.version - 1; 

     };
      private _loadNextReport = () => {
           this.version = this.version + 1;
           this.props.model.updateSelectedReportVersion(this.version);
     }
     render() {
           let disableLeft: boolean = true;
           let disableRight: boolean = true;
           let lastVersion:number = this.props.model.items ? this.props.model.items.lastVersion : 0;
           let matchStatus:string = this.props.model.items ? this.props.model.items.matchStatus : "";
           disableLeft = this.version == 1;
           disableRight = this.version == lastVersion;
    
     
           const items : IContextualMenuItem[] = [
           {
                key: "name",
                name: "AIR CARGO REPORT",
                className: "air-cargo-report-left-item"
           }];

            const farItems: IContextualMenuItem[] = [
            {
                key: "matchStatus",
                name: `Match Status: ${matchStatus}`,
                className:"air-cargo-match-status-far-item" 
            },
             {
                key: "LA",
                name: "",
                iconProps: { iconName: "ChevronLeft" },
                disabled: disableLeft,
                className: css(`air-cargo-report-left-chevron`),
                onClick: this._loadPreviousReport
            },
            {
                key: this.reportText,
                name: `${this.reportText} ${this.version}`,
                className: css(`air-cargo-report-title`)
            },
            {
                key: "RA",
                name: "",
                iconProps: { iconName: "ChevronRight" },
                className: css(`air-cargo-report-right-chevron`),
                disabled: disableRight,
                onClick: this._loadNextReport 
            }
           
        ];
    
        return <CommandBar key={"reportNo"} className="air-cargo-report-command-bar" items={items} farItems={farItems}/>;   
    }
}


@observer
class MEAirCargoReport extends React.Component<IMECargoDetailsProps, any> {

    render() {
        console.log("Air cargo data: ", this.props.model.items);
        return (
            <div className="cargo-report-section">
            
                <div>{<AirCargoReportCommandBar {...this.props} />} </div>
                <div className="ms-Grid">
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<AirCargoReportInformationList {...this.props} />}
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {< AirCargoReportGoodIndList {...this.props} />}
                          
                        </div>
                    </div>
                    <div className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            {<AirCargoReportContactInfoList {...this.props} />}
                        </div>
                        <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                            { <AirCargoReportGoodsInfoList {...this.props} />}
                        </div>
                    </div>
                    
                </div>
            </div>
        );
    }
}

export {MEAirCargoReport, IMECargoDetailsProps}