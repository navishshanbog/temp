import CodeSet from "@twii/common/lib/CodeSet";

const PNRHistoryActionCd = new CodeSet({
    "A": "Add",
    "C": "Cancel",
    "F": "Change Responsible Office",
    "I": "Increase nb party",
    "K": "Time change",
    "N": "Names transmitted",
    "O": "Original Add",
    "P": "Queue Add",
    "Q": "Queue update",
    "R": "Replace",
    "S": "Split",
    "U": "Unknown",
    "W": "change Wait List priority",
    "Z": "Commit"
});

export { PNRHistoryActionCd as default, PNRHistoryActionCd };