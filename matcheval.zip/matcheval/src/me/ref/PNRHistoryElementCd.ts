import CodeSet from "@twii/common/lib/CodeSet";

const PNRHistoryElementCd = new CodeSet({
    "2": "Address (home or hotel)",
    "22": "Document Delivery Address",
    "27": "Ticketing Time Limit",
    "28": "OSI",
    "5": "Telephone Nature Not Known",
    "52": "Tour Option",
    "7": "Remarks (free text information)",
    "AB": "Billing Address",
    "AQ": "Address Verification Element",
    "ES": "Individual Security Elements",
    "F": "Fare Element",
    "MCO": "MCO",
    "MIS": "Element Containing Status Code",
    "NM": "Name",
    "OP": "Option element",
    "RC": "Confidential Remark",
    "RO": "Responsible Officer",
    "SK": "Special Keyword Element",
    "SR": "SSR",
    "SS": "Itinerary Segment",
    "T": "Time",
    "TP": "Total Price",
    "WP": "Waitlist Priority"
});

export { PNRHistoryElementCd as default, PNRHistoryElementCd };