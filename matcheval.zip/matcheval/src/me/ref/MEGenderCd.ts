import CodeSet from "@twii/common/lib/CodeSet";

const MEGenderCd = new CodeSet({
    "M": "Male",
    "F": "Female"
});

export { MEGenderCd }