import CodeSet from "@twii/common/lib/CodeSet";

const ProfileActionIndicators = new CodeSet({
    "X": "Match actioned with the creation of an Alert or a Referral however the original action was then cancelled or undone",
    "A": "Match actioned and Alert automatically created successfully within AMS",
    "p": "Match actioned however the Alert creation response from AMS Pending",
    "E": "Match actioned however the Alert creation attempt resulted in Error response from AMS",
    "M": "Match actioned however Alert created manually within AMS as link to AMS down",
    "Z": "Match actioned however the Alert creation attempt resulted in a Duplicate Alert response from AMS",
    "D": "Match Dismissed",
    "R": "Match Referral to external source outside of AMS",
    "U": "Match status is unactioned"
});

export { ProfileActionIndicators };