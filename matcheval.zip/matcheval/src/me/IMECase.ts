enum MEDomainType {
    Air = "AIR",
    Sea = "SEA"
}

/* Business domain */
enum MEBusinessDomainType {
    Traveller = "TRAVELLER",
    Visa = "VISA",
    Cargo = "CARGO"

}

const AD_GENERATED_CASE ="AD GENERATED CASE";
interface IMECase {
    CaseID?: string;
    DomainType?: MEDomainType;
    // to make it mandatory when integrated with PEGA
    BusinessDomain ?: MEBusinessDomainType;
    BookingSystemCode?: string;
    CreationTs?: string;
    RecordLocator?: string;
    CaseType?: string;
    DirectionCode?: string;
    IATTravellerID?: string;
    LocalPortCode?: string;
    LocalScheduleDate?: string;
    ParentRouteId?: string;
    RouteId?: string;
    TravelDocCntryCode?: string;
    TravelDocId?: string;
    Type?: string;
    Action?: string;
    Identifiers?: IIdentifiers[];
    SearchSystems?: string[];
    consignmentNbr?: string;
    originalMsgId?: string;
    domainType?: string;
    lineId?: string ;
}

interface IIdentifiers {
    Type?: string;
    Value?: string;
}

enum VRAIdnetifiersForME {
    ICSE_CID = "ICSE_CID",
    TRIPS_PID = "TRIPS_PID",
    CASE_ID = "CASE_ID"
}

enum SearchIdentifiers {
    TRAVEL_DOC_NUMBER = "TRAVEL_DOC_NUMBER",
    FULL_NAME = "FULL_NAME"
}

enum MEVisaHistoryIdentiferHeaders {
    ICSE_CID = "ICSE CID",
    TRIPS_PID = "TRIPS PID",
    CASE_ID = "Case Id",
    TRAVEL_DOC_NUMBER = "Travel Doc Number",
    FULL_NAME = "Name"
}

export { IMECase as default, IMECase, MEDomainType, MEBusinessDomainType, AD_GENERATED_CASE, IIdentifiers, VRAIdnetifiersForME, MEVisaHistoryIdentiferHeaders, SearchIdentifiers }

