import * as React from "react";
import Router from "roota/lib/Router";
import { exactPath } from "@twii/common/lib/RouterUtils";
import {IMECase} from "./IMECase";
const r = new Router();

r.use("/portal", exactPath(req => {
    return import("./component/PegaPortalApplet").then(m => {
        return <m.PegaPortalApplet host={req.app} />;
    });
}));

r.use("/traveller", (req => {
    return import("./component/METravellerApplet").then(m => {
        return <m.METravellerApplet host={req.app} meCase={req.params as IMECase} />;
    });
}));

r.use("/visa", (req => {
    return import("./component/MEVisaHistoryApplet").then(m => {
        return <m.MEVisaHistoryApplet host={req.app} meCase={req.params as IMECase} />;
    });
}));


r.use("/cargo", (req => {
    return import("./component/MECargoApplet").then(m => {
        return <m.MECargoApplet host={req.app} meCase={req.params as IMECase} />;
    });
}));

r.use("/search", exactPath((req) => {
    return import("./search/component/MESearchApplet").then(m => {
        return <m.MESearchApplet host={req.app} />;
    });
}));

r.use("/spin", exactPath((req) => {
    return import("./search/component/MESearchSpinner").then(m => {
        return <m.MESearchSpinner />;
    });
}));


r.use("/searchResults", exactPath((req) => {
    return import("./search/component/MESearchResults").then(m => {
        return <m.MESearchResults host={req.app}/>;
    });
}));


export { r as default, r as MERouter }