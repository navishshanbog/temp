import { Output as DateOutputFormats } from "@twii/common/lib/DateFormats";
import { dateFromDataText, momentFromTimestampDataText, isValidMoment } from "@twii/common/lib/util/Date";
import * as moment from "moment";

const formatToNISName = (familyName: string, firstName: string, middleName: string, gender: string, dateOfBirth: Date | string) : string => {

    let dobDisplayValue;
    if (dateOfBirth && typeof(dateOfBirth) === 'string') {
        dobDisplayValue = " " + nisDOBFormat(dateFromDataText(dateOfBirth));
    } else if (dateOfBirth) {
        dobDisplayValue = " " + nisDOBFormat(dateOfBirth as Date);
    } else {
        dobDisplayValue = "";
    }

    return `${familyName}, ${firstName}`
        + (middleName ? " " + middleName : "")
        + (gender ? " (" + genderToNISFormat(gender) + ") " : "(-) ")
        + dobDisplayValue;
};

const genderToNISFormat = (gender: string):string => {
    let genderChar = "N";
    switch(gender.toLowerCase()) {
        case 'male': case 'm': case 'M': genderChar = "M"; break;
        case 'female': case 'f': case 'F': genderChar = "F"; break;
        case 'undeclared': genderChar = "-"; break;
        case 'unknown': genderChar = "U"; break;
        case 'indeterminate': genderChar = "X"; break;
    }
    return genderChar;
};

// takes a date format and returns a string formatted as DDMMMYYYY
const nisDOBFormat = (dob: Date): string => {
    return dob ? moment(dob).format(DateOutputFormats.nisFormat).toUpperCase() : "";
};

const defaultDOBFormat = (dateOfBirth: Date | string): string => {
    let defaultDOB = "";
    if (dateOfBirth && typeof(dateOfBirth) === 'string') {
        var value: string = dateOfBirth;
        defaultDOB =  moment(value).format(DateOutputFormats.default);
    } else if (dateOfBirth) {
        defaultDOB = moment(dateOfBirth).format(DateOutputFormats.default);
    }
    return defaultDOB;
};

// duplicate: to be merged with the above defaultDOBFormat
const defaultDOBFormatForVisa = (dateOfBirth: Date | string): string => {
    let defaultDOB = "";
    if (dateOfBirth && typeof(dateOfBirth) === 'string') {
        var value: string = dateOfBirth;
        defaultDOB =  moment(value).format(DateOutputFormats.filename);
    } else if (dateOfBirth) {
        defaultDOB = moment(dateOfBirth).format(DateOutputFormats.filename);
    }
    return defaultDOB;
};

const dateWithTZForVisaCases = (value: string): string => {
    if(value) {
        const m = momentFromTimestampDataText(value, true);
        return isValidMoment(m) ? m.format(DateOutputFormats.matchEvaluationHeader) : undefined;
    }
    return undefined;
}

export { formatToNISName, nisDOBFormat, genderToNISFormat, defaultDOBFormat,defaultDOBFormatForVisa, dateWithTZForVisaCases };