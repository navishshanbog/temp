import {MESearchRequestModel} from "./MESearchRequestModel";

const MESearchRequestStore = new MESearchRequestModel();

export { MESearchRequestStore };