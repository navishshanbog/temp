import { observable, action, computed } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import ListModel from "@twii/common/lib/ListModel";
import SortModel from "@twii/common/lib/SortModel";
import * as SortUtils from "@twii/common/lib/util/Sort";
import {equalsIgnoreCase} from "@twii/common/lib/util/String";
import {clearSearchResult, getMECaseDetails, presentCaseDetails} from "./MESearchActions";
import {IMESearchResultsInformation} from "./IMESearchResultsInformation";
import {IMESearch} from "./IMESearch";
import {IMESearchHistoryRequest} from "./IMESearchHistoryService";
import {IMESearchRequest} from "./IMESearchRequest";
import {MESearchHistoryServiceContext} from "./MESearchHistoryServiceContext";
import { IAppHost } from "@twii/common/lib/IAppHost";
import {getEntityColumnText} from "../visahistory/VisaHistoryHelper";
import {getSourceSystemDetails} from "./component/MESearchResults";

class MESearchModel extends ListModel<IMESearchResultsInformation> implements IMESearch {
    //@observable sync: ISyncModel = new SyncModel();
    @observable sort = new SortModel();
    @observable selectedSearchResult: IMESearchResultsInformation;
    @observable selectedSearchResultIndex: number;
    private meSearchRequest: IMESearchHistoryRequest;
    private host?:IAppHost;


    @action
    refresh() : Promise<any> {
        const syncId = this.meSearchRequest.credentialType;
        this.sync.syncStart({id: syncId});
        this.setItems([]);
        return MESearchHistoryServiceContext.value.getMESearchDetails(this.meSearchRequest)
            .then((searchResponse) => {
                this.setItems(searchResponse);
                console.log("-- the items from response is ", this.itemsView);
                this.sync.syncEnd();
                if(this.itemsView.length>0) {
                    if (this.itemsView.length == 1) {
                        getMECaseDetails(this.host, this.itemsView);
                    } else {
                        presentCaseDetails(this.host);
                    }
                } else {
                    clearSearchResult(this.host);
                }
            }).catch((error) => {});
    }

    @action
    loadSearchSummary(host: IAppHost, searchRequest: IMESearchRequest) : Promise<any> {
        this.host = host;
        const syncId = "";
        this.meSearchRequest = searchRequest;
        return this.refresh();
    }

    @computed
    get itemsView() {
        return SortUtils.sort(this.items, this.sort, this._toSortValue);
    }

    private _toSortValue = (item : IMESearchResultsInformation, field: string) => {
        if(item) {
            if(equalsIgnoreCase(field, "bioInfo")) {
                return getEntityColumnText(item.bioInfo);
            }
            if(equalsIgnoreCase(field, "visas")) {
                return item.visas;
            }
            if(equalsIgnoreCase(field, "TRIPS")) {
                return getSourceSystemDetails(item, "TRIPS");
            }
            if(equalsIgnoreCase(field, "ICSE")) {
                return getSourceSystemDetails(item, "ICSE");
            }
            return item[field];
        }
    };

    updateSelectedCaseIndex(caseIndex: number) : void {
        this.selectedSearchResultIndex = caseIndex;
        this.selectedSearchResult = this.itemsView[caseIndex];
    }

}


export { MESearchModel }