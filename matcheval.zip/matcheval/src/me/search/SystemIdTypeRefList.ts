import RefListModel from "@twii/common/lib/RefListModel";
const TRIPS = "TRIPS";
const SystemIdTypeRefList = new RefListModel([
    { key: "CASE_ID", subPath: "caseId", text: "Case ID", systemSearch: true },
    { key: "TRIPS_PID", subPath: "tripsId", text: "TRIPS PID", systemSearch: true },
    { key: "ICSE_CID", subPath: "icseId", text: "ICSE CID", systemSearch: true },
    { key: "Full_Name", subPath: "fullName", text: "Full Name", systemSearch: false },
    { key: "Travel_Doc_Number", subPath: "travelDocId", text: "Travel Document Number", systemSearch: false }
]);


export { SystemIdTypeRefList, TRIPS };