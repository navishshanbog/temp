
import {IMESearchResultsInformation} from "./IMESearchResultsInformation";

interface IMESearchHistoryRequest {
    credentialType?: string;
    credential?: string;
}


interface IMESearchHistoryService {
    getMESearchDetails(request : IMESearchHistoryRequest) : Promise<IMESearchResultsInformation[]>;
}

export { IMESearchHistoryService, IMESearchHistoryRequest};