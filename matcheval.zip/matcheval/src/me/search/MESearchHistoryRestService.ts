import axios, { AxiosRequestConfig } from 'axios';
import { IMESearchHistoryService, IMESearchHistoryRequest } from "./IMESearchHistoryService";
import AbstractRestDataService from "../../common/AbstractRestDataService";
import * as DefaultHttpErrorHandler from "@twii/common/lib/HttpErrorHandler";
import {IMESearchResultsInformation} from "./IMESearchResultsInformation";

interface GetMESearchHistoryRestResponse {
    errors?: any;
    getMatchEvalVisaHistorySearchResults?: IMESearchResultsInformation[];
}


class MESearchHistoryRestService extends AbstractRestDataService implements IMESearchHistoryService {
    getMESearchDetails(request : IMESearchHistoryRequest) : Promise<IMESearchResultsInformation[]> {
        //const internalRequest = Object.assign({}, request);
        const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/VRAService/v1/resources/MatchEvalVisaHistorySearch`, req).then((value) => {
            const response = value.data as GetMESearchHistoryRestResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getMatchEvalVisaHistorySearchResults;
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

export { MESearchHistoryRestService };