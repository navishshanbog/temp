import { action, IAction } from "mobx";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { IMESearchRequest } from "./IMESearchRequest";
import {IMECase, IIdentifiers} from "../IMECase";
import AppContext from "@twii/common/lib/AppContext";
import {MESearchHistoryStore} from "./MESearchHistoryStore";
import {IMESearch} from "./IMESearch";
import {MESearchStore} from "./MESearchStore";
import * as StringUtils from "@twii/common/lib/util/String";
import {TRIPS} from "./SystemIdTypeRefList";
import {SystemIdTypeRefList} from "./SystemIdTypeRefList";


const toMatchEval = action((host: IAppHost, meCase: IMECase) => {
    host.open({ path: "/me/visa", query: meCase });
});

const submitRequestWithCaseId = action((host: IAppHost, caseId: string) => {
    let request: IMESearchRequest = {credentialType: "CASE_ID", credential: caseId};
    console.log("user input ", request);
    MESearchHistoryStore.addEntry(request);
    let meCase: IMECase = {CaseID: caseId};
    toMatchEval(host, meCase);
});

const submitRequestWithSourceId = action((host: IAppHost, request: IMESearchRequest) => {
    console.log("user input ", request);
    MESearchHistoryStore.addEntry(request);
    let identifiers: IIdentifiers[] = [{Type: request.credentialType, Value: request.credential}];
    let meCase: IMECase = {Identifiers: identifiers};
    toMatchEval(host, meCase);
});

 const submitRequest = action((host: IAppHost, request: IMESearchRequest) => {
     MESearchHistoryStore.addEntry(request);
     console.log("-- this is the request sent ", request);
     let isSystemId = SystemIdTypeRefList.getItemByKey(request.credentialType).systemSearch;
     if(isSystemId) {
         let identifiers: IIdentifiers[] = [{Type: request.credentialType, Value: request.credential}];
         let meCase: IMECase = {Identifiers: identifiers};
         toMatchEval(host, meCase);
     } else {
         let meSearchModel: IMESearch = MESearchStore;
         host.setState({meSearchModel: meSearchModel});
         request.credentialType = SystemIdTypeRefList.getItemByKey(request.credentialType).subPath;
         meSearchModel.loadSearchSummary(host, request);
         host.load({ path: "/me/spin", query: request });
     }
 });

 const presentCaseDetails = action ((host: IAppHost) => {
     host.load({ path: "/me/searchResults" });
 });

 const getMECaseDetails = action ((host: IAppHost, items: any) => {
     let caseId: string = "";
     let identifiers: IIdentifiers[] = [];
     let meCase: IMECase = {};
     items.map((item, idx) => {
        if(item && item.bioInfo) {
            caseId = item.caseId;
            item.bioInfo.map((bInfo, idx) => {
                let value = StringUtils.equalsIgnoreCase(bInfo.sourceSystem, TRIPS)? "TRIPS_PID" : "ICSE_CID";
                let iden: IIdentifiers = {Type: value, Value: bInfo.id}
                identifiers.push(iden);
            });
            let meCase: IMECase = {Identifiers: identifiers};
            meCase.CaseID = item.caseId;
            toMatchEval(host, meCase);
        }
     });
     host.load({ path: "/me/search"});;
 });


 const clearSearchResult = action((host?: IAppHost) => {
     host.load({ path: "/me/search"});
});

export {
    submitRequest,
    clearSearchResult,
    getMECaseDetails,
    presentCaseDetails,
    submitRequestWithSourceId,
    submitRequestWithCaseId
}

