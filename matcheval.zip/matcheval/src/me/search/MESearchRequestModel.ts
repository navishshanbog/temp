import { observable, action, computed } from "mobx";
import {IMESearchRequest} from "./IMESearchRequest";
import {IMESearchRequestModel} from "./IMESearchRequestModel";
import IError from "@twii/common/lib/IError";
import * as StringUtils from "@twii/common/lib/util/String";


class MESearchRequestModel implements IMESearchRequestModel {
    @observable validationErrors?: IError[] = [];
    @observable credentialType?: string;
    @observable credential?: string;
    @observable busyThinking?: boolean = false;
    @computed
    get isValid() {
        return this.validationErrors.length === 0;
    }

    @computed
    get isValueSpecified() {
        return StringUtils.isNotBlank(this.credentialType) && StringUtils.isNotBlank(this.credential);
    }

    @computed
    get request() : IMESearchRequest {
        return {
            credentialType: StringUtils.isNotBlank(this.credentialType) ? this.credentialType : undefined,
            credential: StringUtils.isNotBlank(this.credential) ? this.credential : undefined
        };
    }

    set request(request : IMESearchRequest) {
        this.setRequest(request);
    }

    @action
    setCredentialType(credentialType?: string) : void {
        this.credentialType = credentialType;
    }

    @action
    setCredential(credential?: string) : void {
        this.credential = credential;
    }

    @action
    setRequest(request : IMESearchRequest) {
        if(request) {
            this.setCredentialType(request.credentialType);
            this.setCredential(request.credential);
        } else {
            this.clear();
        }
    }

    @action
    validate() {
        this.validationErrors = [];
        if(!this.isValueSpecified) {
            this.validationErrors.push({ message: "A value must be specified"});
        }
    }


    @action
    submit(requestHandler?: (request : IMESearchRequest) => void) {
        this.validate();
        if(this.isValid && requestHandler) {
            this.busyThinking = true;
            console.log("-- search for request ", this.request);
            requestHandler(this.request);
        }
    }


    @action
    clearValidation() {
        this.validationErrors = [];
    }

    @action
    clear(): void {
        this.clearValidation();
        this.credentialType = "";
        this.credential = "";
    }
}

export { MESearchRequestModel };