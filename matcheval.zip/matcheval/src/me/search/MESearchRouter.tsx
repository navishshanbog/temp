import * as React from "react";
import Router from "roota/lib/Router";
import { exactPath } from "@twii/common/lib/RouterUtils";
const r = new Router();

r.use("/search", exactPath((req) => {
    return import("./component/MESearchApplet").then(m => {
        return <m.MESearchApplet host={req.app} />;
    });
}));

r.use("/spin", exactPath((req) => {
    return import("./component/MESearchSpinner").then(m => {
        return <m.MESearchSpinner />;
    });
}));


r.use("/searchResults", exactPath((req) => {
    return import("./component/MESearchResults").then(m => {
        return <m.MESearchResults host={req.app}/>;
    });
}));


export { r as default, r as MESearchRouter }