import HistoryModel from "@twii/common/lib/HistoryModel";

const MESearchHistoryStore = new HistoryModel();
MESearchHistoryStore.storageKey = "analystdesktop-matchEvalSearchHistory";
MESearchHistoryStore.legacyValueProp = "request";

export { MESearchHistoryStore };