
interface IMESearchRequest {
    credentialType?: string;
    credential?: string;
}

export { IMESearchRequest  };