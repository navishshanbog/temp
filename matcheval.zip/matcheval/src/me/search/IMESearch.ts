import ISyncModel from "@twii/common/lib/ISyncModel";
import { IAppHost } from "@twii/common/lib/IAppHost";
import {IMESearchResultsInformation} from "./IMESearchResultsInformation";
import ISortableListModel from "@twii/common/lib/ISortableListModel";
import {IMESearchRequest} from "./IMESearchRequest";


interface IMESearch extends ISortableListModel<IMESearchResultsInformation>{
    sync: ISyncModel;
    selectedSearchResult?:IMESearchResultsInformation;
    selectedSearchResultIndex?: number;
    refresh(): Promise<any>;
    loadSearchSummary(host: IAppHost, searchRequest: IMESearchRequest) : Promise<any>;
    updateSelectedCaseIndex(caseIndex: number) : void;
}

export { IMESearch };