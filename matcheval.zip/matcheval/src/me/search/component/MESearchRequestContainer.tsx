import * as React from "react";
import { KeyCodes } from "office-ui-fabric-react/lib/Utilities";
import {MESearchRequestActions} from "./MESearchRequestActions";
import {MESearchRequestEditor} from "./MESearchRequestEditor";

interface IMESearchRequestContainerProps {
    searchRequest: any;
    onSubmit?: (request : any) => void;
    onClear?: () => void;
}

class MESearchRequestContainer extends React.Component<IMESearchRequestContainerProps, any> {
    private _onKeyDown = (e : React.KeyboardEvent<HTMLElement>) => {
        if(e.which === KeyCodes.enter) {
            this.props.searchRequest.submit(this.props.onSubmit);
        }
    }
    render() {
        return (
            <div className="me-search-container" onKeyDown={this._onKeyDown}>
                <MESearchRequestEditor searchRequest={this.props.searchRequest} />
                <MESearchRequestActions searchRequest={this.props.searchRequest} onSubmit={this.props.onSubmit} onClear={this.props.onClear} />
            </div>
        );
    }
}

export { MESearchRequestContainer, IMESearchRequestContainerProps };