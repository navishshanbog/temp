import * as React from "react";
import {IMESearchRequest} from "../IMESearchRequest";
import {SystemIdTypeRefList} from "../SystemIdTypeRefList";
import * as StringUtils from "@twii/common/lib/util/String";
import DefinitionList from "@twii/common/lib/component/DefinitionList";
import { css } from "@uifabric/utilities/lib/css";
import { getClassNames } from "./MESearchHistoryRequestSummary.style";

interface IMESearchHistoryRequestSummaryItemProps {
    name: string;
}

class MESearchHistoryRequestSummaryItem extends React.Component<IMESearchHistoryRequestSummaryItemProps, any> {
    render() {
        return <DefinitionList inline={true} className="me-search-history-request-summary-item" name={this.props.name}>{this.props.children}</DefinitionList>;
    }
}

const createItems = (request : IMESearchRequest) => {
    const r = [];
    if(request) {
        if(StringUtils.isNotBlank(request.credentialType) || StringUtils.isNotBlank(request.credential)) {
            r.push(
                <MESearchHistoryRequestSummaryItem key="credential" name={SystemIdTypeRefList.getItemByKey(request.credentialType, { key: null, text: "Credential" }).text}>
                    {request.credential}
                </MESearchHistoryRequestSummaryItem>
            );
        }
    }
    return r;
};

interface IMESearchHistoryRequestSummaryProps {
    request: IMESearchRequest;
    className?: string;
}

class MESearchHistoryRequestSummary extends React.Component<IMESearchHistoryRequestSummaryProps, any> {
    render() {
        const items = createItems(this.props.request);
        if(items.length > 0) {
            return (
                <div className={css("me-search-history-request-summary", this.props.className, getClassNames().root)} aria-label="ME Search History Request Summary">
                    {items}
                </div>
            );
        }
        return null;
    }
}

export { MESearchHistoryRequestSummary, createItems, IMESearchHistoryRequestSummaryProps };