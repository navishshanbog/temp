import * as React from "react";
import { observer } from "mobx-react";
import {IMESearchRequestModel} from "../IMESearchRequestModel";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { Dropdown, IDropdownOption } from "office-ui-fabric-react/lib/Dropdown";
import Details from "@twii/common/lib/component/Details";
import {SystemIdTypeRefList} from "../SystemIdTypeRefList";
import ValidationErrors from "@twii/common/lib/component/ValidationErrors";
import * as RefListUtils from "@twii/common/lib/RefListUtils";
import "./MESearchRequestEditor.scss";
import * as StringUtils from "@twii/common/lib/util/String";


interface IMESearchRequestEditorProps {
    searchRequest: IMESearchRequestModel;
}

@observer
class MESearchRequestEditor extends React.Component<IMESearchRequestEditorProps, any> {
    private editorComponents;
    private familyName;
    private givenName;

    private _onCredentialTypeChanged = (option: IDropdownOption) => {
        this.props.searchRequest.setCredentialType(String(option.key));
        this.familyName = this.givenName = "";
        this.props.searchRequest.setCredential("");
    }


    private _onFirstNameChange = (value: string) => {
        this.familyName = value;
        this._onCredentialChanged()
    }

    private _onGivenNameChange = (value: string) => {
        this.givenName = value;
        this._onCredentialChanged()
    }

    private _onCredentialChanged = (value?: string) => {
        this.props.searchRequest.setCredential(null);
        if(StringUtils.isNotBlank(value))
            this.props.searchRequest.setCredential(value);
        if(StringUtils.isNotBlank(this.familyName) && StringUtils.isNotBlank(this.givenName)) {
            var fullName = this.givenName.concat(" "+this.familyName) ;
            this.props.searchRequest.setCredential(fullName);
        }
    }


    render() {
        const credentialTypeOptions = RefListUtils.getOptionalRefListItems(SystemIdTypeRefList, false);
        this.editorComponents =<div className="ms-Grid-row ms-sm12 ms-md12 ms-lg12">
                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                    <Dropdown label="Type"
                        options={credentialTypeOptions}
                        onChanged={this._onCredentialTypeChanged}
                        selectedKey={this.props.searchRequest.credentialType || ""} />
                </div>
                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                    <TextField label="Value" onChanged={this._onCredentialChanged} value={this.props.searchRequest.credential || ""} />
                </div>
        </div>
        if(this.props.searchRequest && StringUtils.isNotBlank(this.props.searchRequest.credentialType) && StringUtils.equalsIgnoreCase(this.props.searchRequest.credentialType, "Full_Name")) {
            this.editorComponents = <div className="ms-Grid-row ms-sm12 ms-md12 ms-lg12">
                    <div className="ms-Grid-col ms-sm12 ms-md4 ms-lg4">
                        <Dropdown label="Type"
                              options={credentialTypeOptions}
                              onChanged={this._onCredentialTypeChanged}
                              selectedKey={this.props.searchRequest.credentialType || ""} />
                    </div>
                    <div className="ms-Grid-col ms-sm12 ms-md4 ms-lg4">
                        <TextField label="Family Name" onChanged={this._onFirstNameChange} value={this.familyName || ""}/>
                    </div>
                    <div className="ms-Grid-col ms-sm12 ms-md4 ms-lg4">
                        <TextField label="Given Name/s" onChanged={this._onGivenNameChange} value={this.givenName || ""} />
                    </div>
                </div>
        }

        return (
            <div className="match-eval-search-editor">
                <ValidationErrors errors={this.props.searchRequest.validationErrors} />
                <Details title="Search"
                    open={true}
                    controlOnHeaderClick={true}>
                    <div className="ms-Grid">
                        <div className="ms-Grid-row">
                            {this.editorComponents}
                        </div>
                    </div>
                </Details>
            </div>
        );
    }
}

export { MESearchRequestEditor, IMESearchRequestEditorProps };