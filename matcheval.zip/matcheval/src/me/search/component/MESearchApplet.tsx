import * as React from "react";
import { observer } from "mobx-react";
import IAppletProps from "@twii/common/lib/IAppletProps";
import AppHostWrapper from "@twii/common/lib/component/AppHostWrapper";
import {MESearchRequestContainer} from "./MESearchRequestContainer";
import {IMESearchRequestModel} from "../IMESearchRequestModel";
import {IMESearchRequest} from "../IMESearchRequest";
import {MESearchHistoryRequestSummary} from "./MESearchHistoryRequestSummary";
import IHistoryEntry from "@twii/common/lib/IHistoryEntry";
import { createHistoryMenuItem } from "@twii/common/lib/component/History";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IContextualMenuItem} from "office-ui-fabric-react/lib/ContextualMenu";
import { submitRequest, clearSearchResult } from "../MESearchActions";
import { getSearchRequestModel } from "../MESearchHelper";
import { MESearchHistoryStore } from "../MESearchHistoryStore";


interface IMESearchCommandBarProps extends IAppletProps {
    searchRequest: IMESearchRequestModel;
    isResultsBar: boolean;
    enableBack?: boolean;
}

 @observer
 class MESearchCommandBar extends React.Component<IMESearchCommandBarProps, any> {

     componentWillMount() {
         MESearchHistoryStore.load();
     }
     private _onSelectHistoryItem = (item : IHistoryEntry<IMESearchRequest>) => {
         this.props.searchRequest.setRequest(item.value);
         submitRequest(this.props.host, item.value);
     }


     private _onRenderHistoryItem = (item : IHistoryEntry<IMESearchRequest>, idx : number) => {
         return <MESearchHistoryRequestSummary request={item.value} />
     }

    private _backToSearch = () => {
        this.props.host.load({ path: "/me/search" });
    }

     private _clearHistory = () => {
         MESearchHistoryStore.items = [];
     }

     render() {
         const items : IContextualMenuItem[] = [
             createHistoryMenuItem({
                 key: "recentSearches",
                 name: `Recent Searches ( ${MESearchHistoryStore.items.length})`,
                 history: MESearchHistoryStore,
                 onSelectItem: this._onSelectHistoryItem,
                 onRenderItem: this._onRenderHistoryItem
             })
         ];

         const clearHistory : IContextualMenuItem = {
             key: "clearHistory",
             title: "Clear History",
             iconProps: {
                 iconName: "Cancel"
             },
             onClick: this._clearHistory
         };

         const backToSearch : IContextualMenuItem = {
             key: "backToSearch",
             title: "Back to search",
             iconProps: {
                 iconName: "ChevronLeft"
             },
             onClick: this._backToSearch
         };
         console.log("-- the enable back  ", this.props.enableBack);
         if(MESearchHistoryStore.items.length>0) items.push(clearHistory);
         if(this.props.enableBack) items.push(backToSearch);
         return <CommandBar className="match-eval-search-command-bar" items={items} />
     }
 }


class MESearchApplet extends React.Component<IAppletProps, any> {
     get searchRequest() : IMESearchRequestModel {
         return getSearchRequestModel(this.props.host);
     }
     private _onSubmitRequest = (request : IMESearchRequest) => {
         submitRequest(this.props.host, request);
     }
     private _onClear = () => {
         clearSearchResult(this.props.host);
     }
    componentDidMount() {
        this.props.host.title = "Match Eval Search";
    }

    render() {
        return (
            <AppHostWrapper className="me-search-applet" host={this.props.host} title="Match Eval Search">
                <MESearchCommandBar {...this.props} searchRequest={this.searchRequest} isResultsBar={false}/>
                <MESearchRequestContainer searchRequest={this.searchRequest} onSubmit={this._onSubmitRequest} onClear={this._onClear} />
            </AppHostWrapper>
        );
    }
}

export { MESearchApplet, MESearchCommandBar, IMESearchCommandBarProps}