import * as React from 'react';
import { observer } from "mobx-react";
import IAppletProps from "@twii/common/lib/IAppletProps";
import "./MESearchResults.scss";
import {getSearchRequestModel, getSearchModel} from "../MESearchHelper";
import {IMESearchRequestModel} from "../IMESearchRequestModel";
import AppHostWrapper from "@twii/common/lib/component/AppHostWrapper";
import {MESearchCommandBar} from "./MESearchApplet";
import { IMESearch } from "../IMESearch";
import * as ColumnSortHelper from '@twii/common/lib/component/ColumnSortHelper';
import { css } from "office-ui-fabric-react/lib/Utilities";
import Details from "@twii/common/lib/component/Details";
import {
     DetailsList,
     DetailsListLayoutMode,
     CheckboxVisibility,
     ConstrainMode,
     SelectionMode,
     Selection,
    IColumn,
    ColumnActionsMode
 } from "office-ui-fabric-react/lib/DetailsList";
import {IMESearchResultsInformation} from "../IMESearchResultsInformation";
import { Link } from "office-ui-fabric-react/lib/Link";
import { IMESearchRequest } from "../IMESearchRequest";
import {defaultDOBFormatForVisa} from "../../MENameUtils";
import * as StringUtils from "@twii/common/lib/util/String";
import {submitRequestWithCaseId, submitRequestWithSourceId} from "../MESearchActions";


class MESearchResultsListColumn implements IColumn {
    fieldName: string;
    label: string;
    key: string;
    ariaLabel: string;
    name: string;
    minWidth: number = 150;
    maxWidth: number = 200;
    isResizable: boolean = true;
    columnActionsMode: ColumnActionsMode = ColumnActionsMode.clickable;

    constructor(fieldName: string, label: string) {
        this.fieldName = fieldName;
        this.label = label;
        this.key = fieldName;
        this.ariaLabel = label;
        this.name = label;
    }
}

const getCountryOfBirthDetails = (item : IMESearchResultsInformation) => {
    let cobs;
    let allCOBs:string[] = [];
    if(item.bioInfo && item.bioInfo.length > 0) {
        cobs = item.bioInfo.map((bi, idx) => {
            let tempCobs;
            if(bi.countryOfBirth && bi.countryOfBirth.length>0) {
                tempCobs = bi.countryOfBirth.map((cBirth, idx) => {
                    return idx==0  ? idx!=bi.countryOfBirth.length-1 ? `${cBirth}, ` : idx!=bi.countryOfBirth.length-1 ? `${cBirth}, `: `${cBirth}`: `${cBirth}`;
                });

                if(!checkIfExists(tempCobs, allCOBs)) {
                    allCOBs.push(tempCobs);
                    return <div key={idx}>{tempCobs}</div>
                }
            }
        });
    }
    return <div>{cobs}</div>;
}

const getSourceSystemDetails= (item : IMESearchResultsInformation, sourceSystem: string) => {
    let value = "";
    if(item.bioInfo && item.bioInfo.length > 0) {
        item.bioInfo.map((bi, idx) => {
            // only two source system (ICSE or TRIPS)
            if(StringUtils.equalsIgnoreCase(bi.sourceSystem, sourceSystem))
                value = StringUtils.isNotBlank(bi.id) ? bi.id : value
        });
    }
    return value;
}
const getVisaDetails = (item : IMESearchResultsInformation) => {
    let visaDetails;
    if(item.visas && item.visas.length > 0) {
        visaDetails = item.visas.map((vs, idx) => {
            let visa = "";
            visa = vs.visaStreamCode? vs.visaStreamCode : "";
            visa = vs.visaSubClass? visa? `${visa} ${vs.visaSubClass}`: vs.visaSubClass: visa;
            visa = vs.visaStatus? visa ? `${visa} ( ${vs.visaStatus})`: `( ${vs.visaStatus})`: visa;
            return <div key={idx}>{visa}</div>;
        });
    }
    return <div>{visaDetails}</div>;
}
const getCountryOfCitizenshipDetails = (item : IMESearchResultsInformation) => {
    let countryOfCitzs;
    let allCOCs:string[] = [];
    if(item.bioInfo && item.bioInfo.length > 0) {
        countryOfCitzs = item.bioInfo.map((bi, idx) => {
            let tempCountryOfCitzs;
            if(bi.countryOfCitizenship && bi.countryOfCitizenship.length>0) {
                tempCountryOfCitzs = bi.countryOfCitizenship.map((cCitizen, idx) => {
                    return idx==0  ? idx!=bi.countryOfCitizenship.length-1 ? `${cCitizen}, ` : idx!=bi.countryOfCitizenship.length-1 ? `${cCitizen}, `: `${cCitizen}`: `${cCitizen}`;
                });
                if(!checkIfExists(tempCountryOfCitzs, allCOCs)) {
                    allCOCs.push(tempCountryOfCitzs);
                    return <div key={idx}>{tempCountryOfCitzs}</div>
                }
            }
        });
    }
    return <div>{countryOfCitzs}</div>;
}
const checkIfExists = (child: string[], parent: string[]) => {
    var foundItem: boolean = false;
    parent.map((p: any, idx) => {
        if(JSON.stringify(p)==JSON.stringify(child)) foundItem = true;
    })
    return foundItem;
}

const getEntityDetails = (item : IMESearchResultsInformation) => {
    let bioDetails;
    if(item.bioInfo && item.bioInfo.length > 0) {
        let tempBD = [];
        let tempSourceSys = [];
        item.bioInfo.map((t, idx) => {
            let entity = "";
            entity = t.familyName? t.familyName.toUpperCase() : "";
            entity = t.givenName? entity ? entity+" ,"+t.givenName: t.givenName: entity;

            entity = (t.dateOfBirth && t.sexCd)? entity ? entity+" ("+defaultDOBFormatForVisa(t.dateOfBirth)+", "+t.sexCd+")":
                "("+defaultDOBFormatForVisa(t.dateOfBirth)+", "+t.sexCd+")" : defaultDOBFormatForVisa(t.dateOfBirth)? " ("+defaultDOBFormatForVisa(t.dateOfBirth)+")" : " ("+t.sexCd+")";
            if(tempBD.indexOf(entity)<0) {tempBD.push(entity); tempSourceSys.push(t.sourceSystem)}
            return bioDetails;
        });
        if(tempBD.length>1) {
            bioDetails = tempBD.map((tdb, idx) => {
                return <div key={idx}>{tdb} {tempSourceSys[idx]}</div>;
            });
        } else {
            bioDetails = <div key={tempBD.length}>{tempBD[0]}</div>;
        }
    }
    return <div>{bioDetails}</div>;
}

const _getColumns = (/*requestWithCaseId?: (caseId : string) => void, */requestWithSourceIds?: (request: IMESearchRequest)=> void) : MESearchResultsListColumn[] => {
    return [
        Object.assign(new MESearchResultsListColumn("caseId", "Case ID"), {
            minWidth: 150,
            maxWidth: 200,
            onRender: (item : IMESearchResultsInformation) => {
                let _handleClick = (ev : React.MouseEvent<HTMLElement>) => {
                    ev.stopPropagation();
                    let searchRequest: IMESearchRequest = {credential:item.caseId, credentialType:"CASE_ID"};
                    requestWithSourceIds(searchRequest);

                    //requestWithCaseId(item.caseId);
                };
                return <Link onClick={_handleClick}>{item.caseId}</Link>;
            }
        }),
        new MESearchResultsListColumn("domain", "Domain"),
        Object.assign(new MESearchResultsListColumn("bioInfo", "Entity"), {
            minWidth: 350,
            maxWidth: 360,
            onRender: (item: IMESearchResultsInformation) => {
                return getEntityDetails(item);
            }
        }),
        Object.assign(new MESearchResultsListColumn("ICSE", "ICSE CID"), {
            minWidth: 100,
            maxWidth: 250,
            onRender: (item : IMESearchResultsInformation) => {
                let icseValue = getSourceSystemDetails(item, "ICSE");
                let _handleClick = (ev : React.MouseEvent<HTMLElement>) => {
                    ev.stopPropagation();
                    let searchRequest: IMESearchRequest = {credential:icseValue, credentialType:"ICSE_CID"};
                    requestWithSourceIds(searchRequest);
                };
                return <Link onClick={_handleClick}>{icseValue}</Link>;
            }
        }),
        Object.assign(new MESearchResultsListColumn("TRIPS", "TRIPS PID"), {
            minWidth: 100,
            maxWidth: 250,
            onRender: (item : IMESearchResultsInformation) => {
                let icseValue = getSourceSystemDetails(item, "TRIPS");
                let _handleClick = (ev : React.MouseEvent<HTMLElement>) => {
                    ev.stopPropagation();
                    let searchRequest: IMESearchRequest = {credential:icseValue, credentialType:"TRIPS_PID"};
                    requestWithSourceIds(searchRequest);
                };
                return <Link onClick={_handleClick}>{icseValue}</Link>;
            }
        }),
        Object.assign(new MESearchResultsListColumn("countryOfBirth", "Country of Birth"), {
            minWidth: 100,
            maxWidth: 150,
            onRender: (item : IMESearchResultsInformation) => {
                return getCountryOfBirthDetails(item);
            }
        }),
        Object.assign(new MESearchResultsListColumn("countryOfCitizenship", "Country of Citizenship"), {
            minWidth: 100,
            maxWidth: 150,
            onRender: (item : IMESearchResultsInformation) => {
                return getCountryOfCitizenshipDetails(item);
            }
        }),
        Object.assign(new MESearchResultsListColumn("visas", "Visas"), {
            minWidth: 100,
            maxWidth: 250,
            onRender: (item : IMESearchResultsInformation) => {
                return getVisaDetails(item);
            }
        })
    ] as MESearchResultsListColumn[];
}



@observer
class MESearchResults extends React.Component<IAppletProps, any> {

    private _columns: MESearchResultsListColumn[];
    constructor(props: IAppletProps) {
        super(props);
        this._columns = _getColumns(/*this.requestWithCaseId, */this.requestWithSourceIds);
    }

    private _onColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        this.searchModel.sort.toggleSort(column.fieldName);
    };

    requestWithSourceIds = (request: IMESearchRequest) => {
        console.log("-- trips or icse id is clicked ", request);
        submitRequestWithSourceId(this.props.host, request)
    }

    requestWithCaseId = (caseId: string) => {
        console.log("-- case id is clicked ", caseId, this);
        submitRequestWithCaseId(this.props.host, caseId);
    }

    get searchRequest() : IMESearchRequestModel {
        return getSearchRequestModel(this.props.host);
    }

    get searchModel() : IMESearch {
        return getSearchModel(this.props.host);
    }

    private _onShouldVirtualize = () => {
        return this.searchModel.itemsView.length > 200;
    }

    render() {
        let content;
        console.log("-- items ", this.searchModel);
        if(this.searchModel && this.searchModel.itemsView && this.searchModel.itemsView.length >0) {
            let columns = ColumnSortHelper.applySort(this._columns, this.searchModel.sort);
            content = <DetailsList columns={columns}
                                   compact={true}
                                   onColumnHeaderClick={this._onColumnHeaderClick}
                                   checkboxVisibility={CheckboxVisibility.hidden}
                                   items={this.searchModel.itemsView}
                                   layoutMode={DetailsListLayoutMode.justified}
                                   skipViewportMeasures={false}
                                   selectionMode={SelectionMode.single}
                                   constrainMode={ConstrainMode.unconstrained}
                                   selectionPreservedOnEmptyClick={true}
                                   enterModalSelectionOnTouch={true}
                                   onShouldVirtualize={this._onShouldVirtualize}/>
        } else {
            content = <div>No search results found.</div>
        }
        return (
            <AppHostWrapper className="me-search-applet" host={this.props.host} title="Match Eval Search">
                <MESearchCommandBar {...this.props} searchRequest={this.searchRequest} isResultsBar={true} enableBack={this.searchModel.items.length>1}/>
                <Details className={css("me-search-results")}
                         summary={"Search Results"}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("me-search-history-ribbon")}>
                    {content}
                </Details>
            </AppHostWrapper>
        );
    }
}

export { MESearchResults, getSourceSystemDetails  }

