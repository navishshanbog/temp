import * as React from "react";
import { observer } from "mobx-react";
import {IMESearchRequestModel} from "../IMESearchRequestModel";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import "./MESearchRequestActions.scss";

interface IMESearchRequestActionsProps {
    searchRequest: IMESearchRequestModel;
    onSubmit?: (request : IMESearchRequestModel) => void;
    onClear?: () => void;
}

@observer
class MESearchRequestActions extends React.Component<IMESearchRequestActionsProps, any> {
    _handleSubmit = () => {
        this.props.searchRequest.submit(this.props.onSubmit);
    }
    _handleClear = () => {
        this.props.searchRequest.clear();
        if(this.props.onClear) {
            this.props.onClear();
        }
    }
    render() {
        return (
            <div className="match-eval-search-actions">
                <PrimaryButton
                    className="match-eval-search-action"
                    disabled={!this.props.searchRequest.isValueSpecified}
                    onClick={this._handleSubmit}
                    iconProps={{ iconName: "Search" }}>Search</PrimaryButton>
                <PrimaryButton
                    className="match-eval-search-action"
                    onClick={this._handleClear}
                    disabled={!this.props.searchRequest.isValueSpecified}
                    iconProps={{ iconName: "Clear" }}>Clear</PrimaryButton>
            </div>
        );
    }
}

export { MESearchRequestActions, IMESearchRequestActionsProps };