import * as React from "react";
import { observer } from "mobx-react";
import {IMESearchRequestModel} from "../IMESearchRequestModel";
import { Spinner, SpinnerSize } from "office-ui-fabric-react/lib/Spinner";


interface IMESearchSpinnerProps {
    searchRequest?: IMESearchRequestModel;
}

@observer
class MESearchSpinner extends React.Component<IMESearchSpinnerProps, any> {
    render() {
        return <Spinner title="Loading ..." size={SpinnerSize.large}  />
    }
}

export { MESearchSpinner }