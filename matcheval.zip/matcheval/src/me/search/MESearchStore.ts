import {MESearchModel} from "./MESearchModel";

const MESearchStore = new MESearchModel();

export { MESearchStore };