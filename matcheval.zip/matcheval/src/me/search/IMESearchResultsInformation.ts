import {IBioInfoActivity} from "../visahistory/IBioInfoActivity";
import {IVisas} from "../visahistory/IVisas";

interface IMESearchResultsInformation {
    caseId?: string;
    domain?: string;
    bioInfo?: IBioInfoActivity[];
    visas?: IVisas[];
}

export { IMESearchResultsInformation }