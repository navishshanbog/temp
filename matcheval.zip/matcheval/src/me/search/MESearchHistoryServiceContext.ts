import Context from "@twii/common/lib/Context";
import {IMESearchHistoryService}  from "./IMESearchHistoryService";
import {MESearchHistoryRestService} from "./MESearchHistoryRestService";

const MESearchHistoryServiceContext = new Context<IMESearchHistoryService>({
    factory: () => {
        return new MESearchHistoryRestService();
    }
});

export { MESearchHistoryServiceContext };