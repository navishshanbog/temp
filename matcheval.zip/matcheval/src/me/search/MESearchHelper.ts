import { IAppHost } from "@twii/common/lib/IAppHost";
import { IMESearchRequestModel } from "./IMESearchRequestModel";
import { MESearchRequestModel } from "./MESearchRequestModel";
import { MESearchModel } from "./MESearchModel";
import { IMESearch } from "./IMESearch";
const hasSearchRequestModel = (host : IAppHost) : boolean => {
    return host.state.meSearchRequest ? true : false;
};

const getSearchRequestModel = (host : IAppHost) : IMESearchRequestModel => {
    let r = host.state.meSearchRequest;
    if(!r) {
        r = new MESearchRequestModel();
        host.setState({ meSearchRequest: r });
    }
    return r;
};

const getSearchModel = (host: IAppHost) : IMESearch => {
    let r = host.state.meSearchModel;
    if(!r) {
        r = new MESearchModel();
        host.setState({meSearchModel: r});
    }
    return r;
};

export { getSearchRequestModel, getSearchModel }