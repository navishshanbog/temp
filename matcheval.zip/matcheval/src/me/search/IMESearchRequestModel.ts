import {IMESearchRequest} from "./IMESearchRequest";
import IError from "@twii/common/lib/IError";

interface IMESearchRequestModel extends IMESearchRequest {
    validationErrors?: IError[];
    isValueSpecified?: boolean;
    setCredentialType(credentialType?: string) : void;
    setCredential(credential?: string) : void;
    busyThinking?: boolean;
    request : IMESearchRequest;
    setRequest(request : IMESearchRequest) : void;
    validate() : void;
    isValid : boolean;
    submit(requestHandler : (request : IMESearchRequest) => void);
    clear(): void;
}

export { IMESearchRequestModel  };