import IMECase from "../IMECase";
import IMESummaryModel from "./summary/IMESummaryModel";
import IProfileMatchModel from "./profilematch/IProfileMatchModel";
import IVesselScheduleModel from "./IVesselScheduleModel";
import IMETSPNRModel from "./travellersummary/IMETSPNRModel";
import ITravellerHistoryModel from "./travelhistory/ITravellerHistoryModel";


interface IMEAirModel {
    meCase: IMECase;
    summaryModel: IMESummaryModel;
    profileMatchModel: IProfileMatchModel;
    vesselScheduleModel: IVesselScheduleModel;
    historicalPNRnIATModel: IMETSPNRModel;
    travellerHistoryModel: ITravellerHistoryModel;
    load(meCase: IMECase): Promise<any>;
    refresh() : Promise<any>;
}

export { IMEAirModel as default, IMEAirModel }
