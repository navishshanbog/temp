import ISyncModel from "@twii/common/lib/ISyncModel";
import IMECase from "../IMECase";
import ICruiseBookingData from "../../risk/traveller/cru/ICruiseBookingData";
import ICruiseTraveller from "../../risk/traveller/cru/ICruiseTraveller";
import ITravelDocInfo from "../../risk/traveller/cru/common/ITravelDocInfo";
import ICruiseBookingItineraryType from "../../risk/traveller/cru/common/ICruiseBookingItinerary";
import ITravelAgent from "../../risk/traveller/cru/ITravelAgent";


interface ICruiseBookingModel {
    sync: ISyncModel;
    meCase : IMECase;
    booking: ICruiseBookingData;
    load(meCase : IMECase): Promise<any>;
    cruiseTravellers: ICruiseTraveller[];
    cruiseTravellerTravelDocs: IICruiseTravellerTravelDocs[];
    cruiseTravelAgents: ITravelAgent[];
    cruiseBookingItineraries: ICruiseBookingItineraryType[];
    refresh() : Promise<any>;
}

interface IICruiseTraveller extends ICruiseTraveller {
    PassengerNumber?: number;
}

interface IICruiseTravellerTravelDocs extends IICruiseTraveller {
    travelDoc?: ITravelDocInfo;
}

export { ICruiseBookingModel as default, ICruiseBookingModel, IICruiseTraveller, IICruiseTravellerTravelDocs};
