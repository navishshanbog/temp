import IMECase from "../../IMECase";
import ICruiseBookingModel from "../ICruiseBookingModel";
import IProfileMatchModel from "../profilematch/IProfileMatchModel";
import ITravellerHistoryModel from "../travelhistory/ITravellerHistoryModel";

interface IMECruiseModel {
    meCase: IMECase;
    bookingModel: ICruiseBookingModel;
    profileMatchModel: IProfileMatchModel;
    travellerHistoryModel: ITravellerHistoryModel;
    load(meCase: IMECase): Promise<any>;
    refresh() : Promise<any>;
}

export { IMECruiseModel as default, IMECruiseModel }
