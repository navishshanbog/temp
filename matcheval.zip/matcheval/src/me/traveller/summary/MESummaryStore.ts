import MESummaryModel from "./MESummaryModel";

const MESummaryStore = new MESummaryModel();

export { MESummaryStore as default, MESummaryStore };