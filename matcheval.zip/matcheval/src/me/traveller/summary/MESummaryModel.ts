import { observable, action, computed } from "mobx";
import IGetCurrentBookingDataRequest from "../../../risk/traveller/pnr/request/IGetCurrentBookingDataRequest";
import PNRDataServiceContext from "../../../risk/traveller/pnr/PNRDataServiceContext";
import IPNRRecord from "../../../risk/traveller/pnr/IPNRRecord";
import IBaggage from "../../../risk/traveller/pnr/IBaggage";
import ICheckinBoarding from "../../../risk/traveller/pnr/ICheckinBoarding";
import ISKOtherComment from "../../../risk/traveller/pnr/ISKOtherComment";
import IOtherService from "../../../risk/traveller/pnr/IOtherService";
import ITravellerSummary from "../../../risk/traveller/pnr/ITravellerSummary";
import IPayment from "../../../risk/traveller/pnr/IPayment";
import IPNRHistory from "../../../risk/traveller/pnr/IPNRHistory";
import IPNRPushHistory from "../../../risk/traveller/pnr/IPNRPushHistory";
import ITravelAgent from "../../../risk/traveller/pnr/ITravelAgent";
import IItinerary from "../../../risk/traveller/pnr/IItinerary";
import ISpecialServiceRequest from "../../../risk/traveller/pnr/ISpecialServiceRequest";
import IContact from "../../../risk/traveller/pnr/IContact";
import IBookingSummary from "../../../risk/traveller/pnr/IBookingSummary";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import * as DateUtils from "@twii/common/lib/util/Date";
import { IMECase } from "../../IMECase";
import IMESummaryModel from "./IMESummaryModel";
import IHistoricalPNRRecord from "../../../risk/traveller/pnr/IHistoricalPNRRecord";
import IPNRRecordKey from "../../../risk/traveller/pnr/IPNRRecordKey";
import ITicketing from "../../../risk/traveller/pnr/ITicketing";
import {sort} from "../../MECustomSortHelper";

class MESummaryModel implements IMESummaryModel{

    @observable bookingSummary: IPNRRecord = {};
    @observable sync: ISyncModel = new SyncModel();
    @observable historicalPNRItemBookingSummary: IPNRRecord = {};
    @observable visible: boolean = false;
    private historicalPNRItem: IHistoricalPNRRecord = {};
    private linkedPNRItem: IPNRRecordKey = {};
    meCase: IMECase;

    @action
    refresh() : Promise<any> {
        const syncId = this.meCase.CaseID;
        this.sync.syncStart({ id: syncId });
        let request: IGetCurrentBookingDataRequest = {
            BookingSystemCode : this.meCase.BookingSystemCode,
            BookingCreationTimeStamp : DateUtils.dateFromMatchEvaluationDataText(this.meCase.CreationTs),
            RecordLocator : this.meCase.RecordLocator
        };
        return PNRDataServiceContext.ref.GetCurrentBookingData(request)
            .then((bookingData) => {
                    this.bookingSummary = bookingData.CurrentBookingData;
                    this.sync.syncEnd();

            }).catch((error) => {
                    this.bookingSummary = {};
                    this.sync.syncError(error);

            });
    }

    @action
    getBookingSummaryForHPNR() : Promise<any> {
        const syncId = this.historicalPNRItem.RecordLocator;
        this.sync.syncStart({ id: syncId });
        let request: IGetCurrentBookingDataRequest = {
            BookingSystemCode : this.historicalPNRItem.Carrier,
            BookingCreationTimeStamp : this.historicalPNRItem.CreationTimeStamp,
            RecordLocator : this.historicalPNRItem.RecordLocator
        };
        return PNRDataServiceContext.ref.GetCurrentBookingData(request)
            .then((bookingData) => {
                    this.historicalPNRItemBookingSummary = bookingData.CurrentBookingData;
                    this.sync.syncEnd();

            }).catch((error) => {
                    this.historicalPNRItemBookingSummary = {};
                    this.sync.syncError(error);

            });
    }
    @action
    getBookingSummaryForLinkedPNR() : Promise<any> {
        const syncId = this.linkedPNRItem.RecordLocator;
        this.sync.syncStart({ id: syncId });
        let request: IGetCurrentBookingDataRequest = {
            BookingSystemCode : this.linkedPNRItem.BookingSystemCode,
            BookingCreationTimeStamp : this.linkedPNRItem.PNRCreationTimeStamp,
            RecordLocator : this.linkedPNRItem.RecordLocator
        };
        return PNRDataServiceContext.ref.GetCurrentBookingData(request)
            .then((bookingData) => {
                    this.historicalPNRItemBookingSummary = bookingData.CurrentBookingData;
                    this.sync.syncEnd();

            }).catch((error) => {
                    this.historicalPNRItemBookingSummary = {};
                    this.sync.syncError(error);

            });

    }

    setVisibility(_visible: boolean) {
        this.visible = _visible;
    }

    loadByCaseId(meCase: IMECase) : Promise<any> {
        const syncId = meCase.CaseID;
        if(meCase.RecordLocator && meCase.BookingSystemCode && meCase.CreationTs) {
                this.meCase = meCase;
                return this.refresh();
        } else {
            this.bookingSummary = {};
        }
        return Promise.resolve();
    }

    /* for historial pnr : pnr link */
    loadByHistoricalPNRItem(item : IHistoricalPNRRecord | IPNRRecordKey): Promise<any> {
        const syncId = item.RecordLocator;
            this.historicalPNRItem = item;
            return this.getBookingSummaryForHPNR();

    }

    /* for purchase info pnr link */
    loadByLinkedPNRItem(item : IPNRRecordKey): Promise<any> {
        const syncId = item.RecordLocator;
            this.linkedPNRItem = item;
            return this.getBookingSummaryForLinkedPNR();

    }

    getHistoricalPNRSummary(): IBookingSummary {
        if(this.historicalPNRItemBookingSummary && this.historicalPNRItemBookingSummary.BookingSummaryInfo)
            return this.historicalPNRItemBookingSummary.BookingSummaryInfo;
        return;
    }
    @computed
    get ticketingInfo(): ITicketing[] {
        let ticketingInfo: ITicketing[] = [];
        if(this.bookingSummary && this.bookingSummary.TicketingInfo && this.bookingSummary.TicketingInfo.Ticketing) {
            this.bookingSummary.TicketingInfo.Ticketing.forEach((ticket) => {
            ticketingInfo.push(ticket);
        });

        }
        ticketingInfo = ticketingInfo.length > 1 ? sort(ticketingInfo, "PassengerTattoo") : ticketingInfo;
        return ticketingInfo;
    }

    getBiographicDetails(ticket: ITicketing): ITicketing {
        if(this.bookingSummary && this.bookingSummary.TravellerInfo && this.bookingSummary.TravellerInfo.TravellerSummary) {
            this.bookingSummary.TravellerInfo.TravellerSummary.forEach((travelSummary) => {
                if(travelSummary.PNRTraveller) {
                    if(travelSummary.PNRTraveller.PassengerTattoo == ticket.PassengerTattoo) {
                        ticket.ReservationName = travelSummary.PNRTraveller.ReservationName
                        return ticket;
                    }
                }
            });
        }
        return ticket;
    }


    @computed
    get checkinNboardingItems(): ICheckinBoarding[] {
        let checkinNboardingItems: ICheckinBoarding[] = [];
        if(this.bookingSummary && this.bookingSummary.ItineraryInfo && this.bookingSummary.ItineraryInfo.Itinerary) {
            this.bookingSummary.ItineraryInfo.Itinerary.forEach((itinerary) => {
                let segmentTattoo = itinerary.SegmentTattoo? itinerary.SegmentTattoo : null;
                if (itinerary.CheckinBoardingInfo && itinerary.CheckinBoardingInfo.CheckingBoarding) {
                    itinerary.CheckinBoardingInfo.CheckingBoarding.forEach((boarding) => {
                        boarding.SegmentTattoo = segmentTattoo;
                        checkinNboardingItems.push(boarding);
                    });
                }
            });
        }
        checkinNboardingItems = checkinNboardingItems.length > 1 ? sort(checkinNboardingItems, "PassengerTattoo") : checkinNboardingItems;
        return checkinNboardingItems;
    }



    @computed
    get travelContacts(): IContact[] {
        let travelContacts: IContact[] = [];
        if(this.bookingSummary && this.bookingSummary.ItineraryInfo && this.bookingSummary.ItineraryInfo.Itinerary) {
            this.bookingSummary.ItineraryInfo.Itinerary.forEach((itinerary) => {
                let segmentTattoo = itinerary.SegmentTattoo? itinerary.SegmentTattoo : null;
                if(itinerary.ContactInfo && itinerary.ContactInfo.Contact) {
                    itinerary.ContactInfo.Contact.forEach((contact) => {
                        contact.SegmentTattoo = segmentTattoo;
                        travelContacts.push(contact);
                    });
                }
            });
        }
        travelContacts = travelContacts.length > 1 ? sort(travelContacts, "PassengerTattoo") : travelContacts;
        return travelContacts;
    }

    @computed
    get linkedPNRItems(): IPNRRecordKey[] {
        let linkedPNRItems: IPNRRecordKey[] = [];
        if(this.bookingSummary && this.bookingSummary.LinkedPNRInfo && this.bookingSummary.LinkedPNRInfo.PNRRecordKey)
            this.bookingSummary.LinkedPNRInfo.PNRRecordKey.forEach((linkedPNR) => {
                linkedPNRItems.push(linkedPNR);
            });
        return linkedPNRItems;
    }

    @computed
    get splitPNRItems(): IPNRRecordKey[] {
        let splitPNRItems: IPNRRecordKey[] = [];
        if(this.bookingSummary && this.bookingSummary.SplitPNRInfo && this.bookingSummary.SplitPNRInfo.PNRRecordKey)
            this.bookingSummary.SplitPNRInfo.PNRRecordKey.forEach((splitPNR) => {
                splitPNRItems.push(splitPNR);
            });
        return splitPNRItems;
    }

    @computed
    get travelSummaryItems(): ITravellerSummary[] {
        let travelSummaryItems: ITravellerSummary[] = [];
        if(this.bookingSummary && this.bookingSummary.TravellerInfo && this.bookingSummary.TravellerInfo.TravellerSummary) {
            this.bookingSummary.TravellerInfo.TravellerSummary.forEach((travelSummary) => {
                travelSummaryItems.push(travelSummary);
            });
        }
        travelSummaryItems = travelSummaryItems.length > 1 ? sort(travelSummaryItems, "PNRTraveller.PassengerTattoo") : travelSummaryItems;
        return travelSummaryItems;
    }

    @computed
    get activeItineraryItems(): IItinerary[] {
        let activeItineraryItems: IItinerary[] = [];
        if(this.bookingSummary && this.bookingSummary.ItineraryInfo && this.bookingSummary.ItineraryInfo.Itinerary) {
            this.bookingSummary.ItineraryInfo.Itinerary.forEach((itinerary) => {
                activeItineraryItems.push(itinerary);
            });
        }
        activeItineraryItems = activeItineraryItems.length > 1 ? sort(activeItineraryItems, "SegmentTattoo") : activeItineraryItems;
        return activeItineraryItems;
    }

    @computed
    get otherCommentInfo(): ISKOtherComment[] {
        let otherCommentInfo: ISKOtherComment[] = [];
        if(this.bookingSummary && this.bookingSummary.PNRSKOtherCommentInfo && this.bookingSummary.PNRSKOtherCommentInfo.SKOtherComment) {
            this.bookingSummary.PNRSKOtherCommentInfo.SKOtherComment.forEach((oComment) => {
                otherCommentInfo.push(oComment);
            });
        }
        otherCommentInfo = otherCommentInfo.length > 1 ? sort(otherCommentInfo, "PassengerTattoo") : otherCommentInfo;
        return otherCommentInfo;
    }

    @computed
    get otherServiceInfo(): IOtherService[] {
        let otherServiceInfo: IOtherService[] = [];
        if(this.bookingSummary && this.bookingSummary.OtherServiceInfo && this.bookingSummary.OtherServiceInfo.OtherService) {
            this.bookingSummary.OtherServiceInfo.OtherService.forEach((oService) => {
                otherServiceInfo.push(oService);
            });
        }
        otherServiceInfo = otherServiceInfo.length > 1 ? sort(otherServiceInfo, "PassengerTattoo") : otherServiceInfo;
        return otherServiceInfo;
    }

    @computed
    get paymentItems(): IPayment[] {
        let paymentItems: IPayment[] = [];
        if(this.bookingSummary && this.bookingSummary.PaymentInfo && this.bookingSummary.PaymentInfo.Payment) {
            this.bookingSummary.PaymentInfo.Payment.forEach((pay) => {
                paymentItems.push(pay);
            });
        }
        return paymentItems;
    }

    @computed
    get pnrHistoryItems(): IPNRHistory[] {
        let pnrHistoryItems: IPNRHistory[] = [];
        if(this.bookingSummary && this.bookingSummary.PNRHistoryInfo && this.bookingSummary.PNRHistoryInfo.PNRHistory) {
            this.bookingSummary.PNRHistoryInfo.PNRHistory.forEach((hist) => {
                pnrHistoryItems.push(hist);
            });
        }
        // APA-698 : removing the sort order from AnDe for Services to sort as in the Hyperion
        //pnrHistoryItems = pnrHistoryItems.length > 1 ? sort(pnrHistoryItems, "CreationTimeStamp") : pnrHistoryItems;
        return pnrHistoryItems;
    }

    @computed
    get pushHistoryItems(): IPNRPushHistory[] {
        let pushHistoryItems: IPNRPushHistory[] = [];
        if(this.bookingSummary && this.bookingSummary.PNRPushHistoryInfo && this.bookingSummary.PNRPushHistoryInfo.PNRPushHistory) {
            this.bookingSummary.PNRPushHistoryInfo.PNRPushHistory.forEach((pushHist) => {
                pushHistoryItems.push(pushHist);
            });
        }
        pushHistoryItems = pushHistoryItems.length > 1 ? sort(pushHistoryItems, "PNRReceivedTimeStamp") : pushHistoryItems;
        return pushHistoryItems;
    }

    @computed
    get specialServiceReqInfo(): ISpecialServiceRequest[] {
        let specialServiceReqInfo: ISpecialServiceRequest[] = [];
        if(this.bookingSummary && this.bookingSummary.SpecialServiceRequestInfo && this.bookingSummary.SpecialServiceRequestInfo.SpecialServiceRequest) {
            this.bookingSummary.SpecialServiceRequestInfo.SpecialServiceRequest.forEach((ssRequest) => {
                specialServiceReqInfo.push(ssRequest);
            });
        }
        specialServiceReqInfo = specialServiceReqInfo.length > 1 ? sort(specialServiceReqInfo, "PassengerTattoo") : specialServiceReqInfo;
        return specialServiceReqInfo;
    }

    @computed
    get travelAgents(): ITravelAgent[] {
        let travelAgents: ITravelAgent[] = [];
        if(this.bookingSummary && this.bookingSummary.TravelAgentInfo && this.bookingSummary.TravelAgentInfo.TravelAgent) {
            this.bookingSummary.TravelAgentInfo.TravelAgent.forEach((tAgent) => {
                travelAgents.push(tAgent);
            });
        }
        return travelAgents;
    }

}


export { MESummaryModel as default, MESummaryModel }