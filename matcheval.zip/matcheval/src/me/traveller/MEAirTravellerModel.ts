import { observable, action } from "mobx";
import IMEAirTravellerModel from "./IMEAirTravellerModel";
import {IMECase, MEDomainType} from "../IMECase";
import MESummaryStore from "./summary/MESummaryStore";
import MEProfileMatchStore from "./profilematch/MEProfileMatchStore";
import VesselScheduleModel from "./VesselScheduleModel";
import METSPNRStore from "./travellersummary/METSPNRStore";
import METravelHistoryStore from "./travelhistory/METravelHistoryStore";
import IMESummaryModel from "./summary/IMESummaryModel";
import IProfileMatchModel from "./profilematch/IProfileMatchModel";
import IVesselScheduleModel from "./IVesselScheduleModel";
import IMETSPNRModel from "./travellersummary/IMETSPNRModel";
import ITravellerHistoryModel from "./travelhistory/ITravellerHistoryModel";
import ITravellerSummary from "../../risk/traveller/pnr/ITravellerSummary";
import * as StringUtils from "@twii/common/lib/util/String";

class MEAirTravellerModel implements IMEAirTravellerModel {

    @observable meCase: IMECase;
    @observable summaryModel: IMESummaryModel = MESummaryStore;
    @observable profileMatchModel: IProfileMatchModel = MEProfileMatchStore;
    @observable vesselScheduleModel: IVesselScheduleModel = new VesselScheduleModel();
    @observable historicalPNRnIATModel: IMETSPNRModel = METSPNRStore;
    @observable travellerHistoryModel: ITravellerHistoryModel = METravelHistoryStore;

    @action
    refresh() {
        if(this.meCase) {
            this.summaryModel.loadByCaseId(this.meCase).then((response) => {
                return this._loadTravellerHistory();
            })
            this.profileMatchModel.loadProfileMatches(this.meCase);
            this.vesselScheduleModel.loadByCaseId(this.meCase);
            this.historicalPNRnIATModel.loadByCaseId(this.meCase);
        }
        return Promise.resolve();
    }

    @action
    load(meCase: IMECase) : Promise<any> {
        this.meCase = meCase;
        return this.refresh();
    }

    _loadTravellerHistory = () : Promise<any> => {
        let iatTravellerIds: string[] = [];
        if(this.summaryModel.bookingSummary) {
            let bookingSummary = this.summaryModel.bookingSummary;
            if (bookingSummary && bookingSummary.TravellerInfo && bookingSummary.TravellerInfo.TravellerSummary) {
                bookingSummary.TravellerInfo.TravellerSummary.forEach((travellerSummary: ITravellerSummary) => {
                    if (travellerSummary.IATTraveller && StringUtils.isNotBlank(travellerSummary.IATTraveller.IATTravellerId)) {
                        iatTravellerIds.push(travellerSummary.IATTraveller.IATTravellerId);
                    }
                });
            }
        }
        if(this.meCase.IATTravellerID) {
            iatTravellerIds.push(this.meCase.IATTravellerID);
        }
        return this.travellerHistoryModel.load(iatTravellerIds);
    }
}

export { MEAirTravellerModel as default, MEAirTravellerModel }


