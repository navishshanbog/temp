import METSPNRModel from "./METSPNRModel";

const METSPNRStore = new METSPNRModel();

export { METSPNRStore as default, METSPNRStore };