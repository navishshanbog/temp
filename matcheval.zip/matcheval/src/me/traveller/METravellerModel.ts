import { observable, action } from "mobx";
import IMETravellerModel from "./IMETravellerModel";
import IMEAirTravellerModel from "./IMEAirTravellerModel";
import MEAirTravellerModel from "./MEAirTravellerModel";
import IMECruiseModel from "./cruise/IMECruiseModel";
import MECruiseModel from "./cruise/MECruiseModel";
import { IMECase, MEDomainType, MEBusinessDomainType } from "../IMECase";


class METravellerModel implements IMETravellerModel {
    @observable air : IMEAirTravellerModel;
    @observable sea : IMECruiseModel;

  //  @observable visa : IVisaHistoryModel;
   // @observable cargo : IMEAirCargoReportModel;

    @action
    load(meCase : IMECase) : Promise<any> {
        //if (StringUtils.equalsIgnoreCase(MEBusinessDomainType.Traveller, meCase.BusinessDomain)) {
            if (meCase.DomainType === MEDomainType.Air) {
                this.sea = undefined;
                if (!this.air) {
                    this.air = new MEAirTravellerModel();
                }
                return this.air.load(meCase);
            } else if (meCase.DomainType === MEDomainType.Sea) {
                this.air = undefined;
                if (!this.sea) {
                    this.sea = new MECruiseModel();
                }
                return this.sea.load(meCase);
            } else {
                this.air = undefined;
                this.sea = undefined;
            }
            return Promise.resolve();

        }
        
        // else if (StringUtils.equalsIgnoreCase(MEBusinessDomainType.Visa, meCase.BusinessDomain)) {
        //     // todo:  ... as in current state we would never have traveller information in Visa... so y have traveller info here?
        //     this.air = new MEAirTravellerModel();
        //     return this.air.load(meCase);
        // }

        // else if (StringUtils.equalsIgnoreCase(MEBusinessDomainType.Cargo, meCase.BusinessDomain)) {
            
        //     this.air = new MEAirTravellerModel();
        //     return this.air.load(meCase);
        // }

        // }
        /*else if (StringUtils.equalsIgnoreCase(MEBusinessDomainType.Visa, meCase.BusinessDomain)) {
            // todo:  ... as in current state we would never have traveller information in Visa... so y have traveller info here?
            this.air = new MEAirTravellerModel();
            return this.air.load(meCase);
        }*/
  

}

export { METravellerModel as default, METravellerModel }