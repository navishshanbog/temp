import ProfileMatchModel from "./ProfileMatchModel";

const MEProfileMatchStore = new ProfileMatchModel();

export { MEProfileMatchStore as default, MEProfileMatchStore };