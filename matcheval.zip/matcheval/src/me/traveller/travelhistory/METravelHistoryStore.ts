import TravellerHistoryModel from "./TravellerHistoryModel";

const METravelHistoryStore = new TravellerHistoryModel();

export { METravelHistoryStore as default, METravelHistoryStore };