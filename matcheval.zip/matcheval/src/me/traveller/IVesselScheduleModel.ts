import ISyncModel from "@twii/common/lib/ISyncModel";
import IVesselItinerary from "../../risk/traveller/vessel/response/IVesselItinerary";
import IMECase from "../IMECase";

interface IVesselScheduleModel {
    sync: ISyncModel;
    vesselSchedule: IVesselItinerary[];
    loadByCaseId(meCase: IMECase): Promise<any>;
}

export { IVesselScheduleModel as default, IVesselScheduleModel };
