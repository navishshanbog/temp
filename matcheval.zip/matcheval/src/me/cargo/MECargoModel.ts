import { observable, action } from "mobx";
import {IMECargoModel} from "./IMECargoModel";
import { IMECase, MEDomainType } from "../IMECase";
import * as StringUtils from "@twii/common/lib/util/String";

import {IMEAirCargoModel} from "./aircargo/IMEAirCargoModel";
import {MEAirCargoModel} from "./aircargo/MEAirCargoModel";
import {IMESeaCargoModel} from "./seacargo/IMESeaCargoModel";
import  {MESeaCargoModel} from "./seacargo/MESeaCargoModel";
import { MECargoReportModel } from "./cargoreport/MECargoReportModel";
import {IMECargoReportModel} from "./cargoreport/IMECargoReportModel";

class MECargoModel implements IMECargoModel {
    @observable air : IMECargoReportModel;
    @observable sea : IMECargoReportModel;
    @action
    load(meCase : IMECase) : Promise<any> {
            if (StringUtils.equalsIgnoreCase(meCase.DomainType, MEDomainType.Air)) {
                //this.sea = undefined;
                if (!this.air) {
                    this.air = new MECargoReportModel();
                }
                return this.air.loadCargoReportDetails(meCase);
            } else if (StringUtils.equalsIgnoreCase(meCase.DomainType, MEDomainType.Sea)) {
                this.air = undefined;
                if (!this.sea) {
                   // this.sea = new MESeaCargoModel();
                   this.sea = new MECargoReportModel();
                }
                //return this.sea.loadSeaCargoDetails(meCase);
                return this.sea.loadCargoReportDetails(meCase);
            } else {
                this.air = undefined;
                //this.sea = undefined;
            }
            return Promise.resolve();
    }
}

export { MECargoModel }