import ISyncModel from "@twii/common/lib/ISyncModel";
import {IMECase} from "../../../IMECase";
import IAirCargoSacReport from "./IAirCargoSacReport";

interface IAirCargoSacModel {
      sync: ISyncModel;
      sacItems: IAirCargoSacReport[];
      loadAirCargoSac(requestID: string) : Promise<any>;
    
}

export {IAirCargoSacModel };
