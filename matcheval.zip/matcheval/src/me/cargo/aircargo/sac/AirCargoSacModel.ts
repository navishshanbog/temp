import { observable, action, computed } from "mobx";
import {IAirCargoSacModel} from "./IAirCargoSacModel";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import IAirCargoSacReport from "./IAirCargoSacReport";
import { AirCargoReportServiceContext} from "../MEAirCargoReportServiceContext";
//import { AirCargoSacServiceContext } from "./AirCargoSacServiceContext";


class AirCargoSacModel implements IAirCargoSacModel {
	@observable sync: ISyncModel = new SyncModel();
    @observable sacItems: IAirCargoSacReport[] = [];
	private consignmentNbr: string;
	
	@action
    refresh() : Promise<any> {
        const syncId = this.consignmentNbr;
        this.sync.syncStart({id: syncId});

        return AirCargoReportServiceContext.value.getAirCargoSac({ declarationID: this.consignmentNbr} ) 
            .then(data => {
                this.sacItems = data;
                console.log("--this is from Sac items", this.sacItems);
                this.sync.syncEnd();
            }).catch(error => {
                this.sacItems = [];
                this.sync.syncError(error);
            });
    }

 @action
    loadAirCargoSac(requestId: string) : Promise<any> {
        this.consignmentNbr = requestId;
        //console.log("-- response from cargo SAC service ", this.refresh());
        return this.refresh();
    }

}
export { AirCargoSacModel }

