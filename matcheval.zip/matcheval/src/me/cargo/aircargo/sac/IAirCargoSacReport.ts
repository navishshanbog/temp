interface IAirCargoSacReport {
    declarationID?: string;
    masterBill?: string;
    BrokerageLicenseNo?: string;
    consolidatedCargoStatus?: string;
    lodgedDate?: string;
    branch?: string;
    status?: string;
    departmentBoxNo?: string;
    modeOfTransport?: string;
    dischargePort?: string;
    vesselNo?: string;
    occeanBillOfLading?: string;
    cargoType?: string;
    destinationPort?: string;
    voyageNo?: string;
    houseBillOfLading?: string;
    grossWeight?: string;
    arrivalDate?: string;
    containerNo?: string;
    deliveryAddress?: string;
    importerID?: string;
    importerAddress?: string;
    sacCoommunicator?: string;
    supplierId?: string;
    importerReference?: string;
    communicatorRef?: string;
    aquisInspectionLoc?: string;
    supplierName?: string;
    importerName?: string;
    contactPhoneNo?: string;
    goodDescription?: string;
    vendorId?: string;
    grossWeightUnit?: string;
     consignmentRef?: string;
     version?: number;
}

export { IAirCargoSacReport as default, IAirCargoSacReport };