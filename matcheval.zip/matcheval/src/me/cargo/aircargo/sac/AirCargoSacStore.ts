import { AirCargoSacModel} from "./AirCargoSacModel";

const AirCargoSacStore = new AirCargoSacModel();

export { AirCargoSacStore};