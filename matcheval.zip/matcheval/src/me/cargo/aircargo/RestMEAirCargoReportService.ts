import axios, { AxiosRequestConfig } from 'axios';
import { IAirCargoReportService,
        IAirCargoSacRequest ,
        IAirCargoExamsRequest} from "./IMEAirCargoReportService";
import AbstractRestDataService from "../../../common/AbstractRestDataService";
//import * as DefaultHttpErrorHandler from "@twii/common/lib/HttpErrorHandler";
import IAirCargoSacReport from "./sac/IAirCargoSacReport";
import IAirCargoExamsReport from "./exams/IAirCargoExamsReport";

interface GetAirCargoExamsResponse {
	errors?: any;
	getAirCargoExamsReport?: IAirCargoExamsReport[];
}

interface GetAirCargoSacResponse {
	errors?: any;
	getAirCargoSacReport?: IAirCargoSacReport[];
}

class RestMEAirCargoReportService extends AbstractRestDataService implements IAirCargoReportService {
    getAirCargoSac(request:IAirCargoSacRequest) :  Promise<IAirCargoSacReport[]> {
		const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/AirCargoSacServices/v1/resources/AirCargoSAC`, req).then((value) => {
            const response = value.data as GetAirCargoSacResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getAirCargoSacReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}
    
    getAirCargoExams(request:IAirCargoExamsRequest) :  Promise<IAirCargoExamsReport[]> {
		const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/AirCargoExamsServices/v1/resources/AirCargoEXAMS`, req).then((value) => {
            const response = value.data as GetAirCargoExamsResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getAirCargoExamsReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}
   

}
export { RestMEAirCargoReportService };