import ISyncModel from "@twii/common/lib/ISyncModel";
//import {ICaseActivity} from "./ICaseActivity";
import {IMECase} from "../../IMECase";
/*import { IVisaHistoryCaseDetailsModel } from "./IVisaHistoryCaseDetailsModel";*/
import {IAirCargoActivityDetail} from "@twii/entity/lib/cargo/air/IAirCargoActivityDetail";
//import {IAirCargoFidReport} from "./fid/IAirCargoFidReport";
//import {IAirCargoSacReport} from "./sac/IAirCargoSacReport";

interface IMEAirCargoModel {
    sync: ISyncModel;
    items: IAirCargoActivityDetail[];
   // fidVersion : number ;
    //selectedFidIndex: number;
    //selectedFid: number;
    //sacItems: IAirCargoSacReport[];
    //selectedCaseIndex: number;
    loadAirCargoDetails(meCase : IMECase): Promise<any>;
   // updateSelectedFidIndex(selectedFidIndex: number) : void;
/*    caseItems: ICaseActivity[];
    selectedCaseIndex: number;
    refresh(): Promise<any>;
    loadCaseSummary(meCase: IMECase) : Promise<any>;
    visaHistoryCaseDetailsModel: IVisaHistoryCaseDetailsModel;
    entityBioDetails: any;
    vraResponse: IClientRiskCheck;*/
}

export { IMEAirCargoModel };