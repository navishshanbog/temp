import { action, IAction } from "mobx";
import {AirCargoSacModel} from "../aircargo/sac/AirCargoSacModel";
import {AirCargoSacStore} from "../aircargo/sac/AirCargoSacStore";
import {AirCargoExamsModel} from "../aircargo/exams/AirCargoExamsModel";
import {AirCargoExamsStore} from "../aircargo/exams/AirCargoExamsStore";
import {AirCargoFidModel} from "../aircargo/fid/AirCargoFidModel";
import {AirCargoFidStore} from "../aircargo/fid/AirCargoFidStore";

const getSacDetails = action((declarationId?: string) => {
    AirCargoSacStore.loadAirCargoSac(declarationId);
});

const getExamsDetails = action((masterBillNbr?: string) => {
    AirCargoExamsStore.loadAirCargoExams(masterBillNbr);
});

const getFidDetails = action((masterBillNbr?: string) => {
    AirCargoFidStore.loadAirCargoFid(masterBillNbr);
});

export { getSacDetails , getExamsDetails, getFidDetails}