import { observable, action, computed } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import {IMEAirCargoModel} from "./IMEAirCargoModel";
import {IMECase} from "../../IMECase";
import AirCargoServiceContext from "@twii/entity/lib/cargo/air/AirCargoServiceContext";
import {IAirCargoActivityDetail} from "@twii/entity/lib/cargo/air/IAirCargoActivityDetail";
import { getSacDetails, getExamsDetails,getFidDetails } from "./MEAirCargoAction";


//import {IAirCargoFidReport} from "./fid/IAirCargoFidReport";
//import { AirCargoFidServiceContext } from "./fid/AirCargoFidServiceContext";

//import {ICaseActivity} from "../../visahistory/ICaseActivity";
//import {ICaseDetailsActivity} from "../../visahistory/ICaseDetailsActivity";
//import {VisaHistoryServiceContext} from "../../visahistory/VisaHistoryServiceContext";
//import {IAirCargoSacReport} from "./sac/IAirCargoSacReport";
//import { AirCargoSacServiceContext } from "./sac/AirCargoSacServiceContext";


class MEAirCargoModel implements IMEAirCargoModel {
    @observable sync: ISyncModel = new SyncModel();
    @observable items: IAirCargoActivityDetail[] = [];
    @observable fidVersion : number[] = [];
    @observable selectedFidIndex: number = 0;
    @observable selectedFid : number = 1;
    private consignmentNbr: string;
    private caseId: string = "VME-4303";
    // @observable caseItems: ICaseActivity[] = [];
    //@observable selectedCaseDetails: ICaseDetailsActivity = {};
    //@observable sacItems: IAirCargoSacReport[] = [];


    @action
    refresh() : Promise<any> {
        const syncId = this.consignmentNbr;
        this.sync.syncStart({ id: syncId });
        return AirCargoServiceContext.value.getAirCargoActivityDetails({ parentId: "", masterBillNbr: this.consignmentNbr })  // entity identifies as masterbillnumber
            .then(data => {
                this.items = data;
                console.log("-- items", this.items);
                getFidDetails(this.consignmentNbr);
                getSacDetails(this.consignmentNbr);
                
                getExamsDetails(this.consignmentNbr);
                this.sync.syncEnd();
            }).catch(error => {
                this.items = [];
                this.sync.syncError(error);
            });
    }

    @action
    loadAirCargoDetails(meCase: IMECase) : Promise<any> {
        this.consignmentNbr = meCase.consignmentNbr;
        console.log("-- response from cargo service ", this.refresh());
        return null;
    }
}
export {MEAirCargoModel};