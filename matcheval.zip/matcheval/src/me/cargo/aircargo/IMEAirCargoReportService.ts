
import IAirCargoSacReport from "./sac/IAirCargoSacReport";
import IAirCargoExamsReport from "./exams/IAirCargoExamsReport";


interface IAirCargoSacRequest {
	declarationID: string;
}

interface IAirCargoExamsRequest {
	masterBillNbr: string;
}

interface IAirCargoReportService {
	getAirCargoSac(request: IAirCargoSacRequest) :  Promise<IAirCargoSacReport[]>;
   // getAirCargoBram(request: IAirCargoBramRequest) :  Promise<IAirCargoBramReport[]>;
    getAirCargoExams(request: IAirCargoExamsRequest) :  Promise<IAirCargoExamsReport[]>;
    
}

export {IAirCargoReportService,
        IAirCargoSacRequest ,
        IAirCargoExamsRequest};