import { observable, action, computed } from "mobx";
import {IAirCargoExamsModel} from "./IAirCargoExamsModel";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import IAirCargoExamsReport from "./IAirCargoExamsReport";
//import { AirCargoExamsServiceContext } from "./AirCargoExamsServiceContext";
import { AirCargoReportServiceContext} from "../MEAirCargoReportServiceContext";

class AirCargoExamsModel implements IAirCargoExamsModel {
	@observable sync: ISyncModel = new SyncModel();
    @observable examsItems: IAirCargoExamsReport[] = [];
	private consignmentNbr: string;
	
	@action
    refresh() : Promise<any> {
        const syncId = this.consignmentNbr;
        this.sync.syncStart({id: syncId});

        return AirCargoReportServiceContext.value.getAirCargoExams({  masterBillNbr: this.consignmentNbr} ) 
            .then(data => {
                this.examsItems = data;
                console.log("--this is from EXAMS items", this.examsItems);
                this.sync.syncEnd();
            }).catch(error => {
                this.examsItems = [];
                this.sync.syncError(error);
            });
    }

 @action
    loadAirCargoExams(requestId: string) : Promise<any> {
        this.consignmentNbr = requestId;
        //console.log("-- response from cargo SAC service ", this.refresh());
        return this.refresh();
    }

}
export { AirCargoExamsModel }

