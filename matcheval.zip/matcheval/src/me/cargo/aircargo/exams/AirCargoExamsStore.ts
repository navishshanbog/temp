import { AirCargoExamsModel} from "./AirCargoExamsModel";

const AirCargoExamsStore = new AirCargoExamsModel();

export { AirCargoExamsStore};