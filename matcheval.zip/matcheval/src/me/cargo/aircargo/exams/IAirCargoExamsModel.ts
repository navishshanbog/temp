import ISyncModel from "@twii/common/lib/ISyncModel";
import {IMECase} from "../../../IMECase";
import IAirCargoExamsReport from "./IAirCargoExamsReport";

interface IAirCargoExamsModel {
      sync: ISyncModel;
      examsItems: IAirCargoExamsReport[];
      loadAirCargoExams(requestID: string) : Promise<any>;
    
}

export {IAirCargoExamsModel };
