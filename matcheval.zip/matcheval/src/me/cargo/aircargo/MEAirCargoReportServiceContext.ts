import Context from "@twii/common/lib/Context";
import {IAirCargoReportService}  from "./IMEAirCargoReportService";
import {RestMEAirCargoReportService} from "./RestMEAirCargoReportService";

const AirCargoReportServiceContext = new Context<IAirCargoReportService>({
    factory: () => {
        return new RestMEAirCargoReportService();
    }
});

export { AirCargoReportServiceContext };