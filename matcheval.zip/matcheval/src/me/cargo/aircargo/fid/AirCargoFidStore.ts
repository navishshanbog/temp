import { AirCargoFidModel} from "./AirCargoFidModel";

const AirCargoFidStore = new AirCargoFidModel();

export { AirCargoFidStore};