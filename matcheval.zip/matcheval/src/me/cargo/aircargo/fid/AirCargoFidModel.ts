import { observable, action, computed } from "mobx";
import {IAirCargoFidModel} from "./IAirCargoFidModel";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import {IMECase} from "../../../IMECase";
import IAirCargoFidReport from "./IAirCargoFidReport";
import { AirCargoFidServiceContext } from "./AirCargoFidServiceContext";

class AirCargoFidModel implements IAirCargoFidModel {
	@observable sync: ISyncModel = new SyncModel();
    @observable items: IAirCargoFidReport[] = [];
	private consignmentNbr: string;
	
	@action
    refresh() : Promise<any> {
        const syncId = this.consignmentNbr;
        this.sync.syncStart({id: syncId});

        return AirCargoFidServiceContext.value.getAirCargoFid({ masterBillNbr: this.consignmentNbr} ) 
            .then(data => {
                this.items = data;
                console.log("--this is from FID items", this.items);
                this.sync.syncEnd();
            }).catch(error => {
                this.items = [];
                this.sync.syncError(error);
            });
    }

 @action
    loadAirCargoFid(requestId: string) : Promise<any> {
        this.consignmentNbr = requestId;
        return this.refresh();
    }

}
export { AirCargoFidModel }

