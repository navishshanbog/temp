import IAirCargoFidReport from "./IAirCargoFidReport";

interface IAirCargoFidRequest {
	masterBillNbr: string;
}

interface IAirCargoFidService {
	getAirCargoFid(request: IAirCargoFidRequest) :  Promise<IAirCargoFidReport[]>;
}

export { IAirCargoFidService, IAirCargoFidRequest };
