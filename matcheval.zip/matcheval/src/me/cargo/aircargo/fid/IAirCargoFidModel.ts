import ISyncModel from "@twii/common/lib/ISyncModel";
import {IMECase} from "../../../IMECase";
import IAirCargoFidReport from "./IAirCargoFidReport";

interface IAirCargoFidModel {
      sync: ISyncModel;
      items: IAirCargoFidReport[];
      loadAirCargoFid(requestID: string) : Promise<any>;
    
}

export {IAirCargoFidModel };
