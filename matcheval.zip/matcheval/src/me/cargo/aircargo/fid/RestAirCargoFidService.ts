import axios, { AxiosRequestConfig } from 'axios';
import IAirCargoFidReport from "./IAirCargoFidReport";
import AbstractRestDataService from "../../../../common/AbstractRestDataService";
import { IAirCargoFidService, IAirCargoFidRequest } from "./IAirCargoFidService";

interface GetAirCargoFidResponse {
	errors?: any;
	getAirCargoFidReport?: IAirCargoFidReport[];
}

class RestAirCargoFidService extends AbstractRestDataService implements IAirCargoFidService {
	getAirCargoFid(request:IAirCargoFidRequest) :  Promise<IAirCargoFidReport[]> {
		const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/AirCargoFIDServices/v1/resources/AirCargoFID`, req).then((value) => {
            const response = value.data as GetAirCargoFidResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getAirCargoFidReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}

}

export {RestAirCargoFidService};
