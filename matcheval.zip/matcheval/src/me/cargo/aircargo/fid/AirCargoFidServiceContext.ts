import Context from "@twii/common/lib/Context";
import {IAirCargoFidService}  from "./IAirCargoFidService";
import {RestAirCargoFidService} from "./RestAirCargoFidService";

const AirCargoFidServiceContext = new Context<IAirCargoFidService>({
    factory: () => {
        return new RestAirCargoFidService();
    }
});

export { AirCargoFidServiceContext };