import Context from "@twii/common/lib/Context";
import { IMECargoReportService }  from "./IMECargoReportService";
import { RestMECargoReportService } from "./RestMECargoReportService";

const MECargoReportServiceContext = new Context<IMECargoReportService>({
    factory: () => {
        return new RestMECargoReportService();
    }
});

export { MECargoReportServiceContext };