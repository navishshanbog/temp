import ISyncModel from "@twii/common/lib/ISyncModel";
import {IMECase} from "../../IMECase";
import {IMECargoReportDetails} from "./IMECargoReportDetails";
import {IMECargoReportInformation} from "./IMECargoReportInformation";

interface IMECargoReportModel {
    sync: ISyncModel;
    //items: IMECargoReportDetails[];
    //items: IMECargoReportInformation[];
    items: IMECargoReportInformation;
    versionNo: number;
    //selectedReport: IMECargoReportInformation; 
    //selectedReportIndex: number;
    refresh(): Promise<any>;
    loadCargoReportDetails(meCase : IMECase): Promise<any>;
    updateSelectedReportVersion(newVersion: number) : void;

}

export { IMECargoReportModel };
