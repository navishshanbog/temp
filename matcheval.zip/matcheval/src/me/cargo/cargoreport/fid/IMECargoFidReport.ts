//import IMECargoBramReport from "../bram/IMECargoBramReport";

interface IMECargoFidReport {
    masterBill?: string;
    modeOfReceipt?: string;
    quarantineHeld?: string;
    goodsDelivered?: string;
    paidUnderProtest?: string;
    lodgedDate?: string;
    paymentStatus?: string;
    borderHold?: string;
    modeOfPayment?: string;
    gstDeclarationResponse?: string;
    declarationStatus?: string;
    documentAdviceSent?: string;
    consolidatedCargoStatus?: string;
    modeOfTransport?: string;
    loadingPort?: string;
    arrivalDate?: string;
    grossWeight?: string;
    vesselNo?: string;
    dischargePort?: string;
    firstArrivalPort?: string;
    deliveryAddress?: string;
    voyageNo?: string;
    destinationPortID?: string;
    firstArrivalDate?: string;
    importerID?: string;
    importerName?: string;
    brokerReference?: string;
    importerReference?: string;
    importerBranch?: string;
    brokerPhoneNo?: string;
    nomineeBrokerLicenseNo?: string;
    
    
}

export { IMECargoFidReport as default, IMECargoFidReport };