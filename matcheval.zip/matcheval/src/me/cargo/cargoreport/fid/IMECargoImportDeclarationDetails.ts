import IMECargoFidReport from "./IMECargoFidReport";
import IMECargoSacReport from "../sac/IMECargoSacReport";

interface IMECargoImportDeclarationDetails {
    declarationID?: string;
    versionNbr?: number;
    matchStatus?: string;
    lastVersion?: number;
    fid?: IMECargoFidReport;
    sac?: IMECargoSacReport;
    
}
export {IMECargoImportDeclarationDetails as default, IMECargoImportDeclarationDetails};