import { MECargoImportDeclarationModel} from "./MECargoImportDeclarationModel";

const MECargoImportDeclarationStore = new MECargoImportDeclarationModel();

export { MECargoImportDeclarationStore};


