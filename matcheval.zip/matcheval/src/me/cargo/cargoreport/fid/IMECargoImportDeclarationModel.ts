import ISyncModel from "@twii/common/lib/ISyncModel";
//import {IMECase} from "../../IMECase";
import {IMECargoImportDeclarationDetails} from "./IMECargoImportDeclarationDetails";
//import { IMECargoReportDetails } from "../IMECargoReportDetails";
import { IMECargoReportInformation } from "../IMECargoReportInformation";
import { IMECargoFidReport } from "./IMECargoFidReport";
//import IMECargoBramReport from "../bram/IMECargoBramReport";

interface IMECargoImportDeclarationModel {
    sync: ISyncModel;
    importDecItems: IMECargoImportDeclarationDetails;
    selectedReport: IMECargoReportInformation; 
    versionNo: number;
    importDocType: string;
    refresh(): Promise<any>;
    loadImportDecDetails(selectedReport:  IMECargoReportInformation): Promise<any>;
    loadImportDecVersion(selectedReport:  IMECargoReportInformation, version:number): Promise<any>;
    updateSelectedImportDocumentVersion(selectedReport:  IMECargoReportInformation,version: number) : void;

}

export { IMECargoImportDeclarationModel }
