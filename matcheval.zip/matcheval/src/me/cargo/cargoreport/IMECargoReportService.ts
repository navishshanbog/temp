import IMECargoReportDetails from "./IMECargoReportDetails";
import IMECargoImportDeclarationDetails from "./fid/IMECargoImportDeclarationDetails";
import IBramReport from "../seacargo/bram/IBramReport";
import IMECargoExamsReport from "./exams/IMECargoExamsReport";
import IMECargoReportInformation from "./IMECargoReportInformation";
import IMECargoFidNSacInformation from "./fidNsac/IMECargoFidNSacInformation";

interface IMECargoReportInformationRequest {
        domainType?: string;     
        originalMsgId: string;
        lineId?: string;
        versionNo?: number;
}

interface IMECargoImportDeclarationRequest {
        documentType: string;
        clearanceType: string;
        billNumber: string;
        lineId: string;
        versionNo: number;
   
}

// shadow of IMECargoImportDeclarationRequest
interface IMECargoFidNSacRequest {
	documentType: string;
        clearanceType: string;
        billNumber: string;
        lineId: string;
        versionNo: number;
}

interface IMECargoBramRequest {
	declarationID: string;
        //documentType: string;
        voyageNumber: string;
        lodgedDate: string;
        versionNo: number;
}

interface IMECargoExamsRequest {
	masterBillNbr: string;
}

interface IMECargoReportService {
	getMECargoReportInformationRequest(request: IMECargoReportInformationRequest) : Promise<IMECargoReportInformation>;
        getMECargoImportDeclarationRequest(request: IMECargoImportDeclarationRequest) : Promise<IMECargoImportDeclarationDetails>;
        getMECargoFidNSacRequest(request: IMECargoFidNSacRequest) :  Promise<IMECargoFidNSacInformation>;
        getMECargoBramRequest(request: IMECargoBramRequest) :  Promise<IBramReport>;
        getMECargoExamsRequest(request: IMECargoExamsRequest) :  Promise<IMECargoExamsReport[]>;
}

export {IMECargoReportService, IMECargoImportDeclarationRequest,IMECargoReportInformationRequest, IMECargoBramRequest,IMECargoExamsRequest,IMECargoFidNSacRequest};