interface IContactInformation {
		"consignee":string,
		"consigneePhone":string,
		"consignor":string,
		"reportingClient":string,
		"reponsible":string,
		"notify":string,
		"importerId":string,
		"consigneeAddress":string,
		"consignorAddress":string,
		"reportingAddress":string,
		"reponsibleClientAddress":string,
		"notifyAddress":string,
		"supplierId":string,
		"principalAgent":string,
		"principalAgentAddress":string
}

export {IContactInformation as default, IContactInformation} ;