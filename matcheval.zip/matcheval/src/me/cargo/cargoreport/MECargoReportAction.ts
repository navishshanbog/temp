import { action, IAction } from "mobx";
import { MECargoImportDeclarationStore } from "./fid/MECargoImportDeclarationStore";
import { IMECargoReportInformation } from "./IMECargoReportInformation";

import {MECargoExamsModel} from "../cargoreport/exams/MECargoExamsModel";
import {MECargoExamsStore} from "../cargoreport/exams/MECargoExamsStore";
//import {IMECargoReportService,IMECargoImportDeclarationRequest, IMECargoReportInformationRequest, IMECargoBramRequest, IMECargoExamsRequest } from "./IMECargoReportService";
import IMECargoImportDeclarationDetails from "./fid/IMECargoImportDeclarationDetails";
import { MECargoBramModel } from "./bram/MECargoBramModel";
import {MECargoBramStore } from "./bram/MECargoBramStore";
import {MECargoFidNSacStore} from "./fidNsac/MECargoFidNSacStore";

const getFidAndSacDetails = action((selectedReport:  IMECargoReportInformation) => {
     MECargoImportDeclarationStore.loadImportDecDetails(selectedReport);
});

const getBramDetails = action((declarationId: string, voyageNumber: string, lodgedDate: string, versionNo:number) => {
    MECargoBramStore.loadMECargoBram(declarationId,voyageNumber,lodgedDate,versionNo);
});

const getNewFidNSacDetails = action((selectedReport:  IMECargoReportInformation) => {
    MECargoFidNSacStore.loadImportDecDetails(selectedReport);
});

/*
const getBramDetails = action((selectedFid: IMECargoImportDeclarationDetails) => {
    MECargoBramStore.loadMECargoBram(selectedFid);
});


const selectedImportDeclaration = action((selectedCargoReport?: IMECargoReportDetails) => {
    MECargoImportDeclarationStore.setSelectedCargoReport(selectedCargoReport);
});

const getFidDetails = action((masterBillNbr?: string) => {
    AirCargoFidStore.loadAirCargoFid(masterBillNbr);
});
*/
const getExamsDetails = action((masterBillNbr?: string) => {
    MECargoExamsStore.loadMECargoExams(masterBillNbr);
});

//export { selectedImportDeclaration,  getExamsDetails }
export {  getExamsDetails, getFidAndSacDetails, getBramDetails, getNewFidNSacDetails }