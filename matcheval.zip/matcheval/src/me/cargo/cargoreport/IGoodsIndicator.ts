interface IGoodsIndicator {
        "freightForward":string,
		"lowestBill":string,
		"transhipment":string,
		"transit":string,
		"personnelEffects":string,
		"selfAssessedClearance":string,
		"positiveExamFind":string,
		"perishableGoods":string,
		"reportableDocuments":string,
		"shipperOwned":string,
		"x-rayRequiements":string,
		"hazardousGoods":string,
		"highRiskMovement":string,
		"examPerformed":string,
		"suppressed":string,
		"partShipment":string
}

export {IGoodsIndicator as default, IGoodsIndicator};