import ICargoReport from "./ICargoReport";
import IContactInfomation from "./IGoodsAndVoyageInfo";
import IGoodsIndicator from "./IGoodsIndicator";
import IGoodsAndVoyageInfo from "./IGoodsAndVoyageInfo";

interface IMECargoReportInformation {
	"versionNo":number,
	"matchStatus":string,
	"lastVersion":number,
    "cargoReport": ICargoReport,
    "goodsAndVoyageInfo": IGoodsAndVoyageInfo,
    "contactInformation": IContactInfomation,
    "goodsIndicator": IGoodsIndicator

}
export {IMECargoReportInformation as default, IMECargoReportInformation} ;