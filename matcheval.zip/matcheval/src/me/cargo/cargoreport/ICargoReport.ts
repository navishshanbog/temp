interface ICargoReport {
        "documentType":string,
		"clearanceType":string,
		"houseBill":string,
		"parentBillNo":string,
		"date":string,
		"lineNo":string,
		"lineCount":number, 
		"oceanBill":string,
		"masterBill":string

}

export {ICargoReport as default, ICargoReport} ;