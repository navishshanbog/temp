import { observable, action, computed } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import {IMECargoReportModel} from "./IMECargoReportModel";
import {IMECase, MEDomainType} from "../../IMECase";
import {MECargoReportServiceContext} from "./MECargoReportServiceContext";
import {IMECargoReportDetails} from "./IMECargoReportDetails";
import ListModel from "@twii/common/lib/ListModel";
import { getFidAndSacDetails, getExamsDetails, getNewFidNSacDetails } from "./MECargoReportAction";
import {IMECargoReportInformation} from "./IMECargoReportInformation";
import * as StringUtils from "@twii/common/lib/util/String";
import {IMECargoReportService,IMECargoImportDeclarationRequest, IMECargoReportInformationRequest, IMECargoBramRequest, IMECargoExamsRequest } from "./IMECargoReportService";

class MECargoReportModel implements IMECargoReportModel {
    @observable sync: ISyncModel = new SyncModel();
    @observable items: IMECargoReportInformation;
    @observable versionNo: number = 3;
    private meCase: IMECase;
    private originalMsgId: string = "20130130";
    private lineId: string = "20141210";
    private domainType: string = "Air";
  
   private cargoReportInformationRequest: IMECargoReportInformationRequest;
    @action
    refresh(): Promise<any> {
        const syncId = this.originalMsgId;
        this.sync.syncStart({id: syncId});
        return MECargoReportServiceContext.value.getMECargoReportInformationRequest(this.cargoReportInformationRequest)
        .then(data => {
             this.items = data;
             this.sync.syncEnd();
             this.versionNo = this.items.versionNo;
             console.log("-- returned from DS: report information + version", this.items,this.versionNo);
             getFidAndSacDetails(this.items);
             getExamsDetails(this.originalMsgId);
             //getNewFidNSacDetails(this.items);
        }).catch(error => {
               this.sync.syncError(error);
        });
    }
    @action
    loadCargoReportDetails(meCase: IMECase) : Promise<any> {
         this.meCase = meCase;
         if(this.versionNo > 0 && this.versionNo < 4) {
             if(StringUtils.equalsIgnoreCase(this.meCase.DomainType, MEDomainType.Air)) { 
                 this.domainType = "Air";
                 this.cargoReportInformationRequest = {domainType: this.domainType,originalMsgId: this.originalMsgId, lineId: this.lineId, versionNo: this.versionNo}
             }
             else if(StringUtils.equalsIgnoreCase(this.meCase.DomainType, MEDomainType.Sea)) {  
                 this.domainType = "Sea";
                 this.originalMsgId="20141211";
                 this.cargoReportInformationRequest = {domainType: this.domainType,originalMsgId: this.originalMsgId, lineId: this.lineId, versionNo: this.versionNo}
             }
             else{
                 this.cargoReportInformationRequest = {domainType: this.domainType,originalMsgId: this.originalMsgId, lineId: this.lineId, versionNo: this.versionNo}
             }
        }
        console.log("Request:", this.cargoReportInformationRequest);
        return this.refresh();
    }
    @action
    updateSelectedReportVersion(newVersion:number ) : void {
        if(this.versionNo != newVersion) {
            this.versionNo = newVersion;

        }
        this.loadCargoReportDetails(this.meCase);
    }


}
export { MECargoReportModel }