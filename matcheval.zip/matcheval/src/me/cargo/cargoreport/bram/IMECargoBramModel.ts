import ISyncModel from "@twii/common/lib/ISyncModel";
import {IMECase} from "../../../IMECase";
//import IMECargoBramReport from "./IMECargoBramReport";
import IBramReport from "../../seacargo/bram/IBramReport";
import {IMECargoImportDeclarationDetails} from "../fid/IMECargoImportDeclarationDetails";

interface IMECargoBramModel {
      sync: ISyncModel;
      bramItems: IBramReport;
      versionNo: number;
      selectedReport: IMECargoImportDeclarationDetails; 
      loadMECargoBram(declarationId: string,voyageNumber: string, lodgedDate: string, versionNo:number) : Promise<any>;
      updateSelectedBramVersion(selectedReport:  IMECargoImportDeclarationDetails,version: number) : void;
}

export {IMECargoBramModel };
