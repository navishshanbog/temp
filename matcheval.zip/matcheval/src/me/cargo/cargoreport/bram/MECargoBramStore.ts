import { MECargoBramModel} from "./MECargoBramModel";

const MECargoBramStore = new MECargoBramModel();

export { MECargoBramStore};