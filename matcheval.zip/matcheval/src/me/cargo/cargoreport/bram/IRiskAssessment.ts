interface IRiskAssessment {
    riskType?: string;
    riskScore?: number;

}
export { IRiskAssessment as default, IRiskAssessment};