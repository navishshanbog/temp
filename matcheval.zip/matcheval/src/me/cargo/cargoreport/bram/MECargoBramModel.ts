import { observable, action, computed } from "mobx";
import {IMECargoBramModel} from "./IMECargoBramModel";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import IBramReport from "../../seacargo/bram/IBramReport";
import {MECargoReportServiceContext} from "../MECargoReportServiceContext";
import { IMECargoReportService, IMECargoBramRequest } from "../IMECargoReportService";
import {IMECargoImportDeclarationDetails} from "../fid/IMECargoImportDeclarationDetails";

class MECargoBramModel implements IMECargoBramModel {
	@observable sync: ISyncModel = new SyncModel();
    @observable bramItems: IBramReport = {};
    @observable versionNo: number =2;
    @observable selectedReport: IMECargoImportDeclarationDetails; 
	private consignmentNbr: string;
    private bramRequest: IMECargoBramRequest;
    private bramVersion: number;
    private decId: string;

	@action
    refresh() : Promise<any> {
        const syncId = this.consignmentNbr;
        this.sync.syncStart({id: syncId});

        return MECargoReportServiceContext.value.getMECargoBramRequest(this.bramRequest ) 
            .then(data => {
                this.bramItems = data;
                console.log("--this is from BRAM items", this.bramItems);
                this.sync.syncEnd();
                 
            }).catch(error => {
                this.bramItems = {};
                this.sync.syncError(error);
            });
    }

 @action
    loadMECargoBram(declarationId: string,voyageNumber: string, lodgedDate: string, versionNo:number) : Promise<any> {
        this.bramRequest = {declarationID: declarationId,voyageNumber,lodgedDate,versionNo:versionNo}
        console.log("Bram request: ",this.bramRequest  );
        return this.refresh();
    }

    updateSelectedBramVersion(selectedReport: IMECargoImportDeclarationDetails, nextVersion: number) : void {
          if(this.versionNo != nextVersion) {
            this.versionNo = nextVersion;
            this.selectedReport = selectedReport;
          } 
          this.loadBramVersion(this.selectedReport,this.versionNo );
     }

    @action
    loadBramVersion(selectedReport:  IMECargoImportDeclarationDetails, version:number): Promise<any> {
        this.decId = selectedReport.declarationID;
        this.bramVersion = version;
       // this.bramRequest= {declarationID:this.decId, versionNo:this.bramVersion};
        return null;
    }


}
export { MECargoBramModel }

