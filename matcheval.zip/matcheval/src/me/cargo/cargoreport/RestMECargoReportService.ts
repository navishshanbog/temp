
import axios, { AxiosRequestConfig } from 'axios';
import {IMECargoReportService,IMECargoImportDeclarationRequest, IMECargoReportInformationRequest, IMECargoBramRequest, IMECargoExamsRequest,IMECargoFidNSacRequest } from "./IMECargoReportService";
import AbstractRestDataService from "../../../common/AbstractRestDataService";
import IMECargoReportDetails from "./IMECargoReportDetails";
import IMECargoFidNSacInformation from "./fidNsac/IMECargoFidNSacInformation";
import IMECargoImportDeclarationDetails from "./fid/IMECargoImportDeclarationDetails";
import IMECargoExamsReport from "./exams/IMECargoExamsReport";
import IBramReport from "../seacargo/bram/IBramReport";
import IMECargoReportInformation from "./IMECargoReportInformation";

interface GetCargoReportInformationResponse {
	errors?: any;
	getMatchEvalCargoReportInformation?: IMECargoReportInformation;
}

interface GetCargoImportDeclarationResponse {
    errors?: any;
    getCargoDeclarationReport?: IMECargoImportDeclarationDetails;
}

interface GetCargoFidNSacResponse {
	errors?: any;
	getCargoFidNSacReport?: IMECargoReportInformation[];
}

interface GetMECargoBramResponse {
	errors?: any;
	getMatchEvalCargoReportBRAM?: IBramReport;
}

interface GetMECargoExamsResponse {
	errors?: any;
	getMECargoExamsReport?: IMECargoExamsReport[];
}

class RestMECargoReportService extends AbstractRestDataService implements IMECargoReportService {
   getMECargoReportInformationRequest(request:IMECargoReportInformationRequest) :  Promise<IMECargoReportInformation> {
		const req: AxiosRequestConfig = {
            params: request
        }
        console.log("request param :", req);
        return axios.get(`${this.config.baseUrl}/MECargoService/v1/resources/MatchEvalCargoReportInformation`, req).then((value) => {
            const response = value.data as GetCargoReportInformationResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getMatchEvalCargoReportInformation;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}
    
    getMECargoImportDeclarationRequest(request: IMECargoImportDeclarationRequest) : Promise<IMECargoImportDeclarationDetails> {
        const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/MECargoService/v1/resources/MECargoImportDeclaration`, req).then((value) => {
            const response = value.data as GetCargoImportDeclarationResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getCargoDeclarationReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });  
    }
    //may be use to replace  getMECargoImportDeclarationRequest
    getMECargoFidNSacRequest(request: IMECargoFidNSacRequest) :  Promise<IMECargoFidNSacInformation> {
        const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/MECargoService/v1/resources/MatchEvalCargoFIDnSACInformation`, req).then((value) => {
            const response = value.data as GetCargoFidNSacResponse ;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getCargoFidNSacReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });  
    }
   
     getMECargoBramRequest(request:IMECargoBramRequest) :  Promise<IBramReport> {
		const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/MECargoService/v1/resources/MatchEvalCargoReportBRAM`, req).then((value) => {
            const response = value.data as GetMECargoBramResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getMatchEvalCargoReportBRAM;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}
    getMECargoExamsRequest(request:IMECargoExamsRequest) :  Promise<IMECargoExamsReport[]> {
		const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/MECargoExamsServices/v1/resources/MECargoExamsHistory`, req).then((value) => {
            const response = value.data as GetMECargoExamsResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getMECargoExamsReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}
    

 
}
export { RestMECargoReportService };