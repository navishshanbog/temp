interface IGoodsAndVoyageInfo {
        "goodsDescription":string,
		"grossWeightAndUnit":string,
		"dischargeLocation":string,
		"originalLoadingPort":string,
		"originPort":string,
		"destination":string,
		"withdraw":string,
		"lastOverseasPort":string,
		"packageCountAndType":string,
		"actualArrivalTime":string,
		"estimatedFirstPortArrival":string,
		"vessel":string,
		"Voyage":string,
		"cargoType":string,
		"sealNo":string,
		"arrivalBerth":string,
		"freightMethodOfPayment":string,
		"containerNo":string,
		"containerType":string,
		"goodsOrigin":string,
		"transhipmentNo":string,
		"flight":string,
		"declareValue":string,
		"declareValueCurrency":string
}

export {IGoodsAndVoyageInfo as default, IGoodsAndVoyageInfo} ;