interface ISacDetails {
    declarationId?:string,
    branch?:string,
    brokerageLicenseNo?:string,
    departmentBoxNo?:string
                                                                                
}
export {ISacDetails as default, ISacDetails}