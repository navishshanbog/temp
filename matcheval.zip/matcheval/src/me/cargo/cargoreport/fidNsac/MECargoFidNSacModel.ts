import { observable, action } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import { IMECargoFidNSacInformation } from "./IMECargoFidNSacInformation";
import {IMECargoFidNSacRequest } from "../IMECargoReportService";
import { MECargoReportServiceContext } from "../MECargoReportServiceContext";
import { IMECargoFidNSacModel } from "./IMECargoFidNSacModel";
import {IMECargoReportDetails} from "../IMECargoReportDetails";
//import { IMECargoFidReport } from "./IMECargoFidReport";
import { IMECargoReportInformation } from "../IMECargoReportInformation";
import { getBramDetails } from "../MECargoReportAction";

class MECargoFidNSacModel implements IMECargoFidNSacModel {

     @observable sync: ISyncModel = new SyncModel();
     @observable selectedReport: IMECargoReportInformation; 
     @observable importDecItems: IMECargoFidNSacInformation = {};
     @observable versionNo: number =2;
     @observable importDocType: string = "FID";
    private importDecReportRequest: IMECargoFidNSacRequest;
    private masterBill:string = "";
    private lineId:string = "";
    private documentType:string = "SCR";
    private clearanceType:string = "";
    private importDecVersion:number;

     @action
    refresh(): Promise<any> {
        const syncId = this.masterBill;
        this.sync.syncStart({id: syncId});
         return MECargoReportServiceContext.value.getMECargoFidNSacRequest(this.importDecReportRequest)
             .then((importDecResponse) => {
                 this.importDecItems = importDecResponse;
                 console.log("Returned from Fid N Sac DS", this.importDecItems,this.importDecReportRequest);
                 this.sync.syncEnd();
                // getBramDetails(this.importDecItems.declarationID, this.importDecItems.documentDetails.voyageNumber, this.importDecItems.lodgedDate,this.importDecItems.versionNo);
             }).catch((error) => {
                 if (syncId === this.sync.id) {
                     this.importDecItems = {};
                     this.sync.syncError(error);
                 }
             });
    }

    @action
    loadImportDecDetails(selectedReport:  IMECargoReportInformation): Promise<any> {
        this.selectedReport = selectedReport;
        this.masterBill = selectedReport.cargoReport.masterBill;
        this.documentType = selectedReport.cargoReport.documentType;
        this.clearanceType= selectedReport.cargoReport.clearanceType;
        this.importDocType = this.clearanceType;
        this.lineId = selectedReport.cargoReport.lineNo;
        this.importDecReportRequest= {
                documentType: this.documentType,
                clearanceType: this.clearanceType,
                billNumber:this.masterBill,
                lineId: this.lineId,
                versionNo: this.versionNo
            };
         console.log("Fid N Sac request = ",  this.importDecReportRequest );
            return this.refresh();
           
    }
    @action
    loadImportDecVersion(selectedReport:  IMECargoReportInformation, version:number): Promise<any> {
        this.masterBill = selectedReport.cargoReport.masterBill;
        this.documentType = selectedReport.cargoReport.documentType;
        this.clearanceType= selectedReport.cargoReport.clearanceType;
        this.importDecVersion = version;
        this.importDecReportRequest= {
                documentType: this.documentType,
                clearanceType: this.clearanceType,
                billNumber:this.masterBill,
                lineId: this.lineId,
                versionNo: this.importDecVersion
            };
            this.importDocType = this.clearanceType;
            //console.log("Import dec1 = ", this.importDocType );
            return this.refresh();
    }

     updateSelectedImportDocumentVersion(selectedReport:  IMECargoReportInformation, nextVersion: number) : void {
          if(this.versionNo != nextVersion) {
            this.versionNo = nextVersion;
            this.selectedReport = selectedReport;
          } 
          this.loadImportDecVersion(this.selectedReport,this.versionNo );
     }

  

}

export { MECargoFidNSacModel }