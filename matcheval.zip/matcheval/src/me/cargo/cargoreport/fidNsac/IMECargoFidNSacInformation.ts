import IContactInformation from "./IContactInformation";
import IDeclarationDetails from "./IDeclarationDetails";
import IDocumentDetails from "./IDocumentDetails";
import IGoodsAndVoyageInfo from "./IGoodsAndVoyageInfo";
import ISacDetails from "./ISacDetails";

interface IMECargoFidNSacInformation {
    declarationID?: string;
    versionNo?:number,
    matchStatus?:string,
    lastVersion?:number,
    consolidatedCargoStatus?:string,
    declarationStatus?:string,
    origin?:string,
    lodgedDate?:string,
    goodsDescription?:string,
    modeOfTransport?:string,
    dischargePort?:string,
    arrivateDate?:string,
    deliveryAddress?:string,
    destinationPort?:string,
    grossWeight?:string,
    grossWeightUnit?:string,
    vesselId?:string,          
    vesselName?:string,
    declarationId?:string,      
    status?:string,  
    sacDetails?: ISacDetails,
    goodsAndVoyageInfo?: IGoodsAndVoyageInfo,
    contactInformation?: IContactInformation,
    declarationDetails?: IDeclarationDetails,
    documentDetails?: IDocumentDetails


}

export {IMECargoFidNSacInformation as default, IMECargoFidNSacInformation}