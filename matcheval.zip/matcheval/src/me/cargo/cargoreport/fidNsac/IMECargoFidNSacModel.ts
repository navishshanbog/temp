import ISyncModel from "@twii/common/lib/ISyncModel";
import IMECargoFidNSacInformation from "./IMECargoFidNSacInformation";
import { IMECargoReportInformation } from "../IMECargoReportInformation";

interface IMECargoFidNSacModel {
    sync: ISyncModel;
    importDecItems: IMECargoFidNSacInformation;
    selectedReport: IMECargoReportInformation; 
    versionNo: number;
    importDocType: string;
    refresh(): Promise<any>;
    loadImportDecDetails(selectedReport:  IMECargoReportInformation): Promise<any>;
    loadImportDecVersion(selectedReport:  IMECargoReportInformation, version:number): Promise<any>;
    updateSelectedImportDocumentVersion(selectedReport:  IMECargoReportInformation,version: number) : void;

}

export { IMECargoFidNSacModel }
