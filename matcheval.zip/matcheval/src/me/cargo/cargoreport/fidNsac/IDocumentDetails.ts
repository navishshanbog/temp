interface IDocumentDetails {
    firstArrivalDate?: string,
    loadingPort?: string,
    firstArrivalPort?: string,
    voyageNumber?: string,
    airlinecode?: string
}
export {IDocumentDetails as default, IDocumentDetails}