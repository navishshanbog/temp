interface IContactInformation {
    importerId?:string,
    importerName?:string,
    communicatorRef?:string,
    sacCommnicator?:string,
    supplierName?:string,
    supplierId?:string,
    vendorId?:string,
    importerRef?:string,
    importerAddress?:string,
    contactPhoneNo?:string,
    aqisInspectionLocation?:string,
    broker?:string,
    nomineeBrokerLicenceNo?:string,
    brokerPhone?:string,
    deliveryClientName?:string
}

export {IContactInformation as default, IContactInformation}