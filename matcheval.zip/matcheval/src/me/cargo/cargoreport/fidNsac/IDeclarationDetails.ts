interface IDeclarationDetails {
    quarantineHeld?:string,
    modeOfPayment?:string,
    gstDeclarationResponse?:string,
    paymentStatus?:string,
    modeOfReceipt?:string,
    documentAdviceSent?:string,
    borderHold?:string,
    payUnderProtest?:string,
    cval?:string
}

export {IDeclarationDetails as default, IDeclarationDetails}