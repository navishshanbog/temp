import { MECargoFidNSacModel} from "./MECargoFidNSacModel";

const MECargoFidNSacStore = new MECargoFidNSacModel();

export { MECargoFidNSacStore};


