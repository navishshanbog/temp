interface IGoodsAndVoyageInfo {
    oceanBillOfLanding?:string,
    containerNo?:string,
    houseBillOfLanding?:string,
    houseWayAirBill?:string,
    masterAirWayBill?:string,
    consignmentRef?:string
}

export {IGoodsAndVoyageInfo as default, IGoodsAndVoyageInfo}