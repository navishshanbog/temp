import { MECargoExamsModel} from "./MECargoExamsModel";

const MECargoExamsStore = new MECargoExamsModel();

export { MECargoExamsStore};