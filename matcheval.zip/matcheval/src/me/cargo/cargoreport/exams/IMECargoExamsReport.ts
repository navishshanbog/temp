   interface IMECargoExamsReport {
            cargoType: string,   
				masterBillNbr: string, 
				houseBillNbr: string,  
				examsId: string,     
				examsDate: string,   
				examsStatus: string,  
				entityExaminationRoleType: string,
				billType: string,
				goodDescription: string,
				consigneeName: string,
				consigneeAddress: string,
				consignorName: string,
				consignorAddress: string,
				selectionCriteriaDesc: string,
				PriorityType: string,
				examPort: string,
				findType: string,
				toolUsed: string,
				nbrOfMatch: number,
				nbrOfFinds: number,
				nbrOfExams: number,
				nbrOfSignificantFinds: number
   
}

export {  IMECargoExamsReport as default, IMECargoExamsReport }; 
