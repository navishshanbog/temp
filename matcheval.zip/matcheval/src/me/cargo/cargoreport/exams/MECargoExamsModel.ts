import { observable, action, computed } from "mobx";
import {IMECargoExamsModel} from "./IMECargoExamsModel";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import IMECargoExamsReport from "./IMECargoExamsReport";
//import { MECargoExamsServiceContext } from "./MECargoExamsServiceContext";
import { MECargoReportServiceContext} from "../MECargoReportServiceContext";

class MECargoExamsModel implements IMECargoExamsModel {
	@observable sync: ISyncModel = new SyncModel();
    @observable examsItems: IMECargoExamsReport[] = [];
	private consignmentNbr: string;
	
	@action
    refresh() : Promise<any> {
        const syncId = this.consignmentNbr;
        this.sync.syncStart({id: syncId});

        return MECargoReportServiceContext.value.getMECargoExamsRequest({  masterBillNbr: this.consignmentNbr} ) 
            .then(data => {
                this.examsItems = data;
                this.sync.syncEnd();
                 console.log("--this is from EXAMS items", this.examsItems);
                   console.log("-has Syned: ", this.sync.hasSynced);
            }).catch(error => {
                this.examsItems = [];
                this.sync.syncError(error);
            });
    }

 @action
    loadMECargoExams(requestId: string) : Promise<any> {
        this.consignmentNbr = requestId;
        //console.log("-- response from cargo SAC service ", this.refresh());
        return this.refresh();
    }

}
export { MECargoExamsModel }

