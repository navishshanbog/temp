import ISyncModel from "@twii/common/lib/ISyncModel";
import {IMECase} from "../../../IMECase";
import IMECargoExamsReport from "./IMECargoExamsReport";

interface IMECargoExamsModel {
      sync: ISyncModel;
      examsItems: IMECargoExamsReport[];
      loadMECargoExams(requestID: string) : Promise<any>;
    
}

export {IMECargoExamsModel };
