import { MECargoReportModel} from "./MECargoReportModel";

const MECargoReportStore = new MECargoReportModel();

export { MECargoReportStore};