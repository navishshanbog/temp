//import {IMEAirCargoModel} from "./aircargo/IMEAirCargoModel";
//import {IMESeaCargoModel} from "./seacargo/IMESeaCargoModel";
import {IMECase} from "../IMECase";
import {IMECargoReportModel} from "./cargoreport/IMECargoReportModel";

interface IMECargoModel {
    air?: IMECargoReportModel;
    sea?: IMECargoReportModel;
    load(meCase : IMECase) : Promise<any>;
}

export { IMECargoModel }