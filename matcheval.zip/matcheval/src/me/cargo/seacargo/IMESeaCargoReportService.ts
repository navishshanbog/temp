
import IAirCargoFidReport from "../aircargo/fid/IAirCargoFidReport";
import IAirCargoExamsReport from "../aircargo/exams/IAirCargoExamsReport";
//import IAirCargoBramReport from "../aircargo/bram/IAirCargoBramReport";

interface ISeaCargoFidRequest {
	declarationID: string;
}

interface ISeaCargoExamsRequest {
	masterBillNbr: string;
}

interface ISeaCargoReportService {
	getSeaCargoFid(request: ISeaCargoFidRequest) :  Promise<IAirCargoFidReport[]>;
    //getSeaCargoBram(request: ISeaCargoBramRequest) :  Promise<IAirCargoBramReport[]>;
    getSeaCargoExams(request: ISeaCargoExamsRequest) :  Promise<IAirCargoExamsReport[]>;
    
}

export {ISeaCargoReportService,
        ISeaCargoFidRequest ,
        ISeaCargoExamsRequest};