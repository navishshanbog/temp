
import axios, { AxiosRequestConfig } from 'axios';
import {ISeaCargoReportService,
        ISeaCargoFidRequest ,
        ISeaCargoExamsRequest} from "./IMESeaCargoReportService";
import AbstractRestDataService from "../../../common/AbstractRestDataService";
import IAirCargoFidReport from "../aircargo/fid/IAirCargoFidReport";
import IAirCargoExamsReport from "../aircargo/exams/IAirCargoExamsReport";
//import IAirCargoBramReport from "../aircargo/bram/IAirCargoBramReport";

interface GetSeaCargoExamsResponse {
	errors?: any;
	getSeaCargoExamsReport?: IAirCargoExamsReport[];
}

interface GetSeaCargoFidResponse {
	errors?: any;
	getSeaCargoFidReport?: IAirCargoFidReport[];
}

class RestMESeaCargoReportService extends AbstractRestDataService implements ISeaCargoReportService {
    getSeaCargoFid(request:ISeaCargoFidRequest) :  Promise<IAirCargoFidReport[]> {
		const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/AirCargoSacServices/v1/resources/AirCargoSAC`, req).then((value) => {
            const response = value.data as GetSeaCargoFidResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getSeaCargoFidReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}
    
    getSeaCargoExams(request:ISeaCargoExamsRequest) :  Promise<IAirCargoExamsReport[]> {
		const req: AxiosRequestConfig = {
            params: request
        }
        return axios.get(`${this.config.baseUrl}/AirCargoExamsServices/v1/resources/AirCargoEXAMS`, req).then((value) => {
            const response = value.data as GetSeaCargoExamsResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getSeaCargoExamsReport;
        }).catch((error) => {
            if(error.response && error.response.status !== 404) {
                throw error;
            }
        });
	}
   


}
export { RestMESeaCargoReportService };