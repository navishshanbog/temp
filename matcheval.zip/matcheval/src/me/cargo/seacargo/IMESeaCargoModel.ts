import ISyncModel from "@twii/common/lib/ISyncModel";
import {IMECase} from "../../IMECase";
import {ISeaCargoActivityDetail} from "@twii/entity/lib/cargo/sea/ISeaCargoActivityDetail";

interface IMESeaCargoModel {
    sync: ISyncModel;
    items: ISeaCargoActivityDetail[];
    loadSeaCargoDetails(meCase : IMECase): Promise<any>;

}

export { IMESeaCargoModel };