import { observable, action, computed } from "mobx";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import {IMESeaCargoModel} from "./IMESeaCargoModel";
import {IMECase} from "../../IMECase";
import SeaCargoServiceContext from "@twii/entity/lib/cargo/sea/SeaCargoServiceContext";
import {ISeaCargoActivityDetail} from "@twii/entity/lib/cargo/sea/ISeaCargoActivityDetail";
import { getFidDetails, getExamsDetails } from "../aircargo/MEAirCargoAction";

class MESeaCargoModel implements IMESeaCargoModel {
    @observable sync: ISyncModel = new SyncModel();
    @observable items: ISeaCargoActivityDetail[] = [];
    private consignmentNbr: string;

    @action
    refresh(): Promise<any> {
        const syncId = this.consignmentNbr;
        this.sync.syncStart({id: syncId});
        return SeaCargoServiceContext.value.getSeaCargoActivityDetails({parentId: "", oceanBillNbr: this.consignmentNbr})
        .then(data => {
            this.items = data;
             console.log("-- items", this.items);
             getFidDetails(this.consignmentNbr);
             getExamsDetails(this.consignmentNbr);
             this.sync.syncEnd();
        }).catch(error => {
                this.items = [];
                this.sync.syncError(error);
        });
    }
    @action
    loadSeaCargoDetails(meCase: IMECase) : Promise<any> {
        this.consignmentNbr = meCase.consignmentNbr;
        console.log("-- response from cargo service ", this.refresh());
        return null;
    }

}
export { MESeaCargoModel }