import IBramScoreDetails from "./IBramScoreDetails";
import IScoreAndMatchDetails from "./IScoreAndMatchDetails";

interface IBramReport {
    lastVersion?: number,
    bramScore?: IBramScoreDetails,
    scoreAndMatchDetails?: IScoreAndMatchDetails
}

export {IBramReport as default, IBramReport};