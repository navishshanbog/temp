
interface ITypeNScore {
    type: string;
    score: string;
}
export {ITypeNScore as default, ITypeNScore};