import ITypeNScore from "./ITypeNScore";

interface IScoreAndMatchDetails {
    overallScore?:string,
    actionOrOutcome?:string,
	matchStatus?:string,
	riskTypeAndScore?:ITypeNScore[],
	matchValue?:string[]

}

export { IScoreAndMatchDetails as default, IScoreAndMatchDetails};
