interface IBramScoreDetails {
    declarationId?:string,
	originalLodgeDate?:string,
	documentType?:string,
	vesselId?:string,
	vesselName?:string,
	importerName?:string,
	brokerName?:string,
	noOfImportForImporter?:string,
	dateOfLastImportationForImporter?:string,
	noOfImportsFromSupplier?:string,
	noOfBrokersUsed?:string,
	tranportType?:string,
	importerABN?:string,
	deliveryClientName?:string,
	noOfImportsWithinLast12months?:string,
	dateOfIssueOfImportABN?:string,
	noOfDifferentsuppliers?:string,
	noOfDeclarationsLodgedByBroker?:string
}

export { IBramScoreDetails as default, IBramScoreDetails };