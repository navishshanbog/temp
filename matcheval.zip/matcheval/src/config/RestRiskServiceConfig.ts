import IUrlConfig from "@twii/common/lib/config/IUrlConfig";

const RestRiskServiceConfig : IUrlConfig = {
    baseUrl: "/IntelTraveller"
};

export { RestRiskServiceConfig as default, RestRiskServiceConlfig };