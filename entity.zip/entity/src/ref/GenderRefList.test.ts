import GenderRefList from "./GenderRefList";

describe("GenderRefList", () => {
    test("all", () => {
        GenderRefList.items.forEach((item) => {
            expect(GenderRefList.getItemByKey(item.key).text === item.text);
        });
    });
});