import CodeSet from "@twii/common/lib/CodeSet";

const immigrationDirectiveCd = new CodeSet({
    "E": "Enter",
    "R": "Refer to Immigration"
});

export { immigrationDirectiveCd as default, immigrationDirectiveCd };