import RefListModel from "@twii/common/lib/RefListModel";

const PersonOrgRefList = new RefListModel([
    {
        key: "Y",
        text: "Yes"
    },
    {
        key: "N",
        text: "No"
    }
]);

export { PersonOrgRefList as default, PersonOrgRefList };