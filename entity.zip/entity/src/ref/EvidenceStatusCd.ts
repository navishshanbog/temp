import CodeSet from "@twii/common/lib/CodeSet";

const evidenceStatusCd = new CodeSet({
    "C": "Current",
    "V": "Void"
});

export { evidenceStatusCd as default, evidenceStatusCd };