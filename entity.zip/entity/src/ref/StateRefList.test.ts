import StateRefList from "./StateRefList";

describe("StateRefList", () => {
    test("all", () => {
        StateRefList.items.forEach((item) => {
            expect(StateRefList.getItemByKey(item.key).text === item.text);
        });
    });
});