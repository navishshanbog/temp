const nameGenderCd : { [key: string] : string } = {
    "M": "Male",
    "F": "Female"
}

export { nameGenderCd as default, nameGenderCd };