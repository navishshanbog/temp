import CodeSet from "@twii/common/lib/CodeSet";

const entriesAllowedCd = new CodeSet({
    "M": "Many"
});

export { entriesAllowedCd as default, entriesAllowedCd };