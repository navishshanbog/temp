import StreetTypeRefList from "./StreetTypeRefList";

describe("StateRefList", () => {
    test("all", () => {
        StreetTypeRefList.items.forEach((item) => {
            expect(StreetTypeRefList.getItemByKey(item.key).text === item.text);
        });
    });
});