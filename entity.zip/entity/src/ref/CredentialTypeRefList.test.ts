import CredentialTypeRefList from "./CredentialTypeRefList";

describe("CredentialTypeRefList", () => {
    test("all", () => {
        CredentialTypeRefList.items.forEach((item) => {
            expect(CredentialTypeRefList.getItemByKey(item.key).text === item.text);
        });
    });
});