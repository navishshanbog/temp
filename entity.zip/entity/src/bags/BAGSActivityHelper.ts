import { action } from "mobx";
import { IActivityFilterProps } from "@twii/common/lib/IActivityFilterProps";
import { IEntityBAGSActivity } from "./IEntityBAGSActivity";
import { ISortProps } from "@twii/common/lib/ISortProps";
import * as StringUtils from "@twii/common/lib/util/String";
import * as SearchUtils from "@twii/common/lib/util/Search";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as moment from "moment";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import { BAGSActivityColumns, CraftMovementDate } from "./component/BAGSActivityColumns";
import { BAGSServiceContext } from "./BAGSServiceContext";
import { IBAGSActivitiesGetRequest } from "./IBAGSService";
import { IMasterEntityModel } from "../entity/IMasterEntityModel";
import { IMasterEntitySourceModel } from "../entity/IMasterEntitySourceModel";
import { Data as DateDataFormats } from "@twii/common/lib/DateFormats";
import { MasterEntitySourceListModel } from "../entity/MasterEntitySourceListModel";
import * as BAGSConstants from "./BAGSConstants";
import { getForMasterEntity } from "../entity/MasterEntitySourceServiceUtils";

const textFilterItemImpl = (item: IEntityBAGSActivity, text: string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, BAGSActivityColumns), text);
};

const textFilterItem = (item: IEntityBAGSActivity, text: string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items: IEntityBAGSActivity[], text: string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IEntityBAGSActivity, test: moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.craftMovementDate), test);
};

const toFilterItem = (item: IEntityBAGSActivity, test: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.craftMovementDate), test);
};

const rangeFilterItem = (item: IEntityBAGSActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items: IEntityBAGSActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items: IEntityBAGSActivity[], activityFilter: IActivityFilterProps) => {
    return activityFilter ? rangeFilter(textFilter(items, activityFilter.filterText), activityFilter.filterFromDate, activityFilter.filterToDate) : items;
};

const toSortValue = (item: IEntityBAGSActivity, field: string) => {
    if (item) {
        if (field === CraftMovementDate.fieldName) {
            return DateUtils.dateFromDataText(item.craftMovementDate);
        }
        return item[field];
    }
};

const compare = (a: IEntityBAGSActivity, b: IEntityBAGSActivity, sort: ISortProps) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if (sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IEntityBAGSActivity[], sort: ISortProps) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const getByCompositeId = (compositeId: string, source: IMasterEntitySourceModel, entity: IMasterEntityModel): Promise<IEntityBAGSActivity[]> => {
    const compositeIdComponents = compositeId.split('|');
    // super poo
    const req: IBAGSActivitiesGetRequest = {
        travelDocNbr: compositeIdComponents[0],
        travelDocCntryCode: compositeIdComponents[1],
        birthDate: moment(compositeIdComponents[2], DateDataFormats.key, true).format(DateDataFormats.default),
        sexCode: compositeIdComponents[3]
    };
    return BAGSServiceContext.value.getBAGSActivities(req).then(r => {
        return r ? r.map((i, index) => {
            i["key"] = i.travelDocCntryCode + "_" + index;
            return Object.assign({}, i, { source: source, entity: entity });
        }) : [];
    });
}

const getEntityActivities = (entity: IMasterEntityModel): Promise<IEntityBAGSActivity[]> => {
    return getForMasterEntity(entity, BAGSConstants.sourceSystemCode, getByCompositeId);
};

const getEntityActivityList = (entity: IMasterEntityModel) => {
    return entity.getState("bagsActivityList", () => {
        const r = new MasterEntitySourceListModel(entity, BAGSConstants.sourceSystemCode, getEntityActivities);
        r.setFilterHandler(filter);
        r.setSortHandler(sort);
        r.load();
        return r;
    });
};

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getByCompositeId,
    getEntityActivities,
    getEntityActivityList
};