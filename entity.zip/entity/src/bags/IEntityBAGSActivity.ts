import { IBAGSActivity } from "./IBAGSActivity";
import { IEntityActivity } from "../entity/IEntityActivity";

interface IEntityBAGSActivity extends IEntityActivity, IBAGSActivity {}

export { IEntityBAGSActivity }