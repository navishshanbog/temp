import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const BAGSActivityViewPrefsStore = new ViewPreferencesModel("bagsActivity");

export { BAGSActivityViewPrefsStore as default, BAGSActivityViewPrefsStore }