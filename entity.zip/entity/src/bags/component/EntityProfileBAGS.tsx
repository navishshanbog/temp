import * as React from "react";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { buildSectionHeader, buildTable, buildComments } from "../../entity/profile/EntityProfileDocumentHelper";
import BAGSActivityColumns from "./BAGSActivityColumns";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileBAGSApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="bags-activities" title="BAGS Activities">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={BAGSActivityColumns} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const BAGSActivityDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("BAGS Activities", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, BAGSActivityColumns, doc);
    buildComments(group.comments, doc);
};

export { EntityProfileBAGSApp, EntityProfileBAGSApp as default, BAGSActivityDocumentHandler }