import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { Sync } from "@twii/common/lib/component/Sync";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import { IEntityBAGSActivity } from "../IEntityBAGSActivity";
import BAGSActivityDetailsList from "./BAGSActivityDetailsList";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import BAGSActivityViewPrefsStore from "../BAGSActivityViewPrefsStore";
import BAGSActivityColumns from "./BAGSActivityColumns";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { AppView } from "@twii/common/lib/component/AppView";
import { observer } from "mobx-react";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { getEntityActivityList } from "../BAGSActivityHelper";

interface IBAGSActivityListProps {
    list: IMasterEntitySourceListModel<IEntityBAGSActivity>;
}

@observer
class BAGSActivityListCommandBar extends React.Component<IBAGSActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "BAGS Activities" }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(BAGSActivityViewPrefsStore, BAGSActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class BAGSActivityList extends React.Component<IBAGSActivityListProps, any> {
    private _onRenderMenu = () => {
        return <BAGSActivityListCommandBar {...this.props} />
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <BAGSActivityDetailsList {...this.props} viewPreferences={BAGSActivityViewPrefsStore} />
            </AppView>
        );
    }
}

class BAGSActivityListContainer extends React.Component<IBAGSActivityListProps, any> {
    private _onRenderDone = () => {
        return <BAGSActivityList {...this.props} />;
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} />;
    }
}

class BAGSActivityListApp extends EntitySourceApp {
    protected _onRenderSource = (props) => {
        return <BAGSActivityListContainer list={getEntityActivityList(props.masterEntity)} />;
    }
}

export {
    BAGSActivityList,
    BAGSActivityListContainer,
    IBAGSActivityListProps,
    BAGSActivityListApp,
    BAGSActivityListApp as default
}