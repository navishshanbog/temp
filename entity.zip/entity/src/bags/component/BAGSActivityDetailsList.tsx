import * as React from "react";
import { IEntityBAGSActivity } from "../IEntityBAGSActivity";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import BAGSActivityColumns from "./BAGSActivityColumns";
import MasterEntitySourceDetailsList from "../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";

interface IBAGSActivityDetailsListProps {
    list: IMasterEntitySourceListModel<IEntityBAGSActivity>;
    viewPreferences?: IViewPreferencesModel;
}

class BAGSActivityDetailsList extends React.Component<IBAGSActivityDetailsListProps, any> {
    render() {
        return <MasterEntitySourceDetailsList
                        columns={BAGSActivityColumns}
                        list={this.props.list}
                        typeLabel="BAGS Activities"
                        itemType="activity"
                        viewPreferences={this.props.viewPreferences} />;
    }
}

export { BAGSActivityDetailsList as default, BAGSActivityDetailsList, IBAGSActivityDetailsListProps }