import MasterEntityModel from "../entity/MasterEntityModel";
import BAGSServiceContext from "./BAGSServiceContext";
import MockBAGSService from "./MockBAGSService";
import * as BAGSConstants from "./BAGSConstants";
import * as DateUtils from "@twii/common/lib/util/Date";
import { getEntityActivityList } from "./BAGSActivityHelper";
import { toPromise } from "@twii/common/lib/SyncUtils";

describe("Master Entity BAGS Activity List Model", () => {
    test("test set master entity", async () => {
        const e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: BAGSConstants.sourceSystemCode,
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            }
                        }
                    ]
                }
            ]
        });

        expect(e.sourceCodes.length).toBe(1);
        expect(e.sourceCodes[0]).toBe(BAGSConstants.sourceSystemCode);

        const bagsService = new MockBAGSService();
        bagsService.getBAGSActivitiesResponse = [
            {
                "travelDocNbr":"1",
                "travelDocCntryCode":"AUS",
                "birthDate":"1988-01-21",
                "sexCode":"M",
                "craftMovementNumber":"JQ58",
                "craftMovementDate":"2013-12-04",
                "portCode":"PCA",
                "directionCode":"I",
                "targetingMthdType":"A",
                "modeOfEntryType":"BACKOFHALL",
                "findMethodType":"",
                "bagLocationType":"",
                "examinationResultType":"",
                "concealmentMthdType":"",
                "travellerType":"PASSENGER ",
                "bagsExamSeverityCategory":"NO UNDECLARED ITEMS AREFOUND",
                "resultType":"",
                "outcomeType":""
            },
            {
                "travelDocNbr":"2",
                "travelDocCntryCode":"AUS",
                "birthDate":"1988-01-21",
                "sexCode":"M",
                "craftMovementNumber":"JQ59",
                "craftMovementDate":"2013-09-11",
                "portCode":"PCB",
                "directionCode":"I",
                "targetingMthdType":"B",
                "modeOfEntryType":"BACKOFHALL",
                "findMethodType":"",
                "bagLocationType":"",
                "examinationResultType":"",
                "concealmentMthdType":"",
                "travellerType":"JUMBO ",
                "bagsExamSeverityCategory":"NO UNDECLARED ITEMS AREFOUND",
                "resultType":"",
                "outcomeType":""
            }
        ]
        bagsService.recordRequests = true;

        BAGSServiceContext.value = bagsService;

        expect(BAGSServiceContext.value).toBe(bagsService);

        const activityListModel = getEntityActivityList(e);

        expect(activityListModel.entity).toBe(e);

        await toPromise(activityListModel.sync);

        expect(bagsService.getBAGSActivitiesRequests.length).toBe(1);

        const r = bagsService.getBAGSActivitiesRequests[0];

        expect(r.travelDocNbr).toBe("N7107645");
        expect(r.travelDocCntryCode).toBe("AUS");
        expect(r.birthDate).toBe("1988-01-21");
        expect(r.sexCode).toBe("M");

        expect(activityListModel.items.length).toBe(bagsService.getBAGSActivitiesResponse.length);

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply a filter
        e.activityFilter.setFilterText("JQ59");

        expect(activityListModel.itemsView.length).toBe(1);
        expect(activityListModel.itemsView[0].travelDocNbr).toBe("2");

        activityListModel.filter.setFilterText("noChance");

        expect(activityListModel.itemsView.length).toBe(0);

        e.activityFilter.clear();
        activityListModel.filter.clear();

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply master entity and list filter
        e.activityFilter.setFilterText("BACKOFHALL");

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        activityListModel.filter.setFilterText("JQ59");

        expect(activityListModel.itemsView.length).toBe(1);
        expect(activityListModel.itemsView[0].travelDocNbr).toBe("2");

        e.activityFilter.clear();
        activityListModel.filter.clear();

        // range filter tests
        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2013-09-10"));

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2013-09-11"));

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2013-09-12"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].travelDocNbr).toBe("1");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2013-12-05"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].travelDocNbr).toBe("1");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2013-12-04"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].travelDocNbr).toBe("1");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2013-12-03"));

        expect(activityListModel.itemsView.length).toBe(0);
    });

});