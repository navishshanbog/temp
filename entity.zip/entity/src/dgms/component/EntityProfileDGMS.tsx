import * as React from "react";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { buildSectionHeader, buildTable, buildComments } from "../../entity/profile/EntityProfileDocumentHelper";
import DGMSActivityColumns from "./DGMSActivityColumns";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileDGMSApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="dgms-activities" title="DGMS Activities">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={DGMSActivityColumns} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const DGMSActivityDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("DGMS Activities", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, DGMSActivityColumns, doc);
    buildComments(group.comments, doc);
};

export { EntityProfileDGMSApp as default, EntityProfileDGMSApp, DGMSActivityDocumentHandler }