import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IDGMSActivity from "../IDGMSActivity";
import DGMSActivityDetailsList from "./DGMSActivityDetailsList";
import DGMSActivityColumns from "./DGMSActivityColumns";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import DGMSActivityViewPrefsStore from "../DGMSActivityViewPrefsStore";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { getEntityActivityList } from "../DGMSActivityHelper";

interface IDGMSActivityListProps {
    list: IMasterEntitySourceListModel<IDGMSActivity>;
}

@observer
class DGMSActivityListCommandBar extends React.Component<IDGMSActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "DGMS Activities" }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(DGMSActivityViewPrefsStore, DGMSActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class DGMSActivityList extends React.Component<IDGMSActivityListProps, any> {
    private _onRenderMenu = () => {
        return <DGMSActivityListCommandBar {...this.props} />;
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <DGMSActivityDetailsList {...this.props} viewPreferences={DGMSActivityViewPrefsStore} />
            </AppView>
        )
    }
}

class DGMSActivityListContainer extends React.Component<IDGMSActivityListProps, any> {
    private _onRenderDone = () => {
        return <DGMSActivityList {...this.props} />
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} />
    }
}

class DGMSActivityListApp extends EntitySourceApp {
    protected _onRenderSource = (props) => {
        return <DGMSActivityListContainer list={getEntityActivityList(props.masterEntity)} />
    };
}

export {
    DGMSActivityList,
    DGMSActivityListContainer,
    IDGMSActivityListProps,
    DGMSActivityListApp,
    DGMSActivityListApp as default
}