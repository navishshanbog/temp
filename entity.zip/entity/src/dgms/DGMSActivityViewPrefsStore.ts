import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const DGMSActivityViewPrefsStore = new ViewPreferencesModel("dgmsActivity");

export { DGMSActivityViewPrefsStore as default, DGMSActivityViewPrefsStore }