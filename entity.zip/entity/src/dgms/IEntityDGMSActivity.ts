import { IEntityActivity } from "../entity/IEntityActivity";
import { IDGMSActivity } from "./IDGMSActivity";

interface IEntityDGMSActivity extends IEntityActivity, IDGMSActivity {}

export { IEntityDGMSActivity }