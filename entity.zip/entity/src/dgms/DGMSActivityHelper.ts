import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import { IEntityDGMSActivity } from "./IEntityDGMSActivity";
import ISort from "@twii/common/lib/ISortProps";
import IListResult from "@twii/common/lib/IListResult";
import IListModel from "@twii/common/lib/IListModel";
import * as StringUtils from "@twii/common/lib/util/String";
import * as SearchUtils from "@twii/common/lib/util/Search";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as moment from "moment";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import { DGMSActivityColumns, DateDetected } from "./component/DGMSActivityColumns";
import DGMSServiceContext from "./DGMSServiceContext";
import * as DGMSConstants from "./DGMSConstants";
import IActivityListModel from "@twii/common/lib/IActivityListModel";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import { IMasterEntityModel } from "../entity/IMasterEntityModel";
import { getForMasterEntity } from "../entity/MasterEntitySourceServiceUtils";
import IMasterEntitySourceModel from "../entity/IMasterEntitySourceModel";

const textFilterItemImpl = (item: IEntityDGMSActivity, text : string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, DGMSActivityColumns).join(""), text);
};

const textFilterItem = (item: IEntityDGMSActivity, text : string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items : IEntityDGMSActivity[], text : string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IEntityDGMSActivity, from: moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.dateDetected), from);
};

const toFilterItem = (item: IEntityDGMSActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.dateDetected), to);
};

const rangeFilterItem = (item: IEntityDGMSActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items : IEntityDGMSActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items : IEntityDGMSActivity[], props : IActivityFilterProps) => {
    return props ? rangeFilter(textFilter(items, props.filterText), props.filterFromDate, props.filterToDate) : items;
};

const toSortValue = (item: IEntityDGMSActivity, field: string) => {
    if(item) {
        if(field === DateDetected.fieldName) {
            return DateUtils.dateFromDataText(item.dateDetected);
        }
        return item[field];
    }
};

const compare = (a : IEntityDGMSActivity, b : IEntityDGMSActivity, sort : ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IEntityDGMSActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const getActivityiesByParentId = (parentId : string, source : IMasterEntitySourceModel, entity : IMasterEntityModel) : Promise<IEntityDGMSActivity[]> => {
    return DGMSServiceContext.value.getDGMSActivities({ parentId: parentId }).then(r => {
        return r ? r.map((i, index) => {
            i["key"] = i.clientId + "_" + index;
            return Object.assign({}, i, { source: source, entity: entity });
        }) : [];
    });
}

const getEntityActivities = (entity : IMasterEntityModel) : Promise<IEntityDGMSActivity[]> =>  {
    return getForMasterEntity(entity, DGMSConstants.sourceSystemCode, getActivityiesByParentId);
};

const getEntityActivityList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityDGMSActivity> => {
    return entity.getState("dgmsActivityList", () => {
        const r = new MasterEntitySourceListModel(entity, DGMSConstants.sourceSystemCode, getEntityActivities);
        r.setFilterHandler(filter);
        r.setSortHandler(sort);
        r.load();
        return r;
    });
};

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getActivityiesByParentId,
    getEntityActivities,
    getEntityActivityList
};