import MasterEntityModel from "../entity/MasterEntityModel";
import DGMSServiceContext from "./DGMSServiceContext";
import MockDGMSService from "./MockDGMSService";
import * as DGMSConstants from "./DGMSConstants";
import * as DateUtils from "@twii/common/lib/util/Date";
import { getEntityActivityList } from "./DGMSActivityHelper";
import { toPromise } from "@twii/common/lib/SyncUtils";

describe("Master Entity DGMS Activity List Model", () => {
    test("test set master entity", async () => {
        const e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: DGMSConstants.sourceSystemCode,
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "1"
                            }
                        }
                    ]
                }
            ]
        });

        expect(e.sourceCodes.length).toBe(1);
        expect(e.sourceCodes[0]).toBe(DGMSConstants.sourceSystemCode);

        const dgmsService = new MockDGMSService();
        dgmsService.getDGMSActivitiesResponse = [
            {
                "dgmsNumber":"702878",
                "clientId":"677034",
                "dealerId":"",
                "startTimestamp":"2015-07-19 09:17:34.336000",
                "dateDetected":"2015-07-19",
                "isDeclared":"N",
                "detentionNumber":"",
                "detentionDescription":"Other Detention",
                "seizureDescription":"Customs Seizure",
                "detentionModeDescription":"Officer's suspicion",
                "modeOfConcealment":"",
                "modeOfEntry":"AIR AO",
                "port":"Parcels Post Vic",
                "dealer":"",
                "goodsDeclarationDescription":"NOT CLEARLY WRITTEN ON DECLARATION"
            },
            {
                "dgmsNumber":"695675",
                "clientId":"677034",
                "dealerId":"",
                "startTimestamp":"2015-06-16 07:28:08.548000",
                "dateDetected":"2015-06-16",
                "isDeclared":"N",
                "detentionNumber":"",
                "detentionDescription":"Other Detention",
                "seizureDescription":"Customs Seizure",
                "detentionModeDescription":"Located by mass screen x-ray",
                "modeOfConcealment":"",
                "modeOfEntry":"AIR AO",
                "port":"Parcels Post NSW",
                "dealer":"",
                "goodsDeclarationDescription":"NIE"
            }
        ]
        dgmsService.recordRequests = true;

        DGMSServiceContext.value = dgmsService;

        expect(DGMSServiceContext.value).toBe(dgmsService);
        
        const activityListModel = getEntityActivityList(e);
        expect(activityListModel.entity).toBe(e);

        await toPromise(activityListModel.sync);

        expect(dgmsService.getDGMSActivitiesRequests.length).toBe(1);

        const r = dgmsService.getDGMSActivitiesRequests[0];

        expect(r.parentId).toBe("1");

        expect(activityListModel.items.length).toBe(dgmsService.getDGMSActivitiesResponse.length);

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply a filter
        e.activityFilter.setFilterText("Parcels Post Vic");

        expect(activityListModel.itemsView.length).toBe(1);
        expect(activityListModel.itemsView[0].dgmsNumber).toBe("702878");

        activityListModel.filter.setFilterText("noChance");

        expect(activityListModel.itemsView.length).toBe(0);

        e.activityFilter.clear();
        activityListModel.filter.clear();

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply master entity and list filter
        e.activityFilter.setFilterText("AIR AO");

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        activityListModel.filter.setFilterText("Parcels Post NSW");

        expect(activityListModel.itemsView.length).toBe(1);
        expect(activityListModel.itemsView[0].dgmsNumber).toBe("695675");

        e.activityFilter.clear();
        activityListModel.filter.clear();

        // range filter tests
        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2015-06-15"));

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2015-06-16"));

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2015-06-17"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].dgmsNumber).toBe("702878");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2015-07-20"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].dgmsNumber).toBe("702878");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2015-07-19"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].dgmsNumber).toBe("702878");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2015-07-18"));

        expect(activityListModel.itemsView.length).toBe(0);
    });

});