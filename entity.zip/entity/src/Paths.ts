interface IPaths {
    basePath : string;
    settings() : string;
    help() : string;
    newSearch() : string;
    newSearchEntitySummaryValues(entityId : string | number) : string;
    newSearchDetails(entityId : string | number) : string;
    search() : string;
    searchResult() : string;
    profile() : string;
    entity(entityId : string | number) : string;
    entitySummary(entityId : string | number) : string;
    entitySources(entityId : string | number) : string;
    entitySource(entityId : string | number, sourceSystemCode : string) : string;
    entitySourceAttributes(entityId : string | number, sourceSystemCode : string) : string;
    entitySourceActivities(entityId : string | number, sourceSystemCode : string, activitiesPath?: string) : string;
    airCargoDetails(parentId : string) : string;
    seaCargoDetails(parentId : string) : string;
    iataAgencyDetails() : string;
    abrDetails(abn : string) : string;
    iatMovementDetails() : string;
    iatAliases() : string;
    iatFlightLists() : string;
    iatVisa(visaIdentifyingNumber : string) : string;
    iatPassport(travelDocDeptCountryCode : string, travelDocumentId : string) : string;
    visaApplicationClients(applicationId :  string) :  string;
}

class Paths implements IPaths {
    private _basePath : string;
    constructor(basePath?: string) {
        this._basePath = basePath;
    }
    get basePath() {
        return this._basePath || "";
    }
    settings() {
        return `${this.basePath}/settings`;
    }
    help() {
        return `${this.basePath}/help`;
    }
    newSearch() {
        return `${this.basePath}/search/new`;
    }
    newSearchEntitySummaryValues(entityId : string | number) {
        return `${this.basePath}/search/new/${encodeURIComponent(String(entityId))}/values`;
    }
    newSearchDetails(entityId : string | number) {
        return `${this.basePath}/search/new/${encodeURIComponent(String(entityId))}`;
    }
    search() {
        return `${this.basePath}/search`;
    }
    searchResult() {
        return `${this.basePath}/search/result`;
    }
    profile() {
        return `${this.basePath}/profile`;
    }
    entity(entityId : string | number) {
        return `${this.basePath}/${encodeURIComponent(String(entityId))}`;
    }
    entitySummary(entityId : string | number) {
        return `${this.entity(entityId)}/summary`;
    }
    entitySources(entityId : string | number) {
        return `${this.entity(entityId)}/sources`;
    }
    entitySource(entityId : string | number, sourceSystemCode : string) {
        return `${this.entitySources(entityId)}/${encodeURIComponent(sourceSystemCode)}`;
    }
    entitySourceAttributes(entityId : string | number, sourceSystemCode : string) {
        return `${this.entitySource(entityId, sourceSystemCode)}/attributes`;
    }
    entitySourceActivities(entityId : string | number, sourceSystemCode : string, activitiesPath: string = "/activities") {
        return `${this.entitySource(entityId, sourceSystemCode)}${activitiesPath}`;
    }
    airCargoDetails(clientInstanceId : string) {
        return `${this.basePath}/ICS/air/${encodeURIComponent(clientInstanceId)}`;
    }
    seaCargoDetails(clientInstanceId : string) {
        return `${this.basePath}/ICS/sea/${encodeURIComponent(clientInstanceId)}`;
    }
    iataAgencyDetails() {
        return `${this.basePath}/IATA`;
    }
    abrDetails(abn : string) {
        return `${this.basePath}/ABR/${encodeURIComponent(abn)}`;
    }
    iatMovementDetails() {
        return `${this.basePath}/IAT/movement`;
    }
    iatAliases() {
        return `${this.basePath}/IAT/aliases`;
    }
    iatFlightLists() {
        return `${this.basePath}/IAT/flightLists`;
    }
    iatVisa(visaIdentifyingNumber: string) {
        return `${this.basePath}/IAT/visas/${encodeURIComponent(visaIdentifyingNumber)}`;
    }
    iatPassport(travelDocDeptCountryCode : string, travelDocumentId: string) {
        return `${this.basePath}/IAT/passports/${encodeURIComponent(travelDocDeptCountryCode)}/${encodeURIComponent(travelDocumentId)}`;
    }
    visaApplicationClients(applicationId :  string) {
        return `${this.basePath}/ICSE/visa/applications/${encodeURIComponent(applicationId)}/clients`;
    }
}

export { IPaths, Paths }