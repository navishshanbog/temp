const sourceSystemCode = "ETA";

export { sourceSystemCode }