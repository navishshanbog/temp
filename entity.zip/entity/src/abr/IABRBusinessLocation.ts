interface IABRBusinessLocation {
    pid?: string | number;
    locnTypCd?: string;
    locnStrtDt?: string;
    busLocnAddrLn1?: string;
    busLocnAddrLn2?: string;
    busLocnSbrb?: string;
    busLocnStt?: string;
    busLocnPc?: string;
    busLocnCntryCd?: string;
    busLocnDpid?: string;
    busLocnLtd?: string;
    busLocnLngtd?: string;
    busLocnMshBlk?: string;
    busLocnGnafPid?: string;
    busLocnPosnlRlblty?: string;
    busLocnPhAreaCd?: string;
    busLocnPhNum?: string;
    busLocnPhAreaCdMbl?: string;
    busLocnPhNumMbl?: string;
    busLocnEml?: string;
    busLocnIndyClsn?: string;
    busLocnIndyClsnDescn?: string;
}

export { IABRBusinessLocation }
