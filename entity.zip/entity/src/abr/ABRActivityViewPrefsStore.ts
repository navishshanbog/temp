import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const ABRActivityViewPrefsStore = new ViewPreferencesModel("abrActivity");

export { ABRActivityViewPrefsStore as default, ABRActivityViewPrefsStore }