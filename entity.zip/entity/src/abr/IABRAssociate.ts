interface IABRAssociate {
    pid?: string | number;
    rltnshpCd?: string;
    AssocOrgNm?: string;
    AssocTitlCd?: string;
    AssocGvnNm?: string;
    AssocOthrGvnNms?: string;
    AssocFmlyNm?: string;
    AssocNmSufxCd?: string;
}


export { IABRAssociate };