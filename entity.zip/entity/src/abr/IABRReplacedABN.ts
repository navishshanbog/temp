import { IEntityABRActivity } from "./IEntityABRActivity";

interface IABRReplacedABN extends IEntityABRActivity {
    pid?: string | number;
    rplcdAbn?: string;
    rplcdAbnDt?: string;
}

export { IABRReplacedABN as default, IABRReplacedABN };