import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import { IEntityABRActivity } from "./IEntityABRActivity";
import * as StringUtils from "@twii/common/lib/StringUtils";
import * as SearchUtils from "@twii/common/lib/util/Search";
import * as SortUtils from "@twii/common/lib/SortUtils";
import * as moment from "moment";
import * as DateUtils from "@twii/common/lib/DateUtils";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import { ABRActivityColumns } from "./component/ABRActivityColumns";
import ABRServiceContext from "./service/ABRServiceContext";
import IMasterEntitySourceModel from "../entity/IMasterEntitySourceModel";
import IMasterEntityModel from "../entity/IMasterEntityModel";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import * as ABRConstants from "./ABRConstants";
import { getForMasterEntityWithSourceLoader } from "../entity/MasterEntitySourceServiceUtils";
import { ISortProps } from "@twii/common/lib/ISortProps";
import { dedupArray } from "@twii/common/lib/MergeUtils";

const convertNullToEmptyString = (text: string) => {
    return text ? text : "";
}

const dateFields : string[] = [
    "abnRegDOE", "abnCanDOE", "gstRegDOE", "gstCanDOE"
];

const toSortValue = (item: IEntityABRActivity, field: string) => {
    if (item) {
        if (dateFields.indexOf(field) >= 0) {
            return DateUtils.dateFromDataText(item[field]);
        }
        return item[field];
    }
};

const compare = (a: IEntityABRActivity, b: IEntityABRActivity, sort: ISortProps) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if (sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IEntityABRActivity[], sort: ISortProps) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const textFilterItemImpl = (item: IEntityABRActivity, text: string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, ABRActivityColumns), text);
};

const textFilter = (items: IEntityABRActivity[], text: string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IEntityABRActivity, test: moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.abnRegnDt), test);
};

const toFilterItem = (item: IEntityABRActivity, test: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.abnRegnDt), test);
};

const rangeFilterItem = (item: IEntityABRActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items: IEntityABRActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items: IEntityABRActivity[], activityFilter: IActivityFilterProps) => {
    return activityFilter ? rangeFilter(textFilter(items, activityFilter.filterText), activityFilter.filterFromDate, activityFilter.filterToDate) : items;
};

const getActivitiesByAbrNumber = (source: IMasterEntitySourceModel, entity: IMasterEntityModel): Promise<IEntityABRActivity[]> => {
    const abns = dedupArray(source.credentials.filter(c => StringUtils.equalsIgnoreCase(c.credentialTypeCd, "ABN"))
                                    .map(c => c.credentialValue).filter(a => StringUtils.isNotBlank(a)));
    const results : IEntityABRActivity[] = [];
    if(abns.length > 0) {
        const ps = abns.map(abn => {
            return ABRServiceContext.value.getABRActivities({ abn: abn }).then(r => {
                r.forEach(i => {
                    results.push(Object.assign({}, i, { source: source, entity: entity }))
                });
            })
        });
        return Promise.all(ps).then(() => {
            return results;
        });
    }
    return Promise.resolve(results);
}

const getEntityActivities = (entity: IMasterEntityModel): Promise<IEntityABRActivity[]> => {
    return getForMasterEntityWithSourceLoader(entity, ABRConstants.sourceSystemCode, getActivitiesByAbrNumber);
}

const getEntityActivityList = (entity: IMasterEntityModel): MasterEntitySourceListModel<IEntityABRActivity> => {
    return entity.getState("abrActivityList", () => {
        const r = new MasterEntitySourceListModel(entity, ABRConstants.sourceSystemCode, getEntityActivities);
        r.setFilterHandler(filter);
        r.setSortHandler(sort);
        r.load();
        return r;
    });
};

export {
    getEntityActivities,
    getEntityActivityList,
    convertNullToEmptyString
};