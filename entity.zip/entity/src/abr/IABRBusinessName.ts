interface IABRBusinessName {
    pid?: string | number;
    busNm?: string;
}

export { IABRBusinessName };