import { IABRDetails } from "./IABRDetails";
import { IABRService } from "./service/IABRService";
import ABRServiceContext from "./service/ABRServiceContext";

const getABRDetails = (abn : string, service : IABRService = ABRServiceContext.value) : Promise<IABRDetails> => {
    const details : IABRDetails = {};
    const request = { abn: abn };
    const ps = [
        service.getABRAssociates(request).then(associates => {
            details.associates = associates;
        }),
        service.getABRBusinessLocations(request).then(businessLocations => {
            details.businessLocations = businessLocations
        }),
        service.getABRBusinessNames(request).then(businessNames => {
            details.businessNames = businessNames;
        }),
        service.getABROtherTradingNames(request).then(otherTradingNames => {
            details.otherTradingNames = otherTradingNames;
        }),
        service.getABRReplacedABN(request).then(replaced => {
            details.replaced = replaced;
        })
    ];
    return Promise.all(ps).then(() => {
        return details;
    });
};

export { getABRDetails }