import { Context } from "@twii/common/lib/Context";
import { IABRService } from "./IABRService";
import RestABRService from "../service/RestABRService";

const ABRServiceContext = new Context<IABRService>({
    factory: () => {
        return new RestABRService();
    }
});

export { ABRServiceContext as default, ABRServiceContext };