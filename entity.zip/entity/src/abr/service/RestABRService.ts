import axios from "axios";
import { IABRService, IABRListRequest } from "../service/IABRService";
import { IABRActivity } from "../IABRActivity";
import { IABRAssociate } from "../IABRAssociate";
import { IABRBusinessLocation } from "../IABRBusinessLocation";
import { AbstractRestDataService } from "../../common/service/AbstractRestDataService";
import { IABRBusinessName } from "../IABRBusinessName";
import { IABROtherTradingName } from "../IABROtherTradingName";
import IABRReplacedABN from "../IABRReplacedABN";

const Defaults = {
    maxNoRecords: 2000
};

interface IABRListResponse {
    errors?: any;
    [key : string] : any;
}

class RestABRService extends AbstractRestDataService implements IABRService {
    private _handleListResponse<T>(value : any, responseDataKey : string) : T[] {
        const data = value.data as IABRListResponse;
        if (data.errors) {
            return this.handleDataServiceError(data.errors);
        }
        const response = data[responseDataKey];
        return response && response.data ? response.data : [];
    }
    private _listRequest<T>(op : string, request : IABRListRequest) : Promise<T[]> {
        const internalRequest = Object.assign({}, request);
        if (isNaN(internalRequest.maxNumberOfRecords) || internalRequest.maxNumberOfRecords <= 0) {
            internalRequest.maxNumberOfRecords = Defaults.maxNoRecords;
        }
        return axios.get(`${this.baseUrl}/abr/resources/v1/${op}/${encodeURIComponent(request.abn)}`, {
            params: { maxNoRecords: internalRequest.maxNumberOfRecords }
        }).then(value => {
            return this._handleListResponse<T>(value, op);
        });
    }
    getABRActivities(request: IABRListRequest): Promise<IABRActivity[]> {
        return this._listRequest<IABRActivity>("getAbrAgencyData", request);
    };
    getABRAssociates(request: IABRListRequest): Promise<IABRAssociate[]> {
        return this._listRequest<IABRAssociate>("getABRAssociates", request);
    };
    getABRBusinessLocations(request: IABRListRequest): Promise<IABRBusinessLocation[]> {
        return this._listRequest<IABRBusinessLocation>("getAbrBusinessLocation", request);
    };
    getABRBusinessNames(request: IABRListRequest): Promise<IABRBusinessName[]> {
        return this._listRequest<IABRBusinessName>("getAbrBusName", request);
    };
    getABROtherTradingNames(request: IABRListRequest): Promise<IABROtherTradingName[]> {
        return this._listRequest<IABROtherTradingName>("getAbrOthtrdnames", request);
    };
    getABRReplacedABN(request: IABRListRequest): Promise<IABRReplacedABN[]> {
        return this._listRequest<IABRReplacedABN>("getAbrReplacedAbn", request);
    };
}

export { RestABRService as default, RestABRService, Defaults };