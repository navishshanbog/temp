import { IABRService, IABRListRequest } from "./IABRService";
import { IABRActivity } from "../IABRActivity";
import { IABRAssociate } from "../IABRAssociate";
import { IABRBusinessLocation } from "../IABRBusinessLocation";
import { IABROtherTradingName } from "../IABROtherTradingName";
import IABRReplacedABN from "../IABRReplacedABN";
import { IABRBusinessName } from "../IABRBusinessName";

const agencyData = [
    
];

class MockABRService implements IABRService {
    abrActivities : IABRActivity[] = [
        {
            "pid": "28049228",
            "abn": "22914894",
            "entTypCd": "IND",
            "orgNm": "",
            "nmTitlCd": "MS",
            "prsnGvnNm": "NAOMI",
            "prsnOthrGvnNms": "VIOLETTA",
            "prsnFmlyNm": "SIRONE",
            "nmSufxCd": "",
            "abnRegnDt": "2006-06-06",
            "abnCancnDt": "2016-09-20",
            "mnTrdgNm": "",
            "sonAddrLn1": "15 COBBITY ST",
            "sonAddrLn2": "",
            "sonSbrb": "SEVEN HILLS",
            "sonStt": "NSW",
            "sonPc": "2147",
            "sonCntryCd": "AUS",
            "sonDpid": "88406201",
            "mnBusAddrLn1": "15 COBBITY ST",
            "mnBusAddrLn2": "",
            "mnBusSbrb": "SEVEN HILLS",
            "mnBusStt": "NSW",
            "mnBusPc": "2147",
            "mnBusCntryCd": "AUS",
            "mnBusDpid": "88406201",
            "entEml": "N_SIR2011@OPTUSNET.COM.AU",
            "prtyIdBlnk": "",
            "gstRegnDt": "1149516000000",
            "gstCancnDt": "1158069600000",
            "mnIndyClsn": "03010",
            "mnIndyClsnDescn": "Forestry",
            "acn": "",
            "suprsnInd": "N"
          },
          {
            "pid": "34634634",
            "abn": "364634634",
            "entTypCd": "IND",
            "orgNm": "Org name",
            "nmTitlCd": "",
            "prsnGvnNm": "",
            "prsnOthrGvnNms": "",
            "prsnFmlyNm": "",
            "nmSufxCd": "",
            "abnRegnDt": "2006-06-06",
            "abnCancnDt": "2016-09-20",
            "mnTrdgNm": "Company X",
            "sonAddrLn1": "15 COBBITY ST",
            "sonAddrLn2": "",
            "sonSbrb": "SEVEN HILLS",
            "sonStt": "NSW",
            "sonPc": "2147",
            "sonCntryCd": "AUS",
            "sonDpid": "88406201",
            "mnBusAddrLn1": "15 COBBITY ST",
            "mnBusAddrLn2": "",
            "mnBusSbrb": "SEVEN HILLS",
            "mnBusStt": "NSW",
            "mnBusPc": "2147",
            "mnBusCntryCd": "AUS",
            "mnBusDpid": "88406201",
            "entEml": "N_SIR2011@OPTUSNET.COM.AU",
            "prtyIdBlnk": "",
            "gstRegnDt": "1149516000000",
            "gstCancnDt": "1158069600000",
            "mnIndyClsn": "03010",
            "mnIndyClsnDescn": "Forestry",
            "acn": "",
            "suprsnInd": "N"
          }
    ];
    abrAssociates : IABRAssociate[] = [
        {
            "pid": "6007586",
            "rltnshpCd": "PTN",
            "AssocOrgNm": "",
            "AssocTitlCd": "MR",
            "AssocGvnNm": "MATHEW",
            "AssocOthrGvnNms": "",
            "AssocFmlyNm": "CAIAFA",
            "AssocNmSufxCd": ""
        },
        {
            "pid": "6007586",
            "rltnshpCd": "PTN",
            "AssocOrgNm": "",
            "AssocTitlCd": "MRS",
            "AssocGvnNm": "SUSAN",
            "AssocOthrGvnNms": "LEE",
            "AssocFmlyNm": "CAIAFA",
            "AssocNmSufxCd": ""
        }
    ];
    abrBusinessLocations : IABRBusinessLocation[] = [
        {
			"pid": "707665",
			"locnTypCd": "015",
			"locnStrtDt": "2016-09-14",
			"busLocnAddrLn1": "1 BEINDA STREET",
			"busLocnAddrLn2": null,
			"busLocnSbrb": "BOMADERRY",
			"busLocnStt": "NSW",
			"busLocnPc": "2541",
			"busLocnCntryCd": "AUS",
			"busLocnDpid": "0",
			"busLocnLtd": null,
			"busLocnLngtd": null,
			"busLocnMshBlk": null,
			"busLocnGnafPid": null,
			"busLocnPosnlRlblty": null,
			"busLocnPhAreaCd": "02",
			"busLocnPhNum": "88850000",
			"busLocnPhAreaCdMbl": "",
			"busLocnPhNumMbl": null,
			"busLocnEml": "jli@woolworths.com.au",
			"busLocnIndyClsn": "4123",
			"busLocnIndyClsnDescn": "Liquor Retailing"
		},
		{
			"pid": "707665",
			"locnTypCd": "015",
			"locnStrtDt": "2017-07-26",
			"busLocnAddrLn1": "ROUSE HILL TOWN CENTRE",
			"busLocnAddrLn2": "10-14 MARKET LANE",
			"busLocnSbrb": "ROUSE HILL",
			"busLocnStt": "NSW",
			"busLocnPc": "2155",
			"busLocnCntryCd": "AUS",
			"busLocnDpid": "0",
			"busLocnLtd": null,
			"busLocnLngtd": null,
			"busLocnMshBlk": null,
			"busLocnGnafPid": null,
			"busLocnPosnlRlblty": null,
			"busLocnPhAreaCd": "02",
			"busLocnPhNum": "96776417",
			"busLocnPhAreaCdMbl": "",
			"busLocnPhNumMbl": null,
			"busLocnEml": "jbroome@woolworths.com.au",
			"busLocnIndyClsn": "4110",
			"busLocnIndyClsnDescn": "Supermarket and Grocery Stores"
		},
		{
			"pid": "707665",
			"locnTypCd": "015",
			"locnStrtDt": "2017-07-28",
			"busLocnAddrLn1": "CNR KARAWATHA DRIVE",
			"busLocnAddrLn2": "AND GOLF LINKS ROAD",
			"busLocnSbrb": "MOUNTAIN CREEK",
			"busLocnStt": "QLD",
			"busLocnPc": "4557",
			"busLocnCntryCd": "AUS",
			"busLocnDpid": "0",
			"busLocnLtd": null,
			"busLocnLngtd": null,
			"busLocnMshBlk": null,
			"busLocnGnafPid": null,
			"busLocnPosnlRlblty": null,
			"busLocnPhAreaCd": "07",
			"busLocnPhNum": "54774815",
			"busLocnPhAreaCdMbl": "",
			"busLocnPhNumMbl": null,
			"busLocnEml": "jbroome@woolworths.com.au",
			"busLocnIndyClsn": "4110",
			"busLocnIndyClsnDescn": "Supermarket and Grocery Stores"
		},
		{
			"pid": "707665",
			"locnTypCd": "015",
			"locnStrtDt": "2017-07-28",
			"busLocnAddrLn1": "100 OVERTON ROAD",
			"busLocnAddrLn2": null,
			"busLocnSbrb": "WILLIAMS LANDING",
			"busLocnStt": "VIC",
			"busLocnPc": "3027",
			"busLocnCntryCd": "AUS",
			"busLocnDpid": "0",
			"busLocnLtd": null,
			"busLocnLngtd": null,
			"busLocnMshBlk": null,
			"busLocnGnafPid": null,
			"busLocnPosnlRlblty": null,
			"busLocnPhAreaCd": "03",
			"busLocnPhNum": "83476654",
			"busLocnPhAreaCdMbl": "",
			"busLocnPhNumMbl": null,
			"busLocnEml": "jbroome@woolworths.com.au",
			"busLocnIndyClsn": "4110",
			"busLocnIndyClsnDescn": "Supermarket and Grocery Stores"
		},
		{
			"pid": "707665",
			"locnTypCd": "015",
			"locnStrtDt": "2016-09-12",
			"busLocnAddrLn1": "114 MAIN ROAD",
			"busLocnAddrLn2": null,
			"busLocnSbrb": "MOONAH",
			"busLocnStt": "TAS",
			"busLocnPc": "7009",
			"busLocnCntryCd": "AUS",
			"busLocnDpid": "90303733",
			"busLocnLtd": "0.000000",
			"busLocnLngtd": "0.000000",
			"busLocnMshBlk": "60056480000",
			"busLocnGnafPid": "GATAS702499659",
			"busLocnPosnlRlblty": null,
			"busLocnPhAreaCd": "03",
			"busLocnPhNum": "62274809",
			"busLocnPhAreaCdMbl": "",
			"busLocnPhNumMbl": null,
			"busLocnEml": "jbroome@woolworths.com.au",
			"busLocnIndyClsn": "4110",
			"busLocnIndyClsnDescn": "Supermarket and Grocery Stores"
		}
	];
	abrOtherTradingNames : IABROtherTradingName[] = [
		{
            "pid": 707665,
            "othrTrdgNm": "2 Cool Products"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "ABERVALE WINE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "ASTOR CELLARS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Advantage Lakeside Liquor"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Always On"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Ark Pet Products"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Asaka Foods"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Australian Discount Stores"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Australian Safeway Stores (Queensland)"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Australian Supermarkets"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "B.C.C STORES"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "BIG W"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "BIG W DISCOUNT STORES"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "BWS-BEER WINE SPIRITS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Beerwah Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Big Bomber Liquors"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "CARINGBAH SHOPPING TOWN"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "CHEAPER LIQUOR"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "CONSTANTIA FOODS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Cellarmart"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Cellermart"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "City and Country Cellars"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "DAN MURPHYS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "DANISH SMOKEHOUSE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "DICK SMITH ELECTRONICS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "DOONSIDE MARKETPLACE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "EUROPEAN SMOKEHOUSE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "FIRST ESTATE WINE MERCHANT"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "FLEMINGS FABULOUS FOOD STORES"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Food Fair"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Food For Less"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "GLENMORE PARK MARKETPLACE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "GRIFFITH MARKETPLACE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "GROCERY WHOLESALERS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "HAWKESBURY MARKETPLACE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "HOME BRAND"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Hypermart"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "JACOBY'S FURNITURE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Jack the Slasher"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "LIQUOR PLUS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "LIQUOR PLUS BIG BARN"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Leghorn's Specialty Chickens"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Liberty Liquors"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Lilydale Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Livingston Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "MAC'S LIQUOR"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "MARKET TOWERS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "MAXI MART"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "MRS BEATTIE'S LOLLY SHOP"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Market Square"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Marketta Foods"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Melbourne Wines And Spirits"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Melton Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Metro Image Centre"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Metro Shopping"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Morayfield Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Mosman Fine Wines"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Mount Hawthorn Wine Bin"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Mowbray Roel Vos Supermarket"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Mussellbrook Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Nathan Plaza"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Naytura"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Naytura Health Food Store"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Nightcliff Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "No Frills Cash & Carry Liquor"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "No Frills Food Market"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "No Frills Wholesale cash n carry"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "No Name Products"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Northern Food Services"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Northside Plaza"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Nowra Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Orana Mall"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Oxenford Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "PADDINGTON GROCERIES"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "POLLY'S SNACK BAR"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "PRICE MARK CLOTHING"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "PURITY STORES"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Paddington Fine Wines"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Pak'N Save"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Pak-N-Pay"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Palm Beach Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Plumpton Market Place"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity Food Distributors"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity Metro"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity New Town"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity Plus Petrol"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity Supermarket Bay Village"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity Supermarkets"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity Supermarkets Frequent Shopper Club"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Purity\/Roelf Vos Retail College"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "QUALEST"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "ROELF VOS SUPERSTORES"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Radio Shack"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Raymond Terrace Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Richmond Market Place"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Riverdale Centre"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Roelf Vos"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Roelf Vos Metro"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Roelf Vos Supermarket"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "SAFEWAY"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Safeway Liquor Stores"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Safeway Metro"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Safeway Petrol"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Safeway Plus Petrol"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Safeway-Easyway"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Safeways"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Select Liquor"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Shop-Ezy"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "South Granville Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "St Helena Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Staples Office Supplies"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Statewide cash n carry"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Statewide food services"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Super Cellars"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "THE BOTTEGA"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "TOWN HALL CAFE"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "TOWN HALL FOOD MARKET"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Tandy Electronics"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Tandy Protection Services"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Tasmanian Fine Wine Distributors"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Bargains are Better"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Cheaper Liquor Co"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Cheaper Liquor Company"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Cool Rock Cellars"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Fresh Food People Purity"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Fresh Food People Roelf Vos"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Fresh Food People Safeway"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Fresh Food People Woolworths"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Hunter Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Hunter at Greenhills"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Naytura Health Food Co"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Naytura Health Food Store"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Paddington Grocer"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Park Cellars Glebe"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Purity Retail College"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "The Town Plaza Charters Towers"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Thrifty Supermarkets"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Townsville Trading Company"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "UNIVERSAL WHOLESALERS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Vos Supermarket"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WBS Wine Beer Spirits"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLCOM ONE BANKING"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLIES"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLSTAR"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS BREEZE BANKING"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS EXPORT"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS EZY BANKING"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS FASTRACK"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS FOOD FAIR"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS HOME SHOP"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS HOMEMAKERS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS MARIO'S FINE MEATS"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOOLWORTHS MR PICKWICK'S BAKERY"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOW Woolworths"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "WOWLINK"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Wagga Southpoint Shopping Centre"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Wagga Wagga Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "West Ryde Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Windsor Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Always On"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths EZY bill pay"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths EZY share Services"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Ezy Financial Services"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Ezy Home Loans"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Ezy Investments"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Ezy Personal Loans"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Ezy Savings"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Ezy insurance"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Ezy mobile"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Gawler Shopping Centre"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Liquor"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Marketplace"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Marketplace at Albany Creek"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Metro"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Petrol"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Petrol Plus"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths Supermarkets"
          },
          {
            "pid": 707665,
            "othrTrdgNm": "Woolworths variety Stores"
          }
    ];
    abrReplacedABN : IABRReplacedABN[] = [
      {
        "pid": "89273752",
        "rplcdAbn": "57074821720",
        "rplcdAbnDt": "2015-10-05"
      },
      {
        "pid": "8927424234",
        "rplcdAbn": "23423432",
        "rplcdAbnDt": "2017-05-15"
      }
    ];
    abrBusinessNames : IABRBusinessName[] = [
      {
        "pid": 707665,
        "busNm": "HOCKING LIQUOR"
      },
      {
        "pid": 707665,
        "busNm": "Everyday Delivery"
      },
      {
        "pid": 707665,
        "busNm": "FIGTREE CELLARS LIQUOR STORE"
      },
      {
        "pid": 707665,
        "busNm": "WooliesX"
      },
      {
        "pid": 707665,
        "busNm": "Metro Liquor"
      },
      {
        "pid": 707665,
        "busNm": "YOKINE CELLARS"
      },
      {
        "pid": 707665,
        "busNm": "WOOLWORTHS SUPERMARKETS FREQUENT SHOPPER CLUB"
      },
      {
        "pid": 707665,
        "busNm": "THE CHEAPER LIQUOR CO. BWS BEER WINE SPIRITS"
      },
      {
        "pid": 707665,
        "busNm": "BWS - BEER WINE SPIRITS"
      },
      {
        "pid": 707665,
        "busNm": "NEUTRAL BAY SHOPPING VILLAGE"
      },
      {
        "pid": 707665,
        "busNm": "WOOLWORTHS LIQUOR"
      },
      {
        "pid": 707665,
        "busNm": "DAN MURPHY'S"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Money"
      },
      {
        "pid": 707665,
        "busNm": "Endeavour Drinks Group"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths FoodCo"
      },
      {
        "pid": 707665,
        "busNm": "MACRO WHOLEFOODS"
      },
      {
        "pid": 707665,
        "busNm": "WOOLWORTHS HOMESHOP"
      },
      {
        "pid": 707665,
        "busNm": "WOOLWORTHS PETROL"
      },
      {
        "pid": 707665,
        "busNm": "WOOLWORTHS EVERYDAY MOBILE"
      },
      {
        "pid": 707665,
        "busNm": "INTERNATIONAL LIQUOR WHOLESALERS"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Online"
      },
      {
        "pid": 707665,
        "busNm": "woolworths group"
      },
      {
        "pid": 707665,
        "busNm": "FIRST ESTATE WINE MERCHANT"
      },
      {
        "pid": 707665,
        "busNm": "NORTHSIDE PLAZA"
      },
      {
        "pid": 707665,
        "busNm": "MACRO WHOLEFOODS MARKET"
      },
      {
        "pid": 707665,
        "busNm": "More Savings Everyday"
      },
      {
        "pid": 707665,
        "busNm": "FLEMINGS FABULOUS FOOD STORES"
      },
      {
        "pid": 707665,
        "busNm": "Nirvana Beach Liquor"
      },
      {
        "pid": 707665,
        "busNm": "RADIO SHACK"
      },
      {
        "pid": 707665,
        "busNm": "SAFEWAY PETROL"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Rewards"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Hampers"
      },
      {
        "pid": 707665,
        "busNm": "EVERYDAY REWARDS"
      },
      {
        "pid": 707665,
        "busNm": "MIKE LUSCOMBE'S HARDWARE"
      },
      {
        "pid": 707665,
        "busNm": "EVERYDAY MONEY"
      },
      {
        "pid": 707665,
        "busNm": "WOOLWORTHS METRO"
      },
      {
        "pid": 707665,
        "busNm": "QUALTEST"
      },
      {
        "pid": 707665,
        "busNm": "FOOD FOR LESS"
      },
      {
        "pid": 707665,
        "busNm": "The Fresh Food People Woolworths"
      },
      {
        "pid": 707665,
        "busNm": "SAFEWAY"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Flowers"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Food Quarter"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Mobile"
      },
      {
        "pid": 707665,
        "busNm": "MACRO ORGANICS"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Food Innovators"
      },
      {
        "pid": 707665,
        "busNm": "METRO IMAGE CENTRE"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Local"
      },
      {
        "pid": 707665,
        "busNm": "WOW BRANDS"
      },
      {
        "pid": 707665,
        "busNm": "Darlinghurst Cellars"
      },
      {
        "pid": 707665,
        "busNm": "Woolworths Insurance"
      },
      {
        "pid": 707665,
        "busNm": "WOOLWORTHS"
      },
      {
        "pid": 707665,
        "busNm": "BIG W"
      },
      {
        "pid": 707665,
        "busNm": "THOMAS DUX GROCER"
      },
      {
        "pid": 707665,
        "busNm": "SAFEWAY LIQUOR"
      }
    ];
    getABRActivities(request : IABRListRequest) : Promise<IABRActivity[]> {
      console.log("-- Mock Get ABR Activities Request: " + JSON.stringify(request));
      return Promise.resolve(this.abrActivities);
    }
    getABRAssociates(request : IABRListRequest) : Promise<IABRAssociate[]> {
      console.log("-- Mock Get ABR Associates Request: " + JSON.stringify(request));
      return Promise.resolve(this.abrAssociates);
    }
    getABRBusinessLocations(request: IABRListRequest) : Promise<IABRBusinessLocation[]> {
      console.log("-- Mock Get ABR Business Locations Request: " + JSON.stringify(request));
      return Promise.resolve(this.abrBusinessLocations);
    }
    getABROtherTradingNames(request: IABRListRequest) : Promise<IABROtherTradingName[]> {
      console.log("-- Mock Get ABR Other Trading Names Request: " + JSON.stringify(request));
      return Promise.resolve(this.abrOtherTradingNames);
	  }
    getABRReplacedABN(request: IABRListRequest) : Promise<IABRReplacedABN[]> {
      console.log("-- Mock Get ABR Replaced ABN Request: " + JSON.stringify(request));
      return Promise.resolve(this.abrReplacedABN);
    }
    getABRBusinessNames(request: IABRListRequest) : Promise<IABRBusinessName[]> {
      console.log("-- Mock Get ABR Business Names Request: " + JSON.stringify(request));
      return Promise.resolve(this.abrBusinessNames);
    }
}

export { MockABRService }