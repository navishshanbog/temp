import { IABRActivity } from "../IABRActivity";
import { IABRAssociate } from "../IABRAssociate";
import { IABRBusinessLocation } from "../IABRBusinessLocation";
import { IABROtherTradingName } from "../IABROtherTradingName";
import { IABRReplacedABN } from "../IABRReplacedABN";
import { IABRBusinessName } from "../IABRBusinessName";

interface IABRListOptions {
    maxNumberOfRecords?: number;
}

interface IABRListRequest extends IABRListOptions {
    abn: string;
}

interface IABRService {
    getABRActivities(request : IABRListRequest) : Promise<IABRActivity[]>;
    getABRAssociates(request : IABRListRequest) : Promise<IABRAssociate[]>;
    getABRBusinessLocations(request: IABRListRequest) : Promise<IABRBusinessLocation[]>;
    getABROtherTradingNames(request: IABRListRequest) : Promise<IABROtherTradingName[]>;
    getABRReplacedABN(request: IABRListRequest) : Promise<IABRReplacedABN[]>;
    getABRBusinessNames(request: IABRListRequest) : Promise<IABRBusinessName[]>;
}

export { IABRService, IABRListRequest, IABRListOptions };