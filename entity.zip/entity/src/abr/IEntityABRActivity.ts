import { IABRActivity } from "./IABRActivity";
import { IEntityActivity } from "../entity/IEntityActivity";

interface IEntityABRActivity extends IEntityActivity, IABRActivity {}

export { IEntityABRActivity }