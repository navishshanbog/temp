interface IABRActivity {
    pid?: string | number;
    abn?: string;
    entTypCd?: string;
    orgNm?: string;
    nmTitlCd?: string;
    prsnGvnNm?: string;
    prsnOthrGvnNms?: string;
    prsnFmlyNm?: string;
    nmSufxCd?: string;
    abnRegnDt?: string;
    abnCancnDt?: string;
    mnTrdgNm?: string;
    sonAddrLn1?: string;
    sonAddrLn2?: string;
    sonSbrb?: string;
    sonStt?: string;
    sonPc?: string;
    sonCntryCd?: string;
    sonDpid?: string;
    mnBusAddrLn1?: string;
    mnBusAddrLn2?: string;
    mnBusSbrb?: string;
    mnBusStt?: string;
    mnBusPc?: string;
    mnBusCntryCd?: string;
    mnBusDpid?: string;
    entEml?: string;
    prtyIdBlnk?: string;
    gstRegnDt?: string;
    gstCancnDt?: string;
    mnIndyClsn?: string;
    mnIndyClsnDescn?: string;
    acn?: string;
    suprsnInd?: string;
}

export { IABRActivity }