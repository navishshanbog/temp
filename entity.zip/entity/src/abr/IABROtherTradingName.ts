interface IABROtherTradingName {
    pid?: string | number;
    othrTrdgNm?: string;
}

export { IABROtherTradingName };