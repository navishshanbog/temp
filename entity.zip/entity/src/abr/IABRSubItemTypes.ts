const IABRSubItemTypes = {
    ABNBusinessNames: "ABNBusinessNames",
    ABNOtherTradingNames: "ABNOtherTradingNames",
    ABNOtherAddresses: "ABNOtherAddresses",
    ABNReplacedABN: "ABNReplacedABN",
    ABNAssociates: "ABNAssociates"
}

export {IABRSubItemTypes as default, IABRSubItemTypes}