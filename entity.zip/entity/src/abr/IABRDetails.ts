import { IABRAssociate } from "./IABRAssociate";
import { IABRBusinessLocation } from "./IABRBusinessLocation";
import { IABROtherTradingName } from "./IABROtherTradingName";
import { IABRReplacedABN } from "./IABRReplacedABN";
import { IABRBusinessName } from "./IABRBusinessName";

interface IABRDetails {
    associates?: IABRAssociate[];
    businessLocations?: IABRBusinessLocation[];
    otherTradingNames?: IABROtherTradingName[];
    replaced?: IABRReplacedABN[];
    businessNames?: IABRBusinessName[];
}

export { IABRDetails }