import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { copySubActivitiesToClipboard } from "../entity/component/MasterEntitySourceHelper";

interface IMovementSubActivityHelperProps {
    modelData?: any;
    subEntityHeader?: string;
    subItemType?: string;
    name?: string;
    title?: string;
    disabled?: boolean;
}

const createCopyForABRActivities = (opts: IMovementSubActivityHelperProps): IContextualMenuItem => {
    const { modelData, name, title, subItemType, subEntityHeader } = opts;
    return {
        key: "copySubActivityToClipboard",
        name: name || "Copy",
        title: title || "Copy",
        iconProps: { iconName: "Copy" },
        fieldValues: modelData.items,
        source: modelData.parent ? modelData.parent.source : undefined,
        sourceItemType: "activity",
        sourceSubItemType: subItemType,
        masterEntityId: modelData.parent && modelData.parent.entity ? modelData.parent.entity.masterEntityId : undefined,
        sourceSubItemHeader: subEntityHeader,
        disabled: opts.disabled,
        onClick: copySubActivitiesToClipboard
    }
};

export { createCopyForABRActivities, IMovementSubActivityHelperProps }