import { IABRActivity } from "../IABRActivity";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import { IABRDetails } from "../IABRDetails";
import { SyncSupplier } from "@twii/common/lib/model/SyncSupplier";
import { getABRDetails } from "../ABRDetailsHelper";

// TODO: caching
const findDetailsByActivity = (activity : IABRActivity) : ISyncSupplier<IABRDetails, IABRActivity> => {
    const s = new SyncSupplier();
    s.parent = activity;
    s.loader = (parent : IABRActivity) => {
        return getABRDetails(parent.abn);
    };
    return s;
};

const findDetailsByABN = (abn : string) : ISyncSupplier<IABRDetails, IABRActivity> => {
    return findDetailsByActivity({ abn: abn });
};

export {
    findDetailsByActivity,
    findDetailsByABN
}