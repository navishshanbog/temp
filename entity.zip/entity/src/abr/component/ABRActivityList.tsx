import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import { IABRActivity } from "../IABRActivity";
import ABRActivityDetailsList from "./ABRActivityDetailsList";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import ABRActivityViewPrefsStore from "../ABRActivityViewPrefsStore";
import ABRActivityColumns from "./ABRActivityColumns";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { Sync } from "@twii/common/lib/component/Sync";
import { AppView } from "@twii/common/lib/component/AppView";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { getEntityActivityList } from "../ABRActivityHelper";
import { IEntityABRActivity } from "../IEntityABRActivity";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";
import { PathsContext } from "../../PathsContext";

interface IABRActivityListProps {
    list: IMasterEntitySourceListModel<IEntityABRActivity>;
    onItemInvoked?: (item : IABRActivity) => void;
}

@observer
class ABRActivityListCommandBar extends React.Component<IABRActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "ABR Activities", viewOptions: { fromFilterHidden: true, toFilterHidden: true } }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(ABRActivityViewPrefsStore, ABRActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class ABRActivityList extends React.Component<IABRActivityListProps, any> {
    private _onRenderMenu = () => {
        return <ABRActivityListCommandBar {...this.props} />;
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <ABRActivityDetailsList {...this.props} viewPreferences={ABRActivityViewPrefsStore} />
            </AppView>
        )
    }
}


class ABRActivityListContainer extends React.Component<IABRActivityListProps, any> {
    private _onRenderDone = () => {
        return <ABRActivityList {...this.props} />;
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} />;
    }
}

class ABRActivityListApp extends EntitySourceApp {
    private _onItemInvoked = (item : IABRActivity) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.abrDetails(item.abn),
            abrActivity: item,
            panelProps: panelProps
        };
    }
    protected _onRenderSource = (props) => {
        return <ABRActivityListContainer list={getEntityActivityList(props.masterEntity)} onItemInvoked={this._onItemInvoked} />;
    }
}

export {
    ABRActivityList,
    ABRActivityListContainer,
    IABRActivityListProps,
    ABRActivityListApp,
    ABRActivityListApp as default
}