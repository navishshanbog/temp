import { IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import * as DateUtils from "@twii/common/lib/DateUtils";
import { IABRActivity } from "../IABRActivity";
import { nameToNISFormat } from "../../entity/EntityNameUtils";
import { join } from "@twii/common/lib/StringUtils";

const abn: IColumn = {
    key: "abn",
    ariaLabel: "ABN",
    name: "ABN",
    fieldName: "abn",
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 40,
    maxWidth: 100
};

const type: IColumn = {
    key: "entTypCd",
    ariaLabel: "Type",
    name: "Type",
    fieldName: "entTypCd",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const getName = (item: IABRActivity): string => {
    return item.orgNm ? item.orgNm : nameToNISFormat({
        firstName: item.prsnGvnNm,
        familyName: item.prsnFmlyNm,
        nameSuffix: item.nmSufxCd,
        namePrefix: item.nmTitlCd
    });
}

const name: IColumn = {
    key: "name",
    ariaLabel: "Name",
    name: "Name",
    fieldName: "name",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: getName
    },
    onRender: getName
};

const mainTradingName: IColumn = {
    key: "mnTrdgNm",
    ariaLabel: "Main Trading Name",
    name: "Main Trading Name",
    fieldName: "mnTrdgNm",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true
};

const getRegisteredDate = (item: IABRActivity) : string => {
    return DateUtils.dataToOutputText(item.abnRegnDt);
};

const registered: IColumn = {
    key: "abnRegnDt",
    ariaLabel: "Registered",
    name: "Registered",
    fieldName: "abnRegnDt",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: getRegisteredDate
    },
    onRender: getRegisteredDate
};

const getCancelledDate = (item : IABRActivity) : string => {
    return DateUtils.dataToOutputText(item.abnCancnDt);
};

const cancelled: IColumn = {
    key: "abnCancnDt",
    ariaLabel: "Cancelled",
    name: "Cancelled",
    fieldName: "abnCancnDt",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: getCancelledDate
    },
    onRender: getCancelledDate
};

const getAddress = (item : IABRActivity) : string => {
    return join([item.sonAddrLn1, item.sonAddrLn2, item.sonSbrb, item.sonStt, item.sonPc], s => s, ", ");
};

const address: IColumn = {
    key: "sonAddr",
    ariaLabel: "Address ",
    name: "Address",
    fieldName: "sonAddr",
    minWidth: 100,
    maxWidth: 250,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: getAddress
    },
    onRender: getAddress/*(item : IABRActivity) => {
        let _handleClick = (ev : React.MouseEvent<HTMLElement>) => {
            ev.stopPropagation();
            openAddressForActivityDetails(item);
        };
        return <Link onClick={_handleClick}>{getAddress(item)}</Link>;
    }*/
}

const industry: IColumn = {
    key: "mnIndyClsnDescn",
    ariaLabel: "Industry",
    name: "Industry",
    fieldName: "mnIndyClsnDescn",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true
};

const email: IColumn = {
    key: "entEml",
    ariaLabel: "Email",
    name: "Email",
    fieldName: "entEml",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true
};

const getGstRegisteredDate = (item : IABRActivity) : string => {
    return DateUtils.dataToOutputText(item.gstRegnDt);
};

const gstRegistered: IColumn = {
    key: "gstRegnDt",
    ariaLabel: "GST Registered",
    name: "GST Registered",
    fieldName: "gstRegnDt",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: getGstRegisteredDate
    },
    onRender: getGstRegisteredDate
};

const getGstCancelledDate = (item : IABRActivity) : string => {
    return DateUtils.dataToOutputText(item.gstCancnDt);
};

const gstCancelled: IColumn = {
    key: "gstCancnDt",
    ariaLabel: "GST Cancelled",
    name: "GST Cancelled",
    fieldName: "gstCancnDt",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: getGstCancelledDate
    },
    onRender: getGstCancelledDate
};

const asicNumber: IColumn = {
    key: "acn",
    ariaLabel: "ACN",
    name: "ACN",
    fieldName: "acn",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true
};

const suprsnInd: IColumn = {
    key: "suprsnInd",
    ariaLabel: "Publicly Suppressed",
    name: "Publicly Suppressed",
    fieldName: "suprsnInd",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true
};

const ABRActivityColumns: IColumn[] = [
    abn,
    type,
    name,
    mainTradingName,
    registered,
    cancelled,
    address,
    industry,
    email,
    gstRegistered,
    gstCancelled,
    asicNumber,
    suprsnInd
];

export {
    ABRActivityColumns as default,
    ABRActivityColumns,
    abn,
    type,
    name,
    registered,
    cancelled,
    address,
    industry,
    email,
    gstRegistered,
    gstCancelled,
    asicNumber,
    suprsnInd,
    getName
}