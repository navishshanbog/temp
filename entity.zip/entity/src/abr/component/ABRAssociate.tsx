import * as React from "react";
import { IABRAssociate } from "../IABRAssociate";
import { DetailsList, IColumn, SelectionMode, DetailsListLayoutMode, ConstrainMode, CheckboxVisibility } from "office-ui-fabric-react/lib/DetailsList";
import { alwaysFalse } from "@twii/common/lib/Suppliers";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { join } from "@twii/common/lib/StringUtils";
import { identity } from "@twii/common/lib/MapFuncs";

interface IABRAssociateListProps {
    list: IABRAssociate[];
}

const getNameText = (item : IABRAssociate) => {
    return join([item.AssocOrgNm, item.AssocTitlCd, item.AssocGvnNm, item.AssocOthrGvnNms, item.AssocFmlyNm], identity, " ");
};

const ABRAssociateColumns : IColumn[] = [
    {
        key: "name",
        fieldName: "name",
        name: "Name",
        minWidth: 150,
        onRender: getNameText,
        isResizable: true,
        data: { getText: getNameText }
    },
    {
        key: "rltnshpCd",
        fieldName: "rltnshpCd",
        name: "Relationship",
        minWidth: 80,
        isResizable: true
    }
];

class ABRAssociateDetailsList extends React.Component<IABRAssociateListProps, any> {
    render() {
        if(this.props.list && this.props.list.length > 0) {
            return (
                <DetailsList columns={ABRAssociateColumns}
                             items={this.props.list}
                             selectionMode={SelectionMode.single}
                             layoutMode={DetailsListLayoutMode.fixedColumns}
                             constrainMode={ConstrainMode.unconstrained}
                             checkboxVisibility={CheckboxVisibility.hidden}
                             onShouldVirtualize={alwaysFalse} />
            );
        }
        return <MessageBar messageBarType={MessageBarType.info}>No Associations found</MessageBar>;
    }
}

export {
    IABRAssociateListProps,
    ABRAssociateDetailsList,
    ABRAssociateColumns
}