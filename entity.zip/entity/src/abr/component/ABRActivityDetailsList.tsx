import * as React from "react";
import { IABRActivity } from "../IABRActivity";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import { ABRActivityColumns, abn } from "./ABRActivityColumns";
import MasterEntitySourceDetailsList from "../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import { Link } from "office-ui-fabric-react/lib/Link";

interface IABRActivityDetailsListProps {
    list: IMasterEntitySourceListModel<IABRActivity>;
    viewPreferences?: IViewPreferencesModel;
    onItemInvoked?: (item : IABRActivity) => void;
}

interface IABRLinkProps {
    item: IABRActivity;
    onItemInvoked: (item : IABRActivity) => void;
}

class ABRLink extends React.Component<IABRLinkProps, any> {
    private _onClickABN = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        this.props.onItemInvoked(this.props.item);
    }
    render() {
        return <Link onClick={this._onClickABN}>{this.props.item.abn}</Link>;
    }
}

class ABRActivityDetailsList extends React.Component<IABRActivityDetailsListProps, any> {
    private _onRenderABN = (item : IABRActivity) => {
        return <ABRLink item={item} onItemInvoked={this.props.onItemInvoked} />
    }
    render() {
        let columns = ABRActivityColumns;
        if(this.props.onItemInvoked) {
            const abnIndex = columns.findIndex(c => c.key === abn.key);
            columns = [].concat(columns);
            columns[abnIndex] = Object.assign({}, columns[abnIndex], { onRender: this._onRenderABN });
        }
        return <MasterEntitySourceDetailsList
                        columns={columns}
                        list={this.props.list}
                        typeLabel="ABR Activities"
                        itemType="activity"
                        viewPreferences={this.props.viewPreferences}
                        onItemInvoked={this.props.onItemInvoked} />;
    }
}

export { ABRActivityDetailsList as default, ABRActivityDetailsList, IABRActivityDetailsListProps }