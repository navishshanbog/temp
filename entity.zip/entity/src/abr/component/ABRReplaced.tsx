import * as React from "react";
import { IABRReplacedABN } from "../IABRReplacedABN";
import { observer } from "mobx-react";
import { DetailsList, IColumn, SelectionMode, DetailsListLayoutMode, ConstrainMode, CheckboxVisibility } from "office-ui-fabric-react/lib/DetailsList";
import { alwaysFalse } from "@twii/common/lib/Suppliers";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import * as DateUtils from "@twii/common/lib/DateUtils";

interface IABRReplacedABNListProps {
    list: IABRReplacedABN[];
}

const onReplacedDateText = (item : IABRReplacedABN) => {
    return DateUtils.dataToOutputText(item.rplcdAbnDt)
};

const ABRReplacedABNColumns : IColumn[] = [
    {
        key: "rplcdAbn",
        fieldName: "rplcdAbn",
        name: "Replaced ABN",
        minWidth: 150,
        isResizable: true
    },
    {
        key: "rplcdAbnDt",
        fieldName: "rplcdAbnDt",
        name: "Date",
        minWidth: 80,
        isResizable: true,
        onRender: onReplacedDateText,
        data: { getText: onReplacedDateText }
    }
];

@observer
class ABRReplacedABNDetailsList extends React.Component<IABRReplacedABNListProps, any> {
    render() {
        if(this.props.list && this.props.list.length > 0) {
            return (
                <DetailsList columns={ABRReplacedABNColumns}
                             items={this.props.list}
                             selectionMode={SelectionMode.single}
                             layoutMode={DetailsListLayoutMode.fixedColumns}
                             constrainMode={ConstrainMode.unconstrained}
                             checkboxVisibility={CheckboxVisibility.hidden}
                             onShouldVirtualize={alwaysFalse} />
            );
        }
        return <MessageBar messageBarType={MessageBarType.info}>No Replaced ABN Records found</MessageBar>;
    }
}

export {
    IABRReplacedABNListProps,
    ABRReplacedABNDetailsList,
    ABRReplacedABNColumns
}