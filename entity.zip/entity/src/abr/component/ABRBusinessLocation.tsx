import * as React from "react";
import { IABRBusinessLocation } from "../IABRBusinessLocation";
import { getViewPreferenceColumns } from "@twii/common/lib/component/ColumnHelper";
import ABRBusinessLocationsColumns from "./ABRBusinessLocationsColumns";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import { MessageBarType, MessageBar } from "office-ui-fabric-react/lib/MessageBar";
import { DetailsList, SelectionMode, DetailsListLayoutMode, ConstrainMode, CheckboxVisibility } from "office-ui-fabric-react/lib/DetailsList";
import { alwaysFalse } from "@twii/common/lib/Suppliers";
const ABRBusinessLocationsViewPrefsStore = new ViewPreferencesModel("abrBusinessLocations");

interface IABRBusinessLocationListProps {
    list: IABRBusinessLocation[];
}

class ABRBusinessLocationDetailsList extends React.Component<IABRBusinessLocationListProps, any> {
    private get _filteredColumns() {
        return getViewPreferenceColumns(ABRBusinessLocationsColumns, ABRBusinessLocationsViewPrefsStore);
    }
    render() {
        let columns = this._filteredColumns;
        if(this.props.list && this.props.list.length > 0) {
            return (
                <DetailsList columns={columns}
                             items={this.props.list}
                             selectionMode={SelectionMode.single}
                             layoutMode={DetailsListLayoutMode.fixedColumns}
                             constrainMode={ConstrainMode.unconstrained}
                             checkboxVisibility={CheckboxVisibility.hidden}
                             onShouldVirtualize={alwaysFalse} />
            );
        }
        return <MessageBar messageBarType={MessageBarType.info}>No Business Location details found</MessageBar>;
    }
}

export {
    IABRBusinessLocationListProps,
    ABRBusinessLocationDetailsList,
    ABRBusinessLocationsViewPrefsStore
}