import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IABRBusinessName } from "../IABRBusinessName";
import { List } from "office-ui-fabric-react/lib/List";
import { alwaysFalse } from "@twii/common/lib/Suppliers";

interface IABRBusinessNameListProps {
    list: IABRBusinessName[]
}

const ABRBusinessNameListFields = [
    {
        key: "busNm",
        fieldName: "busNm",
        name: "Business Name",
        minWidth: 50
    }
];

class ABRBusinessNameList extends React.Component<IABRBusinessNameListProps, any> {
    private _onRenderCell = (item : IABRBusinessName) => {
        return item.busNm;
    }
    render() {
        if(this.props.list && this.props.list.length > 0) {
            return (
                <div style={{ padding: 8}}>
                    <List items={this.props.list} onRenderCell={this._onRenderCell} onShouldVirtualize={alwaysFalse} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.info}>No Business Names Available</MessageBar>
    }
}

export {
    IABRBusinessNameListProps,
    ABRBusinessNameList,
    ABRBusinessNameListFields
};