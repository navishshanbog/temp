import { IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import { IABRBusinessLocation } from "../IABRBusinessLocation";
import { join } from "@twii/common/lib/StringUtils";

const getAddress = (item : IABRBusinessLocation) : string => {
    return join([item.busLocnAddrLn1, item.busLocnAddrLn2, item.busLocnSbrb, item.busLocnStt, item.busLocnPc], s => s, ", ");
};

const getPhNumWithAreaCd = (item : IABRBusinessLocation) : string => {
    return join([item.busLocnPhAreaCd, item.busLocnPhNum], s => s, " ");
};

const busLocnAddrLn1: IColumn = {
    key: "busLocnAddrLn1",
    ariaLabel: "Address",
    name: "Address",
    fieldName: "busLocnAddrLn1",
    minWidth: 100,
    maxWidth: 150,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    data: {
        getText: getAddress
    },
    onRender: getAddress
};

const busLocnPhNumWthAreaCd: IColumn = {
    key: "busLocnPhNum",
    ariaLabel: "Phone number",
    name: "Phone number",
    fieldName: "busLocnPhNum",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: getPhNumWithAreaCd
    },
    onRender: getPhNumWithAreaCd
};

const busLocnPhNumMbl: IColumn = {
    key: "busLocnPhNumMbl",
    ariaLabel: "Mobile Number",
    name: "Mobile number",
    fieldName: "busLocnPhNumMbl",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true
};

const busLocnEml: IColumn = {
    key: "busLocnEml",
    ariaLabel: "Email",
    name: "Email",
    fieldName: "busLocnEml",
    minWidth: 100,
    maxWidth: 200,
    columnActionsMode: ColumnActionsMode.clickable,
    isResizable: true
};

const busLocnIndyClsnDescn: IColumn = {
    key: "busLocnIndyClsnDescn",
    ariaLabel: "Industry",
    name: "Industry",
    fieldName: "busLocnIndyClsnDescn",
    minWidth: 40,
    maxWidth: 100,
    isResizable: true,
    isMultiline: true,
    columnActionsMode: ColumnActionsMode.clickable
};

const ABRBusinessLocationsColumns: IColumn[] = [
    busLocnAddrLn1,
    busLocnPhNumWthAreaCd,
    busLocnPhNumMbl,
    busLocnEml,
    busLocnIndyClsnDescn
];

export {
    ABRBusinessLocationsColumns as default,
    ABRBusinessLocationsColumns,
    busLocnAddrLn1,
    busLocnPhNumWthAreaCd,
    busLocnPhNumMbl ,
    busLocnEml,
    busLocnIndyClsnDescn
}