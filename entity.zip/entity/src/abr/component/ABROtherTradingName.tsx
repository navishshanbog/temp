import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { List } from "office-ui-fabric-react/lib/List";
import { IABROtherTradingName } from "../IABROtherTradingName";
import { alwaysFalse } from "@twii/common/lib/Suppliers";

interface IABROtherTradingNameListProps {
    list: IABROtherTradingName[];
}

const ABROtherTradingNameListFields = [
    {
        key: "othrTrdgNm",
        fieldName: "othrTrdgNm",
        name: "Other Trading Name",
        minWidth: 50
    }
];

class ABROtherTradingNameList extends React.Component<IABROtherTradingNameListProps, any> {
    private _onRenderCell = (item : IABROtherTradingName) => {
        return item.othrTrdgNm;
    }
    render() {
        if(this.props.list && this.props.list.length > 0) {
            return (
                <div style={{ padding: 8 }}>
                    <List items={this.props.list} onRenderCell={this._onRenderCell} onShouldVirtualize={alwaysFalse} />
                </div>
            );
        } 
        return <MessageBar messageBarType={MessageBarType.info}>No Other Trading Names Available</MessageBar>
    }
}

export {
    IABROtherTradingNameListProps,
    ABROtherTradingNameList,
    ABROtherTradingNameListFields
};