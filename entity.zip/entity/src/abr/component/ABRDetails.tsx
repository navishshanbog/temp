import * as React from "react";
import { Details } from "@twii/common/lib/component/Details";
import { ABRBusinessNameList } from "./ABRBusinessName";
import { ABROtherTradingNameList } from "./ABROtherTradingName";
import { ABRBusinessLocationDetailsList } from "./ABRBusinessLocation";
import { ABRAssociateDetailsList } from "./ABRAssociate";
import { ABRReplacedABNDetailsList } from "./ABRReplaced";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import { EntityAppView } from "../../common/component/EntityAppView";
import { IABRActivity } from "../IABRActivity";
import { IABRDetails } from "../IABRDetails";
import { Sync } from "@twii/common/lib/component/Sync";
import { AppView } from "@twii/common/lib/component/AppView";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { createCopyForABRActivities } from "../ABRSubActivityHelper";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import { findDetailsByActivity } from "../model/ABRFinder";


interface IABRDetailsProps {
    details: IABRDetails;
}

class ABRDetails extends React.Component<IABRDetailsProps, any> {
    render() {
        return (
            <div style={{ padding: 8 }}>
                <Details title="Business Names" open controlOnHeaderClick>
                    <ABRBusinessNameList list={this.props.details.businessNames} />
                </Details>
                <Details title="Other Trading Names" open controlOnHeaderClick>
                    <ABROtherTradingNameList list={this.props.details.otherTradingNames} />
                </Details>
                <Details title="Business Addresses" open controlOnHeaderClick>
                    <ABRBusinessLocationDetailsList list={this.props.details.businessLocations} />
                </Details>
                <Details title="Associated" open controlOnHeaderClick>
                    <ABRAssociateDetailsList list={this.props.details.associates} />
                </Details>
                <Details title="Replaced ABN" open controlOnHeaderClick>
                    <ABRReplacedABNDetailsList list={this.props.details.replaced} />
                </Details>
            </div>
        );
    }
}

interface IABRDetailsContainerProps {
    model: ISyncSupplier<IABRDetails, IABRActivity>;
}

class ABRDetailsAppView extends React.Component<IABRDetailsContainerProps, any> {
    render() {
        // this highlights how badly we need to rework the clipboard - 
        // going to create a basic json based common document format to copy to clipboard
        const copyItem : IContextualMenuItem = createCopyForABRActivities({
            modelData: {
                parent: this.props.model.parent,
                items: [
                    this.props.model.value
                ]
            },
            subItemType: "detail",
            subEntityHeader: `ABN ${this.props.model.parent.abn} Details`
        });
        const items : IContextualMenuItem[] = [];
        items.push(copyItem);
        return (
            <AppView commandBarProps={{ items: items }}>
                <ABRDetails details={this.props.model.value} />
            </AppView>
        );
    }
}

class ABRDetailsContainer extends React.Component<IABRDetailsContainerProps, any> {
    componentWillMount() {
        this.props.model.load();
    }
    private _onRenderDone = () => {
        return <ABRDetailsAppView {...this.props} />
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading details..." />;
    }
}

class ABRDetailsApp extends EntityAppBase {
    get activity() : IABRActivity {
        if(this.props.match.abrActivity) {
            return this.props.match.abrActivity;
        }
        return this.props.match.params;
    }
    get detailsSupplier() : ISyncSupplier<IABRDetails, IABRActivity> {
        return findDetailsByActivity(this.activity);
    }
    componentWillMount() {
        this.host.title = `ABN ${this.activity.abn} Details`;
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker>
                <ABRDetailsContainer model={this.detailsSupplier} />
            </EntityAppView>
        );
    }
}

export {
    IABRDetailsProps,
    ABRDetails,
    ABRDetailsApp,
    ABRDetailsApp as default
}