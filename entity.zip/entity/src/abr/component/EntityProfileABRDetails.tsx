import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { ABRDetails } from "./ABRDetails";
import { IABRDetails } from "../IABRDetails";

class EntityProfileABRDetails extends React.Component<IAppProps, any> {
    render() {
        let details;
        const items = this.props.match.items;
        if(items && items.length > 0) {
            const subItems = items[0].subItems;
            if(subItems && subItems.length > 0) {
                details = subItems[0];
            }
        }
        return (
            <ABRDetails details={details as IABRDetails} />
        );
    }
}

export {
    EntityProfileABRDetails,
    EntityProfileABRDetails as default
}