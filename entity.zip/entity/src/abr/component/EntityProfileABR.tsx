import * as React from "react";
import IEntityProfileSourceGroupProps from "../../entity/profile/component/IEntityProfileSourceGroupProps";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import SubEntityProfileSourceDetailList from "../../entity/profile/component/SubEntityProfileSourceDetailList";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { buildSectionHeader, buildTable, buildComments, buildSectionSubHeader, buildSectionTable, buildSectionList } from "../../entity/profile/EntityProfileDocumentHelper";
import ABRActivityColumns from "./ABRActivityColumns";
import IEntitySourceItems from "../../entity/IEntitySourceItems";
import { equalsIgnoreCase } from "@twii/common/lib/util/String";
import IABRSubItemTypes from "../IABRSubItemTypes";
import ABRBusinessLocationsColumns from "./ABRBusinessLocationsColumns";
import { getViewPreferenceColumns } from "@twii/common/lib/component/ColumnHelper";
import { ABRReplacedABNColumns } from "./ABRReplaced";
import { ABRAssociateColumns } from "./ABRAssociate";
import ABRActivityViewPrefsStore from "../ABRActivityViewPrefsStore";
import { ABROtherTradingNameListFields } from "./ABROtherTradingName";
import { ABRBusinessNameListFields } from "./ABRBusinessName";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileABRApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="abr-activities" title="ABR Activities">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={ABRActivityColumns} />
                <SubEntityProfileSourceDetailList group={this.group} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const ABRActivityDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;
    buildSectionHeader("ABR Activities", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, getViewPreferenceColumns(ABRActivityColumns, ABRActivityViewPrefsStore), doc);
    if (group.hasSubTypes) {
        group.subEntities.map((subEntity: IEntitySourceItems) => {
            if (!(subEntity.items === null)) {
                if (equalsIgnoreCase(subEntity.type, "detail")) {
                    buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader + " - Business Names", doc);
                    buildSectionTable(subEntity.items[0].subItems[0].businessNames, ABRBusinessNameListFields, doc);

                    buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader + " - Other Trading Names", doc);
                    buildSectionTable(subEntity.items[0].subItems[0].otherTradingNames, ABROtherTradingNameListFields, doc);

                    buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader + " - Business Addresses", doc);
                    buildSectionTable(subEntity.items[0].subItems[0].businessLocations, ABRBusinessLocationsColumns, doc);

                    buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader + " - Associated", doc);
                    buildSectionTable(subEntity.items[0].subItems[0].associates, ABRAssociateColumns, doc);

                    buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader + " - Replaced ABN", doc);
                    buildSectionTable(subEntity.items[0].subItems[0].replaced, ABRReplacedABNColumns, doc);
                }
            }
        });
    }
    buildComments(group.comments, doc);
};

export {
    EntityProfileABRApp as default,
    EntityProfileABRApp,
    ABRActivityDocumentHandler
}