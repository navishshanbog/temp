import * as IATAConstants from "./IATAConstants";
import * as FilterUtils from "@twii/common/lib/util/Filter";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import ISort from "@twii/common/lib/ISortProps";
import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import IActivityListModel from "@twii/common/lib/IActivityListModel";
import { IEntityIATAAgency } from "./IEntityIATAAgency";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import { getForMasterEntitySource } from "../entity/MasterEntitySourceServiceUtils";
import IATAServiceContext from "./IATAServiceContext";
import { IATAAgencyColumns } from "./component/IATAAgencyColumns";
import { IMasterEntityModel } from "../entity/IMasterEntityModel";
import { getForMasterEntity } from "../entity/MasterEntitySourceServiceUtils";
import IMasterEntitySourceModel from "../entity/IMasterEntitySourceModel";

const getAgenciesByAgencyId = (iataTravelAgencyId : string, source : IMasterEntitySourceModel, entity : IMasterEntityModel) => {
    return IATAServiceContext.value.getIATAAgencies(iataTravelAgencyId).then(r => {
        return r ? r.map((i, index) => {
            i["key"] = i.carrierCode + "_" + index;
            return Object.assign({}, i, { source: source, entity : entity });
        }) : [];
    });
}

const agencyToFilterRow = (item : IEntityIATAAgency) => {
    return ColumnTextHelper.getRowText(item, IATAAgencyColumns);
};

const agencyFilterHandler = (items : IEntityIATAAgency[], props : IActivityFilterProps) => {
    return FilterUtils.filter(items, props, agencyToFilterRow);
};

const agencySortHandler = (items : IEntityIATAAgency[], sort : ISort) => {
    return SortUtils.sort(items, sort);
};

const getEntityAgencies = (entity : IMasterEntityModel) : Promise<IEntityIATAAgency[]> => {
    return getForMasterEntity(entity, IATAConstants.sourceSystemCode, getAgenciesByAgencyId);
};

const getEntityAgencyList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityIATAAgency> => {
    return entity.getState("iataAgencyList", () => {
        const r = new MasterEntitySourceListModel(entity, IATAConstants.sourceSystemCode, getEntityAgencies);
        r.setFilterHandler(agencyFilterHandler);
        r.setSortHandler(agencySortHandler);
        r.load();
        return r;
    });
};

export { getEntityAgencyList, getEntityAgencies }