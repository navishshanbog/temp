import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const IATAAgenciesViewPrefsStore = new ViewPreferencesModel("iataAgencies");

export { IATAAgenciesViewPrefsStore as default, IATAAgenciesViewPrefsStore }