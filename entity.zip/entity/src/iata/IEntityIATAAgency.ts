import { IEntityActivity } from "../entity/IEntityActivity";
import { IIATAAgency } from "./IIATAAgency";

interface IEntityIATAAgency extends IEntityActivity, IIATAAgency {}

export { IEntityIATAAgency }