const sourceSystemCode = "IATA";

export { sourceSystemCode }