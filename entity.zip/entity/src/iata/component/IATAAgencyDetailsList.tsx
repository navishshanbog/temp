import * as React from "react";
import IIATAAgency from "../IIATAAgency";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IATAAgencyColumns from "./IATAAgencyColumns";
import MasterEntitySourceDetailsList from "../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import { openAgencyDetails } from "../IATAActions";

interface IIATAAgencyDetailsListProps {
    list: IMasterEntitySourceListModel<IIATAAgency>;
    viewPreferences?: IViewPreferencesModel;
    onItemInvoked?: (item : IIATAAgency) => void;
}

class IATAAgencyDetailsList extends React.Component<IIATAAgencyDetailsListProps, any> {
    render() {
        return <MasterEntitySourceDetailsList
                    columns={IATAAgencyColumns}
                    viewPreferences={this.props.viewPreferences}
                    list={this.props.list}
                    typeLabel="IATA Agencies"
                    itemType="agency"
                    onItemInvoked={this.props.onItemInvoked} />;
    }
}

export { IATAAgencyDetailsList as default, IATAAgencyDetailsList, IIATAAgencyDetailsListProps }