import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IIATAAgencyDetail from "../IIATAAgencyDetail";
import IIATAAgencyDetailModel from "../IIATAAgencyDetailModel";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import * as DateUtils from "@twii/common/lib/util/Date";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import AgencyTypeCdRef from "../../ref/AgencyTypeCd";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./IATAAgencyDetail.scss";
import {createCopyForIATAActivities} from "./IATAAgencySubActivityHelper";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import IIATAAgency from "../IIATAAgency";
import { EntityAppView } from "../../common/component/EntityAppView";
import { AppView } from "@twii/common/lib/component/AppView";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { ListModel } from "@twii/common/lib/model/ListModel";
import IATAServiceContext from "../IATAServiceContext";
import { observer } from "mobx-react";

const Fields: IColumn[] = [{ //IDetailsAttributeConfig<IIATAAgencyDetail>[] = [{
    key: "recordIdentifier",
    name: "Record Identifier",
    fieldName: "recordIdentifier",
    minWidth: 50
}, {
    key: "fileIdentifier",
    name: "File Identifier",
    fieldName: "fileIdentifier",
    minWidth: 50
}, {
    key: "iataArea",
    name: "IATA Area",
    fieldName: "iataArea",
    minWidth: 50
}, {
    key: "iataCode",
    name: "Travel Agency Code",
    fieldName: "iataCode",
    minWidth: 50
}, {
    key: "iataCodeCheckDigit",
    name: "Check Digit",
    fieldName: "iataCodeCheckDigit",
    minWidth: 50
}, {
    key: "iataCodeWithCheckDigit",
    name: "IATA Code",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={`${item.iataCode}${item.iataCodeCheckDigit}`}/>;
    },
    data: {
        getText: (item : IIATAAgencyDetail) => `${item.iataCode}${item.iataCodeCheckDigit}`
    },
    fieldName: "iataCodeWithCheckDigit",
    minWidth: 50
}, {
    key: "cassNumber",
    name: "CASS Number",
    fieldName: "cassNumber",
    minWidth: 50
}, {
    key: "locationType",
    name: "Location Type",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={AgencyTypeCdRef.getDesc(item.locationType)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => AgencyTypeCdRef.getDesc(item.locationType) },
    fieldName: "locationType",
    minWidth: 50
}, {
    key: "airlineCode",
    name: "Airline Code",
    fieldName: "airlineCode",
    minWidth: 50
}, {
    key: "legalName1",
    name: "Legal Name 1",
    fieldName: "legalName1",
    minWidth: 50
}, {
    key: "legalName2",
    name: "Legal Name 2",
    fieldName: "legalName2",
    minWidth: 50
}, {
    key: "legalName3",
    name: "Legal Name 3",
    fieldName: "legalName3",
    minWidth: 50
}, {
    key: "travelAgencyName",
    name: "Travel Agency Name",
    fieldName: "travelAgencyName",
    minWidth: 50
}, {
    key: "fullTradingName",
    name: "Full Trading Name",
    fieldName: "fullTradingName",
    minWidth: 50
}, {
    key: "locationAddress1",
    name: "Location Address 1",
    fieldName: "locationAddress1",
    minWidth: 50
}, {
    key: "locationAddress2",
    name: "Location Address 2",
    fieldName: "locationAddress2",
    minWidth: 50
}, {
    key: "locationAddress3",
    name: "Location Address 3",
    fieldName: "locationAddress3",
    minWidth: 50
}, {
    key: "locationCity",
    name: "Location City",
    fieldName: "locationCity",
    minWidth: 50
}, {
    key: "locationStateCode",
    name: "Location State Code",
    fieldName: "locationStateCode",
    minWidth: 50
}, {
    key: "locationIsoCountryCode",
    name: "Location ISO Country Code",
    fieldName: "locationIsoCountryCode",
    minWidth: 50
}, {
    key: "locationCountryCode",
    name: "Location Country Code",
    fieldName: "locationCountryCode",
    minWidth: 50
}, {
    key: "locationCountryStatePostalAbbrvtn",
    name: "Location Country State Postal Abbrvtn",
    fieldName: "locationCountryStatePostalAbbrvtn",
    minWidth: 50
}, {
    key: "locationIataCountryCode",
    name: "Location IATA Country Code",
    fieldName: "locationIataCountryCode",
    minWidth: 50
}, {
    key: "locationPostalCode",
    name: "Location Postal Code",
    fieldName: "locationPostalCode",
    minWidth: 50
}, {
    key: "mailingAddress1",
    name: "Mailing Address 1",
    fieldName: "mailingAddress1",
    minWidth: 50
}, {
    key: "mailingAddress2",
    name: "Mailing Address 2",
    fieldName: "mailingAddress2",
    minWidth: 50
}, {
    key: "mailingCity",
    name: "Mailing City",
    fieldName: "mailingCity",
    minWidth: 50
}, {
    key: "mailingStateName",
    name: "Mailing State Name",
    fieldName: "mailingStateName",
    minWidth: 50
}, {
    key: "mailingCountryStatePostalAbbrvtn",
    name: "Mailing Country State Postal Abbrvtn",
    fieldName: "mailingCountryStatePostalAbbrvtn",
    minWidth: 50
}, {
    key: "mailingCountryCode",
    name: "Mailing Country Code",
    fieldName: "mailingCountryCode",
    minWidth: 50
}, {
    key: "mailingIsoCountryCode",
    name: "Mailing ISO Country Code",
    fieldName: "mailingIsoCountryCode",
    minWidth: 50
}, {
    key: "mailingIataCountryCode",
    name: "Mailing IATA Country Code",
    fieldName: "mailingIataCountryCode",
    minWidth: 50
}, {
    key: "mailingPostalCode",
    name: "Mailing Postal Code",
    fieldName: "mailingPostalCode",
    minWidth: 50
}, {
    key: "phone1InternationalDialCode",
    name: "Phone 1 International Dial Code",
    fieldName: "phone1InternationalDialCode",
    minWidth: 50
}, {
    key: "phone1StdCode",
    name: "Phone 1 STD Code",
    fieldName: "phone1StdCode",
    minWidth: 50
}, {
    key: "telephone1Number",
    name: "Telephone 1 Number",
    fieldName: "telephone1Number",
    minWidth: 50
}, {
    key: "phone2InternationalDialCode",
    name: "Phone 2 International Dial Code",
    fieldName: "phone2InternationalDialCode",
    minWidth: 50
}, {
    key: "phone2StdCode",
    name: "Phone 2 STD Code",
    fieldName: "phone2StdCode",
    minWidth: 50
}, {
    key: "telephone2Number",
    name: "Telephone 2 Number",
    fieldName: "telephone2Number",
    minWidth: 50
}, {
    key: "faxInternationalDialingCode",
    name: "Fax International Dialing Code",
    fieldName: "faxInternationalDialingCode",
    minWidth: 50
}, {
    key: "faxStdCode",
    name: "Fax STD Code",
    fieldName: "faxStdCode",
    minWidth: 50
}, {
    key: "faxNumber",
    name: "Fax Number",
    fieldName: "faxNumber",
    minWidth: 50
}, {
    key: "tollFreeInternationalDialingCode",
    name: "Toll Free International Dialing Code",
    fieldName: "tollFreeInternationalDialingCode",
    minWidth: 50
}, {
    key: "tollFreeStdCode",
    name: "Toll Free STD Code",
    fieldName: "tollFreeStdCode",
    minWidth: 50
}, {
    key: "tollFreeNumber",
    name: "Toll Free Number",
    fieldName: "tollFreeNumber",
    minWidth: 50
}, {
    key: "emailAddressofLocation",
    name: "Email Address of Location",
    fieldName: "emailAddressofLocation",
    minWidth: 50
}, {
    key: "webSiteAddressofLocation",
    name: "Web Site Address of Location",
    fieldName: "webSiteAddressofLocation",
    minWidth: 50
}, {
    key: "telexTeletypeNumber",
    name: "Telex Teletype Number",
    fieldName: "telexTeletypeNumber",
    minWidth: 50
}, {
    key: "crossReferenceArea",
    name: "Cross Reference Area",
    fieldName: "crossReferenceArea",
    minWidth: 50
}, {
    key: "crossReferenceIataCode",
    name: "Cross Reference IATA Code",
    fieldName: "crossReferenceIataCode",
    minWidth: 50
}, {
    key: "crossReferenceIataCheckDigit",
    name: "Cross Reference IATA Check Digit",
    fieldName: "crossReferenceIataCheckDigit",
    minWidth: 50
}, {
    key: "locationCategory1",
    name: "Location Category 1",
    fieldName: "locationCategory1",
    minWidth: 50
}, {
    key: "locationCategory2",
    name: "Location Category 2",
    fieldName: "locationCategory2",
    minWidth: 50
}, {
    key: "locationCategory3",
    name: "Location Category 3",
    fieldName: "locationCategory3",
    minWidth: 50
}, {
    key: "passengerOrCargoIndicator",
    name: "Passenger or Cargo Indicator",
    fieldName: "passengerOrCargoIndicator",
    minWidth: 50
}, {
    key: "companyType",
    name: "Company Type",
    fieldName: "companyType",
    minWidth: 50
}, {
    key: "solicitationFlag",
    name: "Solicitation Flag",
    fieldName: "solicitationFlag",
    minWidth: 50
}, {
    key: "qualifiedTicketAgentLastName",
    name: "Qualified Ticket Agent Last Name",
    fieldName: "qualifiedTicketAgentLastName",
    minWidth: 50
}, {
    key: "qualifiedTicketAgentFirstName",
    name: "Qualified Ticket Agent First Name",
    fieldName: "qualifiedTicketAgentFirstName",
    minWidth: 50
}, {
    key: "locationManagerLastName",
    name: "Location Manager Last Name",
    fieldName: "locationManagerLastName",
    minWidth: 50
}, {
    key: "locationManagerFirstName",
    name: "Location Manager First Name",
    fieldName: "locationManagerFirstName",
    minWidth: 50
}, {
    key: "taxReferenceNumber",
    name: "Tax Reference Number",
    fieldName: "taxReferenceNumber",
    minWidth: 50
}, {
    key: "otherTaxReferenceNumber",
    name: "Other Tax Reference Number",
    fieldName: "otherTaxReferenceNumber",
    minWidth: 50
}, {
    key: "computerReservationNumber1",
    name: "Computer Reservation Number 1",
    fieldName: "computerReservationNumber1",
    minWidth: 50
}, {
    key: "computerReservationNumber2",
    name: "Computer Reservation Number 2",
    fieldName: "computerReservationNumber2",
    minWidth: 50
}, {
    key: "computerReservationNumber3",
    name: "Computer Reservation Number 3",
    fieldName: "computerReservationNumber3",
    minWidth: 50
}, {
    key: "computerReservationNumber4",
    name: "Computer Reservation Number 4",
    fieldName: "computerReservationNumber4",
    minWidth: 50
}, {
    key: "organisation1LastChangeDate",
    name: "Organisation 1 Last Change Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation1LastChangeDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation1LastChangeDate) },
    fieldName: "organisation1LastChangeDate",
    minWidth: 50
}, {
    key: "organisation1LastReinspectionDate",
    name: "Organisation 1 Last Re-inspection Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation1LastReinspectionDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation1LastReinspectionDate) },
    fieldName: "organisation1LastReinspectionDate",
    minWidth: 50
}, {
    key: "organisation1OriginalApprovalDate",
    name: "Organisation 1 Original Approval Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation1OriginalApprovalDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation1OriginalApprovalDate) },
    fieldName: "organisation1OriginalApprovalDate",
    minWidth: 50
}, {
    key: "organisation1LocationEndorsedBy",
    name: "Organisation 1 Location Endorsed By",
    fieldName: "organisation1LocationEndorsedBy",
    minWidth: 50
}, {
    key: "organisation1EndorsementStatusCode",
    name: "Organisation 1 Endorsement Status Code",
    fieldName: "organisation1EndorsementStatusCode",
    minWidth: 50
}, {
    key: "organisation1StatusAttainedDate",
    name: "Organisation 1 Status Attained Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation1StatusAttainedDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation1StatusAttainedDate) },
    fieldName: "organisation1StatusAttainedDate",
    minWidth: 50
}, {
    key: "organisation1LocationClass",
    name: "Organisation 1 Location Class",
    fieldName: "organisation1LocationClass",
    minWidth: 50
}, {
    key: "organisation2LastChangeDate",
    name: "Organisation 2 Last Change Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation2LastChangeDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation2LastChangeDate) },
    fieldName: "organisation2LastChangeDate",
    minWidth: 50
}, {
    key: "organisation2LastReinspectionDate",
    name: "Organisation 2 Last Re-inspection Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation2LastReinspectionDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation2LastReinspectionDate) },
    fieldName: "organisation2LastReinspectionDate",
    minWidth: 50
}, {
    key: "organisation2OriginalApprovalDate",
    name: "Organisation 2 Original Approval Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation2OriginalApprovalDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation2OriginalApprovalDate) },
    fieldName: "organisation2OriginalApprovalDate",
    minWidth: 50
}, {
    key: "organisation2LocationEndorsedBy",
    name: "Organisation 2 Location Endorsed By",
    fieldName: "organisation2LocationEndorsedBy",
    minWidth: 50
}, {
    key: "organisation2EndorsementStatusCode",
    name: "Organisation 2 Endorsement Status Code",
    fieldName: "organisation2EndorsementStatusCode",
    minWidth: 50
}, {
    key: "organisation2StatusAttainedDate",
    name: "Organisation 2 Status Attained Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.organisation2StatusAttainedDate)}/>;
    },
    data: { getText: (item : IIATAAgencyDetail) => DateUtils.dataToOutputText(item.organisation2StatusAttainedDate) },
    fieldName: "organisation2StatusAttainedDate",
    minWidth: 50
}, {
    key: "organisation2LocationClass",
    name: "Organisation 2 Location Class",
    fieldName: "organisation2LocationClass",
    minWidth: 50
}, {
    key: "bspOrCassCode",
    name: "BSP or CASS Code",
    fieldName: "bspOrCassCode",
    minWidth: 50
}, {
    key: "agentRefNumber",
    name: "Agent Ref Number",
    fieldName: "routeId",
    minWidth: 50
}, {
    key: "agentRefNumberForCrossReferencedParent",
    name: "Agent Ref Number for Cross Referenced Parent",
    fieldName: "agentRefNumberForCrossReferencedParent",
    minWidth: 50
}, {
    key: "associationMembershipandAffiliations1",
    name: "Association Membership and Affiliations 1",
    fieldName: "associationMembershipandAffiliations1",
    minWidth: 50
}, {
    key: "associationMembershipandAffiliations2",
    name: "Association Membership and Affiliations 2",
    fieldName: "associationMembershipandAffiliations2",
    minWidth: 50
}, {
    key: "agentLicenseNumber",
    name: "Agent License Number",
    fieldName: "agentLicenseNumber",
    minWidth: 50
}, {
    key: "languageofCorrespondence",
    name: "Language of Correspondence",
    fieldName: "languageofCorrespondence",
    minWidth: 50
}, {
    key: "fileVersion",
    name: "File Version",
    fieldName: "fileVersion",
    minWidth: 50
}, {
    key: "fileProdDate",
    name: "File Prod Date",
    onRender: function(item: IIATAAgencyDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.fileProdDate)}/>;
    },
    data: { getText: (item: IIATAAgencyDetail) => DateUtils.dataToOutputText(item.fileProdDate) },
    fieldName: "fileProdDate",
    minWidth: 50
}, {
    key: "fileName",
    name: "File Name",
    fieldName: "fileName",
    minWidth: 50
}, {
    key: "fileLoadedTimeStamp",
    name: "File Loaded TimeStamp",
    onRender: function(item: IIATAAgencyDetail) {
        let fileLoadedTs: Date = DateUtils.dateFromTimestampDataText(item.fileLoadedTimeStamp);
        let fileLoadedTsStr: string = fileLoadedTs ? DateUtils.dateToTimestampOutputText(fileLoadedTs) : item.fileLoadedTimeStamp;
        return <DetailsAttribute key={this.key} label={this.name} value={fileLoadedTsStr}/>;
    },
    data: {
        getText: (item: IIATAAgencyDetail) => {
            let fileLoadedTs: Date = DateUtils.dateFromTimestampDataText(item.fileLoadedTimeStamp);
            let fileLoadedTsStr: string = fileLoadedTs ? DateUtils.dateToTimestampOutputText(fileLoadedTs) : item.fileLoadedTimeStamp;
            return fileLoadedTsStr;
        }
    },
    fieldName: "fileLoadedTimeStamp",
    minWidth: 50
}];

interface IIATAAgencyDetailsProps {
    model?: IListModel<IIATAAgencyDetail, IIATAAgency>;
}

const IATAAgencyDetailsViewPrefsStore = new ViewPreferencesModel("iataAgencyDetails");

@observer
class IATAAgencyDetailsItems extends React.Component<IIATAAgencyDetailsProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: IIATAAgencyDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={IATAAgencyDetailsViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return content;
    }
}

class IATAAgencyDetails extends React.Component<IIATAAgencyDetailsProps, any> {
    private _getSubEntityHeader = () => {
        let header = "IATA Agency Details: ";
        const agency = this.props.model.parent;
        if(agency) {
            header = agency.travelAgencyName ? header + agency.travelAgencyName : "";
            header = agency.iataTravelAgencyCode ? header+" | " + agency.iataTravelAgencyCode : "";
        }
        return header;
    }
    private _onRenderMenu = () => {
        return (
            <CommandBar items={[createCopyForIATAActivities ({
                modelData:this.props.model,
                subEntityHeader: this._getSubEntityHeader,
                subItemType: "IATAAgency",
                name: "Copy",
                title: "Copy"
            })]}
            farItems={[
                createViewPreferencesMenuItem(IATAAgencyDetailsViewPrefsStore, Fields)]} />
        );
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <div style={{ padding: 8 }}>
                    <IATAAgencyDetailsItems {...this.props} />
                </div>
            </AppView>
        );
    }
}

class IATAAgencyDetailsContainer extends React.Component<IIATAAgencyDetailsProps, any> {
    private _onRenderDone = () => {
        return <IATAAgencyDetails {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading IATA Agency Details..." />
    }
}

class IATAAgencyDetailsApp extends EntityAppBase {
    componentWillMount() {
        this.host.title = "IATA Agency Details";
        this.model.load();
    }
    get agency() : IIATAAgency {
        if(this.props.match.iataAgency) {
            return this.props.match.iataAgency;
        }
        return this.props.match.params;
    }
    get model() : IListModel<IIATAAgencyDetail, IIATAAgency> {
        return this.host.getState("iataAgencyDetails", () => {
            const m = new ListModel<IIATAAgencyDetail, IIATAAgency>();
            m.parent = this.agency;
            m.loader = () => {
                return IATAServiceContext.value.getIATAAgencyDetails(String(this.agency.iataTravelAgencyCode) + String(this.agency.iataTravelAgencyCheckDigit));
            };
            return m;
        }, m => m.parent.iataTravelAgencyCode !== this.agency.iataTravelAgencyCode || m.parent.iataTravelAgencyCheckDigit !== this.agency.iataTravelAgencyCheckDigit);
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker >
                <IATAAgencyDetailsContainer model={this.model} />
            </EntityAppView>
        );
    }
}

export {
    IATAAgencyDetailsContainer,
    IIATAAgencyDetailsProps,
    IATAAgencyDetailsItems,
    IATAAgencyDetails,
    Fields as IATAColumns,
    IATAAgencyDetailsViewPrefsStore,
    IATAAgencyDetailsApp,
    IATAAgencyDetailsApp as default
};