import * as React from "react";
import IEntityProfileSourceGroupProps from "../../entity/profile/component/IEntityProfileSourceGroupProps";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import IATAAgencyColumns from "./IATAAgencyColumns";
import IATAAgencyViewPrefsStore from "../IATAAgenciesViewPrefsStore";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { buildSectionHeader, buildComments, buildTable } from "../../entity/profile/EntityProfileDocumentHelper";
import { getViewPreferenceColumns } from "@twii/common/lib/component/ColumnHelper";
import { openAgencyDetails } from "../IATAActions";
import SubEntityProfileSourceDetailList from "../../entity/profile/component/SubEntityProfileSourceDetailList";
import { IEntitySourceItems } from "../../entity/IEntitySourceItems";
import { buildSectionList, buildSectionSubHeader } from "../../entity/profile/EntityProfileDocumentHelper";
import { equalsIgnoreCase } from "@twii/common/lib/util/String";
import { IATAColumns, IATAAgencyDetailsViewPrefsStore } from "./IATAAgencyDetail"
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileIATAApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="iata-agencies" title="IATA Agencies">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={IATAAgencyColumns} viewPreferences={IATAAgencyViewPrefsStore} onItemInvoked={openAgencyDetails} />
                <SubEntityProfileSourceDetailList group={this.group} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const IATAAgencyDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("IATA Agencies", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, getViewPreferenceColumns(IATAAgencyColumns, IATAAgencyViewPrefsStore), doc);
    if (group.hasSubTypes) {
        group.subEntities.map((subEntity: IEntitySourceItems) => {
            if (!(subEntity.items === null)) {
                buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader, doc);
                if (equalsIgnoreCase(subEntity.type, "IATAAgency")) {
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(IATAColumns, IATAAgencyDetailsViewPrefsStore), doc);
                }
            }
        });
    }
    buildComments(group.comments, doc);
};

export { EntityProfileIATAApp as default, EntityProfileIATAApp, IATAAgencyDocumentHandler }