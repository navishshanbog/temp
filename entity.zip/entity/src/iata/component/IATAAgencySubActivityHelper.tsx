import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { copySubActivitiesToClipboard } from "../../entity/component/MasterEntitySourceHelper";


interface IIATASubActivityHelperProps {
    modelData?: any,
    subEntityHeader?: () => string;
    subItemType?:string;
    name?: string;
    title?: string;
    disabled?: boolean;
}


const createCopyForIATAActivities = (opts : IIATASubActivityHelperProps) : IContextualMenuItem => {
    const { modelData, name, title, subItemType, subEntityHeader } = opts;
    return {
        key: "copySubActivityToClipboard",
        name: name || "Copy",
        title: title || "Copy",
        iconProps: { iconName: "Copy" },
        fieldValues: modelData.items,
        source: modelData.parent ? modelData.parent.source : undefined,
        sourceItemType: "agency",
        sourceSubItemType: subItemType,
        masterEntityId: modelData.parent && modelData.parent.entity ? modelData.parent.entity.masterEntityId : undefined,
        sourceSubItemHeader: subEntityHeader ? subEntityHeader() : undefined,
        disabled: opts.disabled,
        onClick: copySubActivitiesToClipboard
    }
};

export { createCopyForIATAActivities, IIATASubActivityHelperProps }