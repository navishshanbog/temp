import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import IATAAgencyDetailsList from "./IATAAgencyDetailsList";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IIATAAgency from "../IIATAAgency";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import IATAAgencyColumns from "./IATAAgencyColumns";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { openAgencyDetails } from "../IATAActions";
import IATAAgenciesViewPrefsStore from "../IATAAgenciesViewPrefsStore";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";
import { PathsContext } from "../../PathsContext";
import { getEntityAgencyList } from "../IATAAgencyHelper";

interface IIATAAgencyListProps {
    list: IMasterEntitySourceListModel<IIATAAgency>;
    onItemInvoked?: (item : IIATAAgency) => void;
}

@observer
class IATAAgencyListCommandBar extends React.Component<IIATAAgencyListProps, any> {
    private _onClickAgencyDetails = () => {
        if(this.props.list.selection.selectionCount === 1 && this.props.onItemInvoked) {
            this.props.onItemInvoked(this.props.list.selection.selectedItems[0]);
        }
    };
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "IATA Agencies", viewOptions: { fromFilterHidden: true, toFilterHidden: true } }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "agency" })
        ];
        const farItems : IContextualMenuItem[] = [
            {
                key: "agencyDetails",
                name: "Agency Details",
                iconProps: { iconName: "ZoomIn"},
                onClick: this._onClickAgencyDetails,
                disabled: !this.props.onItemInvoked || this.props.list.selection.selectionCount !== 1
            },
            createViewPreferencesMenuItem(IATAAgenciesViewPrefsStore, IATAAgencyColumns)
        ];
        return <CommandBar className="entity-source-list-command-bar iata-agency-list-command-bar" items={items} farItems={farItems} />;
    }
}

class IATAAgencyList extends React.Component<IIATAAgencyListProps, any> {
    private _onRenderMenu = () => {
        return <IATAAgencyListCommandBar {...this.props} />;
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <IATAAgencyDetailsList {...this.props} viewPreferences={IATAAgenciesViewPrefsStore} />
            </AppView>
        );
    }
}

class IATAAgencyListContainer extends React.Component<IIATAAgencyListProps, any> {
    private _onRenderDone = () => {
       return <IATAAgencyList {...this.props} />;
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading IATA Agencies..." />;
    }
}

class IATAAgencyListApp extends EntitySourceApp {
    private _onItemInvoked = (item : IIATAAgency) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.iataAgencyDetails(),
            query: {
                iataTravelAgencyCode: item.iataTravelAgencyCode,
                iataTravelAgencyCheckDigit: item.iataTravelAgencyCheckDigit
            },
            iataAgency: item,
            panelProps: panelProps
        };
    }
    protected _onRenderSource = (props) => {
        return <IATAAgencyListContainer list={getEntityAgencyList(props.masterEntity)} onItemInvoked={this._onItemInvoked} />;
    }
}

export {
    IATAAgencyList,
    IATAAgencyListContainer,
    IIATAAgencyListProps,
    IATAAgencyListApp,
    IATAAgencyListApp as default
}