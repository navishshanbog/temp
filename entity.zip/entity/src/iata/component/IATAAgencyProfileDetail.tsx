import * as React from "react";
import "./IATAAgencyDetail.scss";
import {IATAAgencyDetailsItems} from "./IATAAgencyDetail";
import ListModel from "@twii/common/lib/model/ListModel";
import IIATAAgencyDetail from "../IIATAAgencyDetail";

class IATAAgencyProfileDetail extends React.Component<any, any> {
    get model() {
        const m = new ListModel<IIATAAgencyDetail>();
        const items = this.props.match.items;
        if(items && items.length > 0) {
            const subItems = items[0].subItems;
            if(subItems) {
                m.items = subItems;
            }
        }
        m.sync.syncEnd();
        return m;
    }
    render() {
        return (
            <div className="iata-agency-details-body details-panel">
                <IATAAgencyDetailsItems model={this.model} />
            </div>
        );
    }
}


export{ IATAAgencyProfileDetail as default, IATAAgencyProfileDetail };