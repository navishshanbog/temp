import MasterEntityModel from "../../entity/MasterEntityModel";
import SeaCargoServiceContext from "./SeaCargoServiceContext";
import MockSeaCargoService from "./MockSeaCargoService";
import * as CargoConstants from "../CargoConstants";
import { getEntityActivityList } from "./SeaCargoActivityHelper";
import { toPromise } from "@twii/common/lib/SyncUtils";

describe("Master Entity Sea Cargo Activity List Model", () => {
    test("test set master entity", async () => {
        const e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: CargoConstants.sourceSystemCode,
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "1"
                            }
                        }
                    ]
                }
            ]
        });

        expect(e.sourceCodes.length).toBe(1);
        expect(e.sourceCodes[0]).toBe(CargoConstants.sourceSystemCode);

        const testSeaCargoService = new MockSeaCargoService();
        testSeaCargoService.getSeaCargoActivitiesResponse = [
            {
                
                "clientInstanceId": "83978121134910",
                "documentType": "SCR",
                "originalMsgId": "2015-02-18 16:47:09.172235",
                "clientRoleTypeList": "Reporter",
                "searchArrivalDate": "2015-02-21",
                "vesselId": "9270452",
                "vesselName": "YARD NO.1264A HUDONG ZHONGHUA",
                "oceanBillNbr": "HKGSYD400609",
                "houseBillNbr": "3380",
                "consigneeAddress": "52A PIPER ST LILYFIELD 2040 AU",
                "consigneeClientId": "288332907469405",
                "consigneeName": "STEPHEN MING - CHIU SZE",
                "consignorAddress": null,
                "consignorClientId": "40160322481227",
                "consignorName": null,
                "parentBillLadingNbr": "",
                "originalLoadingPortCode": "HKHKG",
                "goodsDescr": "PERSONAL EFFECTS",
                "grossWeight": "200.00",
                "grossWeightUnit": "KG",
                "stsCargoStatusCode": null,
                "decTotalCval": null,
                "examCount": 1,
                "examIndicator": "Y",
                "examFindResultCode": "FIREARM",
                "positiveFindInd": "Y",
                "examFindCount": 2
        }
                
        ]
        testSeaCargoService.recordRequests = true;

        SeaCargoServiceContext.value = testSeaCargoService;

        expect(SeaCargoServiceContext.value).toBe(testSeaCargoService);
        
        const activityListModel = getEntityActivityList(e);
        expect(activityListModel.entity).toBe(e);

        await toPromise(activityListModel.sync);

        expect(testSeaCargoService.getSeaCargoActivitiesRequests.length).toBe(1);

        const r = testSeaCargoService.getSeaCargoActivitiesRequests[0];

        expect(r.parentId).toBe("1");

        expect(activityListModel.items.length).toBe(testSeaCargoService.getSeaCargoActivitiesResponse.length);

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply a filter
       // e.activityFilter.setFilterText("030S");

        expect(activityListModel.itemsView.length).toBe(1);
        expect(activityListModel.itemsView[0].originalMsgId).toBe("2015-02-18 16:47:09.172235");

        activityListModel.filter.setFilterText("noChance");

        expect(activityListModel.itemsView.length).toBe(0);

        e.activityFilter.clear();
        activityListModel.filter.clear();

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);
    });

});