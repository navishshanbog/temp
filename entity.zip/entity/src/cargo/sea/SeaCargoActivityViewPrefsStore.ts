import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const SeaCargoActivityViewPrefsStore = new ViewPreferencesModel("seaCargoActivity");

export { SeaCargoActivityViewPrefsStore as default, SeaCargoActivityViewPrefsStore }