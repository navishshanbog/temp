import axios from "axios";
import { ISeaCargoService, ISeaCargoActivitiesGetRequest, ISeaCargoDetailsGetRequest } from "./ISeaCargoService";
import ISeaCargoActivity from "./ISeaCargoActivity";
import ISeaCargoActivityDetail from "./ISeaCargoActivityDetail";
import AbstractRestDataService from "../../common/AbstractRestDataService";
import * as DefaultHttpErrorHandler from "@twii/common/lib/HttpErrorHandler";
import { IServiceResponseStatus } from "../../common/IServiceResponseStatus";

const DEFAULT_MAX_NO_RECORDS = 200;
const EXAM_COUNT_IND = "Y";

interface ISeaCargoSummary {
    teradataResponse?: IServiceResponseStatus;
    numRows?: number;
    hasMoreRows?: boolean;
    data?: ISeaCargoActivity[];
}

interface GetActivitiesRestResponse {
    error?: any;
    getSeaCargoSummary?: ISeaCargoSummary;
}

interface ISeaCargoDetailed {
    teradataResponse?: IServiceResponseStatus;
    numRows?: number;
    hasMoreRows?: boolean;
    data?: ISeaCargoActivityDetail[];
}

interface GetActivityDetailsRestResponse {
    error?: any;
    getSeaCargoDetailed?: ISeaCargoDetailed;
}

class RestSeaCargoService extends AbstractRestDataService implements ISeaCargoService {
    getSeaCargoActivities(request : ISeaCargoActivitiesGetRequest) : Promise<ISeaCargoActivity[]> {
        return axios.get(`${this.config.baseUrl}/ics/resources/v1/seaCargo/${encodeURIComponent(request.parentId)}`, {
            params: { maxNoOfRecords: request.maxNumberOfRecords > 0 ? request.maxNumberOfRecords : DEFAULT_MAX_NO_RECORDS, orderByExamCountInd: request.orderByExamCountInd !== undefined ? request.orderByExamCountInd ? "Y" : "N" : EXAM_COUNT_IND }
        }).then(value => {
            const response = value.data as GetActivitiesRestResponse;
            if(response.error) {
                return this.handleError(response.error);
            }
            return response.getSeaCargoSummary && response.getSeaCargoSummary.data ? response.getSeaCargoSummary.data : [];
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
    getSeaCargoActivityDetails(request : ISeaCargoDetailsGetRequest) : Promise<ISeaCargoActivityDetail[]> {
        return axios.get(`${this.config.baseUrl}/ics/resources/v1/seaCargoDetailed/${encodeURIComponent(request.parentId)}`, {
            params: { oceanBillNum: request.oceanBillNbr, maxNoOfRecords: request.maxNumberOfRecords > 0 ? request.maxNumberOfRecords : DEFAULT_MAX_NO_RECORDS, orderByExamCountInd: request.orderByExamCountInd !== undefined ? request.orderByExamCountInd ? "Y" : "N" : EXAM_COUNT_IND }
        }).then(value => {
            const response = value.data as GetActivityDetailsRestResponse;
            if(response.error) {
                return this.handleError(response.error);
            }
            return response.getSeaCargoDetailed && response.getSeaCargoDetailed.data ? response.getSeaCargoDetailed.data : [];
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

export { RestSeaCargoService };