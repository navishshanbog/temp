import { IEntityActivity } from "../../entity/IEntityActivity";
import { ISeaCargoActivity } from "./ISeaCargoActivity";

interface IEntitySeaCargoActivity extends IEntityActivity, ISeaCargoActivity {}

export { IEntitySeaCargoActivity }