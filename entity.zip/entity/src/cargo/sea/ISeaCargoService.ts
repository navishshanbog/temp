import ISeaCargoActivity from "./ISeaCargoActivity";
import ISeaCargoActivityDetail from "./ISeaCargoActivityDetail";

interface ISeaCargoGetRequest {
    maxNumberOfRecords?: number;
    orderByExamCountInd?: boolean;
}

interface ISeaCargoActivitiesGetRequest extends ISeaCargoGetRequest {
    parentId: string;
}

interface ISeaCargoDetailsGetRequest extends ISeaCargoGetRequest {
    parentId: string;
    oceanBillNbr: string;
}

interface ISeaCargoService {
    getSeaCargoActivities(request : ISeaCargoActivitiesGetRequest) : Promise<ISeaCargoActivity[]>;
    getSeaCargoActivityDetails(request : ISeaCargoDetailsGetRequest) : Promise<ISeaCargoActivityDetail[]>;
}

export {
    ISeaCargoService,
    ISeaCargoActivitiesGetRequest,
    ISeaCargoDetailsGetRequest,
    ISeaCargoGetRequest
};