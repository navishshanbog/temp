import { ISeaCargoService, ISeaCargoActivitiesGetRequest, ISeaCargoDetailsGetRequest } from "./ISeaCargoService";
import ISeaCargoActivity from "./ISeaCargoActivity";
import ISeaCargoActivityDetail from "./ISeaCargoActivityDetail";

class MockSeaCargoService implements ISeaCargoService {
    recordRequests: boolean = false;
    delay: number = 4000;
    getSeaCargoActivitiesResponse: ISeaCargoActivity[] = [
        {
                "clientInstanceId": "83978121134910",
                "documentType": "SCR",
                "originalMsgId": "2015-02-18 16:47:09.172235",
                "clientRoleTypeList": "Reporter",
                "searchArrivalDate": "2015-02-21",
                "vesselId": "9270452",
                "vesselName": "YARD NO.1264A HUDONG ZHONGHUA",
                "oceanBillNbr": "HKGSYD400609",
                "houseBillNbr": "3380",
                "consigneeAddress": "52A PIPER ST LILYFIELD 2040 AU",
                "consigneeClientId": "288332907469405",
                "consigneeName": "STEPHEN MING - CHIU SZE",
                "consignorAddress": null,
                "consignorClientId": "40160322481227",
                "consignorName": null,
                "parentBillLadingNbr": "",
                "originalLoadingPortCode": "HKHKG",
                "goodsDescr": "PERSONAL EFFECTS",
                "grossWeight": "200.00",
                "grossWeightUnit": "KG",
                "stsCargoStatusCode": null,
                "decTotalCval": null,
                "examCount": 1,
                "examIndicator": "Y",
                "examFindResultCode": "FIREARM",
                "positiveFindInd": "Y",
                "examFindCount": 2
        }
           
    ];
    getSeaCargoActivityDetailResponse: ISeaCargoActivityDetail[] = [
        {
                "clientInstanceId": "83978121134910",
                "documentType": "SCR",
                "originalMsgId": "2015-02-18 16:47:09.17223",
                "clientRoleTypeList": "Reporter",
                "lineId": "2015-02-18 16:47:09.212993",
                "consignmentClearanceType": "Informal Clearance",
                "searchArrivalDate": "2015-02-21",
                "vesselId": "9270452",
                "vesselName": "YARD NO.1264A HUDONG ZHONGHUA",
                "voyageNbr": "0170S",
                "withdrawnInd": "N",
                "withdrawnAEST": null,
                "cargoType": "LCL",
                "containerNbr": "TEMU3820605",
                "destinationPortCode": "AUSYD",
                "destination_AUStateCode": "NSW",
                "dischargePortCode": "AUSYD",
                "discharge_AUStateCode": "NSW",
                "lineCount": 1,
                "oceanBillNbr": "HKGSYD400609",
                "originalLoadingPortCode": "HKHKG",
                "packageCount": 7,
                "packageType": "PK",
                "reporting_ClientAddress": null,
                "reportingClientName": null,
                "reportingClientPostcode": null,
                "reportingClientStateCode": null,
                "responsibleClientAddress": null,
                "responsibleClientName": null,
                "responsibleClientPostcode": null,
                "responsibleClientStateCode": null,
                "seaActualArrivalAEST": "2015-02-21 12:48:00.0",
                "seaActualArrivalBerthCode": "AUSYDBD11",
                "seaActualArrivalReportingId": "45085663154",
                "seaImpendingArrivalEstablishedETAAEST": "2015-02-21 11:06:00.0",
                "seaImpendingArrivalEstablishedETALocTs": "2015-02-21 12:06:00.0",
                "seaImpendingArrivalFirstPortCode": "AUSYD",
                "seaImpendingArrivalFirstPortETAAEST": "2015-02-21 11:06:00.0",
                "seaImpendingArrivalEstablishedLastOSPortCode": "HKHKG",
                "xraySendRequirermentInd": "N",
                "freightForwardInd": "N",
                "houseBillNbr": "3383",
                "lowestBillInd": "Y",
                "oceanDischargeAUState": "NSW",
                "oceanDischargePortCode": "AUSYD",
                "consigneeAddress": "25 MORAWA DRIVE MULGRAVE 3170 AU",
                "consigneeName": "LAI NGA CANDY WONG",
                "consigneePostcode": null,
                "consigneeStateCode": null,
                "consigneeContactPhone": null,
                "consignorAddress": null,
                "consignorName": null,
                "consignorPostcode": null,
                "consignorStateCode": null,
                "notifyAddress": null,
                "notifyName": null,
                "notifyPostcode": null,
                "notifyStateCode": null,
                "originCountryCode": "HK",
                "originPortCode": "HKHKG",
                "firstPortAUStateCode": null,
                "firstPortCode": "",
                "goodsCountryOriginCode": "HK",
                "parentBillLadingNbr": "",
                "principalAgentAddress": null,
                "principalAgentName": null,
                "principalAgentPostcode": null,
                "principalAgentStateCode": null,
                "containerType": "GENN",
                "fumigationInd": "N",
                "goodsDescr": "PERSONAL EFFECTS",
                "grossWeight": "315.00",
                "grossWeightUnit": "KG",
                "hazardousGoodsInd": "N",
                "perishableGoodsInd": "N",
                "personalEffectsInd": "Y",
                "reportableDocumentsInd": "N",
                "sealNbr": "T443700",
                "selfAssessedClearanceInd": "N",
                "shipperOwnedInd": "N",
                "transhipmentNbr": "",
                "examCount": 1,
                "examIndicator": "Y",
                "examFindCount": 2,
                "examFindResultCode": "FIREARM",
                "examFindSigCount": 0,
                "positiveFindInd": "Y"
        }
    ];
    getSeaCargoActivitiesRequests: ISeaCargoActivitiesGetRequest[] = [];
    getSeaCargoActivityDetailRequests: ISeaCargoDetailsGetRequest[] = [];
    getSeaCargoActivities(request : ISeaCargoActivitiesGetRequest) : Promise<ISeaCargoActivity[]> {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if(this.recordRequests) {
                    this.getSeaCargoActivitiesRequests.push(request);
                }
                resolve(this.getSeaCargoActivitiesResponse);
            }, this.delay);
        });
    }
    getSeaCargoActivityDetails(request : ISeaCargoDetailsGetRequest) : Promise<ISeaCargoActivityDetail[]> {
        console.log("-- Mock: Sea Cargo Activity Details Request: " + JSON.stringify(request));
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if(this.recordRequests) {
                    this.getSeaCargoActivityDetailRequests.push(request);
                }
                return resolve(this.getSeaCargoActivityDetailResponse);
            }, this.delay);
        });
    }
}

export { MockSeaCargoService as default, MockSeaCargoService }