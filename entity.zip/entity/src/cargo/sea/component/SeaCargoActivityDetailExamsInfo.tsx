import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import ISeaCargoActivityDetail from "../ISeaCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./SeaCargoActivityDetailExamsInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { Sync } from "@twii/common/lib/component/Sync";

const Fields: IColumn[] = [{ //IDetailsAttributeConfig<ISeaCargoActivityDetail> [] = [{
    key: "examCount",
    name: "Exams Count:",
    fieldName: "examCount",
    minWidth: 50,
    isMultiline: true
},
{
    key: "examFindResultCode",
    name: "Find Result:",
    fieldName: "examFindResultCode",
    minWidth: 50,
    isMultiline: true
       
},
{
    key: "examFindCount",
    name: "Exam Finds:",
    fieldName: "examFindCount",
    minWidth: 50,
    isMultiline: true
        
},
{
    key: "examFindSigCount",
    name: "Significant Finds:",
    fieldName: "examFindSigCount",
    minWidth: 50,
    isMultiline: true
                   
}]

interface ISeaCargoActivityDetailExamsInfoProps {
    model?: IListModel<ISeaCargoActivityDetail>;
}

const SeaCargoActivityDetailExamsInfoViewPrefsStore = new ViewPreferencesModel("seaCargoActivityDetailExamsInfo");

class SeaCargoActivityDetailExamsInfo extends React.Component<ISeaCargoActivityDetailExamsInfoProps, any> {

    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: ISeaCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailExamsInfoViewPrefsStore} />;

            });
            
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load exams infomation details</MessageBar>;
        }
        return <div className="sea-cargo-activity-detail-exams-info">{content}</div>;
    }
}

class SeaCargoActivityDetailExamsInfoContainer extends React.Component<ISeaCargoActivityDetailExamsInfoProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetailExamsInfo {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} />;
    }
}

@observer
class SeaCargoActivityDetailExamsInfoList extends React.Component<ISeaCargoActivityDetailExamsInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                        summary={<div>{"Exams Infomation"} </div>}
                        open={true}
                        controlOnHeaderClick={true}
                        headerClassName={css("sea-cargo-activity-details-exams-info-header")}
                        bodyClassName={css("sea-cargo-activity-details-exams-info-body")}>
                        <CommandBar items={[]} farItems={[
                            createViewPreferencesMenuItem(SeaCargoActivityDetailExamsInfoViewPrefsStore, Fields)]} />
                        <SeaCargoActivityDetailExamsInfoContainer {...this.props} />

            </Details>
        );
    }
}


export {
    SeaCargoActivityDetailExamsInfoList as default,
    SeaCargoActivityDetailExamsInfoList,
    SeaCargoActivityDetailExamsInfoContainer,
    SeaCargoActivityDetailExamsInfo,
    ISeaCargoActivityDetailExamsInfoProps,
    Fields as SeaCargoExamsInfoFields,
    SeaCargoActivityDetailExamsInfoViewPrefsStore
}