import * as React from "react";
import ISeaCargoActivity from "../ISeaCargoActivity";
import IMasterEntitySourceListModel from "../../../entity/IMasterEntitySourceListModel";
import SeaCargoActivityColumns, { OceanBillNbr } from "./SeaCargoActivityColumns";
import MasterEntitySourceDetailsList from "../../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import { Link } from "office-ui-fabric-react/lib/Link";
import { IColumn } from "office-ui-fabric-react/lib/DetailsList";

interface ISeaCargoActivityDetailsListProps {
    list: IMasterEntitySourceListModel<ISeaCargoActivity>;
    viewPreferences?: IViewPreferencesModel;
    onItemInvoked?: (item : ISeaCargoActivity, index : number) => void;
}

interface ISeaCargoActivityDetailsListItemProps extends ISeaCargoActivityDetailsListProps {
    item: ISeaCargoActivity;
    itemIndex: number;
}

class OceanBillNumberLink extends React.Component<ISeaCargoActivityDetailsListItemProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.preventDefault();
        this.props.onItemInvoked(this.props.item, this.props.itemIndex);
    }
    render() {
        return <Link onClick={this._onClick}>{String(this.props.item.oceanBillNbr)}</Link>;
    }
}

class SeaCargoActivityDetailsList extends React.Component<ISeaCargoActivityDetailsListProps, any> {
    private _onRenderOceanBillNumber = (item : ISeaCargoActivity, idx : number) => {
        return <OceanBillNumberLink {...this.props} item={item} itemIndex={idx} />;
    }
    render() {
        let columns : IColumn[];
        if(this.props.onItemInvoked) {
            columns = [].concat(SeaCargoActivityColumns);
            const colIdx = columns.findIndex(c => c.key === OceanBillNbr.key);
            columns[colIdx] = Object.assign({}, columns[colIdx], {
                onRender: this._onRenderOceanBillNumber 
            });
        } else {
            columns = SeaCargoActivityColumns;
        }
        return <MasterEntitySourceDetailsList
                    columns={columns}
                    list={this.props.list}
                    typeLabel="Sea Cargo Activities"
                    itemType="activity/sea"
                    viewPreferences={this.props.viewPreferences}
                    onItemInvoked={this.props.onItemInvoked} />;
    }
}

export { SeaCargoActivityDetailsList as default, SeaCargoActivityDetailsList, ISeaCargoActivityDetailsListProps }