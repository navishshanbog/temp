import * as React from "react";
import { observer } from "mobx-react";
import "./SeaCargoActivityDetail.scss";
import SeaCargoActivityDetailsGoodsInfoList from "./SeaCargoActivityDetailGoodsInfo";
import SeaCargoActivityDetailContactInfoList from "./SeaCargoActivityDetailContactInfo";
import SeaCargoActivityDetailExamsInfoList from "./SeaCargoActivityDetailExamsInfo";
import SeaCargoActivityDetailGoodsIndList from "./SeaCargoActivityDetailGoodsIndicator";
import {SeaCargoActivityDetailCargoReport} from "./SeaCargoActivityDetailCargoReport";
import {createCopyForCargoActivities} from "../../component/EntityCargoSubActivityHelper";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import ISeaCargoActivityDetail from "../ISeaCargoActivityDetail";
import { AppView } from "@twii/common/lib/component/AppView";
import { EntityAppBase } from "../../../common/component/EntityAppBase";
import ListModel from "@twii/common/lib/model/ListModel";
import SeaCargoServiceContext from "../SeaCargoServiceContext";
import { EntityAppView } from "../../../common/component/EntityAppView";
import { IEntitySeaCargoActivity } from "../IEntitySeaCargoActivity";

interface ISeaCargoActivityDetailProps {
    model?: IListModel<ISeaCargoActivityDetail>;
}

@observer
class SeaCargoActivityDetailCommandBar extends React.Component<ISeaCargoActivityDetailProps, any> {
    private _onCopyCargoReport = (e : React.MouseEvent<HTMLAnchorElement>) => {
        createCopyForCargoActivities(this.props.model, "sea/cargoReport", "activity/sea", "Sea",e);
    }
    render() {
        const items : IContextualMenuItem[] = [
            {
                key: "copyReport",
                name: "Copy",
                iconProps: {
                    iconName: "Copy"
                },
                onClick: this._onCopyCargoReport,
                disabled: this.props.model.sync.syncing || this.props.model.sync.error
            }
        ];
        return (
            <CommandBar items={items} />
        );
    }
}

@observer
class SeaCargoActivityDetail extends React.Component<ISeaCargoActivityDetailProps, any> {
    private _onRenderMenu = () => {
        return <SeaCargoActivityDetailCommandBar {...this.props} />;
    }
    componentWillMount() {
        this.props.model.load();
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <div style={{ padding: 8}}>
                    <SeaCargoActivityDetailCargoReport {...this.props}/>
                    <SeaCargoActivityDetailsGoodsInfoList {...this.props} />
                    <SeaCargoActivityDetailContactInfoList {...this.props} />
                    <SeaCargoActivityDetailGoodsIndList {...this.props} />
                    <SeaCargoActivityDetailExamsInfoList {...this.props} />
                </div>
            </AppView>
        );
    }
}

class SeaCargoActivityDetailApp extends EntityAppBase {
    get activity() : IEntitySeaCargoActivity {
        if(this.props.match.seaCargoActivity) {
            return this.props.match.seaCargoActivity;
        }
        return this.props.match.params as IEntitySeaCargoActivity;
    }
    componentWillMount() {
        this.host.setTitle("Sea Cargo Activity Details Report");
    }
    get detail() : IListModel<ISeaCargoActivityDetail> {
        return this.host.getState("seaCargoActivityDetails", () => {
            const m = new ListModel<ISeaCargoActivityDetail>();
            m.parent = this.activity;
            m.loader = () => {
                return SeaCargoServiceContext.value.getSeaCargoActivityDetails({ parentId: this.activity.clientInstanceId, oceanBillNbr: this.activity.oceanBillNbr });
            };
            return m;
        }, m => m.parent.clientInstanceId !== this.activity.clientInstanceId || m.parent.oceanBillNbr !== this.activity.oceanBillNbr);
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker >
                <SeaCargoActivityDetail model={this.detail} />
            </EntityAppView>
        );
    }
}

export {
    SeaCargoActivityDetail,
    ISeaCargoActivityDetailProps,
    SeaCargoActivityDetailApp,
    SeaCargoActivityDetailApp as default
};