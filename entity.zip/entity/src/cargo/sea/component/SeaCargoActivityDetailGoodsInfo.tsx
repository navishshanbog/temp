import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import ISeaCargoActivityDetail from "../ISeaCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./SeaCargoActivityDetailGoodsInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { Sync } from "@twii/common/lib/component/Sync";
import { IListModel } from "@twii/common/lib/model/IListModel";

const Fields: IColumn[] = [{  // IDetailsAttributeConfig<ISeaCargoActivityDetail> [] = [{
    key: "goodsDescr",
    name: "Goods description:",
    fieldName: "goodsDescr",
    minWidth: 50,
    isMultiline: true
},
    {
        key: "vesselName",
        name: "Vessel & Voyage:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.vesselName) + (" (ID: ") + (item.vesselId) + ("), ") + (item.voyageNbr)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.vesselName} (ID: ${item.vesselId}), ${item.voyageNbr}`},
        fieldName: "vesselName",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "cargoType",
        name: "Cargo Type:",
        fieldName: "cargoType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "sealNbr",
        name: "Seal number:",
        fieldName: "sealNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "originPortCode",
        name: "Origin Port:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.originPortCode) + (", ") + (item.originCountryCode)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.originPortCode}, ${item.originCountryCode}`},
        fieldName: "originPortCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "destinationPortCode",
        name: "Destination:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.destinationPortCode) + (", ") + (item.destination_AUStateCode)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.destinationPortCode}, ${item.destination_AUStateCode}`},
        fieldName: "destinationPortCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "packageCount",
        name: "Package Count & Type:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.packageCount) + (" (") + (item.packageType) + (")")}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.packageCount} (${item.packageType})`},
        fieldName: "packageCount",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "seaActualArrivalAEST",
        name: "Actual arrival time (AEST):",
        fieldName: "seaActualArrivalAEST",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "transhipmentNbr",
        name: "Transhipment number:",
        fieldName: "transhipmentNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "grossWeight",
        name: "Gross Weight:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.grossWeight) + (" ") + (item.grossWeightUnit)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.grossWeight} ${item.grossWeightUnit}`},
        fieldName: "grossWeight",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "withdrawnInd",
        name: "Withdrawn:",
        onRender: function (item: ISeaCargoActivityDetail) {
            if((item.withdrawnAEST != null) && (item.withdrawnAEST != "")) {
                return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.withdrawnInd) + (" - ") + (item.withdrawnAEST)}/>;
            }
            else {
                return <DetailsAttribute key={this.key} label={this.name} value={(item.withdrawnInd)} />;
            }
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.withdrawnInd} - ${item.withdrawnAEST}`},
        fieldName: "withdrawnInd",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "containerNbr",
        name: "Container Number and Type:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.containerNbr) + (" , ") + (item.containerType)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.containerNbr} , ${item.containerType}`},
        fieldName: "containerNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "goodsCountryOriginCode",
        name: "Goods origin:",
        fieldName: "goodsCountryOriginCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "seaImpendingArrivalEstablishedLastOSPortCode",
        name: "Last Overseas Port:",
        fieldName: "seaImpendingArrivalEstablishedLastOSPortCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "dischargePortCode",
        name: "Discharge location:",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.dischargePortCode) + (", ") + (item.discharge_AUStateCode)}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.dischargePortCode} , ${item.discharge_AUStateCode}`},
        fieldName: "dischargePortCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "seaImpendingArrivalEstablishedETAAEST",
        name: "Estimated first port arrival (AEST):",
        onRender: function (item: ISeaCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={(item.seaImpendingArrivalEstablishedETAAEST || "") + (" (") + (item.seaImpendingArrivalFirstPortCode) + (")")}/>;
        },
        data: {getText: (item: ISeaCargoActivityDetail) => `${item.seaImpendingArrivalEstablishedETAAEST || ""} (${item.seaImpendingArrivalFirstPortCode})`},
        fieldName: "seaImpendingArrivalEstablishedETAAEST",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "seaActualArrivalBerthCode",
        name: "Arrival Berth:",
        fieldName: "seaActualArrivalBerthCode",
        minWidth: 50,
        isMultiline: true
    }];

interface ISeaCargoActivityDetailsGoodsInfoProps {
    model?: IListModel<ISeaCargoActivityDetail>;
}

const SeaCargoActivityDetailsGoodsInfoViewPrefStore = new ViewPreferencesModel("seaCargoActivityDetailsGoodsInfo");

class SeaCargoActivityDetailsGoodsInfo extends React.Component<ISeaCargoActivityDetailsGoodsInfoProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: ISeaCargoActivityDetail, idx: number) => {
            return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsGoodsInfoViewPrefStore} />;
        });

        } else {
            content = <MessageBar messageBarType={MessageBarType.info}> Failed to load details</MessageBar>;

        }
        return <div className="sea-cargo-activity-details-goods-info"> {content} </div>;

    }
}

class SeaCargoActivityDetailsGoodsInfoContainer extends React.Component<ISeaCargoActivityDetailsGoodsInfoProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetailsGoodsInfo {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea Cargo Details Goods and voyage information..." />;
    }

}

@observer
class SeaCargoActivityDetailsGoodsInfoList extends React.Component<ISeaCargoActivityDetailsGoodsInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Goods and voyage information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("sea-cargo-activity-details-goods-info-header")}
                         bodyClassName="sea-cargo-activity-details-goods-info-body">
                        <CommandBar items={[]} farItems={[
                            createViewPreferencesMenuItem(SeaCargoActivityDetailsGoodsInfoViewPrefStore, Fields)]} />
                         <SeaCargoActivityDetailsGoodsInfoContainer {...this.props} />
            </Details>
        );
    }
}

export {
    SeaCargoActivityDetailsGoodsInfoList as default,
    SeaCargoActivityDetailsGoodsInfoList,
    SeaCargoActivityDetailsGoodsInfoContainer,
    SeaCargoActivityDetailsGoodsInfo,
    ISeaCargoActivityDetailsGoodsInfoProps,
    Fields as SeaCargoGoodsInfoFields,
    SeaCargoActivityDetailsGoodsInfoViewPrefStore

}