import * as React from "react";
import {SeaCargoActivityDetailsContainer} from "./SeaCargoActivityDetailCargoReport";
import "./SeaCargoActivityDetailCargoReport.scss";
import {SeaCargoActivityDetailsGoodsInfoContainer} from "./SeaCargoActivityDetailGoodsInfo";
import "./SeaCargoActivityDetailGoodsInfo.scss";
import {SeaCargoActivityDetailExamsInfoContainer} from "./SeaCargoActivityDetailExamsInfo";
import {SeaCargoActivityDetailsContactInfoContainer} from "./SeaCargoActivityDetailContactInfo";
import "./SeaCargoActivityDetailContactInfo.scss";
import {SeaCargoActivityDetailGoodsIndContainer} from "./SeaCargoActivityDetailGoodsIndicator";
import "./SeaCargoActivityDetailGoodsIndicator.scss";
import "./SeaCargoActivityDetailExamsInfo.scss";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { ListModel } from "@twii/common/lib/model/ListModel";

class SeaCargoActivityDetailProfileInfo extends React.Component<IAppProps, any> {
    get model() {
        const m = new ListModel();
        const items = this.props.match.items;
        if(items && items.length > 0) {
            const subItems = items[0].subItems;
            if(subItems) {
                m.setItems(subItems);
            }
        }
        m.sync.syncEnd();
        return m;
    }
    render() {
        return (
            <div key="seaCargo">
                <div className="sea-cargo-activity-details-cargo-report-body details-panel">
                    <SeaCargoActivityDetailsContainer model={this.model} />
                </div>
                <div className="sea-cargo-activity-details-goods-info-body details-panel">
                    <SeaCargoActivityDetailsGoodsInfoContainer model={this.model} />
                </div>
                <div className="sea-cargo-activity-details-contact-info-body details-panel">
                    <SeaCargoActivityDetailsContactInfoContainer model={this.model} />
                </div>
                <div className="sea-cargo-activity-details-goods-ind-body details-panel">
                    <SeaCargoActivityDetailGoodsIndContainer model={this.model} />
                </div>
                <div className="sea-cargo-activity-details-exams-info-body details-panel">
                    <SeaCargoActivityDetailExamsInfoContainer model={this.model} />
                </div>
            </div>
        );
    }
}

export {
    SeaCargoActivityDetailProfileInfo as default,
    SeaCargoActivityDetailProfileInfo
}