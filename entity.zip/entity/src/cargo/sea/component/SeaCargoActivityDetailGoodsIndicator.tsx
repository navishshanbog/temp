import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import ISeaCargoActivityDetail from "../ISeaCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./SeaCargoActivityDetailGoodsIndicator.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { Sync } from "@twii/common/lib/component/Sync";

const getFullValText = (item: string) => {
	let fullValText;
	if (item === "Y") {
            fullValText = "Yes";
        }
        else if (item === "N") {
            fullValText = "No";
        }
        else {
            fullValText = item;
        }
	return fullValText;
}

const Fields: IColumn[] = [{ // IDetailsAttributeConfig<ISeaCargoActivityDetail>[] = [{
    key: "freightForwardInd",
    name: "Freight forward:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.freightForwardInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.freightForwardInd)},
    fieldName: "freightForwardInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "lowestBillInd",
    name: "Lowest Bill:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.lowestBillInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.lowestBillInd)},
    fieldName: "lowestBillInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "perishableGoodsInd",
    name: "Perishable Goods:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.perishableGoodsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.perishableGoodsInd)},
    fieldName: "perishableGoodsInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "reportableDocumentsInd",
    name: "Reportable Documents:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.reportableDocumentsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.reportableDocumentsInd)},
    fieldName: "reportableDocumentsInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "shipperOwnedInd",
    name: "Shipper Owned:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.shipperOwnedInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.shipperOwnedInd)},
    fieldName: "shipperOwnedInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "xraySendRequirermentInd",
    name: "X-ray Requirement:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.xraySendRequirermentInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.xraySendRequirermentInd)},
    fieldName: "xraySendRequirermentInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "hazardousGoodsInd",
    name: "Hazardous Goods:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.hazardousGoodsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.hazardousGoodsInd)},
    fieldName: "hazardousGoodsInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "personalEffectsInd",
    name: "Personal Effects:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.personalEffectsInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.personalEffectsInd)},
    fieldName: "personalEffectsInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "selfAssessedClearanceInd",
    name: "Self-Assessed Clearance:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.selfAssessedClearanceInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.selfAssessedClearanceInd)},
    fieldName: "selfAssessedClearanceInd",
    minWidth: 50,
    isMultiline: true
},
{
    key: "positiveFindInd",
    name: "Positive Exam Find:",
    onRender: function(item: ISeaCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.positiveFindInd)} />; 
    },
    data: {getText: (item: ISeaCargoActivityDetail) => getFullValText(item.positiveFindInd)},
    fieldName: "positiveFindInd",
    minWidth: 50,
    isMultiline: true
}]

interface ISeaCargoActivityDetailGoodsIndProps {
    model?: IListModel<ISeaCargoActivityDetail>;
}

const SeaCargoActivityDetailGoodsIndViewPrefsStore = new ViewPreferencesModel("seaCargoActivityDetailGoodInd");

class  SeaCargoActivityDetailGoodsInd extends React.Component<ISeaCargoActivityDetailGoodsIndProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: ISeaCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailGoodsIndViewPrefsStore} />;
            });

        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load detail</MessageBar>;
        }
        return <div className="sea-cargo-activity-details-goods-ind">{content} </div>;
    }
} 

class SeaCargoActivityDetailGoodsIndContainer extends React.Component<ISeaCargoActivityDetailGoodsIndProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetailGoodsInd {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea Cargo Details Goods Indicator information..." />;
    }
}
@observer

class SeaCargoActivityDetailGoodsIndList extends React.Component<ISeaCargoActivityDetailGoodsIndProps, any> {
    render() {
        return (
             <Details className={css("details-panel")}
                        summary={<div>{"Goods Indicators"}</div>}
                        open={true}
                        controlOnHeaderClick={true}
                        headerClassName={css("sea-cargo-activity-details-goods-ind-header")}
                        bodyClassName={css("sea-cargo-activity-details-goods-ind-body")}>
                        <CommandBar items={[]} farItems={[
                            createViewPreferencesMenuItem(SeaCargoActivityDetailGoodsIndViewPrefsStore, Fields)]} />
                        <SeaCargoActivityDetailGoodsIndContainer {...this.props} />
             </Details>
        );
    }
}

export { 
    SeaCargoActivityDetailGoodsIndList as default,
    SeaCargoActivityDetailGoodsIndList,
    SeaCargoActivityDetailGoodsIndContainer,
    SeaCargoActivityDetailGoodsInd,
    ISeaCargoActivityDetailGoodsIndProps,
    Fields as SeaCargoDetailGoodsIndFields,
    SeaCargoActivityDetailGoodsIndViewPrefsStore
};