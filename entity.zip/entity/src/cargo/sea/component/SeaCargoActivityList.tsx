import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import SeaCargoActivityDetailsList from "./SeaCargoActivityDetailsList";
import IMasterEntitySourceListModel from "../../../entity/IMasterEntitySourceListModel";
import ISeaCargoActivity from "../ISeaCargoActivity";
import SeaCargoActivityColumns from "./SeaCargoActivityColumns";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { Sync } from "@twii/common/lib/component/Sync";
import { createCopyToClipboardItem } from "../../../entity/component/MasterEntitySourceHelper";
import SeaCargoActivityViewPrefsStore from "../SeaCargoActivityViewPrefsStore";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { AppView } from "@twii/common/lib/component/AppView";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { observer } from "mobx-react";
import { EntitySourceApp } from "../../../entity/component/EntitySourceApp";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";
import { PathsContext } from "../../../PathsContext";
import { getEntityActivityList } from "../SeaCargoActivityHelper";
import { IEntitySeaCargoActivity } from "../IEntitySeaCargoActivity";

interface ISeaCargoActivityListProps {
    list: IMasterEntitySourceListModel<ISeaCargoActivity>;
    onItemInvoked?: (item : ISeaCargoActivity, index?: number) => void;
}

@observer
class SeaCargoActivityListCommandBar extends React.Component<ISeaCargoActivityListProps, any> {
    private _onClickSeaCargoDetails = () => {
        if(this.props.list.selection.selectionCount === 1) {
            this.props.onItemInvoked(this.props.list.selection.selectedItems[0]);
        }
    };
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "Sea Cargo Activities"}),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity/sea" }),
        ];
        const farItems : IContextualMenuItem[] = [
            {
                key: "SeaCargoDetails",
                name: "Sea Cargo Report",
                iconProps: { iconName: "ZoomIn"},
                onClick: this._onClickSeaCargoDetails,
                disabled: this.props.list.selection.selectionCount !== 1
            },
            createViewPreferencesMenuItem(SeaCargoActivityViewPrefsStore, SeaCargoActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class SeaCargoActivityList extends React.Component<ISeaCargoActivityListProps, any> {
    private _onRenderMenu = () => {
        return <SeaCargoActivityListCommandBar {...this.props} />
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <SeaCargoActivityDetailsList {...this.props} viewPreferences={SeaCargoActivityViewPrefsStore} onItemInvoked={this.props.onItemInvoked} />
            </AppView>
        );
    }
}

class SeaCargoActivityListContainer extends React.Component<ISeaCargoActivityListProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityList {...this.props} />;
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea Cargo Activities..." />;
    }
}

class SeaCargoActivityListApp extends EntitySourceApp {
    private _onItemInvoked = (item : IEntitySeaCargoActivity) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.setValue({ path: PathsContext.value.seaCargoDetails(item.clientInstanceId), query: { oceanBillNumber: item.oceanBillNbr }, seaCargoActivity: item, panelProps: panelProps });
    }
    protected _onRenderSource = (props) => {
        return <SeaCargoActivityListContainer list={getEntityActivityList(props.masterEntity)} onItemInvoked={this._onItemInvoked} />;
    }
    componentWillMount() {
        this.host.title = "Sea Cargo";
    }
}

export {
    SeaCargoActivityListContainer,
    SeaCargoActivityList,
    ISeaCargoActivityListProps,
    SeaCargoActivityListApp,
    SeaCargoActivityListApp as default
}