import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import ISeaCargoActivityDetail from "../ISeaCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./SeaCargoActivityDetailContactInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { Sync } from "@twii/common/lib/component/Sync";
import { IListModel } from "@twii/common/lib/model/IListModel";

const Fields:  IColumn[] = [{ //IDetailsAttributeConfig<ISeaCargoActivityDetail>[] = [{
    key: "consigneeName",
    name: "Consignee:",
    fieldName: "consigneeName",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consigneeContactPhone",
    name: "Consignee Phone:",
    fieldName: "consigneeContactPhone",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consignorName",
    name: "Consignor:",
    fieldName: "consignorName",
    minWidth: 80,
    isMultiline: true
},
{
    key: "reportingClientName",
    name: "Reporting Client:",
    fieldName: "reportingClientName",
    minWidth: 80,
    isMultiline: true
},
{
    key: "responsibleClientName",
    name: "Responsible:",
    fieldName: "responsibleClientName",
    minWidth: 80,
    isMultiline: true
},
{
    key: "notifyName",
    name: "Notify:",
    fieldName: "notifyName",
    minWidth: 50,
    isMultiline: true
},
{
    key:"principalAgentName",
    name: "Principal Agent:",
    fieldName: "principalAgentName",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consigneeAddress",
    name: "Consignee Address:",
    fieldName: "consigneeAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "consignorAddress",
    name: "Consignor Address:",
    fieldName: "consignorAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "reporting_ClientAddress",
    name: "Reporting Address:",
    fieldName: "reporting_ClientAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "responsibleClientAddress",
    name: "Responsible Client Address:",
    fieldName: "responsibleClientAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "notifyAddress",
    name: "Notify Address:",
    fieldName: "notifyAddress",
    minWidth: 50,
    isMultiline: true
},
{
    key: "principalAgentAddress",
    name: "Principal Agent Address:",
    fieldName: "principalAgentAddress",
    minWidth: 50,
    isMultiline: true
 }];

 interface ISeaCargoActivityDetailsContactInfoProps {
     model?: IListModel<ISeaCargoActivityDetail>;
 }

 const SeaCargoActivityDetailsContactInfoViewPrefStore = new ViewPreferencesModel("seaCargoActivityDetailsContactInfo");

 class SeaCargoActivityDetailsContactInfo extends React.Component<ISeaCargoActivityDetailsContactInfoProps, any> {
    render() {
        let content;
        if(this.props.model.total >0) {
            content = this.props.model.items.map((detail: ISeaCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsContactInfoViewPrefStore} />;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load contact infomation details</MessageBar>;
        }
        return <div className="sea-cargo-activity-details-contact-info">{content}</div>;

    
    }   
 }

class SeaCargoActivityDetailsContactInfoContainer extends React.Component<ISeaCargoActivityDetailsContactInfoProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetailsContactInfo {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea cargo Details contact information..." />;

    }

}  

@observer

class SeaCargoActivityDetailContactInfoList extends React.Component<ISeaCargoActivityDetailsContactInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                        summary={<div>{"Contact Information"}</div>}
                        open={true}
                        controlOnHeaderClick={true}
                        headerClassName={css("sea-cargo-activity-details-contact-info-header")}
                        bodyClassName={css("sea-cargo-activity-details-contact-info-body")}>
                        <CommandBar items={[]} farItems={[
                            createViewPreferencesMenuItem(SeaCargoActivityDetailsContactInfoViewPrefStore, Fields)]} />
                        <SeaCargoActivityDetailsContactInfoContainer {...this.props} />

            </Details>
        );
    }

}

export {
    SeaCargoActivityDetailContactInfoList as default,
    SeaCargoActivityDetailContactInfoList,
    SeaCargoActivityDetailsContactInfoContainer,
    SeaCargoActivityDetailsContactInfo,
    ISeaCargoActivityDetailsContactInfoProps,
    Fields as SeaCargoContactInfoFields,
    SeaCargoActivityDetailsContactInfoViewPrefStore

}   