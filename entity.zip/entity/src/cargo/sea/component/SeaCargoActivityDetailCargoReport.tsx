import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import ISeaCargoActivityDetail from "../ISeaCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./SeaCargoActivityDetailCargoReport.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { Sync } from "@twii/common/lib/component/Sync";

const Fields: IColumn[] = [{  // IDetailsAttributeConfig<ISeaCargoActivityDetail>[] = [{
    key: "documentType",
    name: "Document Type:",
    fieldName: "documentType",
    minWidth: 50,
    isMultiline: true

},
    {
        key: "consignmentClearanceType",
        name: "Clearance Type:",
        fieldName: "consignmentClearanceType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "searchArrivalDate",
        name: "Date:",
        fieldName: "searchArrivalDate",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "houseBillNbr",
        name: "Housebill:",
        fieldName: "houseBillNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "clientRoleTypeList",
        name: "Role:",
        fieldName: "clientRoleTypeList",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "lineCount",
        name: "Line count:",
        fieldName: "lineCount",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "oceanBillNbr",
        name: "Oceanbill:",
        fieldName: "oceanBillNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "parentBillNbr",
        name: "Parent Bill Number:",
        fieldName: "parentBillNbr",
        minWidth: 50,
        isMultiline: true
    }];

interface ISeaCargoActivityDetailCargoReportProps {
    model?: IListModel<ISeaCargoActivityDetail>;
}

const SeaCargoActivityDetailsViewPrefsStore = new ViewPreferencesModel("seaCargoActivityDetails");

class SeaCargoActivityDetails extends React.Component<ISeaCargoActivityDetailCargoReportProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: ISeaCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={SeaCargoActivityDetailsViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="sea-cargo-activity-details">{content}</div>;
    }
}

class SeaCargoActivityDetailsContainer extends React.Component<ISeaCargoActivityDetailCargoReportProps, any> {
    private _onRenderDone = () => {
        return <SeaCargoActivityDetails {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Sea Cargo Details..." />;
    }
}

@observer
class SeaCargoActivityDetailCargoReport extends React.Component<ISeaCargoActivityDetailCargoReportProps, any> {
    render() {
        return (
               <Details className={css("details-panel")}
                         summary={<div>{'Cargo report information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("sea-cargo-activity-details-header")}
                         bodyClassName="sea-cargo-activity-details-cargo-report-body">
                         <CommandBar items={[]} farItems={[
                             createViewPreferencesMenuItem(SeaCargoActivityDetailsViewPrefsStore, Fields)]} />
                         <SeaCargoActivityDetailsContainer {...this.props} />
                </Details>
        );
    }
}

export {
    SeaCargoActivityDetailCargoReport as default,
    SeaCargoActivityDetailCargoReport,
    SeaCargoActivityDetailsContainer,
    SeaCargoActivityDetails,
    ISeaCargoActivityDetailCargoReportProps, Fields as SeaCargoActivityDetailCargoFields,
    SeaCargoActivityDetailsViewPrefsStore
};