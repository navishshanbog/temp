const sourceSystemCode = "ICS";

export { sourceSystemCode }