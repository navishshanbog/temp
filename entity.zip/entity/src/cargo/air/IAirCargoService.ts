import IAirCargoActivity from "./IAirCargoActivity";
import IAirCargoActivityDetail from "./IAirCargoActivityDetail";

interface IAirCargoGetRequest {
    maxNumberOfRecords?: number;
    orderByExamCountInd?: boolean;
}

interface IAirCargoActivitiesGetRequest extends IAirCargoGetRequest {
    parentId: string;
}

interface IAirCargoDetailsGetRequest extends IAirCargoGetRequest {
    parentId: string;
    masterBillNbr: string;
}

interface IAirCargoService {
    getAirCargoActivities(request : IAirCargoActivitiesGetRequest) : Promise<IAirCargoActivity[]>;
    getAirCargoActivityDetails(request : IAirCargoDetailsGetRequest) : Promise<IAirCargoActivityDetail[]>;
}

export { 
    IAirCargoService,
    IAirCargoActivitiesGetRequest,
    IAirCargoDetailsGetRequest,
    IAirCargoGetRequest
};