import * as React from "react";
import { observer } from "mobx-react";
import {AirCargoActivityDetailsContainer} from "./AirCargoActivityDetailCargoReport";
import "./AirCargoActivityDetail.scss";
import {AirCargoActivityDetailGoodsInfoContainer} from "./AirCargoActivityDetailGoodsInfo";
import "./AirCargoActivityDetailGoodsInfo.scss";
import {AirCargoActivityDetailExamsInfoContainer} from "./AirCargoActivityDetailExamsInfo";
import {AirCargoActivityDetailContactInfoContainer} from "./AirCargoActivityDetailContactInfo";
import "./AirCargoActivityDetailContactInfo.scss";
import {AirCargoActivityDetailGoodsIndContainer} from "./AirCargoActivityDetailGoodsIndicators";
import "./AirCargoActivityDetailGoodsIndicators.scss";
import "./AirCargoActivityDetailExamsInfo.scss";
import { ListModel } from "@twii/common/lib/model/ListModel";
import { IAppProps } from "@twii/common/lib/component/IAppProps";

class AirCargoActivityDetailProfileInfo extends React.Component<IAppProps> {
    get model() {
        const m = new ListModel();
        const items = this.props.match.items;
        if(items && items.length > 0) {
            const subItems = items[0].subItems;
            if(subItems) {
                m.setItems(subItems);
            }
        }
        m.sync.syncEnd();
        return m;
    }
    render() {
        return (
            <div key="air-cargo">
                <div className="air-cargo-details-cargo-report-body details-panel">
                    <AirCargoActivityDetailsContainer model={this.model} />
                </div>
                <div className="air-cargo-details-goods-info-body details-panel">
                    <AirCargoActivityDetailGoodsInfoContainer model={this.model} />
                </div>
                <div className="air-cargo-details-contact-info-body details-panel">
                    <AirCargoActivityDetailContactInfoContainer model={this.model} />
                </div>
                <div className="air-cargo-details-goods-indicators-body details-panel">
                    <AirCargoActivityDetailGoodsIndContainer model={this.model} />
                </div>
                <div className="air-cargo-details-exams-info-body details-panel">
                    <AirCargoActivityDetailExamsInfoContainer model={this.model} />
                </div>
            </div>
        );
    }
}

export {
    AirCargoActivityDetailProfileInfo as default,
    AirCargoActivityDetailProfileInfo
}