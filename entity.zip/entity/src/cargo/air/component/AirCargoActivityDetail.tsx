import * as React from "react";
import { observer } from "mobx-react";
import AirCargoActivityDetailGoodsInfoContainer from "./AirCargoActivityDetailGoodsInfo";
import AirCargoActivityDetailContactInfoContainer from "./AirCargoActivityDetailContactInfo";
import AirCargoActivityDetailExamsInfoContainer from "./AirCargoActivityDetailExamsInfo";
import AirCargoActivityDetailGoodsIndContainer from "./AirCargoActivityDetailGoodsIndicators";
import AirCargoActivityDetailsContainer from "./AirCargoActivityDetailCargoReport";
import "./AirCargoActivityDetail.scss";
import {createCopyForCargoActivities} from "../../component/EntityCargoSubActivityHelper";
import { EntityAppBase } from "../../../common/component/EntityAppBase";
import { IListModel } from "@twii/common/lib/model/IListModel";
import IAirCargoActivityDetail from "../IAirCargoActivityDetail";
import ListModel from "@twii/common/lib/model/ListModel";
import AirCargoServiceContext from "../AirCargoServiceContext";
import { EntityAppView } from "../../../common/component/EntityAppView";
import { AppView } from "@twii/common/lib/component/AppView";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IEntityAirCargoActivity } from "../IEntityAirCargoActivity";

interface IAirCargoActivityDetailProps {
    model?: IListModel<IAirCargoActivityDetail>;
}

@observer
class AirCargoActivityDetailCommandBar extends React.Component<IAirCargoActivityDetailProps, any> {
    private _onCopyCargoReport = (e : React.MouseEvent<HTMLAnchorElement>) => {
        createCopyForCargoActivities(this.props.model, "air/cargoReport", "activity/air", "Air",e);
    }
    render() {
        const items : IContextualMenuItem[] = [
            {
                key: "copyReport",
                name: "Copy",
                iconProps: {
                    iconName: "Copy"
                },
                onClick: this._onCopyCargoReport,
                disabled: this.props.model.sync.syncing || this.props.model.sync.error
            }
        ];
        return (
            <CommandBar items={items} />
        );
    }
}

class AirCargoActivityDetail extends React.Component<IAirCargoActivityDetailProps, any> {
    private _onRenderMenu = () => {
        return <AirCargoActivityDetailCommandBar {...this.props} />;
    }
    componentWillMount() {
        this.props.model.load();
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <div style={{ padding: 8}}>
                    <AirCargoActivityDetailsContainer {...this.props} />
                    <AirCargoActivityDetailGoodsInfoContainer {...this.props} />
                    <AirCargoActivityDetailContactInfoContainer {...this.props} />
                    <AirCargoActivityDetailGoodsIndContainer {...this.props} />
                    <AirCargoActivityDetailExamsInfoContainer {...this.props} />
                </div>
            </AppView>
        );
    }
}

class AirCargoActivityDetailApp extends EntityAppBase {
    get activity() : IEntityAirCargoActivity {
        if(this.props.match.airCargoActivity) {
            return this.props.match.airCargoActivity;
        }
        return this.props.match.params as IEntityAirCargoActivity;
    }
    componentWillMount() {
        this.host.setTitle("Air Cargo Activity Details Report");
    }
    get detail() : IListModel<IAirCargoActivityDetail> {
        return this.host.getState("airCargoActivityDetails", () => {
            const m = new ListModel<IAirCargoActivityDetail, IEntityAirCargoActivity>();
            m.parent = this.activity;
            m.loader = () => {
                return AirCargoServiceContext.value.getAirCargoActivityDetails({ parentId: this.activity.clientInstanceId, masterBillNbr: this.activity.masterBillNbr });
            };
            return m;
        }, m => m.parent.clientInstanceId !== this.activity.clientInstanceId || m.parent.masterBillNbr !== this.activity.masterBillNbr);
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker>
                <AirCargoActivityDetail model={this.detail} />
            </EntityAppView>
        );
    }
}

export {
    AirCargoActivityDetail,
    IAirCargoActivityDetailProps,
    AirCargoActivityDetailApp,
    AirCargoActivityDetailApp as default
};