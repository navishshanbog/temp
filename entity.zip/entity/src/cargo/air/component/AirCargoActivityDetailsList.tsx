import * as React from "react";
import IAirCargoActivity from "../IAirCargoActivity";
import IMasterEntitySourceListModel from "../../../entity/IMasterEntitySourceListModel";
import AirCargoActivityColumns, { MasterBillNbr } from "./AirCargoActivityColumns";
import MasterEntitySourceDetailsList from "../../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import { Link } from "office-ui-fabric-react/lib/Link";
import { IColumn } from "office-ui-fabric-react/lib/DetailsList";

interface IAirCargoActivityDetailsListProps {
    list: IMasterEntitySourceListModel<IAirCargoActivity>;
    viewPreferences?: IViewPreferencesModel;
    onItemInvoked?: (item : IAirCargoActivity, index : number) => void;
}

interface IAirCargoActivityDetailsListItemProps extends IAirCargoActivityDetailsListProps {
    item: IAirCargoActivity;
    itemIndex: number;
}

class MasterBillNumberLink extends React.Component<IAirCargoActivityDetailsListItemProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.preventDefault();
        this.props.onItemInvoked(this.props.item, this.props.itemIndex);
    }
    render() {
        return <Link onClick={this._onClick}>{String(this.props.item.masterBillNbr)}</Link>;
    }
}

class AirCargoActivityDetailsList extends React.Component<IAirCargoActivityDetailsListProps, any> {
    private _onRenderMasterBillNumber = (item : IAirCargoActivity, idx : number) => {
        return <MasterBillNumberLink {...this.props} item={item} itemIndex={idx} />;
    }
    render() {
        let columns : IColumn[];
        if(this.props.onItemInvoked) {
            columns = [].concat(AirCargoActivityColumns);
            const colIdx = columns.findIndex(c => c.key === MasterBillNbr.key);
            columns[colIdx] = Object.assign({}, columns[colIdx], {
                onRender: this._onRenderMasterBillNumber 
            });
        } else {
            columns = AirCargoActivityColumns;
        }
        return <MasterEntitySourceDetailsList
                    columns={columns}
                    list={this.props.list}
                    typeLabel="Air Cargo Activities"
                    itemType="activity/air"
                    viewPreferences={this.props.viewPreferences}
                    onItemInvoked={this.props.onItemInvoked} />;
    }
}

export { AirCargoActivityDetailsList as default, AirCargoActivityDetailsList, IAirCargoActivityDetailsListProps }