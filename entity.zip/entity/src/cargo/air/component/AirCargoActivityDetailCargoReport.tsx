import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IAirCargoActivityDetail from "../IAirCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./AirCargoActivityDetailCargoReport.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { Sync } from "@twii/common/lib/component/Sync";

const Fields: IColumn[] = [{  // IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "documentType",
    name: "Document Type:",
    fieldName: "documentType",
    minWidth: 50,
    isMultiline: true
},
    {
        key: "consignmentClearanceType",
        name: "Clearance Type:",
        fieldName: "consignmentClearanceType",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "searchArrivalDate",
        name: "Date:",
        fieldName: "searchArrivalDate",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "houseBillNbr",
        name: "Housebill:",
        fieldName: "houseBillNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "clientRoleTypeList",
        name: "Role:",
        fieldName: "clientRoleTypeList",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "versionNbr",
        name: "Version:",
        fieldName: "versionNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "masterBillNbr",
        name: "Master Bill",
        fieldName: "masterBillNbr",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "parentBillNbr",
        name: "Parent Bill Number:",
        fieldName: "parentBillNbr",
        minWidth: 50,
        isMultiline: true

    }];


interface IAirCargoActivityDetailCargoReportProps {
    model?: IListModel<IAirCargoActivityDetail>;
}

const AirCargoActivityDetailsViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetails");

class AirCargoActivityDetails extends React.Component<IAirCargoActivityDetailCargoReportProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: IAirCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailsViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="air-cargo-details-cargo-report">{content}</div>;
    }
}

class AirCargoActivityDetailsContainer extends React.Component<IAirCargoActivityDetailCargoReportProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetails {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details..." />;
    }
}


@observer
class AirCargoActivityDetailCargoReport extends React.Component<IAirCargoActivityDetailCargoReportProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Cargo Report Information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-cargo-report-header")}
                         bodyClassName="air-cargo-details-cargo-report-body">
                    <CommandBar items={[]} farItems={[
                    createViewPreferencesMenuItem(AirCargoActivityDetailsViewPrefsStore, Fields)]} />
                    <AirCargoActivityDetailsContainer {...this.props} />
           </Details>
        );
    }
}

export {
    AirCargoActivityDetailCargoReport as default,
    AirCargoActivityDetailCargoReport,
    AirCargoActivityDetailsContainer,
    AirCargoActivityDetails,
    IAirCargoActivityDetailCargoReportProps,
    Fields as AirCargoActivityDetailCargoFields,
    AirCargoActivityDetailsViewPrefsStore
};