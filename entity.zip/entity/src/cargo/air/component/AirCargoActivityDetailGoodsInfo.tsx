import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IAirCargoActivityDetail from "../IAirCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./AirCargoActivityDetailGoodsInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { Sync } from "@twii/common/lib/component/Sync";

const Fields: IColumn[] = [{// IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "goodsDescr",
    name: "Goods description:",
    fieldName: "goodsDescr",
    minWidth: 50,
    isMultiline: true
    },

    {
        key: "airlineCode",
        name: "Flight:",
        onRender: function(item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={(item.airlineCode) + (" " ) + (item.flightNbr)} />;
        },
        data: {
            getText: (item: IAirCargoActivityDetail) => `${item.airlineCode} ${item.flightNbr}`
        },
        fieldName: "airlineCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "declaredValueAmount",
        name: "Declared Value (AUD amount):",
        onRender: function(item:IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={(item.declaredValueAmount || "") + (" " ) + (item.currencyCode || "") + (" ( " ) + (item.declaredValueAUDAmount) + (" AUD) ")} />;
        },
        data: {
            getText: (item: IAirCargoActivityDetail) => `${item.currencyCode || ""} ( ${item.declaredValueAUDAmount} AUD) `
        },
        fieldName: "declaredValueAmount",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "originPortCode",
        name: "Origin Port:",
        onRender: function(item:IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={(item.originPortCode) + (", ") + (item.originCountryCode)} />;
        },data: {
            getText: (item: IAirCargoActivityDetail) => `${item.originPortCode}, ${item.originCountryCode}`
        },
        fieldName: "originPortCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "destinationPortCode",
        name: "Destination:",
        onRender: function(item:IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={(item.destinationPortCode) + (", ") + (item.destinationAUStateCode || "")} />;
        }, data: {
            getText: (item: IAirCargoActivityDetail) => `${item.destinationPortCode}, ${item.destinationAUStateCode || ""}`
        },
        fieldName: "destinationPortCode",
        minWidth: 50
    },
    {
        key: "packageCount",
        name: "Package Count & Type:",
        fieldName: "packageCount",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "actualArrivalReportAEST",
        name: "Actual arrival time (AEST):",
        fieldName: "actualArrivalReportAEST",
        minWidth: 50
    },
    {
        key: "grossWeight",
        name: "Gross Weight:",
        fieldName: "consigneeName",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "withdrawnInd",
        name: "Withdrawn:",
         onRender: function(item:IAirCargoActivityDetail) {
             if((item.withdrawnAEST != null) && (item.withdrawnAEST != "")) {
                return <DetailsAttribute key={this.key} label={this.name} value={(item.withdrawnInd) + (" - ") + (item.withdrawnAEST)} />;
             }
             else {
                 return <DetailsAttribute key={this.key} label={this.name} value={(item.withdrawnInd)} />;
             }
        }, 
        data: {
            getText: (item: IAirCargoActivityDetail) => `${item.withdrawnInd} - ${item.withdrawnAEST}`
            
        },
        fieldName: "withdrawnInd",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "impendingArrivalReportLastOSPortCode",
        name: "Last Overseas Port:",
        fieldName: "impendingArrivalReportLastOSPortCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "dischargePortCode",
        name: "Discharge Location:",
         onRender: function(item:IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={(item.dischargePortCode) + (", ") + (item.dischargeAU_StateCode)} />;
        }, data: {
            getText: (item: IAirCargoActivityDetail) => `${item.dischargePortCode}, ${item.dischargeAU_StateCode}`
        },
        fieldName: "dischargePortCode",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "impendingArrivalReportCurrFirstPortETAAEST",
        name: "Estimated first port arrival (AEST):",
        onRender: function(item:IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={(item.impendingArrivalReportCurrFirstPortETAAEST || "") + (" (") + (item.impendingArrivalReportFirstPortCode) + (")")} />;
        }, data: {
            getText: (item: IAirCargoActivityDetail) => `${item.impendingArrivalReportCurrFirstPortETAAEST || ""} (${item.impendingArrivalReportFirstPortCode})`
        },
        fieldName: "impendingArrivalReportCurrFirstPortETAAEST",
        minWidth: 50,
        isMultiline: true
           
}];

interface IAirCargoActivityDetailGoodsInfoProps {
    model?: IListModel<IAirCargoActivityDetail>;
}

const AirCargoActivityDetailGoodsInfoViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetailsGoodsInfo");

class AirCargoActivityDetailGoodsInfo extends React.Component<IAirCargoActivityDetailGoodsInfoProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: IAirCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailGoodsInfoViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="air-cargo-details-goods-info">{content}</div>;
    }
}

class AirCargoActivityDetailGoodsInfoContainer extends React.Component<IAirCargoActivityDetailGoodsInfoProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetailGoodsInfo {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details Goods and voyage information..." />;
    }
}
@observer
class AirCargoActivityDetailGoodsInfoList extends React.Component<IAirCargoActivityDetailGoodsInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Goods and voyage information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-goods-info-header")}
                         bodyClassName="air-cargo-details-goods-info-body">
                <CommandBar items={[]} farItems={[
                    createViewPreferencesMenuItem(AirCargoActivityDetailGoodsInfoViewPrefsStore, Fields)]} />
                        <AirCargoActivityDetailGoodsInfoContainer {...this.props} />
            </Details>    
        );
    }
}

export { 
    AirCargoActivityDetailGoodsInfoList as default,
    AirCargoActivityDetailGoodsInfoList,
    AirCargoActivityDetailGoodsInfoContainer,
    AirCargoActivityDetailGoodsInfo,
    IAirCargoActivityDetailGoodsInfoProps,
    Fields as AirCargoGoodsInfoFields,
    AirCargoActivityDetailGoodsInfoViewPrefsStore
};