import { IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import IAirCargoActivity from "../IAirCargoActivity";
import * as DateUtils from "@twii/common/lib/util/Date";

const OriginalMsgId : IColumn = {
    key: "originalMsgId",
    ariaLabel: "OMT",
    name: "OMT",
    fieldName: "originalMsgId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 100
};

const getSearchArrivalDateText = (item : IAirCargoActivity) => {
    return DateUtils.dataToOutputText(item.searchArrivalDate);
};

const SearchArrivalDate : IColumn = {
    key: "searchArrivalDate",
    ariaLabel: "Arrival Date",
    name: "Arrival Date",
    fieldName: "searchArrivalDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 40,
    maxWidth: 80,
    data: {
        getText(item : IAirCargoActivity) {
            return getSearchArrivalDateText(item);
        }
    },
    onRender: (item :  IAirCargoActivity) => {
        return getSearchArrivalDateText(item);
    }
};

const ClientRoleType : IColumn = {
    key: "clientRoleTypeList",
    ariaLabel: "Role",
    name: "Role",
    fieldName: "clientRoleTypeList",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 80
};

const MasterBillNbr : IColumn = {
    key: "masterBillNbr",
    ariaLabel: "Master Bill",
    name: "Master Bill",
    fieldName: "masterBillNbr",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const getRouteText = (item : IAirCargoActivity) => {
    return (item.airlineCode || "") + (" ") + (item.flightNbr || "");
};

const HouseBillNbr : IColumn = {
    key: "houseBillNbr",
    ariaLabel: "House Bill",
    name: "House Bill",
    fieldName: "houseBillNbr",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
};

const RouteId : IColumn = {
    key: "routeId",
    ariaLabel: "Flight",
    name: "Flight",
    fieldName: "routeId",
    minWidth: 40,
    maxWidth: 150,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText(item : IAirCargoActivity) {
            return getRouteText(item);
        }
    },
    onRender: (item :  IAirCargoActivity) => {
        return getRouteText(item)
    }
};

const GoodsDescription : IColumn = {
    key: "goodsDescr",
    ariaLabel: "Goods Description",
    name: "Goods Description",
    fieldName: "goodsDescr",
    minWidth: 80,
    maxWidth: 150,
    isResizable: true,
    columnActionsMode:ColumnActionsMode.clickable,
    isMultiline: true
};

const PartShipmentInd : IColumn = {
    key: "partShipmentInd",
    ariaLabel: "Part Shipment",
    name: "Part Shipment",
    fieldName: "partShipmentInd",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const GrossWeight : IColumn = {
    key: "grossWeight",
    ariaLabel: "Gross Weight",
    name: "Gross Weight",
    fieldName: "grossWeight",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const StsCargoStatusCode : IColumn = {
    key: "stsCargoStatusCode",
    ariaLabel: "Status",
    name: "Status",
    fieldName: "stsCargoStatusCode",
    minWidth: 40,
    maxWidth: 80,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const ExamFindResultCode : IColumn = {
    key: "examFindResultCode",
    ariaLabel: "Exam Find Result Code",
    name: "Exam Find Result Code",
    fieldName: "examFindResultCode",
    minWidth: 40,
    maxWidth: 80,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const PositiveFindInd : IColumn = {
    key: "positiveFindInd",
    ariaLabel: "Positive Find",
    name: "Positive Find",
    fieldName: "positiveFindInd",
    minWidth: 40,
    maxWidth: 60,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const DeclaredValueOfGoods : IColumn = {
    key: "declaredValueAmount",
    ariaLabel: "Value",
    name: "Value",
    fieldName: "declaredValueAmount",
    minWidth: 60,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
}; 

const DeclaredValueAUDAmount : IColumn = {
    key: "declaredValueAUDAmount",
    ariaLabel: "Value (AUD)",
    name: "Value (AUD)",
    fieldName: "declaredValueAUDAmount",
    minWidth: 60,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
}; 

const Consignee : IColumn = {
    key: "consigneeName",
    ariaLabel: "Consignee Name",
    name: "Consignee Name",
    fieldName: "consigneeName",
    minWidth: 80,
    maxWidth: 120,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
}; 

const ConsigneeAddress : IColumn = {
    key: "consigneeAddress",
    ariaLabel: "Consignee Address",
    name: "Consignee Address",
    fieldName: "consigneeAddress",
    minWidth: 100,
    maxWidth: 200,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
}; 
const Consignor : IColumn = {
    key: "consignorName",
    ariaLabel: "Consignor Name",
    name: "Consignor Name",
    fieldName: "consignorName",
    minWidth: 80,
    maxWidth: 120,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
}; 

const ConsignorAddress : IColumn = {
    key: "consignorAddress",
    ariaLabel: "Consignor Address",
    name: "Consignor Address",
    fieldName: "consignorAddress",
    minWidth: 100,
    maxWidth: 200,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
}; 

const ExamIndicator : IColumn = {
    key: "examIndicator",
    ariaLabel: "Exam Indicator",
    name: "Exam Indicator",
    fieldName: "examIndicator",
    minWidth: 40,
    maxWidth: 60,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const originPortCode : IColumn = {
    key: "originPortCode",
    ariaLabel: "Waybill Origin Port",
    name: "Waybill Origin Port",
    fieldName: "originPortCode",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
}

const AirCargoActivityColumns : IColumn[] = [
    SearchArrivalDate,
    ClientRoleType,
    Consignee,
    ConsigneeAddress,
    Consignor,
    ConsignorAddress,
    RouteId,
    originPortCode,
    MasterBillNbr,
    HouseBillNbr,
    GrossWeight,
    DeclaredValueAUDAmount,
    GoodsDescription,
    StsCargoStatusCode,
    ExamIndicator,
    PositiveFindInd
];

export {
    AirCargoActivityColumns as default,
    AirCargoActivityColumns,
    SearchArrivalDate,
    ClientRoleType,
    Consignee,
    ConsigneeAddress,
    Consignor,
    ConsignorAddress,
    RouteId,
    originPortCode,
    MasterBillNbr,
    HouseBillNbr,
    GrossWeight,
    DeclaredValueAUDAmount,
    GoodsDescription,
    StsCargoStatusCode,
    ExamIndicator,
    PositiveFindInd
}