import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IAirCargoActivityDetail from "../IAirCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import "./AirCargoActivityDetailExamsInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";

const Fields: IColumn[] = [{ //IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "examCount",
    name: "Exams Count:",
    fieldName: "examCount",
    minWidth: 50,
    isMultiline: true
},
    {
        key: "examFindResultCode",
        name: "Find Result:",
        fieldName: "examFindResultCode",
        minWidth: 50,
        isMultiline: true

    },
    {
        key: "examFindCount",
        name: "Exam Finds:",
        fieldName: "examFindCount",
        minWidth: 50,
        isMultiline: true

    },
    {
        key: "examFindSigCount",
        name: "Significant Finds:",
        fieldName: "examFindSigCount",
        minWidth: 50,
        isMultiline: true

    }];

interface IAirCargoActivityDetailExamsInfoProps {
    model?: IListModel<IAirCargoActivityDetail>;
}

const AirCargoActivityDetailExamsInfoViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetailsContactInfo");

class AirCargoActivityDetailExamsInfo extends React.Component<IAirCargoActivityDetailExamsInfoProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: IAirCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailExamsInfoViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load exams infomation details</MessageBar>;
        }
        return <div className="air-cargo-details-exams-info">{content}</div>;
    }
}

class AirCargoActivityDetailExamsInfoContainer extends React.Component<IAirCargoActivityDetailExamsInfoProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetailExamsInfo {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details exams information..." />;
    }
}

@observer
class AirCargoActivityDetailExamsInfoList extends React.Component<IAirCargoActivityDetailExamsInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'EXAMS information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-exams-info-header")}
                         bodyClassName="air-cargo-details-exams-info-body">
                <CommandBar items={[]} farItems={[
                    createViewPreferencesMenuItem(AirCargoActivityDetailExamsInfoViewPrefsStore, Fields)]} />
                        <AirCargoActivityDetailExamsInfoContainer {...this.props} />
            </Details>
                
        );
    }    
} 

export { 
    AirCargoActivityDetailExamsInfoList as default,
    AirCargoActivityDetailExamsInfoList,
    AirCargoActivityDetailExamsInfoContainer,
    AirCargoActivityDetailExamsInfo,
    IAirCargoActivityDetailExamsInfoProps,
    Fields as AirCargoExamsInfoFields,
    AirCargoActivityDetailExamsInfoViewPrefsStore
};