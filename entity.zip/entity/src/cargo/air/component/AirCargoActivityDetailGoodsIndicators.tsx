import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IAirCargoActivityDetail from "../IAirCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./AirCargoActivityDetailGoodsIndicators.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { Sync } from "@twii/common/lib/component/Sync";

const getFullValText = (item: string) => {
	let fullValText;
	if (item === "Y") {
            fullValText = "Yes";
        }
        else if (item === "N") {
            fullValText = "No";
        }
        else {
            fullValText = item;
        }
	return fullValText;
}

const Fields: IColumn[] = [{ // IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "freightForwardInd",
    name: "Freight forward:",
    onRender: function (item: IAirCargoActivityDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.freightForwardInd)}/>;
    },
    data: { getText: (item: IAirCargoActivityDetail) =>  getFullValText(item.freightForwardInd) },
    fieldName: "freightForwardInd",
    minWidth: 50,
    isMultiline: true
},

    {
        key: "lowestBillInd",
        name: "Lowest Bill:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.lowestBillInd)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.lowestBillInd) },
        fieldName: "lowestBillInd",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "highRiskMovementInd",
        name: "High Risk Movement:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={getFullValText(item.highRiskMovementInd)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.highRiskMovementInd) },
        fieldName: "highRiskMovementInd",
        minWidth: 50,
        isMultiline: true

    },
    {
        key: "examIndicator",
        name: "Exam performed:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.examIndicator)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.examIndicator) },
        fieldName: "examIndicator",
        minWidth: 50,
        isMultiline: true

    },
    {
        key: "suppressedInd",
        name: "Suppressed:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.suppressedInd)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.suppressedInd) },
        fieldName: "suppressedInd",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "personalEffectsInd",
        name: "Personal Effects:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.personalEffectsInd)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.personalEffectsInd) },
        fieldName: "personalEffectsInd",
        minWidth: 50,
        isMultiline: true
    },

    {
        key: "selfAssessedClearanceInd",
        name: "Self-Assessed Clearance:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name}
                                     value={getFullValText(item.selfAssessedClearanceInd)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.selfAssessedClearanceInd) },
        fieldName: "selfAssessedClearanceInd",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "partShipmentInd",
        name: "Part Shipment:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.partShipmentInd)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.partShipmentInd) },
        fieldName: "partShipmentInd",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "positiveFindInd",
        name: "Positive Exam Find:",
        onRender: function (item: IAirCargoActivityDetail) {
            return <DetailsAttribute key={this.key} label={this.name} value={getFullValText(item.positiveFindInd)}/>;
        },
        data: { getText: (item: IAirCargoActivityDetail) => getFullValText(item.positiveFindInd) },
        fieldName: "positiveFindInd",
        minWidth: 50,
        isMultiline: true
    }];

interface IAirCargoActivityDetailGoodsIndProps {
    model?: IListModel<IAirCargoActivityDetail>;
}

const AirCargoActivityDetailGoodsInfoViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetailsGoodInd");

class AirCargoActivityDetailGoodsInd extends React.Component<IAirCargoActivityDetailGoodsIndProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: IAirCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailGoodsInfoViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load goods indicator details</MessageBar>;
        }
        return <div className="air-cargo-details-goods-indicators">{content}</div>;
    }
}

class AirCargoActivityDetailGoodsIndContainer extends React.Component<IAirCargoActivityDetailGoodsIndProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetailGoodsInd {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details Goods indicator information..." />;
    }
}

@observer
class AirCargoActivityDetailGoodIndList extends React.Component<IAirCargoActivityDetailGoodsIndProps, any> {
    render() {
        return(
            <Details className={css("details-panel")}
                         summary={<div>{'Goods Indicators'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-goods-indicators-header")}
                         bodyClassName="air-cargo-details-goods-indicators-body">
                <CommandBar items={[]} farItems={[
                    createViewPreferencesMenuItem(AirCargoActivityDetailGoodsInfoViewPrefsStore, Fields)]} />
                         <AirCargoActivityDetailGoodsIndContainer {...this.props} />
            </Details>    
        );
    }

}

export { 
    
    AirCargoActivityDetailGoodIndList as default,
    AirCargoActivityDetailGoodIndList,
    AirCargoActivityDetailGoodsIndContainer,
    AirCargoActivityDetailGoodsInd,
    IAirCargoActivityDetailGoodsIndProps,
    Fields as AirCargoDetailGoodsIndFields
};