import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import AirCargoActivityDetailsList from "./AirCargoActivityDetailsList";
import IMasterEntitySourceListModel from "../../../entity/IMasterEntitySourceListModel";
import IAirCargoActivity from "../IAirCargoActivity";
import AirCargoActivityColumns from "./AirCargoActivityColumns";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { Sync } from "@twii/common/lib/component/Sync";
import { createCopyToClipboardItem } from "../../../entity/component/MasterEntitySourceHelper";
import AirCargoActivityViewPrefsStore from "../AirCargoActivityViewPrefsStore";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { AppView } from "@twii/common/lib/component/AppView";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { observer } from "mobx-react";
import { EntitySourceApp } from "../../../entity/component/EntitySourceApp";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";
import { PathsContext } from "../../../PathsContext";
import { getEntityActivityList } from "../AirCargoActivityHelper";
import { IEntityAirCargoActivity } from "../IEntityAirCargoActivity";

interface IAirCargoActivityListProps {
    list: IMasterEntitySourceListModel<IAirCargoActivity>;
    onItemInvoked?: (item : IAirCargoActivity, index?: number) => void;
}

@observer
class AirCargoActivityListCommandBar extends React.Component<IAirCargoActivityListProps, any> {
    private _onClickAirCargoDetails = () => {
        if(this.props.list.selection.selectionCount === 1) {
            this.props.onItemInvoked(this.props.list.selection.selectedItems[0]);
        }
    };
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "Air Cargo Activities"}),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity/air" })
        ];
        const farItems : IContextualMenuItem[] = [
            {
                key: "airCargoDetails",
                name: "Air Cargo Report",
                iconProps: { iconName: "ZoomIn"},
                onClick: this._onClickAirCargoDetails,
                disabled: this.props.list.selection.selectionCount !== 1
            },
            createViewPreferencesMenuItem(AirCargoActivityViewPrefsStore, AirCargoActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class AirCargoActivityList extends React.Component<IAirCargoActivityListProps, any> {
    private _onRenderMenu = () => {
        return <AirCargoActivityListCommandBar {...this.props} />
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <AirCargoActivityDetailsList {...this.props} viewPreferences={AirCargoActivityViewPrefsStore} onItemInvoked={this.props.onItemInvoked} />
            </AppView>
        );
    }
}

class AirCargoActivityListContainer extends React.Component<IAirCargoActivityListProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityList {...this.props} />;
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Activities..." />;
    }
}

class AirCargoActivityListApp extends EntitySourceApp {
    private _onItemInvoked = (item : IEntityAirCargoActivity) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.setValue({ path: PathsContext.value.airCargoDetails(item.clientInstanceId), query: { masterBillNbr: item.masterBillNbr }, airCargoActivity: item, panelProps: panelProps });
    }
    protected _onRenderSource = (props) => {
        return <AirCargoActivityListContainer list={getEntityActivityList(props.masterEntity)} onItemInvoked={this._onItemInvoked} />;
    }
    componentWillMount() {
        this.host.title = "Air Cargo";
    }
}

export {
    AirCargoActivityListContainer,
    AirCargoActivityList,
    IAirCargoActivityListProps,
    AirCargoActivityListApp,
    AirCargoActivityListApp as default
}