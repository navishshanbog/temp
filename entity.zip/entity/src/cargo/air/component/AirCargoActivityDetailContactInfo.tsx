import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IAirCargoActivityDetail from "../IAirCargoActivityDetail";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Details } from "@twii/common/lib/component/Details";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import "./AirCargoActivityDetailContactInfo.scss";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { Sync } from "@twii/common/lib/component/Sync";

const Fields: IColumn[] = [{  // IDetailsAttributeConfig<IAirCargoActivityDetail>[] = [{
    key: "consigneeName",
    name: "Consignee:",
    fieldName: "consigneeName",
    minWidth: 50,
    isMultiline: true
    },
    {
        key: "consigneeContactPhone",
        name: "Consignee Phone:",
        fieldName: "consigneeContactPhone",
        minWidth: 50,
        isMultiline: true
       
    },
    {
        key: "consignorName",
        name: "Consignor:",
        fieldName: "consignorName",
        minWidth: 50,
        isMultiline: true
        
    },
    {
        key: "reptClientName",
        name: "Reporting Client:",
        fieldName: "reptClientName",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "respClientName",
        name: "Responsible:",
        fieldName: "respClientName",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "notifyName",
        name: "Notify:",
        fieldName: "notifyName",
        minWidth: 50,
        isMultiline: true
    },
    {
        key: "consigneeAddress",
        name: "Consignee Address:",
        fieldName: "consigneeAddress",
        minWidth: 50,
        isMultiline: true
        
    },
    {
        key: "consignorAddress",
        name: "Consignor Address:",
        fieldName: "consignorAddress",
        minWidth: 50,
        isMultiline: true
                      
    },
     {
        key: "reptClientAddress",
        name: "Reporting Address:",
         fieldName: "reptClientAddress",
         minWidth: 50,
         isMultiline: true
    },
     {
        key: "respClientAddress",
        name: "Responsible Client Address:",
         fieldName: "respClientAddress",
         minWidth: 50,
         isMultiline: true
        
    },
    {
        key: "notifyAddress",
        name: "Notify Address:",
        fieldName: "notifyAddress",
        minWidth: 50,
        isMultiline: true
           
}];

interface IAirCargoActivityDetailContactInfoProps {
    model?: IListModel<IAirCargoActivityDetail>;
}

const AirCargoActivityDetailsViewPrefsStore = new ViewPreferencesModel("airCargoActivityDetailsContactInfo");

class AirCargoActivityDetailContactInfo extends React.Component<IAirCargoActivityDetailContactInfoProps, any> {
    render() {
        let content;
        if(this.props.model.total > 0) {
            content = this.props.model.items.map((detail: IAirCargoActivityDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={AirCargoActivityDetailsViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load contact infomation details</MessageBar>;
        }
        return <div className="air-cargo-details-contact-info">{content}</div>;
    }
}

class AirCargoActivityDetailContactInfoContainer extends React.Component<IAirCargoActivityDetailContactInfoProps, any> {
    private _onRenderDone = () => {
        return <AirCargoActivityDetailContactInfo {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.model.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Air Cargo Details contact information..." />;
    }
}

@observer
class AirCargoActivityDetailContactInfoList extends React.Component<IAirCargoActivityDetailContactInfoProps, any> {
    render() {
        return (
            <Details className={css("details-panel")}
                         summary={<div>{'Contact Information'}</div>}
                         open={true}
                         controlOnHeaderClick={true}
                         headerClassName={css("air-cargo-details-contact-info-header")}
                         bodyClassName="air-cargo-details-contact-info-body">
                <CommandBar items={[]} farItems={[
                    createViewPreferencesMenuItem(AirCargoActivityDetailsViewPrefsStore, Fields)]} />
                        <AirCargoActivityDetailContactInfoContainer {...this.props} />
           </Details>
        );
    }
}

export { 
    AirCargoActivityDetailContactInfoList as default,
    AirCargoActivityDetailContactInfoList,
    AirCargoActivityDetailContactInfoContainer,
    AirCargoActivityDetailContactInfo,
    IAirCargoActivityDetailContactInfoProps,
    Fields as AirCargoActivityDetailContactInfoFields,
    AirCargoActivityDetailsViewPrefsStore as AirCargoActivityDetailsContactsInfoViewPrefsStore
};