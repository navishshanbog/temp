import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import { IEntityAirCargoActivity } from "./IEntityAirCargoActivity";
import ISort from "@twii/common/lib/ISortProps";
import AirCargoServiceContext from "./AirCargoServiceContext";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import { AirCargoActivityColumns, SearchArrivalDate, GrossWeight } from "./component/AirCargoActivityColumns";
import * as StringUtils from "@twii/common/lib/util/String";
import * as SearchUtils from "@twii/common/lib/util/Search";
import * as moment from "moment";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as CargoConstants from "../CargoConstants";
import IActivityListModel from "@twii/common/lib/IActivityListModel";
import MasterEntitySourceListModel from "../../entity/MasterEntitySourceListModel";
import { IMasterEntityModel } from "../../entity/IMasterEntityModel";
import { getForMasterEntity } from "../../entity/MasterEntitySourceServiceUtils";
import IMasterEntitySourceModel from "../../entity/IMasterEntitySourceModel";

const textFilterItemImpl = (item: IEntityAirCargoActivity, text : string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, AirCargoActivityColumns), text);
}

const textFilterItem = (item: IEntityAirCargoActivity, text : string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items : IEntityAirCargoActivity[], text : string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IEntityAirCargoActivity, from : moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.searchArrivalDate), from);
};

const toFilterItem = (item: IEntityAirCargoActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.searchArrivalDate), to);
};

const rangeFilterItem = (item: IEntityAirCargoActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items : IEntityAirCargoActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items; 
};

const filter = (items : IEntityAirCargoActivity[], props : IActivityFilterProps) => {
    return props ? rangeFilter(textFilter(items, props.filterText), props.filterFromDate, props.filterToDate) : items;
};

const toSortValue = (item: IEntityAirCargoActivity, field : string) => {
    if(item) {
        if(field === SearchArrivalDate.fieldName) {
            return DateUtils.dateFromDataText(item.searchArrivalDate);
        } else if(field === GrossWeight.fieldName) {
            const n = parseFloat(item.grossWeight);
            return !isNaN(n) ? n : item.grossWeight;
        }
        return item[field];
    }
};

const compare = (a : IEntityAirCargoActivity, b : IEntityAirCargoActivity, sort: ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IEntityAirCargoActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a : IEntityAirCargoActivity, b : IEntityAirCargoActivity) => compare(a, b, sort)) : items;
};

const getActivitiesByParentId = (parentId : string, source : IMasterEntitySourceModel, entity: IMasterEntityModel) : Promise<IEntityAirCargoActivity[]> => {
    return AirCargoServiceContext.value.getAirCargoActivities({ parentId: parentId }).then(r => {
        return r ? r.map((i, index) => {
            i["key"] = i.clientInstanceId + "_" + index;
            return Object.assign({}, i, { source: source, entity: entity });
        }) : [];
    });
};

const getEntityActivities = (entity : IMasterEntityModel) : Promise<IEntityAirCargoActivity[]> => {
    return getForMasterEntity(entity, CargoConstants.sourceSystemCode, getActivitiesByParentId);
};

const getEntityActivityList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityAirCargoActivity> => {
    return entity.getState("airCargoActivityList", () => {
        const r = new MasterEntitySourceListModel(entity, CargoConstants.sourceSystemCode, getEntityActivities);
        r.setFilterHandler(filter);
        r.setSortHandler(sort);
        r.load();
        return r;
    });
};

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getActivitiesByParentId,
    getEntityActivities,
    getEntityActivityList
};