import { IEntityActivity } from "../../entity/IEntityActivity";
import { IAirCargoActivity } from "./IAirCargoActivity";

interface IEntityAirCargoActivity extends IEntityActivity, IAirCargoActivity {}

export { IEntityAirCargoActivity }