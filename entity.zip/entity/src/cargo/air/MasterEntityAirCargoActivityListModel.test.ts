import MasterEntityModel from "../../entity/MasterEntityModel";
import AirCargoServiceContext from "./AirCargoServiceContext";
import MockAirCargoService from "./MockAirCargoService";
import * as CargoConstants from "../CargoConstants";
import { getEntityActivityList } from "./AirCargoActivityHelper";
import { toPromise } from "@twii/common/lib/SyncUtils";

describe("Master Entity Air Cargo Activity List Model", () => {
    test("test set master entity", async () => {
        const e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: CargoConstants.sourceSystemCode,
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "1"
                            }
                        }
                    ]
                }
            ]
        });

        expect(e.sourceCodes.length).toBe(1);
        expect(e.sourceCodes[0]).toBe(CargoConstants.sourceSystemCode);

        const testAirCargoService = new MockAirCargoService();
        testAirCargoService.getAirCargoActivitiesResponse = [
            {
                "documentType": "ACR",
                "originalMsgId": "2015-06-25 14:03:49.833367",
                "clientRoleTypeList": "Consignor",
                "searchArrivalDate": "2015-06-25",
                "masterBillNbr": "16093300336",
                "houseBillNbr": "30377721091",
                "declaredValueAmount": "3.00",
                "declaredValueAUDAmount": "3.88",
                "flightNbr": "139",
                "airlineCode": "CX",
                "goodsDescr": "LASER PEN",
                "grossWeight": "77.00",
                "originPortCode": "HKHKG",
                "consigneeAddress": "142 LITTLE BACK CREEK ROAD NSW2429 AU",
                "consigneeClientId": "543310053046715",
                "consigneeName": "JAMES BROCK",
                "consignorAddress": "XIAORIZI NO 154 BAYIO RD 5F YIN H U GUANGZHOU CIT CHINA CN",
                "consignorClientId": "219641837238334",
                "consignorName": "4PX",
                "stsCargoStatusCode": null,
                "decTotalCval": null,
                "examCount": 1,
                "examIndicator": "Y",
                "examFindResultCode": "WEAP",
                "positiveFindInd": "Y",
                "examFindCount": 1
            }
            
           
        ]
        testAirCargoService.recordRequests = true;

        AirCargoServiceContext.value = testAirCargoService;

        expect(AirCargoServiceContext.value).toBe(testAirCargoService);

        const activityListModel = getEntityActivityList(e);
        expect(activityListModel.entity).toBe(e);

        await toPromise(activityListModel.sync);

        expect(testAirCargoService.getAirCargoActivitiesRequests.length).toBe(1);

        const r = testAirCargoService.getAirCargoActivitiesRequests[0];

        expect(r.parentId).toBe("1");

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply a filter
        e.activityFilter.setFilterText("344");

        activityListModel.filter.setFilterText("noChance");

        expect(activityListModel.itemsView.length).toBe(0);

        e.activityFilter.clear();
        activityListModel.filter.clear();

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);
    });

});