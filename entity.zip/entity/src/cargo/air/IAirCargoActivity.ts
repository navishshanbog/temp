interface IAirCargoActivity {
    documentType?: string;
    originalMsgId?: string;
    clientRoleTypeList?: string;
    searchArrivalDate?: string;
    clientInstanceId?: string;
    masterBillNbr?: string;
    houseBillNbr?: string;
    declaredValueAmount?: string;
    declaredValueAUDAmount?: string;
    flightNbr?: string;
    airlineCode?: string;
    goodsDescr?: string;
    grossWeight?: string;
    originPortCode?: string;
    consigneeAddress?: string;
    consigneeClientId?: string;
    consigneeName?: string;
    consignorAddress?: string;
    consignorClientId?: string;
    consignorName?: string;
    stsCargoStatusCode?: string;
    decTotalCval?: string;
    examCount?: number;
    examIndicator?: string;
    examFindResultCode?: string;
    positiveFindInd?: string;
    examFindCount?: number;
}

export { IAirCargoActivity as default, IAirCargoActivity };