import axios from "axios";
import { IAirCargoService, IAirCargoActivitiesGetRequest, IAirCargoDetailsGetRequest } from "./IAirCargoService";
import IAirCargoActivity from "./IAirCargoActivity";
import IAirCargoActivityDetail from "./IAirCargoActivityDetail";
import AbstractRestDataService from "../../common/AbstractRestDataService";
import * as DefaultHttpErrorHandler from "@twii/common/lib/HttpErrorHandler";
import { IServiceResponseStatus } from "../../common/IServiceResponseStatus";

const DEFAULT_MAX_NO_RECORDS = 200;
const EXAM_COUNT_IND = "Y";

interface IAirCargoSummary {
    teradataResponse?: IServiceResponseStatus; // seriously?
    numRows?: number;
    hasMoreRows?: boolean;
    data?: IAirCargoActivity[];
}

interface GetActivitiesRestResponse {
    error?: any;
    getAirCargoSummary?: IAirCargoSummary;
    totalrecords?: number;
}

interface IAirCargoDetailed {
    teradataResponse?: IServiceResponseStatus; // balls
    numRows?: number;
    hasMoreRows?: boolean;
    data?: IAirCargoActivityDetail[];
}

interface GetActivityDetailsRestResponse {
    error?: any;
    getAirCargoDetailed?: IAirCargoDetailed;
    totalrecords?: number;
}

class RestAirCargoService extends AbstractRestDataService implements IAirCargoService {
    getAirCargoActivities(request : IAirCargoActivitiesGetRequest) : Promise<IAirCargoActivity[]> {
        return axios.get(`${this.config.baseUrl}/ics/resources/v1/airCargo/${encodeURIComponent(request.parentId)}`, {
            params: { maxNoOfRecords: request.maxNumberOfRecords > 0 ? request.maxNumberOfRecords : DEFAULT_MAX_NO_RECORDS, orderByExamCountInd: request.orderByExamCountInd !== undefined ? request.orderByExamCountInd ? "Y" : "N" : EXAM_COUNT_IND }
        }).then((value) => {
            const response = value.data as GetActivitiesRestResponse;
            if(response.error) {
                return this.handleError(response.error);
            }
            return response.getAirCargoSummary && response.getAirCargoSummary.data ? response.getAirCargoSummary.data : [];
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
    getAirCargoActivityDetails(request : IAirCargoDetailsGetRequest) : Promise<IAirCargoActivityDetail[]> {
        return axios.get(`${this.config.baseUrl}/ics/resources/v1/airCargoDetailed/${encodeURIComponent(request.parentId)}`, {
            params: { masterBillNum: request.masterBillNbr, maxNoOfRecords: request.maxNumberOfRecords > 0 ? request.maxNumberOfRecords : DEFAULT_MAX_NO_RECORDS, orderByExamCountInd: request.orderByExamCountInd !== undefined ? request.orderByExamCountInd ? "Y" : "N" : EXAM_COUNT_IND }
        }).then((value) => {
            const response = value.data as GetActivityDetailsRestResponse;
            if(response.error) {
                return this.handleError(response.error);
            }
            return response.getAirCargoDetailed && response.getAirCargoDetailed.data ? response.getAirCargoDetailed.data : [];
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

export { RestAirCargoService };