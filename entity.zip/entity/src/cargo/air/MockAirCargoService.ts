import { IAirCargoService, IAirCargoActivitiesGetRequest, IAirCargoDetailsGetRequest } from "./IAirCargoService";
import IAirCargoActivity from "./IAirCargoActivity";
import IAirCargoActivityDetail from "./IAirCargoActivityDetail";

const createAirCargoActivity = (idx : number) => {
    return {
                "documentType": "ACR",
                "clientInstanceId": `232344${idx}`,
                "originalMsgId": "2015-06-25 14:03:49.833367",
                "clientRoleTypeList": "Consignor",
                "searchArrivalDate": "2015-06-25",
                "masterBillNbr": "16093300336",
                "houseBillNbr": "30377721091",
                "declaredValueAmount": "3.00",
                "declaredValueAUDAmount": "3.88",
                "flightNbr": "139",
                "airlineCode": "CX",
                "goodsDescr": "LASER PEN",
                "grossWeight": "77.00",
                "originPortCode": "HKHKG",
                "consigneeAddress": "142 LITTLE BACK CREEK ROAD NSW2429 AU",
                "consigneeClientId": "543310053046715",
                "consigneeName": "JAMES BROCK",
                "consignorAddress": "XIAORIZI NO 154 BAYIO RD 5F YIN H U GUANGZHOU CIT CHINA CN",
                "consignorClientId": "219641837238334",
                "consignorName": "4PX",
                "stsCargoStatusCode": null,
                "decTotalCval": null,
                "examCount": 1,
                "examIndicator": "Y",
                "examFindResultCode": "WEAP",
                "positiveFindInd": "Y",
                "examFindCount": 1
    };
};

const createAirCargoActivities = (count : number) => {
    const r : IAirCargoActivity[] = [];
    for(let i = 0; i < count; i ++) {
        r.push(createAirCargoActivity(i));
    }
    return r;
};

const defaultAirCargoActivityFactory = () => {
    return createAirCargoActivities(2000);
};

class MockAirCargoService implements IAirCargoService {
    recordRequests: boolean = false;
    delay: number = 2000;
    airCargoActivityFactory : () => IAirCargoActivity[] = defaultAirCargoActivityFactory;
    set getAirCargoActivitiesResponse(value : IAirCargoActivity[]) {
        this.airCargoActivityFactory = () => {
            return value;
        };
    }
    getAirCargoActivityDetailResponse: IAirCargoActivityDetail[] = [
        {
            "documentType": "ACR",
                "originalMsgId": "2015-06-25 14:03:49.650529",
                "clientRoleTypeList": "Consignor",
                "consignmentClearanceType": "CR SAC",
                "searchArrivalDate": "2015-06-25",
                "versionNbr": 1,
                "masterBillNbr": "16093300336",
                "houseBillNbr": "30377905880",
                "reptClientAddress": null,
                "reptClientName": null,
                "reptClientPostCode": null,
                "reptClientStateCode": null,
                "respClientAddress": null,
                "respClientName": null,
                "respClientPostCode": null,
                "respClientStateCode": null,
                "lowestBillInd": "Y",
                "reportedDate": "2015-06-25",
                "airlineCode": "CX",
                "currencyCode": "USD",
                "declaredValueAmount": "3.00",
                "declaredValueAUDAmount": "3.88",
                "destinationPortCode": "AUSYD",
                "destinationAUStateCode": "NSW",
                "dischargePortCode": "AUSYD",
                "dischargeAU_StateCode": "NSW",
                "estimatedArrivalDate": "2015-06-25",
                "firstAustPortCode": "",
                "firstAustStateCode": null,
                "flightNbr": "139",
                "freightForwardInd": "N",
                "goodsDescr": "LASER PEN",
                "grossWeight": "77.00",
                "highRiskMovementInd": "N",
                "actualArrivalReportAEST": "2015-06-25 20:16:00.0",
                "actualArrivalReportLocTs": "2015-06-25 20:16:00.0",
                "impendingArrivalReportFirstPortCode": "AUSYD",
                "impendingArrivalReportFirstPortAUStateCode": "NSW",
                "impendingArrivalReportCurrFirstPortETAAEST": "2015-06-25 20:00:00.0",
                "impendingArrivalReportLastOSPortCode": "HKHKG",
                "loadingPortCode": "HKHKG",
                "originCountryCode": "HK",
                "originPortCode": "HKHKG",
                "packageCount": 1,
                "parentBillNbr": "",
                "partShipmentInd": "N",
                "personalEffectsInd": "N",
                "selfAssessedClearanceInd": "Y",
                "suppressedInd": "N",
                "withdrawnInd": "N",
                "withdrawnAEST": null,
                "consigneeAddress": "2/5 LAWRENCE CT QLD4680 AU",
                "consigneeName": "JACOB MALINEACK",
                "consigneePostcode": null,
                "consigneeStateCode": null,
                "consigneeContactName": null,
                "consigneeContactPhone": null,
                "consignorAddress": "XIAORIZI NO 154 BAYIO RD 5F YIN H U GUANGZHOU CIT CHINA CN",
                "consignorName": "4PX",
                "consignorPostcode": null,
                "consignorStateCode": null,
                "notifyAddress": null,
                "notifyName": null,
                "notifyPostcode": null,
                "notifyStateCode": null,
                "examCount": 1,
                "examFindCount": 1,
                "examIndicator": "Y",
                "examFindResultCode": "WEAP",
                "examFindSigCount": 0,
                "positiveFindInd": "Y"
        }
    ];
    getAirCargoActivitiesRequests: IAirCargoActivitiesGetRequest[] = [];
    getAirCargoActivityDetailRequests: IAirCargoDetailsGetRequest[] = [];
    getAirCargoActivities(request : IAirCargoActivitiesGetRequest) : Promise<IAirCargoActivity[]> {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if(this.recordRequests) {
                    this.getAirCargoActivitiesRequests.push(request);
                }
                resolve(this.airCargoActivityFactory());
            }, this.delay);
        })
        
    }
    getAirCargoActivityDetails(request : IAirCargoDetailsGetRequest) : Promise<IAirCargoActivityDetail[]> {
        console.log("-- Mock: Air Cargo Activity Details Request: " + JSON.stringify(request));
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if(this.recordRequests) {
                    this.getAirCargoActivityDetailRequests.push(request);
                }
                return resolve(this.getAirCargoActivityDetailResponse);
            }, this.delay);
        });
    }
}

export { MockAirCargoService as default, MockAirCargoService }