import EntitySourceDashboardApp from "../../entity/component/EntitySourceDashboardApp";
import { PathsContext } from "../../PathsContext";

class EntityCargoApp extends EntitySourceDashboardApp {
    protected _getDashboardConfig = () : any => {
        return {
            type: "dashboard",
            component: {
                type: "vsplit",
                offset: 0.5,
                top: {
                    component: {
                        type: "window",
                        path: `${PathsContext.value.entitySource(this.entityId, this.sourceSystemCode)}/air`,
                        params: {
                            onSearch: this.props.match.params.onSearch
                        }
                    }
                },
                bottom: {
                    component: {
                        type: "window",
                        path: `${PathsContext.value.entitySource(this.entityId, this.sourceSystemCode)}/sea`,
                        params: {
                            onSearch: this.props.match.params.onSearch
                        }
                    }
                }
            }
        };
    };
}

export { EntityCargoApp as default, EntityCargoApp }