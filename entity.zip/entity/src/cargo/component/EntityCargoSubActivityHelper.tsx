
import {copySubActivitiesToClipboard} from "../../entity/component/MasterEntitySourceHelper";

const createCopyForCargoActivities = (model: any, sourceSubItemType:string, sourceItemType: string, type:string, e) : void => {
    let subItemHeader = type + " Cargo Report: ";
    if(type == "Sea") {
        // tinkering is still required if searchArrivalDate is empty
        subItemHeader = model.parent.searchArrivalDate ? subItemHeader + model.parent.searchArrivalDate : subItemHeader;
        subItemHeader =  model.parent.clientRoleTypeList ? subItemHeader + " | " + model.parent.clientRoleTypeList : subItemHeader;
        subItemHeader = model.parent.oceanBillNbr ? subItemHeader + " | Ocean: " + model.parent.oceanBillNbr : subItemHeader;
        subItemHeader = model.parent.houseBillNbr ? subItemHeader + " | House: " + model.parent.houseBillNbr : subItemHeader;
    } else {
        // tinkering is still required if searchArrivalDate is empty
        subItemHeader =  model.parent.searchArrivalDate ? subItemHeader + model.parent.searchArrivalDate : subItemHeader;
        subItemHeader = model.parent.clientRoleTypeList ? subItemHeader + " | " + model.parent.clientRoleTypeList : subItemHeader;
        subItemHeader = model.parent.masterBillNbr ? subItemHeader + " | Master: " + model.parent.masterBillNbr : subItemHeader;
        subItemHeader = model.parent.houseBillNbr ? subItemHeader + " | House: " + model.parent.houseBillNbr : subItemHeader;
    }
    let item={
        fieldValues: model.items,
        source: model.parent ? model.parent.source : undefined, 
        sourceSubItemType: sourceSubItemType,
        masterEntityId: model.parent && model.parent.entity ? model.parent.entity.masterEntityId : undefined,
        sourceSubItemHeader: subItemHeader,
        sourceItemType:sourceItemType
    }
    copySubActivitiesToClipboard(e, item);
};

export {createCopyForCargoActivities}