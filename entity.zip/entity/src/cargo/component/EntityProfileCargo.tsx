import * as React from "react";
import IEntityProfileSourceGroupProps from "../../entity/profile/component/IEntityProfileSourceGroupProps";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import AirCargoActivityColumns from "../air/component/AirCargoActivityColumns";
import SeaCargoActivityColumns from "../sea/component/SeaCargoActivityColumns";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import {
    buildSectionHeader, buildTable, buildComments
} from "../../entity/profile/EntityProfileDocumentHelper";
import SubEntityProfileSourceDetailList from "../../entity/profile/component/SubEntityProfileSourceDetailList";
import { getViewPreferenceColumns } from "@twii/common/lib/component/ColumnHelper";
import { buildSectionList, buildSectionSubHeader } from "../../entity/profile/EntityProfileDocumentHelper";
import { equalsIgnoreCase } from "@twii/common/lib/util/String";
import { IEntitySourceItems } from "../../entity/IEntitySourceItems";
import { SeaCargoDetailGoodsIndFields, SeaCargoActivityDetailGoodsIndViewPrefsStore } from "../sea/component/SeaCargoActivityDetailGoodsIndicator";
import { SeaCargoActivityDetailCargoFields, SeaCargoActivityDetailsViewPrefsStore } from "../sea/component/SeaCargoActivityDetailCargoReport";
import { SeaCargoContactInfoFields, SeaCargoActivityDetailsContactInfoViewPrefStore } from "../sea/component/SeaCargoActivityDetailContactInfo";
import { SeaCargoGoodsInfoFields, SeaCargoActivityDetailsGoodsInfoViewPrefStore } from "../sea/component/SeaCargoActivityDetailGoodsInfo";
import { SeaCargoExamsInfoFields, SeaCargoActivityDetailExamsInfoViewPrefsStore } from "../sea/component/SeaCargoActivityDetailExamsInfo";
import { AirCargoActivityDetailContactInfoFields, AirCargoActivityDetailsContactsInfoViewPrefsStore } from "../air/component/AirCargoActivityDetailContactInfo";
import { AirCargoDetailGoodsIndFields } from "../air/component/AirCargoActivityDetailGoodsIndicators";
import { AirCargoActivityDetailCargoFields, AirCargoActivityDetailsViewPrefsStore } from "../air/component/AirCargoActivityDetailCargoReport";
import { AirCargoGoodsInfoFields, AirCargoActivityDetailGoodsInfoViewPrefsStore } from "../air/component/AirCargoActivityDetailGoodsInfo";
import { AirCargoExamsInfoFields, AirCargoActivityDetailExamsInfoViewPrefsStore } from "../air/component/AirCargoActivityDetailExamsInfo";
import IAirCargoActivity from "../air/IAirCargoActivity";
import ISeaCargoActivity from "../sea/ISeaCargoActivity";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";
import { PathsContext } from "../../PathsContext";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";

class EntityProfileAirCargoApp extends EntityProfileSourceGroupApp {
    private _onItemInvoked = (item : IAirCargoActivity) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.setValue({ path: PathsContext.value.airCargoDetails(item.clientInstanceId), query: { masterBillNbr: item.masterBillNbr }, airCargoActivity: item, panelProps: panelProps });
    }
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="air-cargo-activities" title="Air Cargo Activities">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={AirCargoActivityColumns} onItemInvoked={this._onItemInvoked} />
                <SubEntityProfileSourceDetailList group={this.group} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const AirCargoActivityDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("Air Cargo Activities", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, AirCargoActivityColumns, doc);
    if (group.hasSubTypes) {
        group.subEntities.map((subEntity: IEntitySourceItems) => {
            if (!(subEntity.items === null)) {
                buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader, doc);
                if (equalsIgnoreCase(subEntity.type, "air/cargoReport")) {
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(AirCargoActivityDetailCargoFields, AirCargoActivityDetailsViewPrefsStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(AirCargoGoodsInfoFields, AirCargoActivityDetailGoodsInfoViewPrefsStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(AirCargoActivityDetailContactInfoFields, AirCargoActivityDetailsViewPrefsStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(AirCargoDetailGoodsIndFields, AirCargoActivityDetailsContactsInfoViewPrefsStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(AirCargoExamsInfoFields, AirCargoActivityDetailExamsInfoViewPrefsStore), doc);
                }
            }
        });
    }
    buildComments(group.comments, doc);
};

class EntityProfileSeaCargoApp extends EntityProfileSourceGroupApp {
    private _onItemInvoked = (item : ISeaCargoActivity) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.setValue({ path: PathsContext.value.seaCargoDetails(item.clientInstanceId), query: { oceanBillNumber: item.oceanBillNbr }, seaCargoActivity: item, panelProps: panelProps });
    }
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="sea-cargo-activities" title="Sea Cargo Activities">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={SeaCargoActivityColumns} onItemInvoked={this._onItemInvoked} />
                <SubEntityProfileSourceDetailList group={this.group} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const SeaCargoActivityDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("Sea Cargo Activities", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, SeaCargoActivityColumns, doc);
    if (group.hasSubTypes) {
        group.subEntities.map((subEntity: IEntitySourceItems) => {
            if (!(subEntity.items === null)) {
                buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader, doc);
                if (equalsIgnoreCase(subEntity.type, "sea/cargoReport")) {
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(SeaCargoActivityDetailCargoFields, SeaCargoActivityDetailsViewPrefsStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(SeaCargoGoodsInfoFields, SeaCargoActivityDetailsGoodsInfoViewPrefStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(SeaCargoContactInfoFields, SeaCargoActivityDetailsContactInfoViewPrefStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(SeaCargoDetailGoodsIndFields, SeaCargoActivityDetailGoodsIndViewPrefsStore), doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(SeaCargoExamsInfoFields, SeaCargoActivityDetailExamsInfoViewPrefsStore), doc);
                }
            }
        });
    }
    buildComments(group.comments, doc);
};

export { EntityProfileAirCargoApp, EntityProfileSeaCargoApp, AirCargoActivityDocumentHandler, SeaCargoActivityDocumentHandler }