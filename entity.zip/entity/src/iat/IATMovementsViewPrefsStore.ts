import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const IATMovementsViewPrefsStore = new ViewPreferencesModel("iatMovements");

export { IATMovementsViewPrefsStore as default, IATMovementsViewPrefsStore }