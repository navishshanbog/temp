import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IATMovementListContainer, IIATMovementListProps } from "./IATMovementList";
import IIATMovement from "../IIATMovement";
import IIATAlias from "../IIATAlias";
import IMasterEntityModel from "../../entity/IMasterEntityModel";
import { getEntityMovementList, getEntityAliasList } from "../IATMovementHelper";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import { Sync } from "@twii/common/lib/component/Sync";
import IMasterEntitySearchRequest from "../../entity/IMasterEntitySearchRequest";
import { AppView } from "@twii/common/lib/component/AppView";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { PathsContext } from "../../PathsContext";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";

interface IATAliasInfoProps {
    aliasList: IMasterEntitySourceListModel<IIATAlias>;
    onOpenAliases?: (entity : IMasterEntityModel) => void;
}

class EntityIATAliasInfo extends React.Component<IATAliasInfoProps, any> {
    componentWillMount() {
        this.props.aliasList.load();
    }
    private _onClickViewAliases = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        if(this.props.onOpenAliases) {
            this.props.onOpenAliases(this.props.aliasList.entity);
        }
    }
    private _onRenderDone = () => {
        if(this.props.aliasList.total > 0) {
            return (
                <MessageBar messageBarType={MessageBarType.warning}>
                    Traveller exists in IAT system, but has no movements.
                    {this.props.onOpenAliases &&
                        <span>You can <a href="#" onClick={this._onClickViewAliases}>View Aliases</a></span>
                    }
                </MessageBar>
            );
        }
        return <MessageBar messageBarType={MessageBarType.error}>There are no IAT details available for the selected Master Entity</MessageBar>;
    }
    render() {
        return <Sync sync={this.props.aliasList.sync} onRenderDone={this._onRenderDone} />
    }
}

class EntityIATMovementContent extends React.Component<IIATMovementListProps, any> {
    private _onRenderDone = () => {
        if(this.props.list.total > 0) {
            return <IATMovementListContainer {...this.props} />
        }
        return <EntityIATAliasInfo aliasList={getEntityAliasList(this.props.list.entity)} onOpenAliases={this.props.onOpenAliases} />;
    }
    render() {
        return <Sync sync={this.props.list.sync} syncLabel="Loading IAT Summary..." onRenderDone={this._onRenderDone} />;
    }
}

interface IEntityIATMovementProps {
    entity: IMasterEntityModel;
    onItemInvoked?: (item : IIATMovement) => void;
    onOpenAliases?: (entity : IMasterEntityModel) => void;
    onOpenFlightList?: (props : IIATMovementListProps) => void;
    onOpenVisas?: (item : IIATMovement) => void;
    onOpenTravelDocuments?: (item : IIATMovement) => void;
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

@observer
class EntityIATMovement extends React.Component<IEntityIATMovementProps, any> {
    render() {
        return (
            <AppView>
                <EntityIATMovementContent list={getEntityMovementList(this.props.entity)}
                                          onItemInvoked={this.props.onItemInvoked}
                                          onOpenAliases={this.props.onOpenAliases}
                                          onOpenFlightList={this.props.onOpenFlightList}
                                          onOpenVisas={this.props.onOpenVisas}
                                          onOpenTravelDocuments={this.props.onOpenTravelDocuments} />
            </AppView>
        );
    }
}

class EntityIATMovementApp extends EntitySourceApp {
    private _onItemInvoked = (item : IIATMovement) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.iatMovementDetails(),
            movement: item,
            query: item,
            panelProps: panelProps
        };
    }
    private _onOpenAliases = (entity : IMasterEntityModel) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.iatAliases(),
            entity: entity,
            panelProps: panelProps
        };
    }
    private _onOpenFlightList = (props : IIATMovementListProps) => {
        const movements = props.list.selection.selectedItems;
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.iatFlightLists(),
            entity: props.list.entity,
            movements: movements,
            panelProps: panelProps
        };
    }
    private _onOpenVisas = (item : IIATMovement) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.iatVisa(item.visaIdentifyingNbr),
            movement: item,
            panelProps: panelProps
        };
    }
    private _onOpenTravelDocuments = (item : IIATMovement) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.iatPassport(item.travelDocDeptCountryCode, item.travelDocumentId),
            movement: item,
            panelProps: panelProps
        };
    }
    protected _onRenderSource = (props) => {
        return <EntityIATMovement entity={props.masterEntity}
                                  onSearch={this.props.match.params.onSearch}
                                  onItemInvoked={this._onItemInvoked}
                                  onOpenAliases={this._onOpenAliases}
                                  onOpenFlightList={this._onOpenFlightList}
                                  onOpenVisas={this._onOpenVisas}
                                  onOpenTravelDocuments={this._onOpenTravelDocuments} />;
    }
}

export {
    EntityIATMovement,
    IEntityIATMovementProps,
    EntityIATMovementApp,
    EntityIATMovementApp as default
}