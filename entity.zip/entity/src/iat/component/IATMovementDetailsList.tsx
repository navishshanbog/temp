import * as React from "react";
import IIATMovement from "../IIATMovement";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IATMovementColumns from "./IATMovementColumns";
import MasterEntitySourceDetailsList from "../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import { mergeRenderers } from "@twii/common/lib/component/ColumnHelper";
import { Link } from "office-ui-fabric-react/lib/Link";

interface IIATMovementDetailsListProps {
    list: IMasterEntitySourceListModel<IIATMovement>;
    viewPreferences?: IViewPreferencesModel;
    onItemInvoked?: (item : IIATMovement) => void;
    onOpenVisas?: (item : IIATMovement) => void;
    onOpenTravelDocuments?: (item : IIATMovement) => void;
}

interface IIATMovementProps {
    item: IIATMovement;
    onClick?: (item : IIATMovement) => void;
}

class IATMovementVisaIdentifyingNumber extends React.Component<IIATMovementProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.preventDefault();
        this.props.onClick(this.props.item);
    }
    render() {
        const { item } = this.props;
        if(item.visaIdentifyingNbr && this.props.onClick) {
            return <Link onClick={this._onClick}>{item.visaIdentifyingNbr}</Link>;
        }
        return item.visaIdentifyingNbr;
    }
}

class IATMovementTravelDocument extends React.Component<IIATMovementProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.preventDefault();
        this.props.onClick(this.props.item);
    }
    render() {
        const { item } = this.props;
        if(item.travelDocumentId && this.props.onClick) {
            return <Link onClick={this._onClick}>{item.travelDocumentId}</Link>;
        }
        return item.travelDocumentId;
    }
}

class IATMovementDetailsList extends React.Component<IIATMovementDetailsListProps, any> {
    private _onRenderVisaIdentifyingNumber = (item : IIATMovement) => {
        return <IATMovementVisaIdentifyingNumber item={item} onClick={this.props.onOpenVisas} />;
    }
    private _onRenderTravelDocument = (item : IIATMovement) => {
        return <IATMovementTravelDocument item={item} onClick={this.props.onOpenTravelDocuments} />;
    }
    render() {
        const columns = mergeRenderers(IATMovementColumns, {
            visaIdentifyingNbr: this._onRenderVisaIdentifyingNumber,
            travelDocumentId: this._onRenderTravelDocument
        });
        return <MasterEntitySourceDetailsList
                    columns={columns}
                    viewPreferences={this.props.viewPreferences}
                    list={this.props.list}
                    typeLabel="IAT Movements"
                    itemType="movement"
                    onItemInvoked={this.props.onItemInvoked} />;
    }
}

export { IATMovementDetailsList as default, IATMovementDetailsList, IIATMovementDetailsListProps }