import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import * as DateUtils from "@twii/common/lib/util/Date";
import NameGenderCdRef from "../../ref/NameGenderCd";
import SourceSystemCdRef from "../../ref/SourceSystemCd";
import IIATAlias from "../IIATAlias";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import {createCopyForIATActivities} from "./IATMovementSubActivityHelper";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import IMasterEntityModel from "../../entity/IMasterEntityModel";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import { findAliasesByEntity, findAliasesByTravellerIds } from "../model/IATFinder";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { AppView } from "@twii/common/lib/component/AppView";
import { EntityAppView } from "../../common/component/EntityAppView";
import "./IATMovementAliases.scss";

const Fields  : IColumn[] = [{ //IDetailsAttributeConfig<IIATAlias>[] = [{
    key: "iatTravellerID",
    fieldName: "iatTravellerID",
    minWidth: 50,
    name: "IAT Traveller Id"
}, {
    key: "aliasSequenceNbr",
    fieldName: "aliasSequenceNbr",
    minWidth: 50,
    name: "Alias Sequence Number"
}, {
    key: "familyName",
    fieldName: "familyName",
    minWidth: 50,
    name: "Family Name"
}, {
    key: "givenNames",
    fieldName: "givenNames",
    minWidth: 50,
    name: "Given Names"
}, {
    key: "birthDate",
    fieldName: "birthDate",
    minWidth: 50,
    name: "Birth Date",
    onRender: function(item: IIATAlias) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.birthDate)}/>;
    },
    data: { getText: (item: IIATAlias) => DateUtils.dataToOutputText(item.birthDate) }
}, {
    key: "birthDeptCountryCode",
    name: "Birth Country",
    fieldName: "birthDeptCountryCode",
    minWidth: 50,
}, {
    key: "sexCode",
    name: "Gender",
    fieldName: "sexCode",
    minWidth: 50,
    onRender: function(item: IIATAlias) {
        return <DetailsAttribute key={this.key} label={this.name} value={NameGenderCdRef[item.sexCode]}/>;
    },
    data: { getText: (item: IIATAlias) => NameGenderCdRef[item.sexCode] }
}, {
    key: "maritalStatusCode",
    fieldName: "maritalStatusCode",
    minWidth: 50,
    name: "Marital Status"
}, {
    key: "birthNameInd",
    fieldName: "birthNameInd",
    minWidth: 50,
    name: "Birth Name Ind"
}, {
    key: "citizenshipNameInd",
    fieldName: "citizenshipNameInd",
    minWidth: 50,
    name: "Citizenship Name Ind"
}, {
    key: "currentNameInd",
    fieldName: "currentNameInd",
    minWidth: 50,
    name: "Current Name Ind"
}, {
    key: "deptPersonIDInd",
    fieldName: "deptPersonIDInd",
    minWidth: 50,
    name: "Dept Person Id Ind"
}, {
    key: "additionalAliasInd",
    fieldName: "additionalAliasInd",
    minWidth: 50,
    name: "Additional Alias Ind"
}, {
    key: "dimiaAliasInd",
    fieldName: "dimiaAliasInd",
    minWidth: 50,
    name: "DIMIA Alias Ind"
}, {
    key: "lastUpdateDate",
    fieldName: "lastUpdateDate",
    minWidth: 50,
    name: "Last Update Date",
    onRender: function(item: IIATAlias) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.lastUpdateDate)}/>;
    },
    data: { getText: (item: IIATAlias) => DateUtils.dataToOutputText(item.lastUpdateDate) }
}, {
    key: "sourceFileCode",
    name: "Source File Code",
    fieldName: "sourceFileCode",
    minWidth: 50,
}, {
    key: "sourceSystemCode",
    name: "Sourced From",
    fieldName: "sourceSystemCode",
    minWidth: 50,
    onRender: function(item: IIATAlias) {
        return <DetailsAttribute key={this.key} label={this.name} value={SourceSystemCdRef.getDesc(item.sourceSystemCode)}/>;
    },
    data: { getText: (item: IIATAlias) => SourceSystemCdRef.getDesc(item.sourceSystemCode) }
}];

const IATMovementAliasesViewPrefsStore = new ViewPreferencesModel("iatMovementAliases");

interface IIATMovementAliasesProps {
    aliases: IIATAlias[];
}

class IATMovementAliases extends React.Component<IIATMovementAliasesProps, any> {
    render() {
        let content;
        if(this.props.aliases && this.props.aliases.length > 0) {
            content = this.props.aliases.map((alias: IIATAlias, idx: number) => {
                return <DetailsItem key={idx} model={alias} attrConfig={Fields} viewPrefModel={IATMovementAliasesViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Movement does not have aliases recorded</MessageBar>;
        }
        return <div className="iat-movement-aliases">{content}</div>
    }
}

interface IIATMovementAliasesContainerProps {
    model: ISyncSupplier<IIATAlias[], IMasterEntityModel>;
}

class IATMovementAliasesAppView extends React.Component<IIATMovementAliasesContainerProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.model.parent) {
            items.push(
                createCopyForIATActivities({
                    modelData: { masterEntity: this.props.model.parent },
                    data: this.props.model.value,
                    subEntityHeader: "IAT Aliases",
                    subItemType: "IATAliases",
                    name: "Copy",
                    title: "Copy"
                })
            );
        }
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(IATMovementAliasesViewPrefsStore, Fields)
        ];
        return (
            <AppView commandBarProps={{ items: items, farItems: farItems }}>
                <IATMovementAliases aliases={this.props.model.value} />
            </AppView>
        )
    }
}

class IATMovementAliasesContainer extends React.Component<IIATMovementAliasesContainerProps, any> {
    componentWillMount() {
        this.props.model.load();
    }
    private _onRenderDone = () => {
        return <IATMovementAliasesAppView {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} syncLabel="Loading Aliases..." onRenderDone={this._onRenderDone} />;
    }
}

class IATMovementAliasesApp extends EntityAppBase {
    get entity() : IMasterEntityModel {
        return this.props.match.entity;
    }
    get iatTravellerIds() : string[] {
        return this.props.match.params.iatTravellerIds;
    }
    get detailsSupplier() : ISyncSupplier<IIATAlias[], IMasterEntityModel> {
        const e = this.entity;
        if(e) {
            return findAliasesByEntity(e);
        }
        return findAliasesByTravellerIds(this.iatTravellerIds);
    }
    componentWillMount() {
        this.host.title = "Aliases";
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker >
                <IATMovementAliasesContainer model={this.detailsSupplier} />
            </EntityAppView>
        );
    }
}

export{
    IATMovementAliasesApp,
    IATMovementAliasesApp as default,
    IIATMovementAliasesProps,
    IATMovementAliases,
    IATMovementAliasesContainer,
    IATMovementAliasesViewPrefsStore,
    Fields as AliasFields
};