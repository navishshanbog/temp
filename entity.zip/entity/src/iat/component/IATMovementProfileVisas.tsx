import * as React from "react";
import "./IATMovementVisas.scss";
import { IATMovementVisas } from "./IATMovementVisas";

class IATMovementProfileVisas extends React.Component<any, any> {
    render() {
        const items = this.props.match.items;
        let list;
        if(items && items.length > 0) {
            list = items[0].subItems;
        }
        return (
            <div className="iat-movement-visas">
                <IATMovementVisas list={list} />
            </div>
        );
    }
}

export { IATMovementProfileVisas as default, IATMovementProfileVisas };