import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { getIcon } from 'office-ui-fabric-react/lib/Styling';
import { IIATAssociatedTravellersModel } from "../model/IIATAssociatedTravellersModel";
import "./IATAssociatedTravellerGraph.scss";
import * as vis from "vis";
import { IIATAssociatedTravellersGraph } from "../IIATAssociatedTravellersGraph";
import { observer } from "mobx-react";
import { CommandBarButton } from "office-ui-fabric-react/lib/Button";

const MovementIcon = getIcon('AirplaneSolid');

const graphOptions = {
    groups: {
        movements: {
            shape: 'icon',
            icon: {
                face: MovementIcon.subset.fontFace.fontFamily,
                code: MovementIcon.code,
                size: 40,
                color: '#57169a'
            },
            font: {
                size: 13
            }
        },
        traveller: {
            shape: 'icon',
            icon: {
                face: 'Analyst Desktop Icons',
                code: '\uE005',
                size: 40,
                color: '#f0a30a'
            },
            font: {
                size: 13,
                vadjust: 5
            }
        },
        assocTravellers: {
            shape: 'icon',
            icon: {
                face: 'Analyst Desktop Icons',
                code: '\uE005',
                size: 40,
                color: '#aa00ff'
            },
            font: {
                size: 13,
                vadjust: 5
            }
        }
    },
    layout: {
        hierarchical: {
            sortMethod: 'directed',
            direction: 'UD'
        }
    },
    edges: {
        smooth: true
    },
    physics: {
        stabilization: false
    }
};

interface IIATAssociatedTravellersGraphProps {
    graph: IIATAssociatedTravellersGraph;
}

class IATAssociatedTravellersGraph extends React.Component<IIATAssociatedTravellersGraphProps, any> {
    private _graphContainerRef : HTMLElement;
    private _canvas : any;
    private _downloadLinkRef : HTMLAnchorElement;
    private _onGraphContainerRef = (graphContainer : HTMLElement) => {
        this._graphContainerRef = graphContainer;
    };
    _handleCanvasImgDownloadLinkClick = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.stopPropagation();
    };
    private _onDownloadLinkRef = (ref: HTMLAnchorElement) => {
        this._downloadLinkRef = ref;
    };
    _draw = () => {
        if (!this._graphContainerRef) {
            return;
        }
        let nodes: any[] = this.props.graph.nodes.slice().map((node: any) => {
           return Object.assign({}, node, { margin: 10 });
        });

        let network = new vis.Network(this._graphContainerRef, { nodes: nodes, edges: this.props.graph.edges.slice() }, graphOptions);
        network.on("beforeDrawing", ctx => {
            // save current translate/zoom
            ctx.save();
            // reset transform to identity
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            // fill background with solid white
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height)
            // restore old transform
            ctx.restore();
        });
        network.once("afterDrawing", (ctx) => {
            network.fit({
                animation: {
                    duration: 500,
                    easingFunction: 'linear'
                }
            });
            this._canvas = ctx.canvas;
        });
        network.on("afterDrawing", (ctx) => {
            if (this._downloadLinkRef && this._downloadLinkRef.href) {
                this._cleanupDownloadBlobRef();
                this._downloadLinkRef.href = ctx.canvas.toDataURL();
            }
        });
    };
    private _cleanupDownloadBlobRef = () => {
        if (this._downloadLinkRef && this._downloadLinkRef.href) {
            try {
                URL.revokeObjectURL(this._downloadLinkRef.href);
            } catch(e) {}
        }
    }
    private _onDownloadImageClick = (e : React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
    }
    downloadImage() {
        const fname = 'AssociatedTravellers.png';
        if(this._canvas && this._canvas.msToBlob && window.navigator && window.navigator.msSaveOrOpenBlob) {
            let blob = this._canvas.msToBlob();
            window.navigator.msSaveOrOpenBlob(blob, fname);
        } else if(this._downloadLinkRef) {
            this._downloadLinkRef.download = fname;
            this._downloadLinkRef.click();
        }
    };
    componentDidMount() {
        this._draw();
    }
    componentDidUpdate() {
        this._draw();
    }
    render() {
        /*
        const downloadCanvasImgButton: IContextualMenuItem = {
            key: 'downloadCanvasImg',
            iconProps: {iconName: 'Camera'},
            name: "Download Image",
            onClick: this._handleDownloadCanvasImgButtonClick
        };
        const thresholdMenuItem: IContextualMenuItem = createThresholdMenuItem(this.props.assocTravellerModel);
        */
        return [
            <div key="container" className="associated-traveller-graph" ref={this._onGraphContainerRef}></div>,
            <a key="download" href="#" hidden={true} ref={this._onDownloadLinkRef} onClick={this._onDownloadImageClick}>Download image</a>
        ];
    }
}

interface IIATAssociatedTravellersGraphContainerProps {
    model: IIATAssociatedTravellersModel;
}

@observer
class IATAssociatedTravellersMovementThresholdSelector extends React.Component<IIATAssociatedTravellersGraphContainerProps, any> {
    private _onClickThreshold = (e, item) => {
        this.props.model.movementThreshold = item.threshold;
    }
    render() {
        const menuItems : IContextualMenuItem[] = this.props.model.movementThresholds.map(movementThreshold => {
            return {
                key: String(movementThreshold),
                name: String(movementThreshold),
                model: this.props.model,
                threshold: movementThreshold,
                onClick: this._onClickThreshold,
                checked: this.props.model.movementThreshold === movementThreshold,
                canCheck: true
            } as IContextualMenuItem;
        });
        return (
            <CommandBarButton menuProps={{ items: menuItems }}>
                Minimum Associated Movements : {this.props.model.movementThreshold}
            </CommandBarButton>
        );
    }
}

const iatAssociatedTravellersMovementThresholdSelectorItem = (props : IIATAssociatedTravellersGraphContainerProps, key : string = "iatMovementThreshold") : IContextualMenuItem => {
    return {
        key: key,
        onRender(item) {
            return <IATAssociatedTravellersMovementThresholdSelector key={key} {...props} />;
        }
    }
}

@observer
class IATAssociatedTravellersGraphWrapper extends React.Component<IIATAssociatedTravellersGraphContainerProps, any> {
    private _graphRef : IATAssociatedTravellersGraph;
    private _onGraphRef = (ref : IATAssociatedTravellersGraph) => {
        this._graphRef = ref;
    }
    downloadImage() {
        if(this._graphRef) {
            this._graphRef.downloadImage();
        }
    }
    render() {
        return <IATAssociatedTravellersGraph graph={this.props.model.associatedTravellersGraph} ref={this._onGraphRef} />;
    }
}

interface IIATAssociatedTravellerGraphCommandBarProps extends IIATAssociatedTravellersGraphContainerProps {
    onDownloadImage?: () => void;
}

class IATAssociatedTravellersGraphCommandBar extends React.Component<IIATAssociatedTravellerGraphCommandBarProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        const farItems : IContextualMenuItem[] = [];
        farItems.push(
            iatAssociatedTravellersMovementThresholdSelectorItem(this.props)
        );
        if(this.props.onDownloadImage) {
            farItems.push(
                {
                    key: "downloadImage",
                    iconProps: { iconName: "Camera" },
                    onClick: this.props.onDownloadImage
                }
            );
        }
        return <CommandBar items={items} farItems={farItems} />
    }
}

class IATAssociatedTravellersGraphContainer extends React.Component<IIATAssociatedTravellersGraphContainerProps, any> {
    private _graphRef : IATAssociatedTravellersGraphWrapper;
    private _onGraphRef = (ref : IATAssociatedTravellersGraphWrapper) => {
        this._graphRef = ref;
    }
    private _onDownloadGraphImage = () => {
        if(this._graphRef) {
            this._graphRef.downloadImage();
        }
    }
    render() {
        return [
            <IATAssociatedTravellersGraphWrapper key="graph" {...this.props} ref={this._onGraphRef} />,
            <IATAssociatedTravellersGraphCommandBar key="commands" {...this.props} onDownloadImage={this._onDownloadGraphImage} />
        ];
    }
}

export {
    IIATAssociatedTravellersGraphContainerProps,
    IATAssociatedTravellersGraphContainer
};