import * as React from "react";
import "./IATMovementDetails.scss";
import { IATMovementDetails } from "./IATMovementDetail";
import { IAppProps } from "@twii/common/lib/component/IAppProps";

class IATMovementProfileDetail extends React.Component<IAppProps, any> {
    render() {
        const items = this.props.match.items;
        let details;
        if(items && items.length > 0) {
            details = items[0].subItems;
        }
        return (
            <IATMovementDetails details={details} />    
        );
    }
}


export { IATMovementProfileDetail as default, IATMovementProfileDetail };