import * as React from "react";
import "./IATMovementAliases.scss";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { IATMovementAliases } from "./IATMovementAliases";

class IATMovementProfileAliases extends React.Component<IAppProps, any> {
    render() {
        let aliases;
        const items = this.props.match.items;
        if(items && items.length > 0) {
            aliases = items[0].subItems;
        }
        return (
            <IATMovementAliases aliases={aliases} />
        );
    }
}


export{ IATMovementProfileAliases as default, IATMovementProfileAliases };