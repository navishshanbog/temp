import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    ColumnActionsMode,
    SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { Link } from "office-ui-fabric-react/lib/Link";
import { Pivot, PivotItem } from "office-ui-fabric-react/lib/Pivot";
import * as DateUtils from "@twii/common/lib/util/Date";
import { formatToNISName } from "../../entity/EntityNameUtils";
import SourceSystemCdRef from "../../ref/SourceSystemCd";
import IIATMovement from "../IIATMovement";
import "./IATMovementDetails.scss";
import NameGenderCdRef from "../../ref/NameGenderCd";
import IMasterEntityModel from "../../entity/IMasterEntityModel";
import IMasterEntitySearchRequest from "../../entity/IMasterEntitySearchRequest";
import { IIATFlightListModel } from "../model/IIATFlightListModel";
import { IATAssociatedTravellerDetail, getIATAssociatedTravellerDetailColumns } from "./IATAssociatedTravellerDetail";
import IIATFlightListItem from "../IIATFlightListItem";
import * as moment from "moment";
import { movementToKey, movementToOutputText } from "../IATMovementHelper";
import { ExcelWorkBook, WorkBookProps, Column, ColumnType } from "../../common/ExcelWorkBook";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import { EntityAppView } from "../../common/component/EntityAppView";
import { findFlightListsByEntityMovements } from "../model/IATFinder";
import { AppView } from "@twii/common/lib/component/AppView";
import { IIATMovementFlightList } from "../IIATMovementFlightList";
import { Output as DateOutputFormats } from "@twii/common/lib/DateFormats";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IATAssociatedTravellersGraphContainer } from "./IATAssociatedTravellerGraph";

class IATFlightListColumn implements IColumn, Column {
    fieldName: string;
    label: string;
    key: string;
    ariaLabel: string;
    name: string;
    minWidth: number = 50;
    maxWidth: number = 100;
    isResizable: boolean = true;
    columnActionsMode: ColumnActionsMode = ColumnActionsMode.clickable;
    width: number = 100;
    excelIncludeColumn: boolean = true;
    type: ColumnType = ColumnType.STRING;
    constructor(fieldName: string, label: string) {
        this.fieldName = fieldName;
        this.label = label;
        this.key = fieldName;
        this.ariaLabel = label;
        this.name = label;
    }
}

interface IIATFlightListItemProps extends IIATFlightListProps {
    item: IIATFlightListItem;
}

class IATFlightListNISName extends React.Component<IIATFlightListItemProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
        const { item, onSearch } = this.props;
        onSearch({ fullName: `${item.givenNames} ${item.familyName}`, dob: item.birthDate });
    }
    render() {
        const { item, onSearch } = this.props;
        const nisName: string = formatToNISName(item.familyName, item.givenNames, null, NameGenderCdRef[item.sexCode], item.birthDate);
        return onSearch ? <Link onClick={this._onClick}>{nisName}</Link> : nisName;
    }
}

const getColumns = (props : IIATFlightListProps) : IATFlightListColumn[] => {
    return [
        Object.assign(new IATFlightListColumn("nisName", "NIS Name"), {
            minWidth: 200,
            maxWidth: 250,
            excelIncludeColumn: false,
            onRender: (item: IIATFlightListItem) => {
                return <IATFlightListNISName {...props} item={item} />;
            }
        }),
        new IATFlightListColumn("travelDocumentId", "Passport"),
        new IATFlightListColumn("travelDocCountryCode", "Passport Country"),
        new IATFlightListColumn("birthDeptCountryCode", "Birth Country"),
        new IATFlightListColumn("aliasSequenceNbr", "Alias Sequence Number"),
        new IATFlightListColumn("givenNames", "Given Names"),
        new IATFlightListColumn("familyName", "Family Name"),
        Object.assign(new IATFlightListColumn("sexCode", "Gender"), {
            minWidth: 10,
            maxWidth: 40,
            onRender: (item: IIATFlightListItem) => {
                return NameGenderCdRef[item.sexCode];
            },
            onRenderExcel:  (item: IIATFlightListItem) => {
                return NameGenderCdRef[item.sexCode];
            }
        }),
        Object.assign(new IATFlightListColumn("birthDate", "Date of Birth"), {
            type: ColumnType.DATE,
            onRender: (item: IIATFlightListItem) => {
                return DateUtils.dataToOutputText(item.birthDate);
            }
        }),
        new IATFlightListColumn("actualMovementMessageID", "Actual Movement Message ID"),
        Object.assign(new IATFlightListColumn("expectedMovementMessageID", "Expected Movement Message ID"), {
            minWidth: 125,
            maxWidth: 125
        }),
        new IATFlightListColumn("expectedMovementNbr", "Expected Movement Number"),
        new IATFlightListColumn("movementStatusCode", "Movement Status Code"),
        new IATFlightListColumn("movementTime", "Movement Time"),
        new IATFlightListColumn("movementHistoryInd", "Movement History Ind"),
        new IATFlightListColumn("visaIdentifyingNBR", "Visa Identifying Number"),
        new IATFlightListColumn("visaID", "Visa ID"),
        new IATFlightListColumn("visaSubClassCode", "Visa SubClass Code"),
        Object.assign(new IATFlightListColumn("visaGrantDate", "Visa Grant Date"), {
            type: ColumnType.DATE,
            onRender: (item: IIATFlightListItem) => {
                return DateUtils.dataToOutputText(item.visaGrantDate);
            }
        }),
        new IATFlightListColumn("passengerCrewCode", "Passenger Crew Code"),
        new IATFlightListColumn("postMovementInd", "Post Movement Ind"),
        new IATFlightListColumn("bagsExamReferralReasonCode", "BAGS Exam Referral Reason Code"),
        new IATFlightListColumn("travelDocSequenceNbr", "Travel Doc Sequence Number"),
        Object.assign(new IATFlightListColumn("sourceSystemCode", "Sourced From"), {
            onRender: (item: IIATFlightListItem) => {
                return SourceSystemCdRef.getDesc(item.sourceSystemCode);
            },
            onRenderExcel:  (item: IIATFlightListItem) => {
                return SourceSystemCdRef.getDesc(item.sourceSystemCode);
            }
        }),
        new IATFlightListColumn("travellerMovementTypeCode", "Traveller Movement Type Code"),
        new IATFlightListColumn("alertInd", "Alert Indicator"),
        new IATFlightListColumn("movementRaceID", "Race ID"),
        new IATFlightListColumn("userID", "User ID"),
        new IATFlightListColumn("numberOfExamsForTheTraveller", "Number of Exams For The Traveller"),
        new IATFlightListColumn("positiveFindCountForTraveller", "Positive Find Count For Traveller"),
        new IATFlightListColumn("examinationForTravellerInd", "Examination For Traveller Ind"),
        new IATFlightListColumn("positiveFindForTravellerInd", "Positive Find For Traveller Ind")
    ] as IATFlightListColumn[];
}

const getVisibleColumns = (columns : IATFlightListColumn[]) : IATFlightListColumn[] => {
    return columns.filter(column => IATFlightListViewPrefsStore.isFieldVisible(column.key));
};

const getExcelVisibleColumns = (columns : IATFlightListColumn[]) : IATFlightListColumn[] => {
    return getVisibleColumns(columns).filter(col => col.excelIncludeColumn);
};

interface IIATFlightListDetailProps {
    columns: IColumn[];
    items: IIATFlightListItem[];
}

class IATFlightListDetailsList extends React.Component<IIATFlightListDetailProps, any> {
    private _onShouldVirtualize = () => {
        return false;
    };
    render() {
        return (
            <DetailsList columns={this.props.columns}
                         items={this.props.items}
                         selectionMode={SelectionMode.single}
                         layoutMode={DetailsListLayoutMode.fixedColumns}
                         constrainMode={ConstrainMode.unconstrained}
                         checkboxVisibility = {CheckboxVisibility.hidden}
                         onShouldVirtualize={this._onShouldVirtualize} />
        );
    }
}

interface IIATFlightListDetailsProps extends IIATFlightListProps {
    columns: IATFlightListColumn[];
}

@observer
class IATFlightListDetails extends React.Component<IIATFlightListDetailsProps, any> {
    render() {
        let visibleColumns = getVisibleColumns(this.props.columns);
        let pivotItems = this.props.model.itemsView.map((movementFlightList: IIATMovementFlightList, idx: number) => {
             return (
                <PivotItem linkText={movementToOutputText(movementFlightList.movement)} key={String(idx)}>
                    <IATFlightListDetailsList columns={visibleColumns} items={movementFlightList.flightList}/>
                </PivotItem>
             );
        });
        let associatedTravellers = this.props.model.associatedTravellers;
        if(associatedTravellers && associatedTravellers.length > 0) {
            pivotItems.push(
                <PivotItem linkText={'Associated Travellers'} key={'assocTravellers'}>
                    <IATAssociatedTravellerDetail list={associatedTravellers} onSearch={this.props.onSearch} />
                    <IATAssociatedTravellersGraphContainer model={this.props.model} />
                </PivotItem>
            );
        }

        return (
            <div className="iat-flight-list">
                <Pivot>
                    {pivotItems}
                </Pivot>
            </div>
        );
    }
}

const IATFlightListViewPrefsStore = new ViewPreferencesModel("iatFlightList");

interface IIATFlightListProps {
    model: IIATFlightListModel;
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

class IATFlightListAppView extends React.Component<IIATFlightListDetailsProps, any> {
    private _downloadXlsxLinkRef : HTMLAnchorElement;
    private _cleanupDownloadBlobRef = () => {
        if(this._downloadXlsxLinkRef && this._downloadXlsxLinkRef.href) {
            try {
                URL.revokeObjectURL(this._downloadXlsxLinkRef.href);
            } catch(e) {}
        }
    };
    private _onClickXlsxDownloadLink = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.stopPropagation();
    };
    private _onXlsxDownloadLinkRef = (ref) => {
        this._downloadXlsxLinkRef = ref;
    };
    
    private _onClickDownloadXlsx = () => {
        let workbookProps: WorkBookProps = {
            Title: "Flight List",
            Subject: "Flight List",
            Author: "Analyst Desktop",
            Company: "DIBP",
            CreatedDate: new Date()
        };
        let columns = getExcelVisibleColumns(this.props.columns);
        let workbook: ExcelWorkBook = new ExcelWorkBook(workbookProps);
        this.props.model.itemsView.forEach(item => {
            workbook.addSheet(movementToKey(item.movement), columns, item.flightList);
        });
        const associatedTravellers = this.props.model.associatedTravellers;
        if (associatedTravellers && associatedTravellers.length > 0) {
            let columns: Column[] = getIATAssociatedTravellerDetailColumns({ list: associatedTravellers, onSearch: this.props.onSearch }).filter(col => col.excelIncludeColumn);
            workbook.addSheet("Associated Travellers", columns, associatedTravellers);
        }

        let blob: Blob = workbook.write();
        let fts = moment(this.props.model.sync.endDate).format(DateOutputFormats.filename);
        let fname = `FlightList-${fts}.xlsx`;
        if(window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob, fname);
        } else if(this._downloadXlsxLinkRef) {
            this._cleanupDownloadBlobRef();
            let url = URL.createObjectURL(blob);
            this._downloadXlsxLinkRef.href = url;
            this._downloadXlsxLinkRef.download = fname;
            this._downloadXlsxLinkRef.click();
        }
    };
    render() {
        const farItems : IContextualMenuItem[] = [];
        farItems.push(
            {
                key: 'downloadXlsx',
                iconProps:{iconName: 'ExcelLogo16'},
                name:"Download",
                title: "Download Excel Spreadsheet",
                onClick:this._onClickDownloadXlsx
            }
        );
        farItems.push(
            createViewPreferencesMenuItem(IATFlightListViewPrefsStore, this.props.columns)
        );
        return (
            <AppView commandBarProps={{ items: [], farItems: farItems }}>
                <a href="#" hidden={true} ref={this._onXlsxDownloadLinkRef} onClick={this._onClickXlsxDownloadLink}>Download Xlsx</a>
                <IATFlightListDetails {...this.props} />
            </AppView>
        );
    }
}

class IATFlightListContainer extends React.Component<IIATFlightListProps, any> {
    componentWillMount() {
        this.props.model.load();
    }
    private _onRenderDone = () => {
        return <IATFlightListAppView {...this.props} columns={getColumns(this.props)} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} />;
    }
}

class IATFlightListApp extends EntityAppBase {
    get entity() : IMasterEntityModel {
        return this.props.match.entity;
    }
    get movements() : IIATMovement[] {
        if(this.props.match.movements) {
            return this.props.match.movements;
        }
        return this.props.match.params.movements;
    }
    get model() : IIATFlightListModel {
        return findFlightListsByEntityMovements({ entity: this.entity, movements: this.movements });
    }
    componentWillMount() {
        this.host.title = "Flight List";
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker>
                <IATFlightListContainer model={this.model} />
            </EntityAppView>
        );
    }
}

export {
    IATFlightListApp,
    IATFlightListApp as default,

};
