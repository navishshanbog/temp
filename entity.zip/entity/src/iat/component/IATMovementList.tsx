import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import IATMovementDetailsList from "./IATMovementDetailsList";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IIATMovement from "../IIATMovement";
import IATMovementColumns from "./IATMovementColumns";
import IATMovementsViewPrefsStore from "../IATMovementsViewPrefsStore";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";
import IMasterEntityModel from "../../entity/IMasterEntityModel";

interface IIATMovementListProps {
    list: IMasterEntitySourceListModel<IIATMovement>;
    onItemInvoked?: (item : IIATMovement) => void;
    onOpenAliases?: (entity : IMasterEntityModel) => void;
    onOpenFlightList?: (props : IIATMovementListProps) => void;
    onOpenVisas?: (item : IIATMovement) => void;
    onOpenTravelDocuments?: (item : IIATMovement) => void;
}

@observer
class IATMovementListCommandBar extends React.Component<IIATMovementListProps, any> {
    private _onClickMovementDetails = () => {
        this.props.onItemInvoked(this.props.list.selection.selectedItems[0]);
    }
    private _onClickAliases = () => {
        this.props.onOpenAliases(this.props.list.entity);
    }
    private _onClickFlightList = () => {
        //openFlightList(this.props.list.entity, this.props.list.selection.selectedItems);
        this.props.onOpenFlightList(this.props);
    }
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "IAT Movements" }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "movement" })
        ];
        const farItems : IContextualMenuItem[] = [];
        if(this.props.onOpenAliases) {
            farItems.push(
                {
                    key: "aliases",
                    name: "Aliases",
                    iconProps: { iconName: "PeopleAlert" },
                    onClick: this._onClickAliases
                }
            );
        }
        if(this.props.onItemInvoked) {
            farItems.push(
                {
                    key: "movementDetails",
                    name: "Movement Details",
                    iconProps: { iconName: "ZoomIn" },
                    onClick: this._onClickMovementDetails,
                    disabled: this.props.list.selection.selectionCount !== 1
                }
            );
        }
        if(this.props.onOpenFlightList) {
            farItems.push(
                {
                    key: "flightList",
                    name: "Flight List",
                    iconProps: { iconName: "Airplane"},
                    onClick: this._onClickFlightList,
                    disabled: this.props.list.selection.selectionCount === 0
                }
            );
        }

        farItems.push(
            createViewPreferencesMenuItem(IATMovementsViewPrefsStore, IATMovementColumns)
        );
        
        return <CommandBar className="entity-source-list-command-bar iat-movement-list-command-bar" items={items} farItems={farItems} />;
    }
}

class IATMovementList extends React.Component<IIATMovementListProps, any> {
    private _onRenderMenu = () => {
        return <IATMovementListCommandBar {...this.props} />
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <IATMovementDetailsList {...this.props} viewPreferences={IATMovementsViewPrefsStore} />
            </AppView>
        )
    }
}

class IATMovementListContainer extends React.Component<IIATMovementListProps, any> {
    private _onRenderDone = () => {
        return <IATMovementList {...this.props} />
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading IAT Movements..." />
    }
}

export {
    IATMovementListContainer as default,
    IATMovementListContainer,
    IIATMovementListProps
}