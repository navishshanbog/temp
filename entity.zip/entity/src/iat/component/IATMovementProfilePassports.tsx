import * as React from "react";
import { IATMovementPassports } from "./IATMovementPassports";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import "./IATMovementPassports.scss";

class IATMovementProfilePassports extends React.Component<IAppProps, any> {
    render() {
        const items = this.props.match.items;
        let list;
        if(items && items.length > 0) {
            list = items[0].subItems;
        }
        return (
            <div className="iat-movement-passports details-panel">
                <IATMovementPassports list={list} />
            </div>
        )
    }
}

export{ IATMovementProfilePassports as default, IATMovementProfilePassports };