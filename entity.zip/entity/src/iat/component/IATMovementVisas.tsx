import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";;
import * as DateUtils from "@twii/common/lib/util/Date";
import SourceSystemCdRef from "../../ref/SourceSystemCd";
import YesNoCodeRef from "../../ref/YesNoCd";
import ImmigrationDirectiveCdRef from "../../ref/ImmigrationDirectiveCd";
import EntriesAllowedCdRef from "../../ref/EntriesAllowedCd";
import EvidenceStatusCdRef from "../../ref/EvidenceStatusCd";
import PhysicalEvidenceStatusCdRef from "../../ref/PhysicalEvidenceStatusCd";
import VisaStatusCdRef from "../../ref/VisaStatusCd";
import IIATVisa from "../IIATVisa";
import "./IATMovementVisas.scss";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import {createCopyForIATActivities} from "./IATMovementSubActivityHelper";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import IIATMovement from "../IIATMovement";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import { findVisasByMovement } from "../model/IATFinder";
import { EntityAppView } from "../../common/component/EntityAppView";
import { AppView } from "@twii/common/lib/component/AppView";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { getMovementSubTitle } from "../IATMovementHelper";

const Fields: IColumn[] = [{  //IDetailsAttributeConfig<IIATVisa>[] = [{
    key: "visaID",
    name: "Visa ID",
    fieldName: "visaID",
    minWidth: 50
}, {
    key: "entriesAllowedCode",
    name: "Entries Allowed",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={EntriesAllowedCdRef.getDesc(item.entriesAllowedCode)}/>;
    },
    data: { getText: (item: IIATVisa) => EntriesAllowedCdRef.getDesc(item.entriesAllowedCode) },
    fieldName: "entriesAllowedCode",
    minWidth: 50
}, {
    key: "entriesMadeCount",
    name: "Entries Made",
    fieldName: "entriesMadeCount",
    minWidth: 50
}, {
    key: "entryExpiryDate",
    name: "No Entries After",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.entryExpiryDate)}/>;
    },
    data: { getText: (item: IIATVisa) => DateUtils.dataToOutputText(item.entryExpiryDate) },
    fieldName: "entryExpiryDate",
    minWidth: 50
}, {
    key: "evidenceNbr",
    name: "Evidence Number",
    fieldName: "evidenceNbr",
    minWidth: 50
}, {
    key: "evidenceStatusCode",
    name: "Evidence Status",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={EvidenceStatusCdRef.getDesc(item.evidenceStatusCode)}/>;
    },
    data: { getText: (item: IIATVisa) => EvidenceStatusCdRef.getDesc(item.evidenceStatusCode) },
    fieldName: "evidenceStatusCode",
    minWidth: 50
}, {
    key: "immigrationDirectiveCode",
    name: "Immigration Directive",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={ImmigrationDirectiveCdRef.getDesc(item.immigrationDirectiveCode)}/>;
    },
    data: { getText: (item: IIATVisa) => ImmigrationDirectiveCdRef.getDesc(item.immigrationDirectiveCode) },
    fieldName: "immigrationDirectiveCode",
    minWidth: 50
}, {
    key: "lastUpdateDate",
    name: "Last Updated",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.lastUpdateDate)}/>;
    },
    data: { getText: (item: IIATVisa) => DateUtils.dataToOutputText(item.lastUpdateDate) },
    fieldName: "lastUpdateDate",
    minWidth: 50
}, {
    key: "lawfulUntilDate",
    name: "Lawful Until",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.lawfulUntilDate)}/>;
    },
    data: { getText: (item: IIATVisa) => DateUtils.dataToOutputText(item.lawfulUntilDate) },
    fieldName: "lawfulUntilDate",
    minWidth: 50
}, {
    key: "migrantEntryExpiryDate",
    name: "Migrant Entry Expiry Date",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.migrantEntryExpiryDate)}/>;
    },
    data: { getText: (item: IIATVisa) => DateUtils.dataToOutputText(item.migrantEntryExpiryDate) },
    fieldName: "migrantEntryExpiryDate",
    minWidth: 50
}, {
    key: "multiIssuedVisaInd",
    name: "Re-issued Visa",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={YesNoCodeRef.getDesc(item.multiIssuedVisaInd)}/>;
    },
    data: { getText: (item: IIATVisa) => YesNoCodeRef.getDesc(item.multiIssuedVisaInd) },
    fieldName: "multiIssuedVisaInd",
    minWidth: 50
}, {
    key: "occupationCode",
    name: "Occupation",
    fieldName: "occupationCode",
    minWidth: 50
}, {
    key: "physicalEvidenceStatusCode",
    name: "Physical Evidence Status",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={PhysicalEvidenceStatusCdRef.getDesc(item.physicalEvidenceStatusCode)}/>;
    },
    data: { getText: (item: IIATVisa) => PhysicalEvidenceStatusCdRef.getDesc(item.physicalEvidenceStatusCode) },
    fieldName: "physicalEvidenceStatusCode",
    minWidth: 50
}, {
    key: "residenceDeptCountryCode",
    name: "Country Of Residence",
    fieldName: "residenceDeptCountryCode",
    minWidth: 50
}, {
    key: "travelDocDeptCountryCode",
    name: "Document Issuing Country",
    fieldName: "travelDocDeptCountryCode",
    minWidth: 50
}, {
    key: "travelDocID",
    name: "Document Id",
    fieldName: "travelDocID",
    minWidth: 50
}, {
    key: "visaApplicationID",
    name: "Visa Application ID",
    fieldName: "visaApplicationID",
    minWidth: 50
}, {
    key: "visaPersonSequenceNbr",
    name: "Visa Person Sequence Number",
    fieldName: "visaPersonSequenceNbr",
    minWidth: 50
}, {
    key: "visaCheckCharacter",
    name: "Visa Check Character",
    fieldName: "visaCheckCharacter",
    minWidth: 50
}, {
    key: "visaGrantDate",
    name: "Visa Grant Date",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.visaGrantDate)}/>;
    },
    data: { getText: (item: IIATVisa) => DateUtils.dataToOutputText(item.visaGrantDate) },
    fieldName: "visaGrantDate",
    minWidth: 50
}, {
    key: "visaGrantNbr",
    name: "Visa Grant Number",
    fieldName: "visaGrantNbr",
    minWidth: 50
}, {
    key: "visaInformationText",
    name: "Visa Information Text",
    fieldName: "visaInformationText",
    minWidth: 50
}, {
    key: "visaIssueCountryCode",
    name: "Visa Issuing Country",
    fieldName: "visaIssueCountryCode",
    minWidth: 50
}, {
    key: "visaClassCode",
    name: "Visa Class",
    fieldName: "visaClassCode",
    minWidth: 50
}, {
    key: "visaStatusCode",
    name: "Visa Status",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={VisaStatusCdRef.getDesc(item.visaStatusCode)}/>;
    },
    data: { getText: (item: IIATVisa) => VisaStatusCdRef.getDesc(item.visaStatusCode) },
    fieldName: "visaStatusCode",
    minWidth: 50
}, {
    key: "visaSubClassCode",
    name: "Visa Sub Class",
    fieldName: "visaSubClassCode",
    minWidth: 50
}, {
    key: "sourceSystemCode",
    name: "Sourced From",
    onRender: function(item: IIATVisa) {
        return <DetailsAttribute key={this.key} label={this.name} value={SourceSystemCdRef.getDesc(item.sourceSystemCode)}/>;
    },
    data: { getText: (item: IIATVisa) => SourceSystemCdRef.getDesc(item.sourceSystemCode) },
    fieldName: "sourceSystemCode",
    minWidth: 50
}];

const IATMovementVisasViewPrefsStore = new ViewPreferencesModel("iatMovementVisas");

interface IIATMovementVisasProps {
    list?: IIATVisa[];
}

class IATMovementVisas extends React.Component<IIATMovementVisasProps, any> {
    render() {
        let content;
        if(this.props.list && this.props.list.length > 0) {
            content = this.props.list.map((visa: IIATVisa, idx: number) => {
                return <DetailsItem key={idx} model={visa} attrConfig={Fields} viewPrefModel={IATMovementVisasViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Movement does not have a visa recorded</MessageBar>;
        }
        return <div className="iat-movement-visas">{content}</div>;
    }
}

interface IIATMovementVisasContainerProps {
    model: ISyncSupplier<IIATVisa[], IIATMovement>;
}

class IATMovementVisasAppView extends React.Component<IIATMovementVisasContainerProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        const farItems : IContextualMenuItem[] = [];
        if(this.props.model.parent) {
            items.push(
                createCopyForIATActivities ({
                    modelData:this.props.model.parent,
                    data: this.props.model.value,
                    subEntityHeader: `Visa: ${this.props.model.parent.visaIdentifyingNbr} | ${getMovementSubTitle(this.props.model.parent)}`,
                    subItemType: "Visa",
                    name: "Copy",
                    title: "Copy"
                })
            );
        }
        farItems.push(
            createViewPreferencesMenuItem(IATMovementVisasViewPrefsStore, Fields)
        );
        return (
            <AppView commandBarProps={{ items: items, farItems: farItems }}>
                <IATMovementVisas list={this.props.model.value} />
            </AppView>
        );
    }
}

class IATMovementVisasContainer extends React.Component<IIATMovementVisasContainerProps, any> {
    componentWillMount() {
        this.props.model.load();
    }
    private _onRenderDone = () => {
        return <IATMovementVisasAppView {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} />;
    }
}

class IATMovementVisasApp extends EntityAppBase {
    get movement() : IIATMovement {
        if(this.props.match.movement) {
            return this.props.match.movement;
        }
        return this.props.match.params;
    }
    get model() : ISyncSupplier<IIATVisa[], IIATMovement> {
        return findVisasByMovement(this.movement);
    }
    componentWillMount() {
        this.host.title = `Visa: ${this.movement.visaIdentifyingNbr} | ${getMovementSubTitle(this.movement)}`;
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker >
                <IATMovementVisasContainer model={this.model} />
            </EntityAppView>
        );
    }
}

export {
    IATMovementVisasApp,
    IATMovementVisasApp as default,
    IIATMovementVisasProps,
    IATMovementVisas,
    IATMovementVisasContainer,
    Fields as VisaFields,
    IATMovementVisasViewPrefsStore
};