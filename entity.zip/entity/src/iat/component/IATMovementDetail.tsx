import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import NameGenderCdRef from "../../ref/NameGenderCd";
import IIATMovementDetail from "../IIATMovementDetail";
import * as DateUtils from "@twii/common/lib/util/Date";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import {IColumn} from "office-ui-fabric-react/lib/DetailsList";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import IIATMovement from "../IIATMovement";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import { EntityAppView } from "../../common/component/EntityAppView";
import { findDetailsByMovement } from "../model/IATFinder";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { AppView } from "@twii/common/lib/component/AppView";
import { createCopyForIATActivities } from "./IATMovementSubActivityHelper";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import "./IATMovementDetails.scss";

const Fields: IColumn[] = [{ // IDetailsAttributeConfig<IIATMovementDetail>[] = [{
    key: "routeId",
    name: "Route Id",
    fieldName: "routeId",
    minWidth: 50
}, {
    key: "localScheduledDate",
    name: "Local Scheduled Date",
    fieldName: "localScheduledDate",
    minWidth: 50,
    onRender: function(item: IIATMovementDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.localScheduledDate)}/>;
    },
    data: { getText: (item: IIATMovementDetail) => DateUtils.dataToOutputText(item.localScheduledDate) }
}, {
    key: "directionCode",
    name: "Direction Code",
    fieldName: "directionCode",
    minWidth: 50
}, {
    key: "fullRoutingText",
    name: "Full Routing Text",
    fieldName: "fullRoutingText",
    minWidth: 50
}, {
    key: "movementDate",
    name: "Movement Date",
    fieldName: "movementDate",
    minWidth: 50,
    onRender: function(item: IIATMovementDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.movementDate)}/>;
    },
    data: { getText: (item: IIATMovementDetail) => DateUtils.dataToOutputText(item.movementDate) }
}, {
    key: "movementTime",
    name: "Movement Time",
    fieldName: "movementTime",
    minWidth: 50
}, {
    key: "movementStatusCode",
    name: "Movement Status",
    fieldName: "movementStatusCode",
    minWidth: 50
}, {
    key: "movementRaceID",
    name: "Movement Race ID",
    fieldName: "movementRaceID",
    minWidth: 50
}, {
    key: "familyName",
    name: "Family Name",
    fieldName: "familyName",
    minWidth: 50
}, {
    key: "givenNames",
    name: "Given Names",
    fieldName: "givenNames",
    minWidth: 50
}, {
    key: "birthDate",
    name: "Birth Date",
    fieldName: "birthDate",
    minWidth: 50,
    onRender: function(item: IIATMovementDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={DateUtils.dataToOutputText(item.birthDate)}/>;
    },
    data: { getText: (item: IIATMovementDetail) => DateUtils.dataToOutputText(item.birthDate) }
}, {
    key: "sexCode",
    name: "Gender",
    fieldName: "sexCode",
    minWidth: 50,
    onRender: function(item: IIATMovementDetail) {
        return <DetailsAttribute key={this.key} label={this.name} value={NameGenderCdRef[item.sexCode]}/>;
    },
    data: { getText: (item: IIATMovementDetail) => NameGenderCdRef[item.sexCode] }
}, {
    key: "childInd",
    name: "Child Ind",
    fieldName: "childInd",
    minWidth: 50
}, {
    key: "aliasSequenceNbr",
    name: "Alias Sequence Number",
    fieldName: "aliasSequenceNbr",
    minWidth: 50
}, {
    key: "travelDocID",
    name: "Travel Document ID",
    fieldName: "travelDocID",
    minWidth: 50
}, {
    key: "travelDocDeptCountryCode",
    name: "Travel Document Country",
    fieldName: "travelDocDeptCountryCode",
    minWidth: 50
}, {
    key: "localPortCode",
    name: "Local Port",
    fieldName: "localPortCode",
    minWidth: 50
}, {
    key: "checkInPortCode",
    name: "Check In Port",
    fieldName: "checkInPortCode",
    minWidth: 50
}, {
    key: "checkInRouteId",
    name: "Check In Route Id",
    fieldName: "checkInRouteId",
    minWidth: 50
}, {
    key: "checkInTime",
    name: "Check In Time",
    fieldName: "checkInTime",
    minWidth: 50
}, {
    key: "visaSubClassCode",
    name: "Visa SubClass",
    fieldName: "visaSubClassCode",
    minWidth: 50
}, {
    key: "passengerCrewCode",
    name: "Passenger Crew Code",
    fieldName: "passengerCrewCode",
    minWidth: 50
}, {
    key: "postMovementInd",
    name: "Post Movement Indicator",
    fieldName: "postMovementInd",
    minWidth: 50
}, {
    key: "travellerMovementTypeCode",
    name: "Traveller Movement Type",
    fieldName: "travellerMovementTypeCode",
    minWidth: 50
}, {
    key: "travelDocSequenceNbr",
    name: "Travel Document Sequence",
    fieldName: "travelDocSequenceNbr",
    minWidth: 50
}, {
    key: "immigrationDirectiveCode",
    name: "Immigration Directive Code",
    fieldName: "immigrationDirectiveCode",
    minWidth: 50
}, {
    key: "referralStatusCode",
    name: "Referral Status Code",
    fieldName: "referralStatusCode",
    minWidth: 50
}, {
    key: "referralTypeCode",
    name: "Referral Type Code",
    fieldName: "referralTypeCode",
    minWidth: 50
}, {
    key: "examinationForTravellerForMovementInd",
    name: "Exam For Movement",
    fieldName: "examinationForTravellerForMovementInd",
    minWidth: 50
}, {
    key: "positiveFindForTravellerForMovementInd",
    name: "Positive Find For Movement",
    fieldName: "positiveFindForTravellerForMovementInd",
    minWidth: 50
}, {
    key: "numberOfExamsForTheTraveller",
    name: "Exams For Traveller",
    fieldName: "numberOfExamsForTheTraveller",
    minWidth: 50
}, {
    key: "positiveFindCountForTraveller",
    name: "Positive Finds For Traveller",
    fieldName: "positiveFindCountForTraveller",
    minWidth: 50
}, {
    key: "alertInd",
    name: "Alert Indicator",
    fieldName: "alertInd",
    minWidth: 50
}];

interface IIATMovementDetailsProps {
    details?: IIATMovementDetail[];
}

class IATMovementDetails extends React.Component<IIATMovementDetailsProps, any> {
    render() {
        let content;
        if(this.props.details && this.props.details.length > 0) {
            content = this.props.details.map((detail: IIATMovementDetail, idx: number) => {
                return <DetailsItem key={idx} model={detail} attrConfig={Fields} viewPrefModel={IATMovementDetailsViewPrefsStore}/>;
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Failed to load details</MessageBar>;
        }
        return <div className="iat-movement-details">{content}</div>;
    }
}

const getSubTitle = (movement : IIATMovement) : string => {
    const titleEls : string[] = [];
    if(movement) {
        if(movement.routeId) {
            titleEls.push(movement.routeId);
        }
        if(movement.localScheduledDate) {
            titleEls.push(DateUtils.dataToOutputText(movement.localScheduledDate));
        }
        if(movement.directionCode) {
            titleEls.push(movement.directionCode);
        }
    }
    return titleEls.length > 0 ? titleEls.join(" | ") : "";
};

interface IIATMovementDetailsContainerProps {
    model?: ISyncSupplier<IIATMovementDetail[], IIATMovement>;
}

class IATMovementDetailsAppView extends React.Component<IIATMovementDetailsContainerProps, any> {
    render() {
        const subTitle = getSubTitle(this.props.model.parent);
        const items : IContextualMenuItem[] = [
            createCopyForIATActivities({
                modelData:this.props.model.parent,
                data: this.props.model.value,
                subEntityHeader: `Movement Details${subTitle ? ": " : ""}${subTitle}`,
                subItemType: "movementDetails",
                name: "Copy",
                title: "Copy"
            }),
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(IATMovementDetailsViewPrefsStore, Fields)
        ];
        return (
            <AppView commandBarProps={{ items: items, farItems: farItems }}>
                <IATMovementDetails details={this.props.model.value} />
            </AppView>
        );
    }
}

class IATMovementDetailsContainer extends React.Component<IIATMovementDetailsContainerProps, any> {
    componentWillMount() {
        this.props.model.load();
    }
    private _onRenderDone = () => {
        return <IATMovementDetailsAppView {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} syncLabel="Loading Details..." onRenderDone={this._onRenderDone} />
    }
}

const IATMovementDetailsViewPrefsStore = new ViewPreferencesModel("iatMovementDetails");

class IATMovementDetailsApp extends EntityAppBase {
    get movement() : IIATMovement {
        if(this.props.match.movement) {
            return this.props.match.movement;
        }
        return this.props.match.params;
    }
    get detailsSupplier() : ISyncSupplier<IIATMovementDetail[], IIATMovement> {
        return findDetailsByMovement(this.movement);
    }
    componentWillMount() {
        const subTitle = getSubTitle(this.movement);
        this.host.title = `Movement Details${subTitle ? ": " : ""}${subTitle}`;
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker >
                <IATMovementDetailsContainer model={this.detailsSupplier} />
            </EntityAppView>
        );
    }
}

export{
    IATMovementDetailsApp,
    IATMovementDetailsApp as default,
    IIATMovementDetailsProps,
    IATMovementDetails,
    IATMovementDetailsContainer,
    Fields as MovementFields,
    IATMovementDetailsViewPrefsStore
};