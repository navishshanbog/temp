import * as React from "react";
import { observer } from "mobx-react";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { IEntitySourceItems } from "../../entity/IEntitySourceItems";
import { buildSectionHeader, buildSectionSubHeader, buildTable, buildComments, buildSectionTable, buildSectionList } from "../../entity/profile/EntityProfileDocumentHelper";
import IATMovementColumns from "./IATMovementColumns";
import IATMovementViewPrefsStore from "../IATMovementsViewPrefsStore";
import IATAssociatedActivityColumnsList from "./IATAssociatedActivityColumnsList";
import { getViewPreferenceColumns } from "@twii/common/lib/component/ColumnHelper";
import SubEntityProfileSourceDetailList from "../../entity/profile/component/SubEntityProfileSourceDetailList";
import { Columns, Fields, IATMovementPassportsViewPrefsStore } from "./IATMovementPassports";
import { equalsIgnoreCase } from "@twii/common/lib/util/String";
import { AliasFields, IATMovementAliasesViewPrefsStore } from "./IATMovementAliases";
import { IATMovementDetailsViewPrefsStore, MovementFields } from "./IATMovementDetail";
import { VisaFields, IATMovementVisasViewPrefsStore } from "./IATMovementVisas";
import { findFlightListsByEntityMovements } from "../model/IATFinder";
import { toPromise } from "@twii/common/lib/SyncUtils";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";
import IIATMovement from "../IIATMovement";
import { PathsContext } from "../../PathsContext";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";
import "./EntityProfileIAT.scss";

@observer
class EntityProfileIATApp extends EntityProfileSourceGroupApp {
    private _onOpenMovementDetails = (item : IIATMovement) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.iatMovementDetails(),
            movement: item,
            query: item,
            panelProps: panelProps
        };
    }
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="iat-movements" title="IAT Movements">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={IATMovementColumns} viewPreferences={IATMovementViewPrefsStore} onItemInvoked={this._onOpenMovementDetails} />
                <SubEntityProfileSourceDetailList group={this.group} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const IATMovementDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("IAT Movements", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, getViewPreferenceColumns(IATMovementColumns, IATMovementViewPrefsStore), doc);

    // custom type - may be better way to do this ?
    if (group.hasSubTypes) {
        group.subEntities.map((subEntity: IEntitySourceItems) => {
            if (!(subEntity.items === null)) {
                buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader, doc);
                if (equalsIgnoreCase(subEntity.type, "Passport")) {
                    buildSectionTable(subEntity.items[0].subItems[0].Aliases, Columns, doc);
                    // buildSectionHeader('', doc);
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(Fields, IATMovementPassportsViewPrefsStore), doc);
                } else if (equalsIgnoreCase(subEntity.type, "IATAliases")) {
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(AliasFields, IATMovementAliasesViewPrefsStore), doc);
                } else if (equalsIgnoreCase(subEntity.type, "movementDetails")) {
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(MovementFields, IATMovementDetailsViewPrefsStore), doc);
                }
                else if (equalsIgnoreCase(subEntity.type, "Visa")) {
                    buildSectionList(subEntity.items[0].subItems, getViewPreferenceColumns(VisaFields, IATMovementVisasViewPrefsStore), doc);
                }
            }
        });
    }
    const s = findFlightListsByEntityMovements({ entity: group.source.entitySource.masterEntity, movements: group.items });
    s.load();
    return toPromise(s.sync).then(() => {
        const associatedTravellers = s.associatedTravellers || [];
        if (associatedTravellers.length > 0) {
            (group.items && group.items.length > 0) &&
                buildSectionSubHeader("Associated Travellers", doc);
            buildSectionTable(associatedTravellers, IATAssociatedActivityColumnsList, doc);
        }
        buildComments(group.comments, doc);
    }).catch((error) => {
        console.log("Error getting associated traveller information");
        buildComments(group.comments, doc);
    });
};

export { EntityProfileIATApp as default, EntityProfileIATApp, IATMovementDocumentHandler }