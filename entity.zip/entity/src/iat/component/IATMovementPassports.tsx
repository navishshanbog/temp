import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { DetailsList, DetailsListLayoutMode, ConstrainMode, CheckboxVisibility, SelectionMode, IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import NameGenderCdRef from "../../ref/NameGenderCd";
import SourceSystemCdRef from "../../ref/SourceSystemCd";
import PassportStatusCdRef from "../../ref/PassportStatusCd";
import PassportTypeCdRef from "../../ref/PassportTypeCd";
import YesNoCdRef from "../../ref/YesNoCd";
import ImmigrationDirectiveCdRef from "../../ref/ImmigrationDirectiveCd";
import * as DateUtils from "@twii/common/lib/util/Date";
import { IIATPassport, IIATPassportAlias } from "../IIATPassport";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import { createCopyForIATActivities } from "./IATMovementSubActivityHelper";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import IIATMovement from "../IIATMovement";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import { getMovementSubTitle } from "../IATMovementHelper";
import { EntityAppView } from "../../common/component/EntityAppView";
import { findPassportsByMovement } from "../model/IATFinder";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { AppView } from "@twii/common/lib/component/AppView";
import "./IATMovementPassports.scss";

const Columns: IColumn[] = [
    {
        key: "givenNames",
        ariaLabel: "Given Names",
        name: "Given Names",
        fieldName: "givenNames",
        minWidth: 50,
        maxWidth: 100,
        isResizable: true,
        columnActionsMode: ColumnActionsMode.clickable
    },
    {
        key: "familyName",
        ariaLabel: "Family Name",
        name: "Family Name",
        fieldName: "familyName",
        minWidth: 50,
        maxWidth: 100,
        isResizable: true,
        columnActionsMode: ColumnActionsMode.clickable
    },
    {
        key: "sexCode",
        ariaLabel: "Gender",
        name: "Gender",
        fieldName: "sexCode",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 10,
        maxWidth: 40,
        onRender: (item: IIATPassportAlias) => {
            return NameGenderCdRef[item.sexCode];
        },
        data: { getText: (item: IIATPassportAlias) => NameGenderCdRef[item.sexCode] }
    },
    {
        key: "birthDate",
        ariaLabel: "Date of Birth",
        name: "Date of Birth",
        fieldName: "birthDate",
        minWidth: 50,
        maxWidth: 80,
        isResizable: true,
        columnActionsMode: ColumnActionsMode.clickable,
        onRender: (item: IIATPassportAlias) => {
            return DateUtils.dataToOutputText(item.birthDate);
        },
        data: { getText: (item: IIATPassportAlias) => DateUtils.dataToOutputText(item.birthDate) }
    },
    {
        key: "birthDeptCountryCode",
        ariaLabel: "Birth Country",
        name: "Birth Country",
        fieldName: "birthDeptCountryCode",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 50,
        maxWidth: 80
    },
    {
        key: "iatTravellerID",
        ariaLabel: "IAT Traveller ID",
        name: "IAT Traveller ID",
        fieldName: "iatTravellerID",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 50,
        maxWidth: 80
    },
    {
        key: "aliasSequenceNbr",
        ariaLabel: "Alias Sequence Number",
        name: "Alias Sequence Number",
        fieldName: "aliasSequenceNbr",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 50,
        maxWidth: 120
    }
];

const Fields: IColumn[] = [{ //: IDetailsAttributeConfig<IIATPassport>[] = [{
    key: "travelDocID",
    fieldName: "travelDocID",
    minWidth: 50,
    name: "Travel Document ID"
}, {
    key: "travelDocDeptCountryCode",
    fieldName: "travelDocDeptCountryCode",
    minWidth: 50,
    name: "Travel Document Country"
}, {
    key: "travelDocTypeCode",
    fieldName: "travelDocTypeCode",
    minWidth: 50,
    name: "Document Type"
}, {
    key: "deptRunNbr",
    fieldName: "deptRunNbr",
    minWidth: 50,
    name: "Department Run Number"
}, {
    key: "documentImpoundInd",
    name: "Document Impounded",
    fieldName: "documentImpoundInd",
    minWidth: 50,
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name} value={YesNoCdRef.getDesc(item.documentImpoundInd)}/>;
    },
    data: { getText: (item: IIATPassport) => YesNoCdRef.getDesc(item.documentImpoundInd) },
}, {
    key: "immigrationDirectiveCode",
    name: "Immigration Directive",
    fieldName: "immigrationDirectiveCode",
    minWidth: 50,
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name}
                                 value={ImmigrationDirectiveCdRef.getDesc(item.immigrationDirectiveCode)}/>;
    },
    data: { getText: (item: IIATPassport) => ImmigrationDirectiveCdRef.getDesc(item.immigrationDirectiveCode)},
}, {
    key: "issueCountryCode",
    fieldName: "issueCountryCode",
    minWidth: 50,
    name: "Issuing Country"
}, {
    key: "issueOfficeCode",
    fieldName: "issueOfficeCode",
    minWidth: 50,
    name: "Issuing Office"
}, {
    key: "lastUpdateDate",
    fieldName: "lastUpdateDate",
    minWidth: 50,
    name: "Last Updated",
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name}
                                 value={DateUtils.dataToOutputText(item.lastUpdateDate)}/>;
    },
    data: { getText: (item: IIATPassport) => ImmigrationDirectiveCdRef.getDesc(item.lastUpdateDate) }
}, {
    key: "passportExpiryDate",
    fieldName: "passportExpiryDate",
    minWidth: 50,
    name: "Passport Expiry Date",
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name}
                                 value={DateUtils.dataToOutputText(item.passportExpiryDate)}/>;
    },
    data: { getText: (item: IIATPassport) => DateUtils.dataToOutputText(item.passportExpiryDate) }
}, {
    key: "passportIssueDate",
    fieldName: "passportIssueDate",
    minWidth: 50,
    name: "Passport Issued",
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name}
                                 value={DateUtils.dataToOutputText(item.passportIssueDate)}/>;
    },
    data: { getText: (item: IIATPassport) => DateUtils.dataToOutputText(item.passportIssueDate) }
}, {
    key: "passportStatusCode",
    fieldName: "passportStatusCode",
    minWidth: 50,
    name: "Passport Status",
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name}
                                 value={PassportStatusCdRef.getDesc(item.passportStatusCode)}/>;
    },
    data: { getText: (item: IIATPassport) => PassportStatusCdRef.getDesc(item.passportStatusCode) }
}, {
    key: "passportTypeCode",
    fieldName: "passportTypeCode",
    minWidth: 50,
    name: "Passport Type",
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name}
                                 value={PassportTypeCdRef.getDesc(item.passportTypeCode)}/>;
    },
    data: { getText: (item: IIATPassport) => PassportTypeCdRef.getDesc(item.passportTypeCode) }
}, {
    key: "sourceSystemCode",
    fieldName: "sourceSystemCode",
    minWidth: 50,
    name: "Sourced From",
    onRender: function (item: IIATPassport) {
        return <DetailsAttribute key={this.key} label={this.name}
                                 value={SourceSystemCdRef.getDesc(item.sourceSystemCode)}/>;
    },
    data: { getText: (item: IIATPassport) => SourceSystemCdRef.getDesc(item.sourceSystemCode) }
}];

const IATMovementPassportsViewPrefsStore = new ViewPreferencesModel("iatMovementPassports");

interface IIATMovementPassportsProps {
    list?: IIATPassport[];
}

@observer
class IATMovementPassports extends React.Component<IIATMovementPassportsProps, any> {
    render() {
        let content;
        if (this.props.list && this.props.list.length > 0) {
            content = this.props.list.map((passport: IIATPassport, idx: number) => {
                return <div key={String(idx)} className={"iat-movement-details-section"}>
                    <DetailsList columns={Columns}
                        items={passport.Aliases}
                        selectionMode={SelectionMode.single}
                        layoutMode={DetailsListLayoutMode.fixedColumns}
                        constrainMode={ConstrainMode.unconstrained}
                        checkboxVisibility={CheckboxVisibility.hidden} />
                    <DetailsItem key={idx} model={passport} attrConfig={Fields} viewPrefModel={IATMovementPassportsViewPrefsStore} />
                </div>
            });
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Movement does not have a passport recorded</MessageBar>;
        }
        return <div className="iat-movement-passports">{content}</div>
    }
}

interface IIATMovementPassportsContainerProps {
    model?: ISyncSupplier<IIATPassport[], IIATMovement>;
}

class IATMovementPassportsAppView extends React.Component<IIATMovementPassportsContainerProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        const farItems : IContextualMenuItem[] = [];
        if(this.props.model.parent) {
            items.push(
                createCopyForIATActivities({
                    modelData: this.props.model.parent,
                    data: this.props.model.value,
                    subEntityHeader: `Passport: ${this.props.model.parent.travelDocumentId} | ${getMovementSubTitle(this.props.model.parent)}`,
                    subItemType: "passport",
                    name: "Copy",
                    title: "Copy"
                })
            );
        }
        farItems.push(
            createViewPreferencesMenuItem(IATMovementPassportsViewPrefsStore, Fields)
        );
        return (
            <AppView commandBarProps={{ items: items, farItems: farItems }}>
                <IATMovementPassports list={this.props.model.value} />
            </AppView>
        )
    }
}

class IATMovementPassportsContainer extends React.Component<IIATMovementPassportsContainerProps, any> {
    componentWillMount() {
        this.props.model.load();
    }
    private _onRenderDone = () => {
        return <IATMovementPassportsAppView {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} />;
    }
}

class IATMovementPassportsApp extends EntityAppBase {
    get movement() : IIATMovement {
        if(this.props.match.movement) {
            return this.props.match.movement;
        }
        return this.props.match.params;
    }
    get model() : ISyncSupplier<IIATPassport[], IIATMovement> {
        return findPassportsByMovement(this.movement);
    }
    componentWillMount() {
        this.host.title = `Passport: ${this.movement.travelDocumentId} | ${getMovementSubTitle(this.movement)}`;
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker >
                <IATMovementPassportsContainer model={this.model} />
            </EntityAppView>
        );
    }
}

export {
    IATMovementPassportsApp as default,
    IATMovementPassportsApp,
    IATMovementPassportsContainer,
    IATMovementPassports,
    IIATMovementPassportsProps,
    IATMovementPassportsViewPrefsStore,
    Columns,
    Fields
};