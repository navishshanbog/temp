import * as React from "react";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    ColumnActionsMode,
    SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { Link } from "office-ui-fabric-react/lib/Link";
import IIATAssociatedTraveller from "../IIATAssociatedTraveller";
import NameGenderCdRef from "../../ref/NameGenderCd";
import IMasterEntitySearchRequest from "../../entity/IMasterEntitySearchRequest";
import IIATAssociatedTravellerMovement from "../IIATAssociatedTravellerMovement";
import { assocMovementToOutputText } from "../IATMovementHelper";
import { formatToNISName } from "../../entity/EntityNameUtils";
import { Column, ColumnType } from "../../common/ExcelWorkBook";
import * as DateUtils from "@twii/common/lib/util/Date";
import "./IATAssociatedTravellerDetail.scss";

class IATAssociatedTravellerDetailColumn implements IColumn, Column {
    fieldName: string;
    label: string;
    key: string;
    ariaLabel: string;
    name: string;
    minWidth: number = 40;
    maxWidth: number = 80;
    isResizable: boolean = true;
    columnActionsMode: ColumnActionsMode = ColumnActionsMode.clickable;
    width: number = 100;
    excelIncludeColumn: boolean = true;
    type: ColumnType = ColumnType.STRING;
    constructor(fieldName: string, label: string) {
        this.fieldName = fieldName;
        this.label = label;
        this.key = fieldName;
        this.ariaLabel = label;
        this.name = label;
    }
}

interface IIATAssociatedTravellerItemProps extends IIATAssociatedTravellerDetailProps {
    item: IIATAssociatedTraveller;
}

class IATAssociatedTravellerNISName extends React.Component<IIATAssociatedTravellerItemProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
        const { item, onSearch } = this.props;
        onSearch({ fullName: `${item.givenNames} ${item.familyName}`, dob: item.birthDate });
    }
    render() {
        const { item, onSearch } = this.props;
        const nisName: string = formatToNISName(item.familyName, item.givenNames, null, NameGenderCdRef[item.sexCode], item.birthDate);
        return onSearch ? <Link onClick={this._onClick}>{nisName}</Link> : nisName;
    }
} 

const getColumns = (props : IIATAssociatedTravellerDetailProps) : IATAssociatedTravellerDetailColumn[] => {
    return [
        Object.assign(new IATAssociatedTravellerDetailColumn("nisName", "NIS Name"), {
            minWidth: 200,
            maxWidth: 250,
            excelIncludeColumn: false,
            onRender: (item: IIATAssociatedTraveller) => {
                return <IATAssociatedTravellerNISName {...props} item={item} />;
            }
        }),
        new IATAssociatedTravellerDetailColumn("givenNames", "Given Names"),
        new IATAssociatedTravellerDetailColumn("familyName", "Family Name"),
        Object.assign(new IATAssociatedTravellerDetailColumn("sexCode", "Gender"), {
            minWidth: 10,
            maxWidth: 40,
            onRender: (item: IIATAssociatedTraveller) => {
                return NameGenderCdRef[item.sexCode];
            },
            onRenderExcel:  (item: IIATAssociatedTraveller) => {
                return NameGenderCdRef[item.sexCode];
            }
        }),
        Object.assign(new IATAssociatedTravellerDetailColumn("birthDate", "Date of Birth"), {
            type: ColumnType.DATE,
            onRender: (assocTraveller: IIATAssociatedTraveller) => {
                return DateUtils.dataToOutputText(assocTraveller.birthDate);
            }
        }),
        new IATAssociatedTravellerDetailColumn("travelDocumentId", "Passport"),
        new IATAssociatedTravellerDetailColumn("travelDocCountryCode", "Passport Country"),
        Object.assign(new IATAssociatedTravellerDetailColumn("movements", "Movements"), {
            minWidth: 200,
            maxWidth: 600,
            width: 300,
            onRender: (assocTraveller: IIATAssociatedTraveller) => {
                if (assocTraveller.assocMovements) {
                    return assocTraveller.assocMovements.map((assocMovement: IIATAssociatedTravellerMovement, idx: number) => {
                        return <span className="associated-traveller-movement"
                                     key={idx}>{assocMovementToOutputText(assocMovement)}</span>;
                    });
                }
            },
            onRenderExcel: (assocTraveller : IIATAssociatedTraveller) => {
                if (assocTraveller.assocMovements) {
                    let movements: string[] = assocTraveller.assocMovements.map((assocMovement: IIATAssociatedTravellerMovement) => {
                        return `${assocMovementToOutputText(assocMovement)}`;
                    });
                    return movements.join();
                }
                return null;
            }
        })
    ] as IATAssociatedTravellerDetailColumn[];
};

interface IIATAssociatedTravellerDetailProps {
    list : IIATAssociatedTraveller[];
    onSearch?: (request: IMasterEntitySearchRequest) => void;
}

class IATAssociatedTravellerDetail extends React.Component<IIATAssociatedTravellerDetailProps, any> {
    render() {
        return (
            <DetailsList className="associated-traveller-detail"
                         columns={getColumns(this.props)}
                         items={this.props.list}
                         selectionMode={SelectionMode.single}
                         layoutMode={DetailsListLayoutMode.fixedColumns}
                         constrainMode={ConstrainMode.unconstrained}
                         checkboxVisibility={CheckboxVisibility.hidden} />
        );
    }
}

export {
    IATAssociatedTravellerDetail as default,
    IATAssociatedTravellerDetail,
    IIATAssociatedTravellerDetailProps,
    IATAssociatedTravellerDetailColumn,
    getColumns as getIATAssociatedTravellerDetailColumns
};