interface IIATAssociatedTravellersGraph {
    nodes: any[];
    edges: any[];
}

export { IIATAssociatedTravellersGraph };