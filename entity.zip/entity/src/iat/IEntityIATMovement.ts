import { IEntityActivity } from "../entity/IEntityActivity";
import { IIATMovement } from "./IIATMovement";

interface IEntityIATMovement extends IEntityActivity, IIATMovement {}

export { IEntityIATMovement }