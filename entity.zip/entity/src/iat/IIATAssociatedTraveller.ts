import IIATAssociatedTravellerMovement from "./IIATAssociatedTravellerMovement";

interface IIATAssociatedTraveller {
    iatTravellerId: string;
    birthDate?: string;
    sexCode?: string;
    familyName?: string;
    givenNames?: string;
    travelDocID?: string;
    travelDocCountryCode?: string;
    assocMovements: IIATAssociatedTravellerMovement[];
}

export { IIATAssociatedTraveller as default, IIATAssociatedTraveller };