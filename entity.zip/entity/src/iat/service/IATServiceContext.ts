import Context from "@twii/common/lib/Context";
import IIATService from "./IIATService";
import RestIATService from "./RestIATService";

const IATServiceContext = new Context<IIATService>({
    value: new RestIATService()
});

export { IATServiceContext as default, IATServiceContext };