import IIATMovement from "./IIATMovement";

interface IIATAssociatedTravellerMovement {
    movement: IIATMovement;
    passengerCrewCode: string;
}

export { IIATAssociatedTravellerMovement as default, IIATAssociatedTravellerMovement };