import IMasterEntityModel from "../entity/IMasterEntityModel";
import IIATMovement from "./IIATMovement";

interface IIATEntityMovements {
    entity?: IMasterEntityModel;
    movements?: IIATMovement[];
}

export { IIATEntityMovements }