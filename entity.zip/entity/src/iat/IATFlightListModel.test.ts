/*
import IATFlightListModel from "./IATFlightListModel";
import IATServiceContext from "./service/IATServiceContext";
import MockIATService from "./service/MockIATService";
import {IIATMovement} from "./IIATMovement";
import MasterEntityModel from "../entity/MasterEntityModel";

const masterEntity = new MasterEntityModel({
    masterEntityId: "1",
    sources: [
        {
            sourceSystemCode: "IAT",
            sourceEntities: [
                {
                    names: [
                        {
                            firstName: "Some",
                            lastName: "Ghit",
                            standardFullName: "Some Ghit",
                            nameGenderCd: "M"
                        }
                    ]
                }
            ]
        }
    ]
});

describe("IAT Flight List Model", () => {
    test("main traveller is excluded from assoc travellers", async () => {
        let movement1: IIATMovement = {
            IATTravellerId: '101',
            routeId: 'VA128',
            localScheduledDate: '2017-01-01',
            directionCode: 'I'
        };
        let movement2: IIATMovement = {
            IATTravellerId: '101',
            routeId: 'SQ128',
            localScheduledDate: '2017-01-01',
            directionCode: 'I'
        };
        const testIATService = new MockIATService();
        IATServiceContext.value = testIATService;
        testIATService.getTravellerMovementFlightListResponse = [
            {
                iatTravellerIdentifier: "101",
                routeId: "VA128",
                localScheduledDate: "2017-01-01",
                directionCode: "I"
            }, {
                iatTravellerIdentifier: "102",
                routeId: "VA128",
                localScheduledDate: "2017-01-01",
                directionCode: "I"
            }
        ];

        let flightListModel = new IATFlightListModel();
        await flightListModel.loadForMovements(masterEntity, [movement1, movement2]);
        expect(flightListModel.getItems(movement1).length).toBe(2);
        expect(flightListModel.getItems(movement2).length).toBe(2);
        expect(flightListModel.assocTravellerModel.list.length).toBe(1);
        expect(flightListModel.assocTravellerModel.list[0].iatTravellerId).toBe('102');
    });

    test("flight list duplicates are not added to assoc travellers", async () => {
        let movement: IIATMovement = {
            IATTravellerId: '101',
            routeId: 'VA128',
            localScheduledDate: '2017-01-01',
            directionCode: 'I'
        };
        const testIATService = new MockIATService();
        IATServiceContext.value = testIATService;
        testIATService.getTravellerMovementFlightListResponse = [
            {
                iatTravellerIdentifier: "102",
                routeId: "VA128",
                localScheduledDate: "2017-01-01",
                directionCode: "I"
            }, {
                iatTravellerIdentifier: "102",
                routeId: "VA128",
                localScheduledDate: "2017-01-01",
                directionCode: "I"
            }
        ];

        let flightListModel = new IATFlightListModel();
        await flightListModel.loadForMovements(masterEntity, [movement]);
        expect(flightListModel.getItems(movement).length).toBe(2);
        expect(flightListModel.assocTravellerModel.list.length).toBe(0);
    });
});
*/