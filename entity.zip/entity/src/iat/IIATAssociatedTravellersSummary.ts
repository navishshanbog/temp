import IIATAssociatedTraveller from "./IIATAssociatedTraveller";

interface IIATAssociatedTravellersSummary {
    associatedTravellers: IIATAssociatedTraveller[];
    movementTypeMap: { [key: string] : string }
}

export { IIATAssociatedTravellersSummary }