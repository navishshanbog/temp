import IIATMovement from "./IIATMovement";
import IIATFlightListItem from "./IIATFlightListItem";

interface IIATMovementFlightList {
    movement: IIATMovement;
    flightList: IIATFlightListItem[];
}

export { IIATMovementFlightList }