import MasterEntityModel from "../entity/MasterEntityModel";
import IATServiceContext from "./service/IATServiceContext";
import MockIATService from "./service/MockIATService";
import * as IATConstants from "./IATConstants";
import * as DateUtils from "@twii/common/lib/util/Date";
import { toPromise } from "@twii/common/lib/SyncUtils";
import { getEntityMovementList } from "./IATMovementHelper";

describe("Master Entity IAT Movements List Model", () => {
    test("test set master entity", async () => {
        const e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: IATConstants.sourceSystemCode,
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "1"
                            }
                        }
                    ]
                }
            ]
        });

        expect(e.sourceCodes.length).toBe(1);
        expect(e.sourceCodes[0]).toBe(IATConstants.sourceSystemCode);

        const testIATService = new MockIATService();
        testIATService.getIATMovementsResponse = [
            {
                "IATTravellerId":"1",
                "checkinPortCode":"POM ",
                "localPortCode":"BNE ",
                "localScheduledDate":"2015-09-23",
                "routeId":"VA188   ",
                "directionCode":"I",
                "movementStatusCode":"A",
                "travelDocumentId":"M7089026",
                "travelDocDeptCountryCode":"AUS ",
                "visaSubClassCd":"",
                "travelMovementTypeCd":"",
                "alertInd":"",
                "examinationInd":"",
                "visaIdentifyingNbr":"6890168504567925"
            },
            {
                "IATTravellerId":"1",
                "checkinPortCode":"BNE ",
                "localPortCode":"BNE ",
                "localScheduledDate":"2015-09-13",
                "routeId":"VA189   ",
                "directionCode":"O",
                "movementStatusCode":"A",
                "travelDocumentId":"",
                "travelDocDeptCountryCode":"",
                "visaSubClassCd":"",
                "travelMovementTypeCd":"",
                "alertInd":"",
                "examinationInd":"",
                "visaIdentifyingNbr":""
            }
        ];
        testIATService.recordRequests = true;

        IATServiceContext.value = testIATService;

        expect(IATServiceContext.value).toBe(testIATService);
        
        const activityListModel = getEntityMovementList(e);
        expect(activityListModel.entity).toBe(e);

        await toPromise(activityListModel.sync);

        expect(testIATService.getIATMovementsRequests.length).toBe(1);

        const r = testIATService.getIATMovementsRequests[0];

        expect(r.iatTravellerId).toBe("1");

        expect(activityListModel.items.length).toBe(testIATService.getIATMovementsResponse.length);

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply a filter
        e.activityFilter.setFilterText("POM");

        expect(activityListModel.itemsView.length).toBe(1);
        expect(activityListModel.itemsView[0].routeId).toBe("VA188   ");

        activityListModel.filter.setFilterText("noChance");

        expect(activityListModel.itemsView.length).toBe(0);

        e.activityFilter.clear();
        activityListModel.filter.clear();

        // range filter tests
        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2015-09-12"));

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2015-09-13"));

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        e.activityFilter.setFilterFromDate(DateUtils.momentFromDataText("2015-09-14"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].routeId).toBe("VA188   ");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2015-09-24"));

        expect(activityListModel.itemsView.length).toBe(1);

        expect(activityListModel.itemsView[0].routeId).toBe("VA188   ");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2015-09-23"));

        expect(activityListModel.itemsView[0].routeId).toBe("VA188   ");

        e.activityFilter.setFilterToDate(DateUtils.momentFromDataText("2015-09-22"));

        expect(activityListModel.itemsView.length).toBe(0);

    });

});