import { action } from "mobx";
import { IEntityIATMovement } from "./IEntityIATMovement";
import IIATAlias from "./IIATAlias";
import IListResult from "@twii/common/lib/IListResult";
import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import * as StringUtils from "@twii/common/lib/util/String";
import * as DateUtils from "@twii/common/lib/util/Date";
import IIATService from "./service/IIATService";
import IATServiceContext from "./service/IATServiceContext";
import ISort from "@twii/common/lib/ISortProps";
import * as IATConstants from "./IATConstants";
import * as FilterUtils from "@twii/common/lib/util/Filter";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import { getForMasterEntitySource } from "../entity/MasterEntitySourceServiceUtils";
import { IATMovementColumns, LocalScheduleDate } from "./component/IATMovementColumns";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import { IMasterEntityModel } from "../entity/IMasterEntityModel";
import IIATAssociatedTravellerMovement from "./IIATAssociatedTravellerMovement";
import { IMasterEntitySourceModel } from "../entity/IMasterEntitySourceModel";
import { getForMasterEntity } from "../entity/MasterEntitySourceServiceUtils";
import IIATMovement from "./IIATMovement";
import { IIATMovementFlightList } from "./IIATMovementFlightList";

const movementToFilterRow = (item : IEntityIATMovement) => {
    return ColumnTextHelper.getRowText(item, IATMovementColumns);
}

const movementFilterHandler = (items : IEntityIATMovement[], props : IActivityFilterProps) => {
    return FilterUtils.filter(items, props, movementToFilterRow, LocalScheduleDate);
};

const movementSortHandler = (items : IEntityIATMovement[], sort : ISort) => {
    return SortUtils.sort(items, sort, SortUtils.dateAwareFieldTransformer([LocalScheduleDate]))
};

const getMovementsByTravellerId = (travellerId : string, source : IMasterEntitySourceModel, entity: IMasterEntityModel) : Promise<IEntityIATMovement[]> => {
    return IATServiceContext.value.getIATMovements({ iatTravellerId: travellerId }).then(r => {
        return r ? r.map((i, index) => {
            i["key"] = i.IATTravellerId + "_" + index;
            return Object.assign({}, i, { source: source, entity: entity });
        }) : [];
    });
};

const getEntityMovements = (entity : IMasterEntityModel) : Promise<IEntityIATMovement[]> => {
    return getForMasterEntity(entity, IATConstants.sourceSystemCode, getMovementsByTravellerId);
};

const getEntityMovementList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityIATMovement> => {
    return entity.getState("iatMovementList", () => {
        const r = new MasterEntitySourceListModel(entity, IATConstants.sourceSystemCode, getEntityMovements);
        r.setFilterHandler(movementFilterHandler);
        r.setSortHandler(movementSortHandler);
        r.load();
        return r;
    });
};

const getAliasForKey = (key : string) => {
    return IATServiceContext.value.getAliases(key);
};

const getEntityAliases = (entity : IMasterEntityModel) : Promise<IIATAlias[]> => {
    return getForMasterEntity(entity, IATConstants.sourceSystemCode, getAliasForKey);
};

const getEntityAliasList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IIATAlias> => {
    return entity.getState("iatAliasList", () => {
        const r = new MasterEntitySourceListModel(entity, IATConstants.sourceSystemCode, getEntityAliases);
        r.load();
        return r;
    });
};

const getTravellerAliases = (iatTravellerIds : string[]) : Promise<IIATAlias[]> => {
    let aliases : IIATAlias[] = [];
    if(iatTravellerIds && iatTravellerIds.length > 0) {
        const ps = iatTravellerIds.map(iatTravellerId => {
            return IATServiceContext.value.getAliases(iatTravellerId).then(a => {
                if(a) {
                    aliases = aliases.concat(a);
                }
            });
        });
        return Promise.all(ps).then(() => {
            return aliases;
        });
    }
    return Promise.resolve(aliases);
};

const getMovementFlightList = (movement : IIATMovement) : Promise<IIATMovementFlightList> => {
    return IATServiceContext.value.getIATFlightList(movement.routeId, movement.localScheduledDate, movement.directionCode).then(flightList => {
        return {
            movement: movement,
            flightList: flightList
        };
    });
};

const movementToKey = (movement : IEntityIATMovement) : string => {
    return `${StringUtils.trim(movement.routeId)}_${movement.localScheduledDate}_${movement.directionCode}`;
};

const getUniqueMovements = (movements : IIATMovement[]) : IIATMovement[] => {
    const unique : IIATMovement[] = [];
    if(movements && movements.length > 0) {
        const uniqueMap = {};
        movements.forEach(m => {
            const key = movementToKey(m);
            if(!uniqueMap[key]) {
                unique.push(m);
                uniqueMap[key] = true;
            }
        });
    }
    return unique;
}

const getMovementFlightLists = (movements : IIATMovement[]) : Promise<IIATMovementFlightList[]> => {
    const uniqueMovements = getUniqueMovements(movements);
    if(uniqueMovements && uniqueMovements.length > 0) {
        const r : IIATMovementFlightList[] = [];
        return Promise.all(uniqueMovements.map(um => {
            return getMovementFlightList(um).then(mfl => {
                if(mfl) {
                    r.push(mfl);
                }
            });
        })).then(() => {
            return r;
        });
    }
    return Promise.resolve([]);
};

const movementToOutputText = (movement: IEntityIATMovement) : string => {
    return `${StringUtils.trim(movement.routeId)} ${DateUtils.dataToOutputText(movement.localScheduledDate)} ${StringUtils.trim(movement.directionCode)}`;
};

const assocMovementToOutputText = (assocMovement: IIATAssociatedTravellerMovement) : string => {
    let movement = assocMovement.movement;
    return `${StringUtils.trim(movement.routeId)} ${DateUtils.dataToOutputText(movement.localScheduledDate)} ${StringUtils.trim(movement.movementTime)} ${StringUtils.trim(movement.movementRaceId)} ${StringUtils.trim(assocMovement.passengerCrewCode)} ${StringUtils.trim(movement.directionCode)}`
};

const getMovementSubTitle = (movement : IIATMovement) : string => {
    const titleEls : string[] = [];
    if(movement) {
        if(movement.routeId) {
            titleEls.push(movement.routeId);
        }
        if(movement.localScheduledDate) {
            titleEls.push(DateUtils.dataToOutputText(movement.localScheduledDate));
        }
        if(movement.directionCode) {
            titleEls.push(movement.directionCode);
        }
    }
    return titleEls.length > 0 ? titleEls.join(" | ") : "";
};

export {
    getEntityMovements,
    getEntityMovementList,
    getEntityAliases,
    getTravellerAliases,
    getEntityAliasList,
    getMovementFlightLists,
    movementToOutputText,
    movementToKey,
    assocMovementToOutputText,
    getMovementSubTitle
};