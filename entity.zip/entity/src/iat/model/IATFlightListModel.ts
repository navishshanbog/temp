import { IIATFlightListModel } from "./IIATFlightListModel";
import { ListModel } from "@twii/common/lib/model/ListModel";
import { IIATMovementFlightList } from "../IIATMovementFlightList";
import { IIATMovement } from "../IIATMovement";
import { getMovementFlightLists, movementToKey } from "../IATMovementHelper";
import { computed, observable, action } from "mobx";
import IIATAssociatedTraveller from "../IIATAssociatedTraveller";
import IIATAssociatedTravellerMovement from "../IIATAssociatedTravellerMovement";
import { IIATAssociatedTravellersGraph } from "../IIATAssociatedTravellersGraph";
import { IIATEntityMovements } from "../IIATEntityMovements";
import IMasterEntityModel from "../../entity/IMasterEntityModel";
import NameGenderCdRef from "../../ref/NameGenderCd";
import * as moment from "moment";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as StringUtils from "@twii/common/lib/util/String";
import { IIATAssociatedTravellersSummary } from "../IIATAssociatedTravellersSummary";

const Defaults = {
    minMovementThreshold: 2
};

const EDGE_COLOR_TRAVELLER_TYPE_CREW = '#BBBBBB';

const getAssociatedTravellersFromFlightLists = (movementFlightLists: IIATMovementFlightList[]) : IIATAssociatedTravellersSummary => {
    const result : IIATAssociatedTravellersSummary = {
        associatedTravellers: [],
        movementTypeMap: {}
    };
    if(movementFlightLists && movementFlightLists.length > 0) {
        const travellerMap : { [key : string] : IIATAssociatedTraveller } = {};
        //const movementTypeMap : { [key : string] : string } = {};
        movementFlightLists.forEach(movementFlightList => {
            const movement = movementFlightList.movement;
            const flightList = movementFlightList.flightList;
            if(flightList && flightList.length > 0) {
                movementFlightList.flightList.forEach(item => {
                    if(item.iatTravellerIdentifier !== movement.IATTravellerId) {
                        let assocTraveller = travellerMap[item.iatTravellerIdentifier];
                        if (!assocTraveller) {
                            assocTraveller = {
                                iatTravellerId: item.iatTravellerIdentifier,
                                birthDate: item.birthDate,
                                sexCode: item.sexCode,
                                familyName: item.familyName,
                                givenNames: item.givenNames,
                                travelDocumentId: item.travelDocumentId,
                                travelDocCountryCode: item.travelDocCountryCode,
                                assocMovements: []
                            } as IIATAssociatedTraveller;
                            travellerMap[item.iatTravellerIdentifier] = assocTraveller;
                            result.associatedTravellers.push(assocTraveller);
                        }
                        // Flight list may contain a traveller more than once. (another data services oddity)
                        // Need to eliminate those cases from showing up as false positives
                        const movementAdded = assocTraveller.assocMovements.some(assocMovement => assocMovement.movement.routeId === movement.routeId
                            && assocMovement.movement.localScheduledDate === movement.localScheduledDate
                            && assocMovement.movement.directionCode === movement.directionCode);
                        if (!movementAdded) {
                            const assocMovement = {
                                movement: {
                                    routeId: movement.routeId,
                                    localScheduledDate: movement.localScheduledDate,
                                    directionCode: movement.directionCode,
                                    movementTime: movement.movementTime,
                                    movementRaceId: item.movementRaceID
                                },
                                passengerCrewCode: item.passengerCrewCode
                            } as IIATAssociatedTravellerMovement;
                            assocTraveller.assocMovements.push(assocMovement);
                        }
                    } else {
                        let movementKey = movementToKey(movement);
                        if (!result.movementTypeMap[movementKey]) {
                            result.movementTypeMap[movementKey] = item.passengerCrewCode;
                        }
                    }
                });
            }
        });
    }
    return result;
};

const formatName = (familyName: string, givenNames: string, gender: string, dateOfBirth: Date | string) : string => {
    return `${familyName}\n${givenNames}${gender ? "\n" + gender.toUpperCase() : ""}${dateOfBirth ? " (" + ageInYears(dateOfBirth) + ")" : ""}`;
};

const ageInYears = (dateOfBirth: Date | string) : number => {
    let mdob: moment.Moment;
    if (typeof(dateOfBirth) === 'string') {
        mdob = DateUtils.momentFromDataText(dateOfBirth);
    } else {
        mdob = moment(dateOfBirth);
    }
    return moment().diff(mdob, 'years');
};

const isCrew = (passengerTypeCode: string) => {
    return passengerTypeCode === 'C';
};

const formatMovement = (movement: IIATMovement) : string => {
    return `${StringUtils.trim(movement.routeId)}\n${DateUtils.dataToOutputText(movement.localScheduledDate)} ${movement.directionCode}`
};

const getAssociatedTravellersGraph = (associatedTravellerSummary : IIATAssociatedTravellersSummary, masterEntity?: IMasterEntityModel) : IIATAssociatedTravellersGraph => {
    let mName;
    if(masterEntity) {
        const mGender = masterEntity.name.nameGenderCd ? NameGenderCdRef[masterEntity.name.nameGenderCd] : undefined;
        mName = formatName(masterEntity.name.familyName, `${masterEntity.name.firstName} ${masterEntity.name.middleName}`, mGender, masterEntity.dateOfBirth);
        if (masterEntity.isComposite) {
            mName = `${mName}\n(Combined Entity)`;
        }
    } else {
        mName = "Entity";
    }
    let nodes = [{
        id: 1,
        label: mName,
        group: 'traveller'
    }];
    let nodeIndex : number = 1;
    let movementNodeMap: { [key : string] : any } = {};
    let edges = [];
    associatedTravellerSummary.associatedTravellers.forEach((assocTraveller: IIATAssociatedTraveller) => {
        let assocTravellerNodeIdx: number = ++nodeIndex;
        const tGender = assocTraveller.sexCode ? NameGenderCdRef[assocTraveller.sexCode] : undefined;
        nodes.push({
            id: assocTravellerNodeIdx,
            label: formatName(assocTraveller.familyName, assocTraveller.givenNames, tGender, assocTraveller.birthDate),
            group: 'assocTravellers'
        });
        assocTraveller.assocMovements.forEach((assocMovement) => {
            let movementKey = movementToKey(assocMovement.movement);
            let movementNode = movementNodeMap[movementKey];
            if (!movementNode) {
                movementNode = { id: ++nodeIndex, label: formatMovement(assocMovement.movement), group: 'movements' };
                movementNodeMap[movementKey] = movementNode;
                nodes.push(movementNode);
                edges.push({
                    from: 1,
                    to: movementNode.id,
                    color: isCrew(associatedTravellerSummary.movementTypeMap[movementKey]) ? EDGE_COLOR_TRAVELLER_TYPE_CREW : undefined
                });
            }
            edges.push({
                from: movementNode.id,
                to: assocTravellerNodeIdx,
                color: isCrew(assocMovement.passengerCrewCode) ? EDGE_COLOR_TRAVELLER_TYPE_CREW : undefined
            });
        });
    });

    return { nodes: nodes, edges: edges };
};

class IATFlightListModel extends ListModel<IIATMovementFlightList, IIATEntityMovements> implements IIATFlightListModel {
    @observable private _movementThreshold : number = Defaults.minMovementThreshold;
    
    protected _loadImpl() {
        return getMovementFlightLists(this.parent.movements);
    }

    @computed
    get movementThreshold() : number {
        return this._movementThreshold;
    }
    set movementThreshold(value) {
        this.setMovementThreshold(value);
    }
    @action
    setMovementThreshold(movementThreshold : number) : void {
        if(movementThreshold >= Defaults.minMovementThreshold) {
            this._movementThreshold = movementThreshold;
        }
    }

    @computed
    get movementThresholds() : number[] {
        const thresholds : number[] = [];
        const ats = this.associatedTravellerSummary.associatedTravellers.forEach(at => {
            if(at && at.assocMovements && at.assocMovements.length >= Defaults.minMovementThreshold && thresholds.indexOf(at.assocMovements.length) < 0) {
                thresholds.push(at.assocMovements.length);
            }
        });
        return thresholds.sort((a, b) => a - b);
    }

    @computed
    private get associatedTravellerSummary() : IIATAssociatedTravellersSummary {
        return getAssociatedTravellersFromFlightLists(this.itemsView);
    }

    @computed
    get associatedTravellers() : IIATAssociatedTraveller[] {
        return this.associatedTravellerSummaryMatchingThreshold.associatedTravellers;
    }

    @computed
    private get associatedTravellerSummaryMatchingThreshold() : IIATAssociatedTravellersSummary {
        const ats = this.associatedTravellerSummary;
        const associatedTravellers = ats.associatedTravellers.filter(at => {
            return at && at.assocMovements && at.assocMovements.length >= this.movementThreshold;
        });
        return {
            associatedTravellers: associatedTravellers,
            movementTypeMap: ats.movementTypeMap
        };
    }

    @computed
    get associatedTravellersGraph() : IIATAssociatedTravellersGraph {
        return getAssociatedTravellersGraph(this.associatedTravellerSummaryMatchingThreshold, this.parent ? this.parent.entity : undefined);
    }
}

export {
    IATFlightListModel
}