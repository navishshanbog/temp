import { IIATMovementFlightList } from "../IIATMovementFlightList";
import { IListModel } from "@twii/common/lib/model/IListModel";
import { IIATEntityMovements } from "../IIATEntityMovements";
import { IIATAssociatedTravellersModel } from "./IIATAssociatedTravellersModel";

interface IIATFlightListModel extends IListModel<IIATMovementFlightList, IIATEntityMovements>, IIATAssociatedTravellersModel  {}

export { IIATFlightListModel }