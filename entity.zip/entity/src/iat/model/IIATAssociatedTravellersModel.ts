import { IIATAssociatedTraveller } from "../IIATAssociatedTraveller";
import { IIATAssociatedTravellersGraph } from "../IIATAssociatedTravellersGraph";

interface IIATAssociatedTravellersModel {
    movementThreshold : number;
    movementThresholds : number[];
    associatedTravellers : IIATAssociatedTraveller[];
    associatedTravellersGraph : IIATAssociatedTravellersGraph;
    setMovementThreshold(movementThreshold : number) : void;
}

export { IIATAssociatedTravellersModel }