import IIATMovement from "../IIATMovement";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import IIATMovementDetail from "../IIATMovementDetail";
import { SyncSupplier } from "@twii/common/lib/model/SyncSupplier";
import IATServiceContext from "../service/IATServiceContext";
import IIATAlias from "../IIATAlias";
import IMasterEntityModel from "../../entity/IMasterEntityModel";
import { getEntityAliases, getTravellerAliases } from "../IATMovementHelper";
import { IIATFlightListModel } from "./IIATFlightListModel";
import { IATFlightListModel } from "./IATFlightListModel";
import { IIATEntityMovements } from "../IIATEntityMovements";
import IIATVisa from "../IIATVisa";
import IIATPassport from "../IIATPassport";

// TODO: caching
const findDetailsByMovement = (movement : IIATMovement) : ISyncSupplier<IIATMovementDetail[], IIATMovement> => {
    const s = new SyncSupplier<IIATMovementDetail[], IIATMovement>();
    s.parent = movement;
    s.loader = (parent : IIATMovement) => {
        return IATServiceContext.value.getIATMovementDetails(
            parent.IATTravellerId,
            parent.routeId,
            parent.localScheduledDate,
            parent.directionCode
        );
    };
    return s;
};

const findAliasesByEntity = (entity : IMasterEntityModel) : ISyncSupplier<IIATAlias[], IMasterEntityModel> => {
    const s = new SyncSupplier();
    s.parent = entity;
    s.loader = (parent : IMasterEntityModel) => {
        return getEntityAliases(parent);
    };
    return s;
};

const findAliasesByTravellerIds = (iatTravellerIds : string[]) : ISyncSupplier<IIATAlias[], IMasterEntityModel> => {
    const s = new SyncSupplier();
    s.loader = () => {
        return getTravellerAliases(iatTravellerIds);
    };
    return s;
};

const findFlightListsByEntityMovements = (entityMovements : IIATEntityMovements) : IIATFlightListModel => {
    return new IATFlightListModel([], entityMovements);
};

const findVisasByMovement = (movement : IIATMovement) : ISyncSupplier<IIATVisa[], IIATMovement> => {
    const s = new SyncSupplier();
    s.parent = movement;
    s.loader = (parent : IIATMovement) => {
        return IATServiceContext.value.getVisas(parent.visaIdentifyingNbr);
    };
    return s;
};

const findPassportsByMovement = (movement : IIATMovement) : ISyncSupplier<IIATPassport[], IIATMovement> => {
    const s = new SyncSupplier();
    s.parent = movement;
    s.loader = (parent : IIATMovement) => {
        return IATServiceContext.value.getPassports(parent.travelDocumentId, parent.travelDocDeptCountryCode);
    };
    return s
};

export {
    findDetailsByMovement,
    findAliasesByEntity,
    findAliasesByTravellerIds,
    findFlightListsByEntityMovements,
    findVisasByMovement,
    findPassportsByMovement
}