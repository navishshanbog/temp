import { action } from "mobx";
import IMasterEntitySource from "../entity/IMasterEntitySource";
import IMasterEntitySourceModel from "../entity/IMasterEntitySourceModel";
import * as FilterUtils from "@twii/common/lib/util/Filter";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import IListResult from "@twii/common/lib/IListResult";
import ISort from "@twii/common/lib/ISortProps";
import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import { EROLLEntityColumns, DataLoadDate } from "./component/EROLLEntityColumns";
import IEROLLEntity from "./IEROLLEntity";
import { IMasterEntityModel } from "../entity/IMasterEntityModel";
import { getForMasterEntityWithSourceLoader } from "../entity/MasterEntitySourceServiceUtils";
import * as EROLLConstants from "./EROLLConstants";

const erollEntityToFilterRow = (item: IEROLLEntity) => {
    return ColumnTextHelper.getRowText(item, EROLLEntityColumns);
};

const erollFilterHandler = (items: IEROLLEntity[], props: IActivityFilterProps) => {
    return FilterUtils.filter(items, props, erollEntityToFilterRow);
};

const erollFieldTransformer = function(item: any, field: string): any {
    if (item) {
        const f = EROLLEntityColumns.find(column => column.fieldName == field);
        if (f && f.data) {
            if (f.data.getData) {
                return f.data.getData(item);
            } else if (f.data.getText) {
                return f.data.getText(item);
            }
        }
        return item[field];
    }
};

const erollSortHandler = (items: IEROLLEntity[], sort : ISort) => {
    return SortUtils.sort(items, sort, erollFieldTransformer);
};

const getEROLLEntity = (itemMap: { [key: string] : IEROLLEntity },
                        items: IEROLLEntity[],
                        sourceEntityId: string,
                        effectiveStartDt: string) => {
    const key = `${sourceEntityId}:${effectiveStartDt}`;
    let entity = itemMap[key];
    if(!entity) {
        entity = {
            sourceEntityId: sourceEntityId,
            effectiveStartDt: effectiveStartDt,
            names: [],
            addresses: []
        };
        itemMap[key] = entity;
        items.push(entity);
    }
    return entity;
};

const getSourceEROLLEntities = (source : IMasterEntitySourceModel, entity : IMasterEntityModel) : Promise<IEROLLEntity[]> => {
    const itemMap : { [key: string] : IEROLLEntity } = {};
    const items : IEROLLEntity[] = [];
    source.sourceEntities.forEach((sourceEntity) => {
        if (sourceEntity.meta) {
            const e = getEROLLEntity(itemMap, items, sourceEntity.sourceEntityId, sourceEntity.meta.effectiveStartDt);
            e.meta = sourceEntity.meta;
        }
        sourceEntity.names.forEach((name) => {
            const e = getEROLLEntity(itemMap, items, sourceEntity.sourceEntityId, name.effectiveStartDt);
            e.names.push(name);
        });
        sourceEntity.addresses.forEach((address) => {
            const e = getEROLLEntity(itemMap, items, sourceEntity.sourceEntityId, address.effectiveStartDt);
            e.addresses.push(address);
        });
    });
    SortUtils.sort(items, { field: DataLoadDate.fieldName, descending: true }, erollFieldTransformer);
    items.forEach((item, index) => {
        item["key"] = item.sourceEntityId + "_" + index;
        item.source = source;
        item.entity = entity;
    })
    return Promise.resolve(items);
};

const getEROLLEntities = (entity : IMasterEntityModel) : Promise<IEROLLEntity[]> => {
    return getForMasterEntityWithSourceLoader(entity, EROLLConstants.sourceSystemCode, getSourceEROLLEntities);
};

const getEROLLEntityList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEROLLEntity> => {
    return entity.getState("erollEntityList", () => {
        const r = new MasterEntitySourceListModel(entity, EROLLConstants.sourceSystemCode, getEROLLEntities);
        r.setFilterHandler(erollFilterHandler);
        r.setSortHandler(erollSortHandler);
        r.load();
        return r;
    });
};

export { getEROLLEntityList }