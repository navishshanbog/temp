import { IEntityActivity } from "../entity/IEntityActivity";
import IMasterEntitySourceEntityMeta from "../entity/IMasterEntitySourceEntityMeta";
import IMasterEntitySourceEntityName from "../entity/IMasterEntitySourceEntityName";
import IMasterEntitySourceEntityAddress from "../entity/IMasterEntitySourceEntityAddress";

interface IEROLLEntity extends IEntityActivity {
    sourceEntityId?: string;
    effectiveStartDt?: string;
    meta?: IMasterEntitySourceEntityMeta;
    names?: IMasterEntitySourceEntityName[];
    addresses?: IMasterEntitySourceEntityAddress[];
}

export { IEROLLEntity as default, IEROLLEntity };