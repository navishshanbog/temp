import * as React from "react";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { buildSectionHeader, buildTable, buildComments } from "../../entity/profile/EntityProfileDocumentHelper";
import { EROLLEntityColumns } from "./EROLLEntityColumns";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileEROLLApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="eroll-instances" title="EROLL Instances">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={EROLLEntityColumns} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const EROLLEntityDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("EROLL Instances", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, EROLLEntityColumns, doc);
    buildComments(group.comments, doc);
};

export { EntityProfileEROLLApp as default, EntityProfileEROLLApp, EROLLEntityDocumentHandler }