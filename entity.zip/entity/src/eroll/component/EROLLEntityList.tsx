import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import EROLLEntityDetailsList from "./EROLLEntityDetailsList";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import {IEROLLEntity} from "../IEROLLEntity";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { getEROLLEntityList } from "../EROLLEntityHelper";

interface IEROLLEntityListProps {
    list: IMasterEntitySourceListModel<IEROLLEntity>;
}

@observer
class EROLLEntityListCommandBar extends React.Component<IEROLLEntityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "EROLL Instances", viewOptions: { fromFilterHidden: true, toFilterHidden: true } }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "entity" })
        ];
        const farItems : IContextualMenuItem[] = [];
        return <CommandBar items={items} farItems={farItems}/>;
    }
}

class EROLLEntityList extends React.Component<IEROLLEntityListProps, any> {
    private _onRenderMenu = () => {
        return <EROLLEntityListCommandBar {...this.props} />;
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <EROLLEntityDetailsList {...this.props} />
            </AppView>
        )   
    }
}

class EROLLEntityListContainer extends React.Component<IEROLLEntityListProps, any> {
    private _onRenderDone = () => {
        return <EROLLEntityList {...this.props} />;
    };
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading EROLL Instances..." />;
    }
}

class EROLLEntityListApp extends EntitySourceApp {
    protected _onRenderSource = (props) => {
        return <EROLLEntityListContainer list={getEROLLEntityList(props.masterEntity)} />
    }
}

export {
    EROLLEntityList,
    EROLLEntityListContainer,
    IEROLLEntityListProps,
    EROLLEntityListApp,
    EROLLEntityListApp as default
}