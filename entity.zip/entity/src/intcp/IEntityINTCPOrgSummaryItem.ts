import { IEntityActivity } from "../entity/IEntityActivity";
import { IINTCPOrgSummaryItem } from "./IINTCPOrgSummaryItem";

interface IEntityINTCPOrgSummaryItem extends IEntityActivity, IINTCPOrgSummaryItem {}

export { IEntityINTCPOrgSummaryItem }