import { INTCPMovementColumns, AtPortDate, DepartureDate} from "./component/INTCPMovementColumns";
import { INTCPOrgSummaryItemColumns } from "./component/INTCPOrgSummaryItemColumns";
import * as INTCPConstants from "./INTCPConstants";
import * as FilterUtils from "@twii/common/lib/util/Filter";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import ISort from "@twii/common/lib/ISortProps";
import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import IActivityListModel from "@twii/common/lib/IActivityListModel";
import { IEntityINTCPMovement } from "./IEntityINTCPMovement";
import { IEntityINTCPOrgSummaryItem } from "./IEntityINTCPOrgSummaryItem";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import { getForMasterEntity } from "../entity/MasterEntitySourceServiceUtils";
import INTCPServiceContext from "./INTCPServiceContext";
import { IMasterEntityModel } from "../entity/IMasterEntityModel";
import IMasterEntitySourceModel from "../entity/IMasterEntitySourceModel";


const getMovementsForKey = (key : string, source : IMasterEntitySourceModel, entity : IMasterEntityModel) : Promise<IEntityINTCPMovement[]> => {
    return INTCPServiceContext.value.getINTCPMovements(key).then(r => {
        return r ? r.map((i, index) => {
            i["key"] = i.travelDocumentNumber + "_" + i.travelDocumentType + "_" + index;
            return Object.assign({}, i, { source: source, entity: entity });
        }) : [];
    });
};

const getEntityMovements = (entity : IMasterEntityModel) : Promise<IEntityINTCPMovement[]> => {
    return getForMasterEntity(entity, INTCPConstants.sourceSystemCode, getMovementsForKey);
};

const getOrgSummaryForKey = (key : string, source : IMasterEntitySourceModel, entity : IMasterEntityModel) : Promise<IEntityINTCPOrgSummaryItem[]> => {
    return INTCPServiceContext.value.getOrganisationINTCPSummary(key).then(r => {
        return r ? r.map(i => {
            return Object.assign({}, i, { source: source, entity: entity });
        }) : [];
    });
};

const getEntityOrgSummary = (entity : IMasterEntityModel) => {
    return getForMasterEntity(entity, INTCPConstants.sourceSystemCode, getOrgSummaryForKey);
};

const movementToFilterRow = (item : IEntityINTCPMovement) => {
    return ColumnTextHelper.getRowText(item, INTCPMovementColumns);
};

const movementFilterHandler = (items : IEntityINTCPMovement[], props : IActivityFilterProps) => {
    return FilterUtils.filter(items, props, movementToFilterRow, AtPortDate);
};

const movementSortHander = (items : IEntityINTCPMovement[], sort : ISort) => {
    const dateColumns = [
        AtPortDate,
        DepartureDate
    ];
    return SortUtils.sort(items, sort, SortUtils.dateAwareFieldTransformer(dateColumns));
};

const getEntityMovementList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityINTCPMovement> => {
    return entity.getState("intcpMovementList", () => {
        const r = new MasterEntitySourceListModel(entity, INTCPConstants.sourceSystemCode, getEntityMovements);
        r.setFilterHandler(movementFilterHandler);
        r.setSortHandler(movementSortHander);
        r.load();
        return r;  
    });
};

const orgSummaryItemToFilterRow = (item : IEntityINTCPOrgSummaryItem) => {
    return ColumnTextHelper.getRowText(item, INTCPOrgSummaryItemColumns);
};

const orgSummaryFilterHandler = (items : IEntityINTCPOrgSummaryItem[], props : IActivityFilterProps) => {
    return FilterUtils.filter(items, props, orgSummaryItemToFilterRow);
};

const orgSummarySortHandler = (items : IEntityINTCPOrgSummaryItem[], sort : ISort) => {
    return SortUtils.sort(items, sort);
};

const getEntityOrgSummaryList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityINTCPOrgSummaryItem> => {
    return entity.getState("intcpOrgSummaryList", () => {
        const r = new MasterEntitySourceListModel(entity, INTCPConstants.sourceSystemCode, getEntityOrgSummary);
        r.setFilterHandler(orgSummaryFilterHandler);
        r.setSortHandler(orgSummarySortHandler);
        r.load();
        return r;
    });
};

export { getEntityMovementList, getEntityOrgSummaryList }