import { IEntityActivity } from "../entity/IEntityActivity";
import { IINTCPMovement } from "./IINTCPMovement";

interface IEntityINTCPMovement extends IEntityActivity, IINTCPMovement {}

export { IEntityINTCPMovement }