import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const INTCPOrgSummaryViewPrefsStore = new ViewPreferencesModel("intcpOrgSummary");

export { INTCPOrgSummaryViewPrefsStore as default, INTCPOrgSummaryViewPrefsStore }