import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import INTCPOrgSummaryItemDetailsList from "./INTCPOrgSummaryItemDetailsList";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IINTCPOrgSummaryItem from "../IINTCPOrgSummaryItem";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { INTCPOrgSummaryViewPrefsStore } from "../INTCPOrgSummaryViewPrefsStore";
import { INTCPOrgSummaryItemColumns } from "./INTCPOrgSummaryItemColumns";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";

interface IINTCPOrgSummaryItemListProps {
    list: IMasterEntitySourceListModel<IINTCPOrgSummaryItem>;
}

@observer
class INTCPOrgSummaryItemListCommandBar extends React.Component<IINTCPOrgSummaryItemListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "INTCP Organisations", viewOptions: { fromFilterHidden: true, toFilterHidden: true } }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "org" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(INTCPOrgSummaryViewPrefsStore, INTCPOrgSummaryItemColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class INTCPOrgSummaryItemList extends React.Component<IINTCPOrgSummaryItemListProps, any> {
    private _onRenderMenu = () => {
        return <INTCPOrgSummaryItemListCommandBar {...this.props} />;
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <INTCPOrgSummaryItemDetailsList {...this.props} viewPreferences={INTCPOrgSummaryViewPrefsStore} />
            </AppView>
        );
    }
}

class INTCPOrgSummaryItemListContainer extends React.Component<IINTCPOrgSummaryItemListProps, any> {
    private _onRenderDone = () => {
        return <INTCPOrgSummaryItemList {...this.props} />;
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading INTCP Org Summary" />;
    }
}

export { INTCPOrgSummaryItemListContainer as default, INTCPOrgSummaryItemListContainer, IINTCPOrgSummaryItemListProps }