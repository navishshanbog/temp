import * as React from "react";
import IEntityProfileSourceGroupProps from "../../entity/profile/component/IEntityProfileSourceGroupProps";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import INTCPMovementColumns from "./INTCPMovementColumns";
import INTCPOrgSummaryColumns from "./INTCPOrgSummaryItemColumns";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { buildSectionHeader, buildTable, buildComments } from "../../entity/profile/EntityProfileDocumentHelper";
import { getViewPreferenceColumns } from "@twii/common/lib/component/ColumnHelper";
import INTCPMovementsViewPrefsStore from "../INTCPMovementsViewPrefsStore";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileINTCPApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="intcp-movements" title="INTCP Movements">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={INTCPMovementColumns} viewPreferences={INTCPMovementsViewPrefsStore} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const INTCPMovementDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("INTCP Movements", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, getViewPreferenceColumns(INTCPMovementColumns, INTCPMovementsViewPrefsStore), doc);
    buildComments(group.comments, doc);
};

class EntityProfileINTCPOrgSummaryApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="intcp-org-summaries" title="INTCP Org Summaries">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={INTCPOrgSummaryColumns} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const INTCPOrgSummaryDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("INTCP Org Summaries", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, INTCPOrgSummaryColumns, doc);
    buildComments(group.comments, doc);
};

export { EntityProfileINTCPApp, EntityProfileINTCPApp as default, EntityProfileINTCPOrgSummaryApp, INTCPMovementDocumentHandler, INTCPOrgSummaryDocumentHandler }