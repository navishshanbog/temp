import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import INTCPMovementDetailsList from "./INTCPMovementDetailsList";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IINTCPMovement from "../IINTCPMovement";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import INTCPMovementColumns from "./INTCPMovementColumns";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import INTCPMovementsViewPrefsStore from "../INTCPMovementsViewPrefsStore";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";

interface IINTCPMovementListProps {
    list: IMasterEntitySourceListModel<IINTCPMovement>;
}

@observer
class INTCPMovementListCommandBar extends React.Component<IINTCPMovementListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "INTCP Movements" }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "movement" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(INTCPMovementsViewPrefsStore, INTCPMovementColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class INTCPMovementList extends React.Component<IINTCPMovementListProps, any> {
    private _onRenderMenu = () => {
        return <INTCPMovementListCommandBar {...this.props} />
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <INTCPMovementDetailsList {...this.props} viewPreferences={INTCPMovementsViewPrefsStore} />
            </AppView>
        );
    }
}

class INTCPMovementListContainer extends React.Component<IINTCPMovementListProps, any> {
    private _onRenderDone = () => {
        return <INTCPMovementList {...this.props} />
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading INTCP Movements..." />;
    }
}

export {
    INTCPMovementListContainer as default,
    INTCPMovementListContainer,
    IINTCPMovementListProps
}