import * as React from "react";
import INTCPMovementList from "./INTCPMovementList";
import INTCPOrgSummaryItemList from "./INTCPOrgSummaryItemList";
import { getEntityMovementList, getEntityOrgSummaryList } from "../INTCPActivityHelper";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";

class EntityINTCPApp extends EntitySourceApp {
    protected _onRenderSource = (props) => {
        const entity = props.masterEntity;
        if (entity.isOrganisation) {
            return <INTCPOrgSummaryItemList list={getEntityOrgSummaryList(entity)}/>
        }
        return <INTCPMovementList list={getEntityMovementList(entity)}/>;
    }
}

export {
    EntityINTCPApp,
    EntityINTCPApp as default
}