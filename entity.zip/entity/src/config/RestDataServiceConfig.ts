import IUrlConfig from "@twii/common/lib/config/IUrlConfig";

const RestDataServicesConfig : IUrlConfig = {
    baseUrl: "/DataServices"
};

export { RestDataServicesConfig as default, RestDataServicesConfig };