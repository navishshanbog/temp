import * as React from "react";
import { css } from "@uifabric/utilities/lib/css";
import { Icon as FabricIcon }from "office-ui-fabric-react/lib/Icon"
import "./analyst-desktop-icons.css";

class Icon extends React.Component<any, any> {
    render() {
        return <i className={css("analyst-desktop-icons", this.props.className)} aria-hidden={true}>{this.props.children}</i>;
    }
}

class ABR extends React.Component<any, any> {
    render() {
        return <Icon className={css("ABR", this.props.className)}>{"\uE001"}</Icon>;
    }
}

class ASIC extends React.Component<any, any> {
    render() {
        return <Icon className={css("ASIC", this.props.className)}>{"\uE008"}</Icon>;
    }
}

class BAGS extends React.Component<any, any> {
    render() {
        return <Icon className={css("BAGS", this.props.className)}>{"\uE004"}</Icon>;
    }
}

class DGMS extends React.Component<any, any> {
    render() {
        return <Icon className={css("DGMS", this.props.className)}>{"\uE007"}</Icon>;
    }
}

class EROLL extends React.Component<any, any> {
    render() {
        return <Icon className={css("EROLL", this.props.className)}>{"\uE006"}</Icon>;
    }
}

class IAT extends React.Component<any, any> {
    render() {
        return <Icon className={css("IAT", this.props.className)}>{"\uE005"}</Icon>;
    }
}

class ICS extends React.Component<any, any> {
    render() {
        return <Icon className={css("ICS", this.props.className)}>{"\uE003"}</Icon>;
    }
}

class PNR extends React.Component<any, any> {
    render() {
        return <Icon className={css("PNR", this.props.className)}>{"\uE002"}</Icon>;
    }
}

class EXAM extends React.Component<any, any> {
    render() {
        return <Icon className={css("EXAM", this.props.className)}>{"\uE002"}</Icon>;
    }
}

class IATA extends React.Component<any, any> {
    render() {
        return <FabricIcon iconName="AirTickets" />;
    }
}

class INTCP extends React.Component<any, any> {
    render() {
        return <FabricIcon iconName="Ferry" />;
    }
}

class ICSE extends React.Component<any, any> {
    render() {
        return <FabricIcon iconName="Snowflake" />;
    }
}

class ETA extends React.Component<any, any> {
    render() {
        return <FabricIcon iconName="DocumentApproval" />;
    }
}

class TRIPS extends React.Component<any, any> {
    render() {
        return <FabricIcon iconName="AirplaneSolid" />;
    }
}

class PRISMS extends React.Component<any, any> {
    render() {
        return <FabricIcon iconName="Education" />;
    }
}

export { Icon,
    ABR,
    ASIC,
    BAGS,
    DGMS,
    EROLL,
    IAT,
    ICS,
    PNR,
    EXAM,
    IATA,
    INTCP,
    ICSE,
    ETA,
    TRIPS,
    PRISMS
};


