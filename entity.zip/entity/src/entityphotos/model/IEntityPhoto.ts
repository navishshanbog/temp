interface IEntityPhoto {
    MSTR_ENTY_ID?: string;
    IAT_TRAVELLER_ID?: string;
    TRAVELLER_ID?: string;
    IMAGE_ID?: string;
    IMAGE_TYPE?: string;
    TD_EXPIRY_DATE?: string;
    ENCODING?: string;
    MATCH_PERCENTAGE?: string;
    IMAGE_SOURCE?: string;
    CREATED_DATETIME?: string;
    IMAGE_DATA?: string;
};

export { IEntityPhoto as default, IEntityPhoto };