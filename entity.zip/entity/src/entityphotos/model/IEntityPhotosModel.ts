import ISyncModel from "@twii/common/lib/ISyncModel";
import IEntityPhoto from "./IEntityPhoto";

interface IEntityPhotosModel {
    entityPhotos: IEntityPhoto[];
    masterEntityId: string;
    sync: ISyncModel;
    getPhotos(masterEntityId: string): Promise<IEntityPhoto[]>
}

export { IEntityPhotosModel as default, IEntityPhotosModel };