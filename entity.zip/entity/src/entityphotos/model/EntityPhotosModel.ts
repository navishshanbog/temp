import { action, observable } from "mobx";
import IEntityPhotosModel from "./IEntityPhotosModel";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import IEntityPhoto from "./IEntityPhoto";
import EntityPhotosServiceContext from "../service/EntityPhotosServiceContext";
import { getPhotoNotAvailableURL } from "../util/EntityPhotosUtil";

class EntityPhotosModel implements IEntityPhotosModel {
    @observable entityPhotos: IEntityPhoto[] = [];
    @observable masterEntityId: string;
    @observable sync: ISyncModel = new SyncModel();
    private _loadPromise: Promise<IEntityPhoto[]>;

    @action
    refresh() : Promise<any> {
        const syncId = this.masterEntityId;
        this.sync.syncStart({ id: syncId });
        return EntityPhotosServiceContext.value.getLatestTravellerImagesByEntityId(this.masterEntityId)
            .then((entityPhotos) => {
                if(syncId === this.sync.id) {
                    this.entityPhotos = entityPhotos;

                    // If image cannot be retreived from TD then replace placeholder image
                    this.entityPhotos.map((photo: IEntityPhoto) => {
                        if(photo.IMAGE_DATA === "") {
                            photo.IMAGE_DATA = getPhotoNotAvailableURL();
                            return photo;
                        };
                    });
                    this.sync.syncEnd();
                }
            }).catch((error) => {
                if(syncId === this.sync.id) {
                    this.entityPhotos = [];
                    this.sync.syncError(error);
                }
            });
    }

    @action
    load(masterEntityId: string) : Promise<IEntityPhoto[]> {
        const syncId = masterEntityId;
        if(syncId !== this.sync.id) {
            this.masterEntityId = masterEntityId;
            this._loadPromise = this.refresh().then(() => {
                return this.entityPhotos;
            });
        }
        return this._loadPromise;
    }

    getPhotos = (masterEntityId: string): Promise<IEntityPhoto[]> => {
        return this.load(masterEntityId)
    };
}

export { EntityPhotosModel as default, EntityPhotosModel }