import * as React from "react";
import 'office-ui-fabric-react/lib/components/Modal/examples/Modal.Basic.Example.scss'
import IEntityPhoto from "../model/IEntityPhoto";
import IDetailsAttributeConfig from "@twii/common/lib/IDetailsAttributeConfig";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import { dataTimestampToOutputText } from "@twii/common/lib/util/Date"


let EntityPhotoMetaFields: IDetailsAttributeConfig<IEntityPhoto>[] = [
    {
        key: "IAT_TRAVELLER_ID",
        name: "IAT Traveller ID"
    },
    {
        key: "IMAGE_ID",
        name: "Image ID"
    },
    {
        key: "IMAGE_TYPE",
        name: "Image Type"
    },
    {
        key: "IMAGE_SOURCE",
        name: "Image Source",
        onRender: (item: IEntityPhoto) => <DetailsAttribute key="IMAGE_SOURCE"
            label="Image Source"
            value={`Smartgate - ${item.IMAGE_SOURCE}`} />
    },
    {
        key: "CREATED_DATETIME",
        name: "Created Time (UTC)",
        onRender: (item: IEntityPhoto) => <DetailsAttribute key="CREATED_DATETIME"
            label={item.IMAGE_SOURCE.toLowerCase().indexOf("arrival") !== -1 ? "Created Time (UTC)" : "Created Time"}
            value={dataTimestampToOutputText(item.CREATED_DATETIME)} />
    }
];

export { EntityPhotoMetaFields }