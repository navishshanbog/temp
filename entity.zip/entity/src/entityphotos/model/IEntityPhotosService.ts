import IEntityPhoto from "./IEntityPhoto";

interface IEntityPhotosService {
    getLatestTravellerImagesByEntityId(masterEntityId: string) : Promise<IEntityPhoto[]>;
}

export { IEntityPhotosService as default, IEntityPhotosService};