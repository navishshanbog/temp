import Context from "@twii/common/lib/Context";
import IEntityPhotosService from "../model/IEntityPhotosService";
import RestEntityPhotosService from "./RestEntityPhotosService";

const EntityPhotosServiceContext = new Context<IEntityPhotosService>({
    value: new RestEntityPhotosService()
});

export { EntityPhotosServiceContext as default, EntityPhotosServiceContext };