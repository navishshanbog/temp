interface IGetLatestTravellerImagesByEntityIdRequest {
    mstEntyID?: string;
    maxNumberOfRecords?: number;
    fromDate?: Date;
    toDate?: Date;
}

export { IGetLatestTravellerImagesByEntityIdRequest as default, IGetLatestTravellerImagesByEntityIdRequest};