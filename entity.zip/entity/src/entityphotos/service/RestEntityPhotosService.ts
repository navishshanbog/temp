import axios from "axios";
import IEntityPhotosService from "../model/IEntityPhotosService";
import IEntityPhoto from "../model/IEntityPhoto";
import AbstractRestDataService from "../../common/AbstractRestDataService";
import * as DefaultHttpErrorHandler from "@twii/common/lib/HttpErrorHandler";

interface IGetLatestTravellerImagesByEntityIdRestResponse {
    errors?: any;
    getLatestEntityBiometricImage?: IEntityPhoto[];
    total?: number;
}

class RestEntityPhotosService extends AbstractRestDataService implements IEntityPhotosService {

    getLatestTravellerImagesByEntityId(masterEntityId: string): Promise<IEntityPhoto[]> {
        return axios.get(`${this.config.baseUrl}/biometricimage/resources/v1/masteredentityimage/latest/${masterEntityId}`).then((value) => {
            const response = value.data as IGetLatestTravellerImagesByEntityIdRestResponse;
            if (response.errors) {
                return this.handleError(response.errors);
            }
            return response.getLatestEntityBiometricImage;
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

export { RestEntityPhotosService as default, RestEntityPhotosService };