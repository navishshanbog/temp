import * as React from "react";
import { observer } from "mobx-react";
import { Image } from "office-ui-fabric-react/lib/Image";
import { PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import './EntityPhotoModal.scss';
import IEntityPhoto from "../model/IEntityPhoto";
import { EntityPhotoMetaFields } from "../model/EntityPhotoMetaFields";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import Details from "@twii/common/lib/component/Details";
import { css } from "@uifabric/utilities/lib/css";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import DetailsItem from "@twii/common/lib/component/DetailsItem";
import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const EntityPhotoMetaViewPrefsStore = new ViewPreferencesModel("entityPhotoImageMeta");

interface EntityPhotoModalProps {
    image: IEntityPhoto;
    showModal?: boolean;
    closeModal: () => void;
}

@observer
class EntityPhotoModal extends React.Component<EntityPhotoModalProps, any>{
    _onModalHeaderClick = () => {
        this.props.closeModal();
    }

    renderLatestPhotos = () => {
        const originalImage = this.props.image;
        const originalImageUrl = originalImage.IMAGE_DATA;
        const imageUrl = (originalImage.ENCODING === "image/jpeg") ? ("data:image/jpeg;base64," + originalImageUrl) : originalImageUrl;

        return (
            <div className="ms-Grid">
                <div className="ms-Grid-row">
                    <div className="entity-photo-image-meta">
                        <div className="ms-Grid-col ms-md6">
                            <Image src={String(imageUrl)}
                                alt="photo_1"
                                className="image-metadata-modal--image" />
                        </div>
                        <div className="ms-Grid-col ms-md6">
                            <DetailsItem
                                model={this.props.image}
                                attrConfig={EntityPhotoMetaFields}
                                viewPrefModel={EntityPhotoMetaViewPrefsStore} />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    renderButtonGroup = () => {
        let disabled = false;
        let checked = false;
        return (
            <div className="image-metadata-button-group">
                <div className="image-metadata-button-load-all-photos">
                    <PrimaryButton
                        data-automation-id='load-all-photos'
                        disabled={disabled}
                        checked={checked}
                        text='Load all photos'
                        onClick={() => alert('Clicked: Load all photos!')}
                    />
                </div >
                <div className="image-metadata-button-load-smartgate-photos">
                    <PrimaryButton
                        data-automation-id='load-smartgate-photos'
                        disabled={disabled}
                        checked={checked}
                        text='Load Smartgate photos'
                        onClick={() => alert('Clicked: Load Smartgate photos!')}
                    />
                </div>
                <div className="image-metadata-button-load-passport-photos">
                    <PrimaryButton
                        data-automation-id='load-passport-photos'
                        disabled={disabled}
                        checked={checked}
                        text='Load Passport photos'
                        onClick={() => alert('Clicked: Load Passport photos!')}
                    />
                </div>
            </div>

        );
    }

    render() {
        return (
            <div className="image-metadata-modal" id="image-metadata-modal">
                <div className=''>
                    <Details className={css("details-panel")}
                        summary={`Image Id: ${this.props.image.IMAGE_ID}`}
                        open={true}
                        controlOnHeaderClick={false}
                        bodyClassName="image-metadata-modal--body">
                        <CommandBar className="image-metadata-modal--command-bar" items={[]}
                            farItems={[createViewPreferencesMenuItem(EntityPhotoMetaViewPrefsStore, EntityPhotoMetaFields)] as IContextualMenuItem[]} />
                        {this.renderLatestPhotos()}
                        {/* {this.renderButtonGroup()} */}
                    </Details>
                </div>
            </div>
        );
    }

}

export {
    EntityPhotoModal as default,
    EntityPhotoModal,
    EntityPhotoModalProps
}