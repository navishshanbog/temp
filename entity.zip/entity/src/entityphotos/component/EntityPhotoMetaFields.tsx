import * as React from "react";
import 'office-ui-fabric-react/lib/components/Modal/examples/Modal.Basic.Example.scss'
import IEntityPhoto from "../model/IEntityPhoto";
import IDetailsAttributeConfig from "@twii/common/lib/IDetailsAttributeConfig";
import DetailsAttribute from "@twii/common/lib/component/DetailsAttribute";
import { dataTimestampToOutputText } from "@twii/common/lib/util/Date"


let EntityPhotoMetaFields: IDetailsAttributeConfig<IEntityPhoto>[] = [
    {
        key: "IAT_TRAVELLER_ID",
        name: "IAT Traveller ID"
    },
    {
        key: "IMAGE_ID",
        name: "Image ID"
    },
    {
        key: "IMAGE_TYPE",
        name: "Image Type"
    },
    {
        key: "CREATED_DATETIME",
        name: "Created Datetime",
        onRender: (item: IEntityPhoto) => <DetailsAttribute key="CREATED_DATETIME"
            label="Created Datetime"
            value={dataTimestampToOutputText(item.CREATED_DATETIME)} />
    }
];

export { EntityPhotoMetaFields }