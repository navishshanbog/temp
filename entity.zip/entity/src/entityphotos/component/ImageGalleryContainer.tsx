import * as React from 'react';
import { observer } from "mobx-react";
import { Image } from "office-ui-fabric-react/lib/Image";
import 'office-ui-fabric-react/lib/components/Modal/examples/Modal.Basic.Example.scss'
import "./ImageGalleryContainer.scss";
import IEntityPhoto from "../model/IEntityPhoto";
import EntityPhotoModal from "./EntityPhotoModal";
import Dialog from 'office-ui-fabric-react/lib/Dialog';
import { css } from '@uifabric/utilities/lib/css';


interface ImageGalleryContainerProps {
  images?: IEntityPhoto[];
}

interface ImageGalleryContainerState {
  showModal: boolean;
}

@observer
class ImageGalleryContainer extends React.Component<ImageGalleryContainerProps, ImageGalleryContainerState> {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false
    }
  }

  private _showModal = () => {
    this.setState({ showModal: true });
  }

  private _closeModal = () => {
    this.setState({ showModal: false });
  }


  render() {
    const image = this.props.images[0];
    const originalImageUrl = image.IMAGE_DATA;
    const imageUrl = (image.ENCODING === "image/jpeg") ? ("data:image/jpeg;base64," + originalImageUrl) : originalImageUrl;
    return (
      <div className="entity-photos-image-gallery">
        <Image src={imageUrl}
          className="entity-photos-image-gallery--thumbnail"
          onClick={this._showModal} />
        <div className="view-photos">
          <Dialog
            hidden={!this.state.showModal}
            onDismiss={this._closeModal}
            modalProps={{ className: "image-metadata-modal", containerClassName: css("image-metadata-modal--container"), isBlocking: false }}
            title="Entity photo">
            <EntityPhotoModal image={image}
              showModal={this.state.showModal}
              closeModal={this._closeModal} />
          </Dialog>
        </div>
      </div>
    );
  }

}

export { ImageGalleryContainer as default, ImageGalleryContainer, ImageGalleryContainerProps, ImageGalleryContainerState };