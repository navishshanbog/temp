import * as React from 'react';
import { IMasterEntityModel } from "../../entity/IMasterEntityModel";
import ImageGalleryContainer from './ImageGalleryContainer';
import { SyncContainer } from '@twii/common/lib/component/SyncContainer';
import { Spinner, SpinnerSize } from 'office-ui-fabric-react/lib/Spinner';
import IEntityPhoto from '../model/IEntityPhoto';

interface IEntityPhotosProps {
    masterEntity?: IMasterEntityModel;
    compactError?: boolean;
    onRenderImage?: (images : IEntityPhoto[], defaultRender?: (images : IEntityPhoto[]) => React.ReactNode, props? : IEntityPhotosProps) => React.ReactNode;
    onRenderNoImage?: (props : IEntityPhotosProps) => React.ReactNode;
}

class EntityPhotos extends React.Component<IEntityPhotosProps, any> {
    componentDidMount() {
        this.props.masterEntity.entityPhotos.getPhotos(this.props.masterEntity.masterEntityId);
    };
    private _onRenderNoImage = () => {
        if(this.props.onRenderNoImage) {
            return this.props.onRenderNoImage(this.props);
        }
        return <div style={{ textAlign: "center", whiteSpace: "normal", wordBreak: "normal" }}>no image</div>;
    }
    private _onRenderDone = () => {
        return (this.props.masterEntity.entityPhotos.entityPhotos && this.props.masterEntity.entityPhotos.entityPhotos.length > 0) ?
           this._onRenderImage() : this._onRenderNoImage();
    }
    protected _defaultRenderImage = (images : IEntityPhoto[]) => {
        return <ImageGalleryContainer images={images} />;
    }
    private _onRenderImage = () => {
        const images = this.props.masterEntity.entityPhotos.entityPhotos;
        if(this.props.onRenderImage) {
            return this.props.onRenderImage(images, this._defaultRenderImage, this.props);
        }
        return this._defaultRenderImage(images);
    }
    private _onRenderCompactError = (error) => {
        return <div style={{ textAlign: "center", whiteSpace: "normal", wordBreak: "normal" }}>error loading image</div>;
    }
    private _onRenderSync = () => {
        return <Spinner size={SpinnerSize.small} label="Checking for photos..." styles={{ label: { whiteSpace: "normal", wordBreak: "normal" }}} />;
    }
    render() {
        return (
            <div className="entity-photos">
                <SyncContainer sync={this.props.masterEntity.entityPhotos.sync}
                                onRenderDone={this._onRenderDone}
                                onRenderError={this.props.compactError ? this._onRenderCompactError : undefined}
                                onRenderSync={this._onRenderSync} />
            </div>

        );
    }
}

export { EntityPhotos as default, EntityPhotos, IEntityPhotosProps }