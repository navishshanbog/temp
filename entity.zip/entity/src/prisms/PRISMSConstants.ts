const sourceSystemCode = "PRISMS";

export { sourceSystemCode }