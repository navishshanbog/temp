import * as React from "react";
import { Router } from "@twii/common/lib/Router";
import { exactPath, reactRouter, injectParametersInterceptor } from "@twii/common/lib/Routers";
import { IRequestHandler } from "@twii/common/lib/IRequestHandler";
import { PreferencesSupplier } from "./common/model/PreferencesSupplier";
const r = new Router();

const defaultHandler = reactRouter(() => import("./search/component/EntitySearchApp"), { exact: false });

r.use((req, next) => {
    return PreferencesSupplier.load().then(() => {
        // NOTE: deliberately ignoring errors - defaults will be picked up
        const nextReq = Object.assign({}, req, { entityPreferences: PreferencesSupplier.value });
        return next(nextReq);
    });

});
r.use((req, next) => {
    if(req.path === "" || req.path === "/" || req.path === "/index") {
        return defaultHandler(req, next);
    }
    return next();
});

r.use("/settings", reactRouter(() => import("./common/component/SettingsApp")));
r.use("/help", reactRouter(() => import("./common/component/Help")));
r.use("/search/new/:entityId/values", reactRouter(() => import("./search/component/EntitySearchResultValuesApp")));
r.use("/search/new/:entityId", reactRouter(() => import("./search/component/EntitySearchResultDetailsApp")));
r.use("/search/new", reactRouter(() => import("./search/component/EntitySearchApp")));

r.use("/search/result", reactRouter(() => import("./entity/component/EntitySearchResultApp")));

r.use("/search", reactRouter(() => import("./entity/component/EntitySearchApp")));

r.use("/profile", exactPath(req => {
    return import("./entity/profile/component/EntityProfileApplet").then(m => {
        return <m.EntityProfileApplet host={req.app} />;
    });
}));

r.use("/:entityId/summary", reactRouter(() => import("./entity/component/EntitySummaryApp")));
const sourceAttributesHandler = reactRouter(() => import("./entity/component/EntitySourceAttributesApp"));
r.use("/:entityId/sources/:sourceSystemCode/attributes", sourceAttributesHandler);
r.use("/:entityId/sources", reactRouter(() => import("./entity/component/EntitySourcesApp")));

const sourceActivityHandlers : { [key : string] : IRequestHandler } = {
    ABR: reactRouter(() => import("./abr/component/ABRActivityList")),
    BAGS: reactRouter(() => import("./bags/component/BAGSActivityList")),
    DGMS: reactRouter(() => import("./dgms/component/DGMSActivityList")),
    EROLL: reactRouter(() => import("./eroll/component/EROLLEntityList")),
    EXAM: reactRouter(() => import("./exams/component/EXAMSActivityList")),
    IAT: reactRouter(() => import("./iat/component/EntityIATMovement")),
    IATA: reactRouter(() => import("./iata/component/IATAAgencyList")),
    INTCP: reactRouter(() => import("./intcp/component/EntityINTCP")),
    ICS: reactRouter(() => import("./cargo/component/EntityCargoApp")),
    ICSE: reactRouter(() => import("./icse/component/EntityVisaDealingsApp")),
    TRIPS: reactRouter(() => import("./trips/component/EntityTRIPSActivitiesApp"))
};
const entitySourceDashboardHandler = reactRouter(() => import("./entity/component/EntitySourceDashboardApp"));
r.use("/:entityId/sources/:sourceSystemCode/activities", (req, next) => {
    const h = sourceActivityHandlers[req.params.sourceSystemCode];
    if(h) {
        return h(req, next);
    }
    return null;
});

const airCargoHandler = injectParametersInterceptor({ sourceSystemCode: "ICS"}, reactRouter(() => import("./cargo/air/component/AirCargoActivityList")));
const seaCargoHandler = injectParametersInterceptor({ sourceSystemCode: "ICS" }, reactRouter(() => import("./cargo/sea/component/SeaCargoActivityList")));
r.use("/:entityId/sources/ics/air", airCargoHandler);
r.use("/:entityId/sources/ics/sea", seaCargoHandler);
r.use("/:entityId/sources/ICS/air", airCargoHandler);
r.use("/:entityId/sources/ICS/sea", seaCargoHandler);

const airCargoDetailHandler = injectParametersInterceptor({ sourceSystemCode: "ICS"}, reactRouter(() => import("./cargo/air/component/AirCargoActivityDetail")));
r.use("/ICS/air/:clientInstanceId", airCargoDetailHandler);
const seaCargoDetailHandler = injectParametersInterceptor({ sourceSystemCode: "ICS"}, reactRouter(() => import("./cargo/sea/component/SeaCargoActivityDetail")));
r.use("/ICS/sea/:clientInstanceId", seaCargoDetailHandler);

const iataAgencyDetailHandler = injectParametersInterceptor({ sourceSystemCode: "IATA"}, reactRouter(() => import("./iata/component/IATAAgencyDetail")));
r.use("/IATA", iataAgencyDetailHandler);

const abrDetailHandler = injectParametersInterceptor({ sourceSystemCode: "ABR"}, reactRouter(() => import("./abr/component/ABRDetails")));
r.use("/ABR/:abn", abrDetailHandler);

const iatMovementDetailHandler = injectParametersInterceptor({ sourceSystemCode: "IAT"}, reactRouter(() => import("./iat/component/IATMovementDetail")));
r.use("/IAT/movement", iatMovementDetailHandler);

const iatAliasesHandler = injectParametersInterceptor({ sourceSystemCode: "IAT"}, reactRouter(() => import("./iat/component/IATMovementAliases")));
r.use("/IAT/aliases", iatAliasesHandler);

const iatFlightListsHandler = injectParametersInterceptor({ sourceSystemCode: "IAT" }, reactRouter(() => import("./iat/component/IATFlightList")));
r.use("/IAT/flightLists", iatFlightListsHandler);

const iatVisasHandler = injectParametersInterceptor({ sourceSystemCode: "IAT" }, reactRouter(() => import("./iat/component/IATMovementVisas")));
r.use("/IAT/visas/:visaIdentifyingNumber", iatVisasHandler);

const iatPassportsHandler = injectParametersInterceptor({ sourceSystemCode: "IAT" }, reactRouter(() => import("./iat/component/IATMovementPassports")));
r.use("/IAT/passports/:travelDocDeptCountryCode/:travelDocumentId", iatPassportsHandler);

const visaApplicationListHandler = injectParametersInterceptor({ sourceSystemCode: "ICSE"}, reactRouter(() => import("./icse/component/VisaApplicationActivityList")));
const visaCancellationListHandler = injectParametersInterceptor({ sourceSystemCode: "ICSE" }, reactRouter(() => import("./icse/component/VisaCancellationActivityList")));
r.use("/:entityId/sources/icse/visa/applications", visaApplicationListHandler);
r.use("/:entityId/sources/icse/visa/cancellations", visaCancellationListHandler);
r.use("/:entityId/sources/ICSE/visa/applications", visaApplicationListHandler);
r.use("/:entityId/sources/ICSE/visa/cancellations", visaCancellationListHandler);

const visaApplicationClientsHandler = injectParametersInterceptor({ sourceSystemCode: "ICSE" }, reactRouter(() => import("./icse/component/VisaApplicationClients")));
r.use("/ICSE/visa/applications/:applicationId/clients", visaApplicationClientsHandler);

const tripsVisaListHandler = injectParametersInterceptor({ sourceSystemCode: "TRIPS"}, reactRouter(() => import("./trips/component/TRIPSVisaList")));
const tripsMovementListHandler = injectParametersInterceptor({ sourceSystemCode: "TRIPS"}, reactRouter(() => import("./trips/component/TRIPSMovementList")));
r.use("/:entityId/sources/trips/visas", tripsVisaListHandler);
r.use("/:entityId/sources/TRIPS/visas", tripsVisaListHandler);
r.use("/:entityId/sources/trips/movements", tripsMovementListHandler);
r.use("/:entityId/sources/TRIPS/movements", tripsMovementListHandler);

// source handler
r.use("/:entityId/sources/:sourceSystemCode", (req, next) => {
    const activityHandler = sourceActivityHandlers[req.params.sourceSystemCode];
    if(activityHandler) {
        return entitySourceDashboardHandler(req, next);
    }
    return sourceAttributesHandler(req, next);
});

r.use("/:entityId", reactRouter(() => import("./entity/component/EntityDetailsApp")));

export { r as default, r as EntityRouter }