import IMasterEntitySourceEntityName from "./IMasterEntitySourceEntityName";
import * as EntityNameUtils from "./EntityNameUtils";
import MasterEntityModel from "./MasterEntityModel";

describe("Entity Name Utils", () => {
    test("getNameScore()", () => {
        const testName1 : IMasterEntitySourceEntityName = {
            firstName: "Sunburn"
        };

        const testName2 : IMasterEntitySourceEntityName = {
            firstName: "Sunburn",
            familyName: "Slapper"
        };

        const testName3 : IMasterEntitySourceEntityName = {
            firstName: "Sunburn",
            middleName: "H",
            familyName: "Slapper"
        };

        const testName4 : IMasterEntitySourceEntityName = {
            firstName: "Sunburn",
            middleName: "H",
            familyName: "Slapper",
            standardFullName: "Sunburn Harry Slapper"
        }

        expect(EntityNameUtils.getNameScore(testName1, true)).toBe(1);
        expect(EntityNameUtils.getNameScore(testName1, false)).toBe(0);
        expect(EntityNameUtils.getNameScore(testName2, true)).toBe(2);
        expect(EntityNameUtils.getNameScore(testName2, false)).toBe(0);
        expect(EntityNameUtils.getNameScore(testName3, true)).toBe(3);
        expect(EntityNameUtils.getNameScore(testName3, false)).toBe(0);
        expect(EntityNameUtils.getNameScore(testName4, true)).toBe(4);
        expect(EntityNameUtils.getNameScore(testName4, false)).toBe(1);
    });

    test("toNISFormat()", () => {
        let e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: "BAGS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            },
                            meta: {
                                sex: "Male",
                                entityTypeCd: "IND",
                                birthDt: "1975-01-01"
                            },
                            names: [
                                {
                                    firstName: "Sunburn",
                                    middleName: "Hurty",
                                    familyName: "Slapper"
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        let nisName = EntityNameUtils.toNISFormat(e);
        expect(nisName).toBe("SLAPPER, Sunburn Hurty (M) 01JAN1975");

        e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: "BAGS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            },
                            meta: {
                                entityTypeCd: "IND",
                                birthDt: "1975-01-01"
                            },
                            names: [
                                {
                                    firstName: "Sunburn",
                                    familyName: "Slapper"
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        nisName = EntityNameUtils.toNISFormat(e);
        expect(nisName).toBe("SLAPPER, Sunburn 01JAN1975");

        e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: "BAGS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            },
                            meta: {
                                entityTypeCd: "IND",
                                sex: "Female"
                            },
                            names: [
                                {
                                    firstName: "Sunburn",
                                    familyName: "Slapper"
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        nisName = EntityNameUtils.toNISFormat(e);
        expect(nisName).toBe("SLAPPER, Sunburn (F)");

        e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: "BAGS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            },
                            meta: {
                                entityTypeCd: "IND",
                                sex: "Male"
                            },
                            names: [
                                {
                                    firstName: "Sunburn",
                                    middleName: "Harry"
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        nisName = EntityNameUtils.toNISFormat(e);
        expect(nisName).toBe("Sunburn Harry (M)");


    });
});