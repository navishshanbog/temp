import { MasterEntityHandleModel } from "./MasterEntityHandleModel";
import { CompositeMasterEntityHandleModel } from "./CompositeMasterEntityHandleModel";
import { IMasterEntityModel } from "./IMasterEntityModel";
import { ISyncHandleModel } from "@twii/common/lib/ISyncHandleModel";
import { getMasterEntityIds, masterEntityIdSeparator } from "./MasterEntityHelper";

const deleteAfter = 2 * 60 * 1000;

interface IEntry {
    handle: ISyncHandleModel<IMasterEntityModel>;
    timeout?: any;
}

const entryMap : { [key : string] : IEntry } = {};

const deleteEntry = (key : string) => {
    delete entryMap[key];
};

// NOTE - we need to make use of a more generic caching mechanism for this kind of stuff

const findSingleEntity = (entityId : string) : ISyncHandleModel<IMasterEntityModel> => {
    let entry = entryMap[entityId];
    if(!entry) {
        entry = { handle: new MasterEntityHandleModel(entityId) };
        entryMap[entityId] = entry;

        // add our deletion timeout
        entry.timeout = setTimeout(() => {
            deleteEntry(entityId);
        }, deleteAfter);
    }
    entry.handle.load();
    return entry.handle;
};

const findCompositeEntity = (entityIds : string[]) : ISyncHandleModel<IMasterEntityModel> => {
    const key = entityIds.join(masterEntityIdSeparator);
    let entry = entryMap[key];
    if(!entry) {
        entry = { handle: new CompositeMasterEntityHandleModel(entityIds, findSingleEntity) };
        entryMap[key] = entry;
        // add our deletion timeout
        entry.timeout = setTimeout(() => {
            deleteEntry(key);
        }, deleteAfter);
    }
    //entry.handle.load();
    return entry.handle;
};

const findByEntityId = (entityId : string) : ISyncHandleModel<IMasterEntityModel> => {
    const entityIds = getMasterEntityIds(entityId);
    if(entityIds.length > 1) {
        return findCompositeEntity(entityIds);
    }
    return findSingleEntity(entityId);
};

export { findByEntityId }