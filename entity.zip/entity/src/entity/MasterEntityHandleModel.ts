import { observable, action, computed } from "mobx";
import { IMasterEntity } from "./IMasterEntity";
import { IMasterEntityModel } from "./IMasterEntityModel";
import { MasterEntityModel } from "./MasterEntityModel";
import { SyncHandleModel } from "@twii/common/lib/SyncHandleModel";
import { toPromise } from "@twii/common/lib/SyncUtils";
import { MasterEntityServiceContext } from "./MasterEntityServiceContext";

class MasterEntityHandleModel extends SyncHandleModel<IMasterEntityModel> {
    @observable private _masterEntityId : string;

    constructor(masterEntityId : string) {
        super();
        this._masterEntityId = masterEntityId;
    }

    @computed
    get masterEntityId() {
        return this._masterEntityId;
    }
    
    loader = () => {
        return MasterEntityServiceContext.value.getMasterEntityById(this.masterEntityId).then(e => {
            return new MasterEntityModel(e);
        });
    }
}

export { MasterEntityHandleModel }