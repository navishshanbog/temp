import { IMasterEntityModel } from "./IMasterEntityModel";
import { IMasterEntitySourceModel } from "./IMasterEntitySourceModel";

interface IEntityActivity {
    source?: IMasterEntitySourceModel;
    entity?: IMasterEntityModel;
}

export { IEntityActivity }