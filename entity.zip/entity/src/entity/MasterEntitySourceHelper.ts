import { IMasterEntityModel } from "./IMasterEntityModel";
import { IMasterEntitySourceModel } from "./IMasterEntitySourceModel";
import { IMasterEntitySourceEntity } from "./IMasterEntitySourceEntity";
import { MasterEntitySourceModel } from "./MasterEntitySourceModel";

const composeSource = (entity : IMasterEntityModel, sourceSystemCode : string) : IMasterEntitySourceModel => {
    const sources = entity ? entity.sources.filter(s => s.sourceSystemCode === sourceSystemCode) : [];
    if(sources.length === 1) {
        return sources[0];
    }
    
    if(sources.length > 1) {
        const r = new MasterEntitySourceModel(entity);
        r.setSourceSystemCode(sourceSystemCode);
        let sourceEntities : IMasterEntitySourceEntity[] = [];
        sources.forEach(s => {
            sourceEntities = sourceEntities.concat(s.sourceEntities);
        });
        r.setSourceEntities(sourceEntities);
        return r;
    }
};

export { composeSource }