interface IMasterEntitySourceKey {
    masterEntityId?: string;
    sourceEntityId?: string;
    sourceSystemCd?: string;
}

export { IMasterEntitySourceKey as default, IMasterEntitySourceKey };