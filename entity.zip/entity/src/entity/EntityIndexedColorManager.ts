import { IndexedColorManager } from "../common/IndexedColorManager";

const EntityIndexedColorManager = new IndexedColorManager();

export { EntityIndexedColorManager }