import {
    IMasterEntityDataService,
    IMasterEntityServiceRequestOptions,
    IMasterEntitySourceRefResponse,
    IMasterEntitySourceEntityMetaResponse,
    IMasterEntitySourceEntityNameResponse,
    IMasterEntitySourceEntityAddressResponse,
    IMasterEntitySourceEntityPhoneResponse,
    IMasterEntitySourceEntityCredentialResponse,
    IMasterEntitySourceEntityEmailResponse
} from "./IMasterEntityDataService";
import { getRefs, getMetas, getNames, getAddresses, getPhones, getCredentials, getEmails } from "./MockMasterEntities";

class MockMasterEntityDataService implements IMasterEntityDataService {
    refResponse : IMasterEntitySourceRefResponse;
    metaResponse : IMasterEntitySourceEntityMetaResponse;
    nameResponse : IMasterEntitySourceEntityNameResponse;
    addressResponse : IMasterEntitySourceEntityAddressResponse;
    phoneResponse : IMasterEntitySourceEntityPhoneResponse;
    credentialResponse : IMasterEntitySourceEntityCredentialResponse;
    emailResponse: IMasterEntitySourceEntityEmailResponse;
    getMasterEntitySourceRef(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceRefResponse> {
        if(this.refResponse) {
            return Promise.resolve(this.refResponse);
        }
        return Promise.resolve({
            getMasterEntitySourceResponse: getRefs(masterEntityId)
        });
    }
    getMasterEntitySourceEntityMeta(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityMetaResponse> {
        if(this.metaResponse) {
            return Promise.resolve(this.metaResponse);
        }
        return Promise.resolve({
            getMasterEntitySourceEntityResponse: getMetas(masterEntityId)
        });
    }
    getMasterEntitySourceEntityName(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityNameResponse> {
        if(this.nameResponse) {
            return Promise.resolve(this.nameResponse);
        }
        return Promise.resolve({
            getMasterEntitySourceEntityNameResponse: getNames(masterEntityId)
        });
    }
    getMasterEntitySourceEntityAddress(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityAddressResponse> {
        if(this.addressResponse) {
            return Promise.resolve(this.addressResponse);
        }
        return Promise.resolve({
            getMasterEntitySourceEntityAddressResponse: getAddresses(masterEntityId)
        });
    }
    getMasterEntitySourceEntityPhone(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityPhoneResponse> {
        if(this.phoneResponse) {
            return Promise.resolve(this.phoneResponse);
        }
        return Promise.resolve({
            getMasterEntitySourceEntityPhoneResponse: getPhones(masterEntityId)
        });
    }
    getMasterEntitySourceEntityCredential(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityCredentialResponse> {
        if(this.credentialResponse) {
            return Promise.resolve(this.credentialResponse);
        }
        return Promise.resolve({
            getMasterEntitySourceEntityCredentialResponse: getCredentials(masterEntityId)
        });
    }
    getMasterEntitySourceEntityEmail(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityEmailResponse> {
        if(this.emailResponse) {
            return Promise.resolve(this.emailResponse);
        }
        return Promise.resolve({
            getMasterEntitySourceEntityEmailResponse: getEmails(masterEntityId)
        });
    }
}

export { MockMasterEntityDataService as default, MockMasterEntityDataService };

