import { observable, action, computed } from "mobx";
import IMasterEntitySourceModel from "./IMasterEntitySourceModel";
import IMasterEntityModel from "./IMasterEntityModel";
import IMasterEntitySourceEntityName from "./IMasterEntitySourceEntityName";
import IMasterEntitySourceEntityAddress from "./IMasterEntitySourceEntityAddress";
import IMasterEntitySourceEntityPhone from "./IMasterEntitySourceEntityPhone";
import IMasterEntitySourceEntityCredential from "./IMasterEntitySourceEntityCredential";
import IMasterEntitySourceEntityMeta from "./IMasterEntitySourceEntityMeta";
import * as EntityNameUtils from "./EntityNameUtils";
import ISyncModel from "@twii/common/lib/ISyncModel";
import SyncModel from "@twii/common/lib/SyncModel";
import ActivityFilterModel from "@twii/common/lib/ActivityFilterModel";
import * as DateUtils from "@twii/common/lib/util/Date";
import IMasterEntitySourceEntityEmail from "./IMasterEntitySourceEntityEmail";
import EntityPhotosModel from "../entityphotos/model/EntityPhotosModel";

abstract class AbstractMasterEntityModel<D> implements IMasterEntityModel<D> {
    @observable sync: ISyncModel = new SyncModel();
    @observable activityFilter = new ActivityFilterModel();
    @observable private _state = {};
    @observable entityPhotos = new EntityPhotosModel();

    abstract get isComposite(): boolean;

    abstract get masterEntityId(): string;

    abstract get masterEntityIds(): string[];

    abstract get nisName(): string;

    abstract data: D;

    abstract setData(data: D);

    abstract sources: IMasterEntitySourceModel[];

    @computed
    get state() {
        return this._state;
    }
    set state(value: any) {
        this.setState(value);
    }
    @action
    setState(state: any) {
        this._state = Object.assign({}, this._state, state);
    }

    @action
    getState(key: string, factory?: (entity: IMasterEntityModel) => any): any {
        let r = this._state[key];
        if (!r && factory) {
            r = factory(this);
            this._state[key] = r;
        }
        return r;
    }

    @computed
    get sourceCodes(): string[] {
        const sourceCodes: string[] = [];
        this.sources.forEach(s => {
            if (sourceCodes.indexOf(s.sourceSystemCode) < 0) {
                sourceCodes.push(s.sourceSystemCode);
            }
        });
        return sourceCodes;
    }

    @computed
    get names(): IMasterEntitySourceEntityName[] {
        const dup: { [key: string]: any } = {};
        const r: IMasterEntitySourceEntityName[] = [];
        this.sources.forEach((source) => {
            source.names.forEach((name) => {
                if (!dup[name.standardFullName]) {
                    dup[name.standardFullName] = name;
                    r.push(name);
                }
            })
        });
        return r;
    }

    @computed
    get name(): IMasterEntitySourceEntityName {
        let r: IMasterEntitySourceEntityName;
        let score = 0;
        this.sources.forEach((source) => {
            return source.names.forEach((name) => {
                const nameScore = EntityNameUtils.getNameScore(name);
                if (nameScore > score) {
                    score = nameScore;
                    r = name;
                } else if (nameScore === score && EntityNameUtils.isMainName(name)) {
                    r = name;
                }
            });
        });

        if (!r) {
            const mainName = this.names.find(EntityNameUtils.isMainName);
            if (mainName) {
                r = mainName;
            }
        }

        if (!r && this.names.length > 0) {
            r = this.names[0];
        }
        return r;
    }

    @computed
    get addresses(): IMasterEntitySourceEntityAddress[] {
        const dup: { [key: string]: any } = {};
        const r: IMasterEntitySourceEntityAddress[] = [];
        this.sources.forEach((source) => {
            source.addresses.forEach((address) => {
                if (!dup[address.standardAddressValue]) {
                    dup[address.standardAddressValue] = address;
                    r.push(address);
                }
            })
        });
        return r;
    }

    @computed
    get phones(): IMasterEntitySourceEntityPhone[] {
        const dup: { [key: string]: any } = {};
        const r: IMasterEntitySourceEntityPhone[] = [];
        this.sources.forEach((source) => {
            source.phones.forEach((phone) => {
                if (!dup[phone.phoneNumber]) {
                    dup[phone.phoneNumber] = phone;
                    r.push(phone);
                }
            })
        });
        return r;
    }

    @computed
    get credentials(): IMasterEntitySourceEntityCredential[] {
        const dup: { [key: string]: any } = {};
        const r: IMasterEntitySourceEntityCredential[] = [];
        this.sources.forEach((source) => {
            source.credentials.forEach((cred) => {
                if (!dup[cred.credentialTypeCd + cred.credentialValue]) {
                    dup[cred.credentialTypeCd + cred.credentialValue] = cred;
                    r.push(cred);
                }
            })
        });
        return r;
    }

    @computed
    get emails(): IMasterEntitySourceEntityEmail[] {
        const dup: { [key: string]: any } = {};
        const r: IMasterEntitySourceEntityEmail[] = [];
        this.sources.forEach((source) => {
            source.emails.forEach((email) => {
                if (!dup[email.emailValue]) {
                    dup[email.emailValue] = email;
                    r.push(email);
                }
            })
        });
        return r;
    }

    @computed
    get personalMetas(): IMasterEntitySourceEntityMeta[] {
        const dup: { [key: string]: any } = {};
        const r: IMasterEntitySourceEntityCredential[] = [];
        this.sources.forEach((source) => {
            source.personalMetas.forEach((personal) => {
                if (!dup[personal.birthDt + personal.birthCountryCd + personal.sex]) {
                    dup[personal.birthDt + personal.birthCountryCd + personal.sex] = personal;
                    r.push(personal);
                }
            })
        });
        return r;
    }

    @computed
    get datesOfBirth(): Date[] {
        const r: Date[] = [];
        const dup = {};
        this.sources.forEach(source => {
            const dobs = source.datesOfBirth;
            if (dobs && dobs.length > 0) {
                dobs.forEach(dob => {
                    const dupKey = DateUtils.dateToDataText(dob);
                    if (!dup[dupKey]) {
                        dup[dupKey] = true;
                        r.push(dob);
                    }
                });
            }
        });
        return r;
    }

    @computed
    get dateOfBirth(): Date {
        const dobs = this.datesOfBirth;
        return dobs && dobs.length > 0 ? dobs[0] : undefined;
    }

    @computed
    get genders(): string[] {
        const r: string[] = [];
        const dup = {};
        this.sources.forEach(source => {
            const genders = source.genders;
            if (genders && genders.length > 0) {
                genders.forEach(gender => {
                    if (!dup[gender]) {
                        dup[gender] = true;
                        r.push(gender);
                    }
                })
            }
        });
        return r;
    }

    @computed
    get gender(): string {
        const genders = this.genders;
        return genders && genders.length > 0 ? genders[0] : undefined;
    }

    @computed
    get isPerson(): boolean {
        return this.sources.some((source) => {
            return source.isPerson;
        });
    }

    @computed
    get isOrganisation(): boolean {
        return this.sources.some((source) => {
            return source.isOrganisation;
        })
    }

    toJSON() {
        return this.data;
    }
}

export { AbstractMasterEntityModel as default, AbstractMasterEntityModel };