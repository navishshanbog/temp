import IMasterEntity from "./IMasterEntity";

enum MasterEntityAttributeType {
    ref = "ref",
    meta = "meta",
    name = "name",
    address = "address",
    phone = "phone",
    credential = "credential",
    email = "email"
}

interface IMasterEntityGetRequest {
    masterEntityId: string;
    // this is to limit retrieval
    attributeTypes?: MasterEntityAttributeType[];
}

/**
 * Yep, this is confusing, but this is the higher level / convenience service (an implementation, for example, might make use of the data service)
 */
interface IMasterEntityService {
    getMasterEntityById(masterEntityId: string) : Promise<IMasterEntity>;
    getMasterEntity(request : IMasterEntityGetRequest) : Promise<IMasterEntity>;
}

export {
    IMasterEntityService as default,
    IMasterEntityService,
    MasterEntityAttributeType,
    IMasterEntityGetRequest
};