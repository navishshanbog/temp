import { observable, action, computed } from "mobx";
import ActivityListModel from "@twii/common/lib/model/ActivityListModel";
import IMasterEntitySearchResultModel from "./IMasterEntitySearchResultModel";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import IMasterEntitySearchService from "./IMasterEntitySearchService";
import IMasterEntitySearchResult from "./IMasterEntitySearchResult";
import MasterEntitySearchServiceContext from "./MasterEntitySearchServiceContext";
import { filterItems, sortItems } from "./MasterEntitySearchResultHelper";
import SelectionModel from "@twii/common/lib/SelectionModel";
import { Sequence } from "@twii/common/lib/Id";

class MasterEntitySearchResultModel extends ActivityListModel<IMasterEntitySearchResultItem> implements IMasterEntitySearchResultModel {
    sortHandler = sortItems;
    filterHandler = filterItems;
    private _searchService : IMasterEntitySearchService;
    @observable request : IMasterEntitySearchRequest;
    @observable hasMoreRows: boolean;
    @observable private _hasMoreRowsAlert : boolean;
    @observable visitedItems = new SelectionModel();
    private _sequence = new Sequence();

    get searchService() : IMasterEntitySearchService {
        return this._searchService || MasterEntitySearchServiceContext.value;
    }
    set searchService(value : IMasterEntitySearchService) {
        this._searchService = value;
    }

    @action
    protected _loadDone = (r : IMasterEntitySearchResult) => {
        this.setItems(r && r.items ? r.items : []);
        this.hasMoreRows = r.hasMoreRows;
        this._hasMoreRowsAlert = undefined;
    }

    @action
    protected _loadError = (error) => {
        this.hasMoreRows = false;
        this._hasMoreRowsAlert = undefined;
        super._loadError(error);
    }

    @action
    refresh() : Promise<any> {
        if(this.request) {
            const syncId = this._sequence.next();
            this.sync.syncStart({ id: syncId });
            return this.searchService.search(this.request).then(r => {
                if(this.sync.id === syncId) {
                    this._onLoadDone(r);
                }
            }).catch(error => {
                if(this.sync.id === syncId) {
                    this._onLoadError(error);
                }
            });
        }
        return Promise.resolve();
    }

    @action
    search(request : IMasterEntitySearchRequest) : Promise<any> {
        this.clear();
        this.request = request;
        return this.refresh();
    }

    @action
    clear() {
        super.clear();
        this.selection.clearSelection();
    }

    @computed
    get hasMoreRowsAlert() {
        return this._hasMoreRowsAlert !== undefined ? this._hasMoreRowsAlert : this.hasMoreRows;
    }
    set hasMoreRowsAlert(value : boolean) {
        this.setHasMoreRowsAlert(value);
    }

    @action
    setHasMoreRowsAlert(hasMoreRowsAlert : boolean) {
        this._hasMoreRowsAlert = hasMoreRowsAlert;
    }
}

export { MasterEntitySearchResultModel as default, MasterEntitySearchResultModel };