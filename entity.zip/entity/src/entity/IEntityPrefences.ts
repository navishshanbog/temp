import { EntitySearchResultViewType } from "../search/EntitySearchResultViewType";
import { EntitySearchResultDataType } from "../search/EntitySearchResultDataType";

interface IEntityPreferences {
    isLinkOpenInANewWindow?: boolean;
    showPhotosInSearchResult?: boolean;
    groupSearchResultsByMaster?: boolean;
    systemsToExcludeFromSearch?: string[];
    searchResultViewType?: EntitySearchResultViewType;
    searchResultDataType?: EntitySearchResultDataType;
    searchResultColumnOrder?: string[];
}

export { IEntityPreferences }