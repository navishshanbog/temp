import IMasterEntitySourceKey from "./IMasterEntitySourceKey";

interface IMasterEntitySourceEntityEmail extends IMasterEntitySourceKey {
    masterEntityId: string;
    sourceEntityId: string;
    sourceSystemCd: string;
    sourceEntityEmailId: string;
    usageTypeCd: string;
    emailValue: string;
    USERNAME: string;
    domainName: string;
    organisationName: string;
    organisationTypeCd: string;
    countryCd: string;
    IPAddressValue: string;
    identifiedContactValue: string;
    effectiveStartDt: string;
    [key: string]: any;
}

export { IMasterEntitySourceEntityEmail as default, IMasterEntitySourceEntityEmail };