import { observable, action, computed } from "mobx";
import { IMasterEntity } from "./IMasterEntity";
import { IMasterEntitySourceModel } from "./IMasterEntitySourceModel";
import { MasterEntitySourceModel } from "./MasterEntitySourceModel";
import { AbstractMasterEntityModel } from "./AbstractMasterEntityModel";
import { toNISFormat } from "./EntityNameUtils";

class MasterEntityModel extends AbstractMasterEntityModel<IMasterEntity> {
    @observable masterEntityId: string;
    @observable private _sources : IMasterEntitySourceModel[] = [];

    constructor(data?: IMasterEntity) {
        super();
        this.setData(data);
    }

    get isComposite() {
        return false;
    }

    @computed
    get masterEntityIds() {
        return [this.masterEntityId];
    }

    @computed
    get nisName() {
        return toNISFormat(this);
    }

    @computed
    get data() {
        return {
            masterEntityId: this.masterEntityId,
            sources: this._sources.map(s => s.data)
        };
    }
    set data(value) {
        this.setData(value);
    }

    @action
    setData(data : IMasterEntity) {
        if(data) {
            this.masterEntityId = data.masterEntityId;
            this.setSources(data.sources ? data.sources.map((s) => {
                return new MasterEntitySourceModel(this, s);
            }) : []);
        } else {
            this.masterEntityId = undefined;
            this.setSources([]);
        }
    }

    @computed
    get sources() {
        return this._sources.slice(0);
    }
    set sources(value : IMasterEntitySourceModel[]) {
        this.setSources(value);
    }

    @action
    setSources(sources : IMasterEntitySourceModel[]) {
        this._sources = [];
        if(sources) {
            sources.forEach(s => {
                this._sources.push(s);
            });
        }
    }
}

export { MasterEntityModel as default, MasterEntityModel };