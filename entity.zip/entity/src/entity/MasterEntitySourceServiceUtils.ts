import { IMasterEntityModel } from "./IMasterEntityModel";
import { IMasterEntitySourceModel } from "./IMasterEntitySourceModel";

interface ISourceLoader<T> {
    (source: IMasterEntitySourceModel,
     entity?: IMasterEntityModel) : Promise<T[]>;
}

interface IRelatedKeyLoader<T> {
    (sourceRelatedKeyValue: string,
     source?: IMasterEntitySourceModel,
     entity?: IMasterEntityModel) : Promise<T[]>;
}

const getForMasterEntitySource = <T>(entity : IMasterEntityModel,
                                     source : IMasterEntitySourceModel,
                                     loader: IRelatedKeyLoader<T>) : Promise<T[]> => {
    let r: T[] = [];
    return Promise.all(source.sourceEntities.map(sourceEntity => {
        if(sourceEntity.ref && sourceEntity.ref.sourceRelatedKeyValue) {
            return loader(sourceEntity.ref.sourceRelatedKeyValue, source, entity).then((items) => {
                r = r.concat(items);
            });
        }
        return Promise.resolve();
    })).then(() => {
        return Promise.resolve(r);
    });
};

const getForMasterEntitySources = <T>(entity : IMasterEntityModel,
                                      sources : IMasterEntitySourceModel[],
                                      loader: IRelatedKeyLoader<T>) : Promise<T[]> => {
    let r : T[] = [];
    if(sources && sources.length > 0) {
        const ps = sources.map(s => {
            return getForMasterEntitySource(entity, s, loader).then(sr => {
                r = r.concat(sr);
            });
        });
        return Promise.all(ps).then(() => {
            return r;
        });
    }
    return Promise.resolve(r);
};

const getForMasterEntity = <T>(entity : IMasterEntityModel,
                               sourceSystemCode: string,
                               loader: IRelatedKeyLoader<T>) : Promise<T[]> => {
    const sources = entity && entity.sources ? entity.sources.filter(s => s.sourceSystemCode === sourceSystemCode) : [];
    return getForMasterEntitySources(entity, sources, loader);
};

const getForMasterEntityWithSourceLoader = <T>(entity : IMasterEntityModel,
                                               sourceSystemCode : string,
                                               loader : ISourceLoader<T>) : Promise<T[]> => {
    const sources = entity && entity.sources ? entity.sources.filter(s => s.sourceSystemCode === sourceSystemCode) : [];

    if(sources.length > 0) {
        let r : T[] = [];
        const ps = sources.map(s => {
            return loader(s, entity).then(sr => {
                r = r.concat(sr);
            });
        });
        return Promise.all(ps).then(() => {
            return r;
        });
    }
    return Promise.resolve([]);
};

export {
    getForMasterEntitySource,
    getForMasterEntitySources,
    getForMasterEntity,
    getForMasterEntityWithSourceLoader,
    ISourceLoader,
    IRelatedKeyLoader
};
