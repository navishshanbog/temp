import IMasterEntityModel from "./IMasterEntityModel";

interface IEntitySourceItems {
    type: string;
    items: any[];
}
/*
interface IIEntitySourceItems {
    subItemType?: string;
    isSubType?: boolean;
    masterEntityId?: string;
    sourceSubItemHeader?: string;
}
*/
export { IEntitySourceItems as default, IEntitySourceItems }