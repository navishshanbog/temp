import Context from "@twii/common/lib/Context";
import IMasterEntitySearchService from "./IMasterEntitySearchService";
//import { DSSolrMasterEntitySearchService } from "./DSSolrMasterEntitySearchService";
import { RestMasterEntitySearchDataService } from "./RestMasterEntitySearchService";

const MasterEntitySearchServiceContext = new Context<IMasterEntitySearchService>({
    id: "MasterEntitySearchService",
    value: new RestMasterEntitySearchDataService()
});

export { MasterEntitySearchServiceContext as default, MasterEntitySearchServiceContext };