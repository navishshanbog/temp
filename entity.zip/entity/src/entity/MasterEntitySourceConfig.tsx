import * as React from "react";
import * as Icons from "../icon/AnalystDesktopIcons";
import { equalsIgnoreCase } from "@twii/common/lib/util/String";

const PREFIX_SEPARATOR = "_";

interface IMasterEntitySourceConfigEntry {
    key?: string;
    title?: string;
    description?: string;
    icon?(props?: any) : any;
    codeAliases?: string[];
}

const entries : IMasterEntitySourceConfigEntry[] = [
    {
        key: "IAT",
        title: "IAT",
        description: "IAT",
        icon(props? : any) {
            return <Icons.IAT {...props} />;
        }
    },
    {
        key: "BAGS",
        title: "BAGS",
        description: "BAGS",
        icon(props? : any) {
            return <Icons.BAGS {...props} />;
        }
    },
    {
        key: "DGMS",
        title: "DGMS",
        description: "Detained Goods Management System",
        icon(props? : any) {
            return <Icons.DGMS {...props} />;
        }
    },
    {
        key: "ICS",
        title: "Cargo",
        description: "Cargo & Exam",
        icon(props? : any) {
            return <Icons.ICS {...props} />;
        }
    },
    {
        key: "ASIC",
        title: "ASIC",
        description: "Australian Securities and Investments Commission",
        icon(props? : any) {
            return <Icons.ASIC {...props} />;
        }
    },
    {
        key: "ABR",
        title: "ABR",
        description: "Australia Business Register",
        icon(props? : any) {
            return <Icons.ABR {...props} />;
        }
    },
    {
        key: "EROLL",
        title: "EROLL",
        description: "Electoral Roll",
        icon(props? : any) {
            return <Icons.EROLL {...props} />;
        }
    },
    {
        key: "EXAM",
        title: "EXAMS",
        description: "EXAMS",
        icon(props? : any) {
            return <Icons.EXAM {...props} />;
        },
        codeAliases: ["EXAMS", "ICS_EXAM", "ICS_EXAMS", "EXAM"]
    },
    {
        key: "IATA",
        title: "IATA",
        description: "IATA",
        icon(props? : any) {
            return <Icons.IATA {...props} />;
        }
    },
    {
        key: "INTCP",
        title: "INTCP",
        description: "INTCP",
        icon(props? : any) {
            return <Icons.INTCP {...props} />;
        }
    },
    {
        key: "ICSE",
        title: "ICSE",
        description: "ICSE",
        icon(props? : any) {
            return <Icons.ICSE {...props} />;
        }
    },
    {
        key: "ETA",
        title: "ETAS",
        description: "ETAS",
        icon(props? : any) {
            return <Icons.ETA {...props} />;
        }
    },
    {
        key: "TRIPS",
        title: "TRIPS",
        description: "TRIPS",
        icon(props? : any) {
            return <Icons.TRIPS {...props} />;
        }
    }, {
        key: "ICSE_PRISMS",
        title: "PRISMS",
        description: "PRISMS",
        icon(props? : any) {
            return <Icons.PRISMS {...props} />;
        },
        codeAliases: ["ICSE_PRISMS", "PRISMS"]
    }
];

const removePrefix = (code : string) : string => {
    if(code) {
        const pfxIdx = code.indexOf(PREFIX_SEPARATOR);
        if(pfxIdx >= 0) {
            return code.substring(pfxIdx + 1);
        }
    }
    return code;
}

const byCode = (code : string) : IMasterEntitySourceConfigEntry => {
    if(code) {
        let r = entries.find(e => (equalsIgnoreCase(e.key, code) || (e.codeAliases && e.codeAliases.findIndex(a => equalsIgnoreCase(a, code)) >= 0)));
        if(!r) {
            console.warn(`Source System ${code} not configured`);
        }
        return r;
    }
}

export { byCode, removePrefix, entries, IMasterEntitySourceConfigEntry };