import HistoryModel from "@twii/common/lib/model/HistoryModel";

const MasterEntityVisitedHistoryStore = new HistoryModel<string>();
MasterEntityVisitedHistoryStore.storageKey = "visitedItemsList";

export { MasterEntityVisitedHistoryStore as default, MasterEntityVisitedHistoryStore };