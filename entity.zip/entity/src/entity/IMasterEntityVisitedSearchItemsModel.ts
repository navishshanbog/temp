interface IVisitedItemsModel {
    mstrEntyId: string,
    timeStamp: number
}

interface IMasterEntityVisitedSearchItemsModel {
    items: IVisitedItemsModel[];
    getItems: () => IVisitedItemsModel[];
    setItems: (mstrEntityIds: string[]) => IVisitedItemsModel[];
    clearItems: () => IVisitedItemsModel[];
    addItem: (mstrEntityId: string) => IVisitedItemsModel[];
    autoClear: () => IVisitedItemsModel[];
    setInLocalStorage: (items: IVisitedItemsModel[]) => void;
}

export {
    IMasterEntityVisitedSearchItemsModel as default,
    IMasterEntityVisitedSearchItemsModel,
    IVisitedItemsModel
}