import IMasterEntitySourceEntityName from "./IMasterEntitySourceEntityName";
import IMasterEntitySourceEntityAddress from "./IMasterEntitySourceEntityAddress";
import IMasterEntitySourceEntityPhone from "./IMasterEntitySourceEntityPhone";
import IMasterEntitySourceEntityCredential from "./IMasterEntitySourceEntityCredential";
import IMasterEntitySourceEntityMeta from "./IMasterEntitySourceEntityMeta";
import IEntityAttributeActions from "./IEntityAttributeActions";
import IMasterEntitySourceEntityEmail from "./IMasterEntitySourceEntityEmail";

interface IEntityModel {
    name: IMasterEntitySourceEntityName;
    names: IMasterEntitySourceEntityName[];
    addresses: IMasterEntitySourceEntityAddress[];
    phones: IMasterEntitySourceEntityPhone[];
    emails: IMasterEntitySourceEntityEmail[];
    credentials: IMasterEntitySourceEntityCredential[];
    personalMetas: IMasterEntitySourceEntityMeta[];
    dateOfBirth: Date;
    datesOfBirth: Date[];
    gender: string;
    genders: string[];
    isPerson: boolean;
    isOrganisation: boolean;
}

export { IEntityModel as default, IEntityModel };