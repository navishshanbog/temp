import { observable, action, computed } from "mobx";
import { IMasterEntity } from "./IMasterEntity";
import { IMasterEntityModel } from "./IMasterEntityModel";
import { ISyncHandle } from "@twii/common/lib/ISyncHandle";
import { ICompositeMasterEntityModel } from "./ICompositeMasterEntityModel";
import { CompositeMasterEntityModel } from "./CompositeMasterEntityModel";
import { SyncHandleModel } from "@twii/common/lib/SyncHandleModel";
import { toPromise } from "@twii/common/lib/SyncUtils";

class CompositeMasterEntityHandleModel extends SyncHandleModel<ICompositeMasterEntityModel> {
    private _masterEntityIds : string[];
    private _componentFinder : (entityId : string) => ISyncHandle<IMasterEntityModel>;

    constructor(masterEntityIds : string[], componentFinder : (entityId : string) => ISyncHandle<IMasterEntityModel>) {
        super();
        this._masterEntityIds = masterEntityIds;
        this._componentFinder = componentFinder;
    }

    loader = () => {
        const components = this.masterEntityIds.map(this._componentFinder);
        const cps = components.map(c => {
            return toPromise(c.sync);
        });
        return Promise.all(cps).then(() => {
            const r = new CompositeMasterEntityModel();
            r.setEntities(components.map(c => c.value));
            return r;
        });
    }

    @computed
    get masterEntityIds() {
        return this._masterEntityIds.slice(0);
    }
}

export { CompositeMasterEntityHandleModel }