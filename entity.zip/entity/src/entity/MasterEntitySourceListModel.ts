import { observable, action, computed } from "mobx";
import { IMasterEntityModel } from "./IMasterEntityModel";
import { ActivityListModel } from "@twii/common/lib/model/ActivityListModel";
import { IMasterEntitySourceListModel } from "./IMasterEntitySourceListModel";

interface IMasterEntitySourceListLoader<T> {
    (entity : IMasterEntityModel) : Promise<T[]>;
}

class MasterEntitySourceListModel<T> extends ActivityListModel<T> implements IMasterEntitySourceListModel<T> {
    @observable private _sourceSystemCode : string;
    @observable private _entity: IMasterEntityModel;

    constructor(entity : IMasterEntityModel, sourceSystemCode?: string, loader?: IMasterEntitySourceListLoader<T>) {
        super();
        this._entity = entity;
        this.setLoader(loader ? () => {
            return loader(entity);
        } : undefined);
    }

    @computed
    get sourceSystemCode() {
        return this._sourceSystemCode;
    }

    @computed
    get entity() {
        return this._entity;
    }

    @computed
    get sources() {
        const sources = this.entity.sources;
        return sources ? sources.filter(s => s.sourceSystemCode === this._sourceSystemCode) : [];
    }

    @computed
    get filterSpecified() {
        return this.entity.activityFilter.specified || this.filter.specified;
    }

    @computed
    get filterView() {
        let r = this.items;
        if(r && r.length > 0 && this.filterHandler) {
            if(this.entity && this.entity.activityFilter) {
                r = this.filterHandler(r, this.entity.activityFilter);
            }
            r = this.filterHandler(r, this.filter);
        }
        return r;
    }  
}

export { MasterEntitySourceListModel as default, MasterEntitySourceListModel, IMasterEntitySourceListLoader }