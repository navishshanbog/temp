import { IAppHost } from "@twii/common/lib/IAppHost";
import { IMasterEntitySearchRequestModel } from "./IMasterEntitySearchRequestModel";
import { MasterEntitySearchRequestModel } from "./MasterEntitySearchRequestModel";
import { IMasterEntitySearchResultModel } from "./IMasterEntitySearchResultModel";
import { MasterEntitySearchResultModel } from "./MasterEntitySearchResultModel";
import * as StringUtils from "@twii/common/lib/StringUtils";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { IMasterEntitySearchRequest } from "./IMasterEntitySearchService";

const hasSearchRequestModel = (host : IAppHost) : boolean => {
    return host.state.entitySearchRequest ? true : false;
};

const getSearchRequestModel = (host : IAppHost) : IMasterEntitySearchRequestModel => {
    return host.getState("entitySearchRequest", () => {
        return new MasterEntitySearchRequestModel();
    });
};

const getSearchResultModel = (host : IAppHost) : IMasterEntitySearchResultModel => {
    return host.getState("entitySearchResult", () => {
        return new MasterEntitySearchResultModel();
    });
};

const createSearchRequest = (value : ISearchField) : IMasterEntitySearchRequest => {
    if(StringUtils.equalsIgnoreCase(value.name, "name") || StringUtils.equalsIgnoreCase(value.name, "fullName")) {
        return {
            fullName: value.searchString
        };
    }
    if(StringUtils.equalsIgnoreCase(value.name, "address") || StringUtils.equalsIgnoreCase(value.name, "fullAddress")) {
        return {
            fullAddress: value.searchString
        };
    }
    if(StringUtils.equalsIgnoreCase(value.name, "email") || StringUtils.equalsIgnoreCase(value.name, "emailAddress")) {
        return {
            emailAddress: value.searchString
        };
    }
    if(StringUtils.equalsIgnoreCase(value.name, "phone") || StringUtils.equalsIgnoreCase(value.name, "phoneNumber")) {
        return {
            phoneNumber: value.searchString
        };
    }
    if(StringUtils.equalsIgnoreCase(value.name, "dob") || StringUtils.equalsIgnoreCase(value.name, "dateOfBirth")) {
        return {
            dob: value.searchString
        };
    }
    if(StringUtils.equalsIgnoreCase(value.name, "gender") || StringUtils.equalsIgnoreCase(value.name, "sex")) {
        return {
            sex: value.searchString
        };
    }
    // otherwise try a credential
    return {
        credentialType: value.name,
        credential: value.searchString
    };
};

export {
    getSearchRequestModel,
    hasSearchRequestModel,
    getSearchResultModel,
    createSearchRequest
}