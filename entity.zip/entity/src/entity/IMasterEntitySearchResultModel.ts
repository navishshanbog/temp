import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import IActivityListModel from "@twii/common/lib/model/IActivityListModel";
import SelectionModel from "@twii/common/lib/SelectionModel";

interface IMasterEntitySearchResultModel extends IActivityListModel<IMasterEntitySearchResultItem> {
    request: IMasterEntitySearchRequest;
    search(request : IMasterEntitySearchRequest);
    hasMoreRows: boolean;
    hasMoreRowsAlert: boolean;
    refresh() : Promise<any>;
    setHasMoreRowsAlert(hasMoreRowsAlert : boolean) : void;
    visitedItems?: SelectionModel<IMasterEntitySearchResultItem>;
}

export { IMasterEntitySearchResultModel as default, IMasterEntitySearchResultModel };