import { byCode } from "./MasterEntitySourceConfig";

describe("MasterEntitySourceConfig", () => {
    test("codes and aliases", () => {
       const e = byCode("ICS_EXAMS");
       expect(e).toBeTruthy();
       expect(e.key).toBe("EXAM");
    });
});