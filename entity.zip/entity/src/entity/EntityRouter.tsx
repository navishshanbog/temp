import { EntityRouter } from "../EntityRouter";

export { EntityRouter, EntityRouter as default }