import IEntityModel from "./IEntityModel";
import IMasterEntity from "./IMasterEntity";
import IMasterEntitySourceModel from "./IMasterEntitySourceModel";
import IActivityFilterModel from "@twii/common/lib/IActivityFilterModel";
import IEntityPhoto from "../entityphotos/model/IEntityPhoto";
import IEntityPhotosModel from "../entityphotos/model/IEntityPhotosModel";

interface IMasterEntityModel<D = any> extends IEntityModel {
    masterEntityId: string;
    masterEntityIds: string[];
    nisName : string;
    isComposite: boolean;
    data: D;
    state: any;
    setState(state : any) : void;
    getState(key : string, factory?: (entity : IMasterEntityModel) => any) : any;
    sources: IMasterEntitySourceModel[];
    sourceCodes: string[];
    activityFilter: IActivityFilterModel;
    setData(data : D) : void;
    entityPhotos: IEntityPhotosModel;
}

export { IMasterEntityModel as default, IMasterEntityModel };