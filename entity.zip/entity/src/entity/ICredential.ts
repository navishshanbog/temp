interface ICredential<V = string> {
    id?: string;
    type?: string;
    value?: V;
}

export { ICredential as default, ICredential };