import { observable, action, computed } from "mobx";
import IMasterEntityModel from "./IMasterEntityModel";
import IMasterEntitySource from "./IMasterEntitySource";
import IMasterEntitySourceModel from "./IMasterEntitySourceModel";
import IMasterEntitySourceEntity from "./IMasterEntitySourceEntity";
import IMasterEntitySourceEntityName from "./IMasterEntitySourceEntityName";
import IMasterEntitySourceEntityAddress from "./IMasterEntitySourceEntityAddress";
import IMasterEntitySourceEntityPhone from "./IMasterEntitySourceEntityPhone";
import IMasterEntitySourceEntityCredential from "./IMasterEntitySourceEntityCredential";
import IMasterEntitySourceEntityMeta from "./IMasterEntitySourceEntityMeta";
import * as EntityNameUtils from "./EntityNameUtils";
import * as StringUtils from "@twii/common/lib/util/String";
import * as DateUtils from "@twii/common/lib/util/Date";
import IMasterEntitySourceEntityEmail from "../entity/IMasterEntitySourceEntityEmail";

class MasterEntitySourceModel implements IMasterEntitySourceModel {
    @observable.ref private _masterEntity : IMasterEntityModel;
    @observable private _sourceSystemCode: string;
    @observable private _sourceEntities: IMasterEntitySourceEntity[] = [];
    @observable private _state : any = {};

    constructor(masterEntity : IMasterEntityModel, data?: IMasterEntitySource) {
        this._masterEntity = masterEntity;
        this.setData(data);
    }

    @computed
    get sourceSystemCode() {
        return this._sourceSystemCode;
    }
    set sourceSystemCode(value) {
        this.setSourceSystemCode(value);
    }
    @action
    setSourceSystemCode(sourceSystemCode : string) {
        this._sourceSystemCode = sourceSystemCode;
    }

    @computed
    get sourceEntities() {
        return this._sourceEntities.slice(0);
    }
    set sourceEntities(value) {
        this.setSourceEntities(value);
    };

    @action
    setSourceEntities(sourceEntities : IMasterEntitySourceEntity[]) {
        this._sourceEntities = [];
        if(sourceEntities) {
            sourceEntities.forEach(se => this._sourceEntities.push(se));
        }
    }

    @computed
    get masterEntity() {
        return this._masterEntity;
    }

    @computed
    get masterEntityId() {
        return this._masterEntity ? this._masterEntity.masterEntityId : undefined;
    }

    @computed
    get state() {
        return this._state;
    }
    set state(value) {
        this.setState(value);
    }
    @action
    setState(state : any) {
        this._state = Object.assign({}, this._state, state);
    }

    @computed
    get data() {
        return {
            sourceSystemCode: this.sourceSystemCode,
            sourceEntities: this.sourceEntities.slice(0)
        }
    }

    @action
    setData(data : IMasterEntitySource) {
        if(data) {
            this._sourceSystemCode = data.sourceSystemCode;
            this._sourceEntities = data.sourceEntities || [];
        } else {
            this._sourceSystemCode = undefined;
            this._sourceEntities = [];
        }
    }

    @computed
    get names() : IMasterEntitySourceEntityName[] {
        const dup : { [key: string] : any } = {};
        const r : IMasterEntitySourceEntityName[] = [];
        this.sourceEntities.forEach((source) => {
            source.names.forEach((name) => {
                if(!dup[name.standardFullName]) {
                    dup[name.standardFullName] = name;
                    r.push(name);
                }
            });
        });
        return r;
    }

    @computed
    get name() : IMasterEntitySourceEntityName {
        let r : IMasterEntitySourceEntityName;
        let score = 0;
        this.sourceEntities.forEach((source) => {
            return source.names.forEach((name) => {
                const nameScore = EntityNameUtils.getNameScore(name, this.isPerson);
                if(nameScore > score) {
                    score = nameScore;
                    r = name;
                } else if(nameScore === score && EntityNameUtils.isMainName(name)) {
                    r = name;
                }
            })
        });
        
        if(!r) {
            const mainName = this.names.find(EntityNameUtils.isMainName);
            if(mainName) {
                r = mainName;
            }
        }

        if(!r && this.names.length > 0) {
            r = this.names[0];
        }
        return r;
    }

    @computed
    get addresses() : IMasterEntitySourceEntityAddress[] {
        const dup : { [key: string] : any } = {};
        const r : IMasterEntitySourceEntityAddress[] = [];
        this.sourceEntities.forEach((source) => {
            source.addresses.forEach((address) => {
                if(!dup[address.standardAddressValue]) {
                    dup[address.standardAddressValue] = address;
                    r.push(address);
                }
            })
        });
        return r;
    }

    @computed
    get phones() : IMasterEntitySourceEntityPhone[] {
        const dup : { [key: string] : any } = {};
        const r : IMasterEntitySourceEntityPhone[] = [];
        this.sourceEntities.forEach((source) => {
            source.phones.forEach((phone) => {
                if(!dup[phone.phoneNumber]) {
                    dup[phone.phoneNumber] = phone;
                    r.push(phone);
                }
            })
        });
        return r;
    }

    @computed
    get emails() : IMasterEntitySourceEntityEmail[] {
        const dup : { [key: string] : any } = {};
        const r : IMasterEntitySourceEntityEmail[] = [];
        this.sourceEntities.forEach((source) => {
            source.emails.forEach((email) => {
                if(!dup[email.emailValue]) {
                    dup[email.emailValue] = email;
                    r.push(email);
                }
            })
        });
        return r;
    }

    @computed
    get credentials() : IMasterEntitySourceEntityCredential[] {
        const dup : { [key: string] : any } = {};
        const r : IMasterEntitySourceEntityCredential[] = [];
        this.sourceEntities.forEach((source) => {
            source.credentials.forEach((cred) => {
                if(!dup[cred.credentialTypeCd + cred.credentialValue]) {
                    dup[cred.credentialTypeCd + cred.credentialValue] = cred;
                    r.push(cred);
                }
            })
        });
        return r;
    }

    private _isPerson(sourceEntity : IMasterEntitySourceEntity) {
        return sourceEntity.meta && StringUtils.equalsIgnoreCase(sourceEntity.meta.entityTypeCd, "IND");
    }

    private _isOrganisation(sourceEntity : IMasterEntitySourceEntity) {
        return sourceEntity.meta && StringUtils.equalsIgnoreCase(sourceEntity.meta.entityTypeCd, "ORG");
    }

    @computed
    get personalMetas() : IMasterEntitySourceEntityMeta[] {
        const dup : { [key: string] : any } = {};
        let r : IMasterEntitySourceEntityMeta[] = [];
        this.sourceEntities.filter(this._isPerson, this).forEach((source) => {
            if(source.meta && !dup[source.meta.birthDt + source.meta.birthCountryCd + source.meta.sex]) {
                dup[source.meta.birthDt + source.meta.birthCountryCd + source.meta.sex] = source.meta;
                r.push(source.meta);
            }
        });
        return r;
    }

    @computed
    get datesOfBirth() : Date[] {
        const metas = this.personalMetas.filter((meta) => {
            return meta && StringUtils.isNotBlank(meta.birthDt);
        });
        const r : Date[] = [];
        const dup = {};
        metas.forEach(meta => {
            if(!dup[meta.birthDt]) {
                dup[meta.birthDt] = true;
                const m = DateUtils.momentFromDataText(meta.birthDt);
                if(m && m.isValid()) {
                    r.push(m.toDate());
                }
            }
        });
        return r;
    }

    @computed
    get dateOfBirth() : Date {
        const dobs = this.datesOfBirth;
        return dobs && dobs.length > 0 ? dobs[0] : undefined;
    }

    @computed
    get genders() : string[] {
        const metas = this.personalMetas.filter((meta) => {
            return meta && StringUtils.isNotBlank(meta.sex) && !StringUtils.equalsIgnoreCase(meta.sex, "NA");
        });
        const r : string[] = [];
        const dup = {};
        metas.forEach(meta => {
            if(!dup[meta.sex]) {
                dup[meta.sex] = true;
                r.push(meta.sex);
            }
        });
        return r;
    }

    @computed
    get gender() : string {
        const genders = this.genders;
        return genders && genders.length > 0 ? genders[0] : undefined;
    }

    @computed
    get isPerson() : boolean {
        return this.sourceEntities.some(this._isPerson, this);
    }

    @computed
    get isOrganisation() : boolean {
        return this.sourceEntities.some(this._isOrganisation, this);
    }

    toJSON() {
        return this.data;
    }
}

export { MasterEntitySourceModel as default, MasterEntitySourceModel };