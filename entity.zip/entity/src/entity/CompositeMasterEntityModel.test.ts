import MasterEntityModel from "./MasterEntityModel";
import CompositeMasterEntityModel from "./CompositeMasterEntityModel";
import * as DateUtils from "@twii/common/lib/util/Date";

describe("Component Master Entity Model", () => {
    test("test sources", () => {
        const me1 = new MasterEntityModel();
        me1.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: "BAGS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            },
                            meta: {
                                sex: "Male",
                                entityTypeCd: "IND",
                                birthDt: "1974-09-01"
                            },
                            names: [
                                {
                                    standardFullName: "Sunburn Slapper",
                                    firstName: "Sunburn",
                                    familyName: "Slapper"
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        const me2 = new MasterEntityModel();
        me2.setData({
            masterEntityId: "2",
            sources: [
                {
                    sourceSystemCode: "DGMS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "wha'ever"
                            },
                            meta: {
                                sex: "Female",
                                entityTypeCd: "IND",
                                birthDt: "1972-09-01"
                            },
                            names: [
                                {
                                    standardFullName: "Shunburn Schlapper",
                                    firstName: "Shunburn",
                                    familyName: "Schlapper"
                                }
                            ]
                        }
                    ]
                },
                {
                    sourceSystemCode: "BAGS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            },
                            meta: {
                                sex: "Male",
                                entityTypeCd: "IND",
                                birthDt: "1974-09-01"
                            },
                            names: [
                                {
                                    standardFullName: "Sunburn Slapper",
                                    firstName: "Sunburn",
                                    familyName: "Slapper"
                                }
                            ]
                        }
                    ]
                }
            ]
        })

        const c = new CompositeMasterEntityModel();
        c.setEntities([me1, me2]);

        expect(c.sources.length).toBe(3);
        expect(c.masterEntityIds.length).toBe(2);
        expect(c.masterEntityIds[0]).toBe("1");
        expect(c.masterEntityIds[1]).toBe("2");
        expect(c.masterEntityId).toBe("1-2");
        expect(c.sources.length).toBe(3);
        expect(c.sourceCodes.length).toBe(2);
        expect(c.names.length).toBe(2);
        expect(c.names[0].standardFullName).toBe("Sunburn Slapper");
        expect(c.names[0].firstName).toBe("Sunburn");
        expect(c.names[0].familyName).toBe("Slapper");
        expect(c.names[1].standardFullName).toBe("Shunburn Schlapper");
        expect(c.names[1].firstName).toBe("Shunburn");
        expect(c.names[1].familyName).toBe("Schlapper");
        expect(c.datesOfBirth.length).toBe(2);
        expect(DateUtils.dateToDataText(c.datesOfBirth[0])).toBe("1974-09-01");
        expect(DateUtils.dateToDataText(c.datesOfBirth[1])).toBe("1972-09-01");
        expect(c.genders.length).toBe(2);
        expect(c.genders[0]).toBe("Male");
        expect(c.genders[1]).toBe("Female");
    });
});