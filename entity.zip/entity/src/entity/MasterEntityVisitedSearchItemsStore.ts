import MasterEntityVisitedSearchItemsModel from './MasterEntityVisitedSearchItemsModel';

const MasterEntityVisitedSearchItemsStore = new MasterEntityVisitedSearchItemsModel();

export { MasterEntityVisitedSearchItemsStore as default, MasterEntityVisitedSearchItemsStore }