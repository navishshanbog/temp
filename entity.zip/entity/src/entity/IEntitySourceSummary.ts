interface IEntitySourceSummary {
    sourceSystemCode?: string;
    count?: number;
}

export { IEntitySourceSummary }