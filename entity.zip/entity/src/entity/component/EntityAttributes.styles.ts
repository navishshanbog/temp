import { IStyle, ITheme, getTheme, concatStyleSets, FontSizes } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface IEntityAttributesStyles {
    root?: IStyle;
    attribute?: IStyle;
    attributeValue?: IStyle;
}

const defaultStyles = (theme : ITheme) : IEntityAttributesStyles => {
    return {
        root: {
            display: "flex",
            alignItems: "center",
            flexWrap: "wrap",
            fontSize: FontSizes.small,
            color: theme.palette.neutralPrimary
        },
        attribute: {
            padding: "1px 2px"
        },
        attributeValue: {
            display: "flex",
            alignItems: "center",
            flexWrap: "wrap",
            wordWrap: "break-word",
            overflowWrap: "break-word"
        }
    }
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles?: IEntityAttributesStyles) : IEntityAttributesStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export { IEntityAttributesStyles, getStyles, defaultStyles, Defaults }