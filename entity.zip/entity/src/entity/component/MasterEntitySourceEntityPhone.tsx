import * as React from "react";
import IMasterEntitySourceEntityPhone from "../IMasterEntitySourceEntityPhone";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { SearchableValue } from "@twii/common/lib/search/component/SearchableValue";

interface IMasterEntitySourceEntityPhoneProps {
    phone?: IMasterEntitySourceEntityPhone;
    onSearch?: (value : ISearchField) => void;
    className?: string;
}

class MasterEntitySourceEntityPhone extends React.Component<IMasterEntitySourceEntityPhoneProps, any> {
    render() {
        const searchString = this.props.phone.phoneNumber;
        return <SearchableValue className={this.props.className} name="phone" searchString={searchString} onClick={this.props.onSearch} />;
    }
}

export { MasterEntitySourceEntityPhone as default, MasterEntitySourceEntityPhone, IMasterEntitySourceEntityPhoneProps };