import { EntityAppBase } from "../../common/component/EntityAppBase";

class EntitySourceAppBase extends EntityAppBase {
    get entityId() {
        return this.props.match.params.entityId;
    }
    get sourceSystemCode() {
        return this.props.match.params.sourceSystemCode;
    }
}

export { EntitySourceAppBase }