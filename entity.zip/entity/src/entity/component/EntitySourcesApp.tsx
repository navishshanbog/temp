import * as React from "react";
import { MasterEntityContainer } from "./MasterEntityContainer";
import { MasterEntitySourceDashboard } from "./MasterEntitySourceDashboard";
import { findByEntityId } from "../MasterEntityFinder";
import { EntityAppView } from "../../common/component/EntityAppView";
import { EntityAppBase } from "../../common/component/EntityAppBase";

class EntitySourcesApp extends EntityAppBase {
    get entityId() {
        return this.props.match.params.entityId;
    }
    get selectSourceSystem() {
        return this.props.match.params.selectSourceSystem;
    }
    componentWillMount() {
        this.host.setTitle("Entity Sources");
    }
    private _onRenderEntity = (entity) => {
        return <MasterEntitySourceDashboard masterEntity={entity}
                                            selectSourceSystem={this.selectSourceSystem}
                                            host={this.host}
                                            onSearch={this.props.match.params.onSearch} />
    }
    render() {
        return (
            <EntityAppView host={this.host} userProfile={this.userProfile} hideSettings hideHelp hideProtectedMarker>
                <MasterEntityContainer entitySupplier={findByEntityId(this.entityId)}
                                       onRenderEntity={this._onRenderEntity} />
            </EntityAppView>
        );
    }
}

export { EntitySourcesApp as default, EntitySourcesApp }