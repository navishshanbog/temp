import * as React from "react";
import { IEntityAppViewProps, EntityAppView } from "../../common/component/EntityAppView";
import { MasterEntitySourceContainer, IMasterEntitySourceContainerProps } from "./MasterEntitySourceContainer";
import MasterEntityContainer from "./MasterEntityContainer";
import IMasterEntityModel from "../IMasterEntityModel";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { byCode } from "../MasterEntitySourceConfig";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import ISyncHandleModel from "@twii/common/lib/ISyncHandleModel";

interface IEntitySourceAppViewProps extends IEntityAppViewProps {
    entitySupplier: ISyncSupplier<IMasterEntityModel> | ISyncHandleModel<IMasterEntityModel>;
    sourceSystemCode?: string;
    onRenderSource?: (props : IMasterEntitySourceContainerProps) => React.ReactNode;
}

class EntitySourceAppView extends React.Component<IEntitySourceAppViewProps, any> {
    private _onRenderNoSource = () => {
        const cfg = byCode(this.props.sourceSystemCode);
        return <MessageBar messageBarType={MessageBarType.warning}>No {cfg ? cfg.title : this.props.sourceSystemCode} information available</MessageBar>;
    }
    private _onRenderEntity = (entity : IMasterEntityModel) => {
        return <MasterEntitySourceContainer masterEntity={entity}
                                            sourceSystemCode={this.props.sourceSystemCode}
                                            onRenderSource={this.props.onRenderSource}
                                            onRenderNoSource={this._onRenderNoSource} />;
    }
    private _onRenderNotLoaded = () => {
        const cfg = byCode(this.props.sourceSystemCode);
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the {cfg ? cfg.title : ""} summary</MessageBar>;
    }
    render() {
        return (
            <EntityAppView {...this.props}
                           hideSettings={!this.props.host.root}
                           hideHelp={!this.props.host.root} hideProtectedMarker>
                <MasterEntityContainer entitySupplier={this.props.entitySupplier}
                                       onRenderEntity={this._onRenderEntity}
                                       onRenderNotLoaded={this._onRenderNotLoaded} />
            </EntityAppView>
        );
    }
}

export { EntitySourceAppView, IEntitySourceAppViewProps }