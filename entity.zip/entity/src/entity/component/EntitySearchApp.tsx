import * as React from "react";
import IMasterEntitySearchRequest from "../IMasterEntitySearchRequest";
import IMasterEntitySearchRequestModel from "../IMasterEntitySearchRequestModel";
import MasterEntitySearchRequestContainer from "./MasterEntitySearchRequestContainer";
import MasterEntitySearchHistoryStore from "../MasterEntitySearchHistoryStore";
import MasterEntitySearchRequestSummary from "./MasterEntitySearchRequestSummary";
import IHistoryEntry from "@twii/common/lib/IHistoryEntry";
import { createHistoryMenuItem } from "@twii/common/lib/component/History";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { submitRequest, clearSearchResult } from "../MasterEntitySearchActions";
import { getSearchRequestModel } from "../MasterEntitySearchHelper";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { EntityAppView } from "../../common/component/EntityAppView";
import * as logoUrl from "../../common/component/Logo.png";

class EntitySearchApp extends React.Component<IAppProps, any> {
    get host() {
        return this.props.match.host;
    }
    get userProfile() {
        return this.props.match.userProfile;
    }
    get searchRequest() : IMasterEntitySearchRequestModel {
        return getSearchRequestModel(this.host);
    }
    private _onSubmitRequest = (request : IMasterEntitySearchRequest) => {
        submitRequest(this.host, request);
    }
    private _onClear = () => {
        clearSearchResult(this.host);
    }
    componentWillMount() {
        this.host.icon.url = logoUrl;
        this.host.title = "Entity Search";
    }
    private _onSelectHistoryItem = (item : IHistoryEntry<IMasterEntitySearchRequest>) => {
        this.searchRequest.setRequest(item.value);
        submitRequest(this.host, item.value);
    }
    private _onRenderHistoryItem = (item : IHistoryEntry<IMasterEntitySearchRequest>, idx : number) => {
        return <MasterEntitySearchRequestSummary request={item.value} />
    }
    render() {
        const items : IContextualMenuItem[] = [];
        items.push(
            createHistoryMenuItem({
                key: "recentSearches",
                name: "Recent Searches",
                history: MasterEntitySearchHistoryStore,
                onSelectItem: this._onSelectHistoryItem,
                onRenderItem: this._onRenderHistoryItem
            })
        );
        return (
            <EntityAppView host={this.host} commandBarProps={{ items: items }}>
                <MasterEntitySearchRequestContainer searchRequest={this.searchRequest} onSubmit={this._onSubmitRequest} onClear={this._onClear} />
            </EntityAppView>
        );
    }
}

export { EntitySearchApp as default, EntitySearchApp }