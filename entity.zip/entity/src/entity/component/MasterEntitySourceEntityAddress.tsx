import * as React from "react";
import IMasterEntitySourceEntityAddress from "../IMasterEntitySourceEntityAddress";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { SearchableValue } from "@twii/common/lib/search/component/SearchableValue";

interface IMasterEntitySourceEntityAddressProps {
    address?: IMasterEntitySourceEntityAddress;
    onSearch?: (value : ISearchField) => void;
    className?: string;
}

class MasterEntitySourceEntityAddress extends React.Component<IMasterEntitySourceEntityAddressProps, any> {
    render() {
        const searchString = this.props.address ? this.props.address.standardAddressValue : undefined;
        return <SearchableValue className={this.props.className} name="address" searchString={searchString} onClick={this.props.onSearch} />;
    }
}

export { MasterEntitySourceEntityAddress as default, MasterEntitySourceEntityAddress, IMasterEntitySourceEntityAddressProps };