import * as React from "react";
import { byCode } from "../MasterEntitySourceConfig";
import { EntityDashboardAppView } from "./EntityDashboardAppView";
import { PathsContext } from "../../PathsContext";
import { EntitySourceAppBase } from "./EntitySourceAppBase";

class EntitySourceDashboardApp extends EntitySourceAppBase {
    componentWillMount() {
        const sourceSystemEntry = byCode(this.sourceSystemCode);
        const title = sourceSystemEntry ? sourceSystemEntry.title : this.sourceSystemCode;
        this.host.title = title;
        this.host.icon = sourceSystemEntry.icon ? sourceSystemEntry.icon() : undefined;
    }
    protected _getDashboardConfig = () : any => {
        return {
            type: "dashboard",
            component: {
                type: "vsplit",
                topHeight: 60,
                minItemHeight: 0,
                top: {
                    component: {
                        type: "window",
                        path: PathsContext.value.entitySourceAttributes(this.entityId, this.sourceSystemCode),
                        params: {
                            onSearch: this.host.params.onSearch
                        }
                    }
                },
                bottom: {
                    component: {
                        type: "window",
                        path: PathsContext.value.entitySourceActivities(this.entityId, this.sourceSystemCode),
                        params: {
                            onSearch: this.host.params.onSearch
                        }
                    }
                }
            }
        };
    }
    render() {
        const dashboardConfig = this._getDashboardConfig();
        return <EntityDashboardAppView entityId={this.entityId}
                                       host={this.host}
                                       userProfile={this.userProfile}
                                       configSupplier={this._getDashboardConfig}
                                       hideSettings
                                       hideHelp 
                                       hideProtectedMarker/>
    }
}

export { EntitySourceDashboardApp as default, EntitySourceDashboardApp }