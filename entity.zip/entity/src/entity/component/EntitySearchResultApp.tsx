import * as React from "react";
import MasterEntitySearchResult from "./MasterEntitySearchResult";
import IMasterEntitySearchRequest from "../IMasterEntitySearchRequest";
import IMasterEntitySearchResultModel from "../IMasterEntitySearchResultModel";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import {
    openSearchResultItem,
    openSearchResultItems
} from "../MasterEntitySearchActions";
import { getSearchResultModel } from "../MasterEntitySearchHelper";
import { removeMeta } from "@twii/common/lib/RequestHelper";
import { EntityAppView } from "../../common/component/EntityAppView";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { createRefreshMenuItem } from "@twii/common/lib/component/Refresh";
import "./EntitySearchResultApp.scss";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import * as logoUrl from "../../common/component/Logo.png";

class EntitySearchResultApp extends EntityAppBase {
    get searchResult(): IMasterEntitySearchResultModel {
        return getSearchResultModel(this.host);
    }
    componentWillMount() {
        this.host.icon.url = logoUrl;
        this.host.title = "Entity Search Results";
        const request: IMasterEntitySearchRequest = removeMeta(this.host.params);
        if(request && Object.keys(request).length > 0) {
            const requestUrl = this.host.getUrl({ query: request });
            const currentRequestUrl = this.host.getUrl({ query: this.searchResult.request });
            if(requestUrl !== currentRequestUrl) {
                this.searchResult.search(request);
            }
        }
    }
    private _onItemSelected = (item: IMasterEntitySearchResultItem) => {
        openSearchResultItem(this.host, item);
    }
    private _onOpenItems = (items: IMasterEntitySearchResultItem[]) => {
        openSearchResultItems(this.host, items);
    }
    private _onClickRefresh = () => {
        this.searchResult.refresh();
    }
    render() {
        const items : IContextualMenuItem[] = [];
        const farItems : IContextualMenuItem[] = [];
        farItems.push(
            createRefreshMenuItem({
                sync: this.searchResult.sync,
                title: "Refresh Search Results",
                onClick: this._onClickRefresh
            })
        );
        return (
            <EntityAppView host={this.host} userProfile={this.userProfile}
                           commandBarProps={{ items: items, farItems: farItems }}
                           className="entity-search-result-app">
                <MasterEntitySearchResult searchResult={this.searchResult}
                        onItemSelected={this._onItemSelected}
                        onOpenItems={this._onOpenItems}
                        host={this.host} />
            </EntityAppView>
        );
    }
}

export { EntitySearchResultApp as default, EntitySearchResultApp }