import * as React from "react";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import { byCode, entries } from "../MasterEntitySourceConfig";
import { IMasterEntitySourceSummaryStyles, getStyles } from "./MasterEntitySourceSummary.styles";
import { getClassNames } from "./MasterEntitySourceSummary.classNames";
import { IEntitySourceSummary } from "../IEntitySourceSummary";
import { css } from "@uifabric/utilities";
import { compare } from "@twii/common/lib/util/Sort";


interface IMasterEntitySourceSummaryProps {
    masterEntity?: IMasterEntitySearchResultItem;
    masterEntitySummary?: IEntitySourceSummary[];
    selectedSourceSystemCode?: string;
    styles?: IMasterEntitySourceSummaryStyles;
    className?: string;
    onClickSource?: (sourceSystemCode : string) => void;
}

interface IMasterEntitySourceSummarySourceProps extends IMasterEntitySourceSummaryProps {
    sourceSystemCode: string;
    count: number;
}

class MasterEntitySourceSystemSummarySource extends React.Component<IMasterEntitySourceSummarySourceProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
        this.props.onClickSource(this.props.sourceSystemCode);
    }
    render() {
        const configEntry = byCode(this.props.sourceSystemCode);
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        const title = this.props.sourceSystemCode + ": " + this.props.count;
        return (
            <div role={this.props.onClickSource ? "button" : undefined}
                 onClick={this.props.onClickSource ? this._onClick : undefined}
                 className={css(classNames.source, { clickable: this.props.onClickSource ? true : false, selected: this.props.sourceSystemCode === this.props.selectedSourceSystemCode })}
                 aria-label={title}
                 title={title}>
                {/* Folks don't want this apparently
                <div className={classNames.sourceCountContainer}>
                    <div className={classNames.sourceCount}>
                        {this.props.count}
                    </div>
                </div>
                */}
                {configEntry ? configEntry.icon() : this.props.sourceSystemCode}
            </div>
        );
    }
}

class MasterEntitySourceSummary extends React.Component<IMasterEntitySourceSummaryProps, any> {
    render() {
        let sourceSummary = this.props.masterEntitySummary;
        if(!sourceSummary && this.props.masterEntity) {
            sourceSummary = [];
            entries.forEach(e => {
                const count = this.props.masterEntity[e.key];
                if(!isNaN(count) && count > 0) {
                    sourceSummary.push({
                        sourceSystemCode: e.key,
                        count: count
                    })
                }
            });
        }
        if(sourceSummary && sourceSummary.length > 0) {
            // sort
            sourceSummary.sort((a, b) => {
                if(this.props.selectedSourceSystemCode) {
                    if(this.props.selectedSourceSystemCode === a.sourceSystemCode) {
                        return -1;
                    } else if(this.props.selectedSourceSystemCode === b.sourceSystemCode) {
                        return  1;
                    }
                }
                return compare(a.sourceSystemCode, b.sourceSystemCode);
            });
            const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
            const sourceViews = sourceSummary.map(s => {
                return <MasterEntitySourceSystemSummarySource key={s.sourceSystemCode} {...this.props} sourceSystemCode={s.sourceSystemCode} count={s.count} />
            });
            return <div className={classNames.root}>{sourceViews}</div>;
        }
        return <div>No Source information available</div>;
    }
}

export { MasterEntitySourceSummary as default, MasterEntitySourceSummary, IMasterEntitySourceSummaryProps }