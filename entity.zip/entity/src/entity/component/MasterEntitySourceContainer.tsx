import * as React from "react";
import { observer } from "mobx-react";
import IMasterEntityModel from "../IMasterEntityModel";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";

interface IMasterEntitySourceContainerProps {
    masterEntity: IMasterEntityModel;
    sourceSystemCode: string;
    className?: string;
    onRenderSource?: (props : IMasterEntitySourceContainerProps) => React.ReactNode;
    onRenderNoSource?: (props : IMasterEntitySourceContainerProps) => React.ReactNode;
}

@observer
class MasterEntitySourceContainer extends React.Component<IMasterEntitySourceContainerProps, any> {
    render() {
        const sources = this.props.masterEntity.sources;
        let content;
        if(sources && sources.length > 0) {
            content = this.props.onRenderSource ? this.props.onRenderSource(this.props) : null;
        } else {
            content = this.props.onRenderNoSource ?
                        this.props.onRenderNoSource(this.props) :
                        <MessageBar messageBarType={MessageBarType.warning}>No {this.props.sourceSystemCode} information available</MessageBar>;
        }
        return content;
    }
}

export {
    IMasterEntitySourceContainerProps,
    MasterEntitySourceContainer as default,
    MasterEntitySourceContainer
}