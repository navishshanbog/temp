import * as React from "react";
import IMasterEntitySourceEntityEmail from "../IMasterEntitySourceEntityEmail";
import { SearchableValue } from "@twii/common/lib/search/component/SearchableValue";
import { ISearchField } from "@twii/common/lib/search/ISearchField";

interface IMasterEntitySourceEntityEmailProps {
    email?: IMasterEntitySourceEntityEmail;
    onSearch?: (value : ISearchField) => void;
    className?: string;
}

class MasterEntitySourceEntityEmail extends React.Component<IMasterEntitySourceEntityEmailProps, any> {
    render() {
        const searchString = this.props.email ? this.props.email.emailValue : undefined;
        return <SearchableValue className={this.props.className} name="email" searchString={searchString} onClick={this.props.onSearch} />;
    }
}

export { MasterEntitySourceEntityEmail as default, MasterEntitySourceEntityEmail, IMasterEntitySourceEntityEmailProps };