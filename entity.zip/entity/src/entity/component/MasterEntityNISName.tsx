import * as React from "react";
import { toNISFormat } from "../EntityNameUtils";
import IMasterEntityModel from "../IMasterEntityModel";

interface IMasterEntityNISNameProps {
    masterEntity: IMasterEntityModel;
    titleSetter?: (title : string) => void;
}

class MasterEntityNISName extends React.Component<IMasterEntityNISNameProps, any> {
    componentWillMount() {
        if(this.props.titleSetter) {
            this.props.titleSetter(toNISFormat(this.props.masterEntity));
        }
    }
    render() {
        return (
            <div className="master-entity-nis-name">
                {toNISFormat(this.props.masterEntity)}
            </div>
        );
    }
}

export { MasterEntityNISName as default, MasterEntityNISName, IMasterEntityNISNameProps };
