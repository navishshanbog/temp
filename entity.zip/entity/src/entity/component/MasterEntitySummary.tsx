import * as React from "react";
import { observer } from "mobx-react";
import { IMasterEntityModel } from "../IMasterEntityModel";
import { ICompositeMasterEntityModel } from "../ICompositeMasterEntityModel";
import MasterEntityNISName from "./MasterEntityNISName";
import MasterEntitySourceEntityName from "./MasterEntitySourceEntityName";
import EntityAttributes from "./EntityAttributes";
import EntityPhotos from "../../entityphotos/component/EntityPhotos";
import { EntityOwner } from "./EntityOwner";
import "./MasterEntitySummary.scss";
import { ISearchField } from "@twii/common/lib/search/ISearchField";

interface IMasterEntityProps {
    masterEntity: IMasterEntityModel;
    onSearch?: (value : ISearchField) => void;
    titleSetter?: (title : string) => void;
}

interface IMasterEntityFeatureProps extends IMasterEntityProps {
    onRenderIcon?: (props: IMasterEntityProps) => React.ReactNode;
}

class MasterEntityPersonTitle extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <div className="master-entity-person-title">
                <MasterEntityNISName masterEntity={this.props.masterEntity} titleSetter={this.props.titleSetter} />
            </div>
        );
    }
}

class MasterEntityOrgTitle extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <div className="master-entity-org-title">
                <MasterEntitySourceEntityName name={this.props.masterEntity.name} titleSetter={this.props.titleSetter} />
            </div>
        );
    }
}

@observer
class MasterEntityTitle extends React.Component<IMasterEntityFeatureProps, any> {
    render() {
        let title;
        if (this.props.masterEntity.isPerson) {
            title = <MasterEntityPersonTitle masterEntity={this.props.masterEntity} titleSetter={this.props.titleSetter} />;
        } else if (this.props.masterEntity.isOrganisation) {
            title = <MasterEntityOrgTitle masterEntity={this.props.masterEntity} titleSetter={this.props.titleSetter} />;
        } else {
            title = <MasterEntitySourceEntityName name={this.props.masterEntity.name} titleSetter={this.props.titleSetter} />;
        }
        let icon;
        if (this.props.onRenderIcon) {
            icon = (
                <div className="master-entity-title-icon">
                    {this.props.onRenderIcon(this.props)}
                </div>
            );
        }
        return (
            <div className="master-entity-title">
                {icon}
                {title}
            </div>
        );
    }
}

class MasterEntitySubtitle extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <div className="master-entity-subtitle">
                <EntityAttributes entity={this.props.masterEntity} onSearch={this.props.onSearch} />
            </div>
        );
    }
}

class MasterEntityPreview extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <div className="master-entity-preview">
                <EntityPhotos masterEntity={this.props.masterEntity} />
            </div>
        );
    }
}

class MasterEntitySummary extends React.Component<IMasterEntityFeatureProps, any> {
    render() {
        return (
            <div className="master-entity-summary">
                <MasterEntityTitle {...this.props} />
                <MasterEntitySubtitle {...this.props} />
            </div>
        );
    }
}

class MasterEntitySummaryWrapper extends React.Component<IMasterEntityFeatureProps, any> {
    render() {
        return (
            <div className="master-entity-summary-wrapper ms-Grid">
                <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-md12 ms-lg11">
                        <MasterEntitySummary {...this.props} />
                    </div>
                    <div className="ms-Grid-col ms-md12 ms-lg1">
                        <MasterEntityPreview masterEntity={this.props.masterEntity} />
                    </div>
                </div>
            </div>
        );
    }
}

const appendTitleSetter = (titleSetter : (title : string) => void) => {
    let compositeTitle = "";
    return (title : string) => {
        if(title) {
            if(!compositeTitle) {
                compositeTitle = title;
            } else {
                compositeTitle += " | " + title;
            }
            titleSetter(compositeTitle); 
        }
    };
};

class CombinedMasterEntitySummary extends React.Component<IMasterEntityProps, any> {
    private _onRenderIcon = (props: IMasterEntityProps) => {
        return <EntityOwner compositeEntity={this.props.masterEntity as ICompositeMasterEntityModel} entity={props.masterEntity} />;
    }
    render() {
        const titleSetter = this.props.titleSetter ? appendTitleSetter(this.props.titleSetter) : undefined;
        const ce: ICompositeMasterEntityModel = this.props.masterEntity as ICompositeMasterEntityModel;
        const content = ce.entities.map(e => <MasterEntitySummaryWrapper {...this.props} masterEntity={e} onRenderIcon={this._onRenderIcon} titleSetter={titleSetter} />);
        return (
            <div className="combined-master-entity-summary">
                {content}
            </div>
        );
    }
}

class MasterEntitySummaryContainer extends React.Component<IMasterEntityProps, any> {
    render() {
        return this.props.masterEntity.isComposite ?
            <CombinedMasterEntitySummary {...this.props} /> :
            <MasterEntitySummaryWrapper {...this.props} />;
    }
}

export {
    MasterEntitySummary as default,
    MasterEntitySummary,
    IMasterEntityProps,
    MasterEntityPersonTitle,
    MasterEntityOrgTitle,
    MasterEntitySummaryContainer,
    IMasterEntityFeatureProps
};