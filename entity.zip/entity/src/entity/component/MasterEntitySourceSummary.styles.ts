import { IStyle, ITheme, getTheme, concatStyleSets, FontSizes } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface IMasterEntitySourceSummaryStyles {
    root?: IStyle;
    source?: IStyle;
    sourceCountContainer?: IStyle;
    sourceCount?: IStyle;
}

const defaultStyles = (theme : ITheme) : IMasterEntitySourceSummaryStyles => {
    return  {
        root: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            selectors: {
                "$source+$source": {
                    marginLeft: 4
                }
            }
        },
        source: {
            position: "relative",
            color: theme.palette.orange,
            fontSize: FontSizes.icon,
            width: 24,
            minWidth: 24,
            height: 24,
            minHeight: 24,
            borderRadius: "100%",
            border: `1px solid ${theme.palette.neutralLight}`,
            backgroundColor: theme.palette.white,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            selectors: {
                "&.selected": {
                    backgroundColor: theme.palette.orange,
                    color: theme.palette.white,
                    border: `1px solid ${theme.palette.orange}`
                },
                "&.clickable": {
                    cursor: "pointer",
                    selectors: {
                        "&:hover": {
                            color: theme.palette.orange,
                            backgroundColor: theme.palette.neutralLight,
                        }
                    }
                }
            }
        },
        sourceCountContainer: {
            position: "absolute",
            top: -4,
            left: -4
        },
        sourceCount: {
            borderRadius: 4,
            padding: 2,
            minWidth: 8,
            lineHeight: 8,
            fontSize: 8,
            color: theme.palette.themeDark,
            backgroundColor: theme.palette.neutralLight,
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        }
    }
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles?: IMasterEntitySourceSummaryStyles) : IMasterEntitySourceSummaryStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export { IMasterEntitySourceSummaryStyles, getStyles, defaultStyles, Defaults }