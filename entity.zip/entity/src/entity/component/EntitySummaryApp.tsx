import * as React from "react";
import MasterEntityContainer from "./MasterEntityContainer";
import { MasterEntitySummaryContainer } from "./MasterEntitySummary";
import { EntityAppView } from "../../common/component/EntityAppView";
import { findByEntityId } from "../MasterEntityFinder";
import IMasterEntityModel from "../IMasterEntityModel";
import { EntityAppBase } from "../../common/component/EntityAppBase";

class EntitySummaryApp extends EntityAppBase {
    get entityId() {
        return this.props.match.params.entityId;
    }
    componentWillMount() {
        this.host.setTitle("Entity Summary");
    }
    private _onRenderEntity = (entity : IMasterEntityModel) => {
        return <MasterEntitySummaryContainer masterEntity={entity} onSearch={this.host.params.onSearch} titleSetter={this.props.match.params.titleSetter} />;
    }
    render() {
        return (
            <EntityAppView host={this.host} userProfile={this.userProfile} hideSettings hideHelp hideProtectedMarker>
                <MasterEntityContainer entitySupplier={findByEntityId(this.entityId)}
                                       onRenderEntity={this._onRenderEntity} />
            </EntityAppView>
        );
    }
}

export { EntitySummaryApp as default, EntitySummaryApp }