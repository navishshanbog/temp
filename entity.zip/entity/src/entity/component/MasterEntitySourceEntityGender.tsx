import * as React from "react";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { SearchableValue } from "@twii/common/lib/search/component/SearchableValue";
import * as DateUtils from "@twii/common/lib/DateUtils";
import GenderRefList from "../../ref/GenderRefList";

interface IMasterEntitySourceEntityGenderProps {
    genderCd?: string;
    onSearch?: (value : ISearchField) => void;
    className?: string;
}

class MasterEntitySourceEntityGender extends React.Component<IMasterEntitySourceEntityGenderProps, any> {
    render() {
        const searchString = this.props.genderCd ? GenderRefList.getItemByKey(this.props.genderCd, { key: this.props.genderCd, text: this.props.genderCd }).text : undefined;
        return <SearchableValue className={this.props.className} name="gender" searchString={searchString} onClick={this.props.onSearch} />;
    }
}

export { MasterEntitySourceEntityGender as default, MasterEntitySourceEntityGender, IMasterEntitySourceEntityGenderProps };