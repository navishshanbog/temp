import * as React from "react";
import IEntityModel from "../IEntityModel";
import MasterEntitySourceEntityName from "./MasterEntitySourceEntityName";
import MasterEntitySourceEntityAddress from "./MasterEntitySourceEntityAddress";
import MasterEntitySourceEntityPhone from "./MasterEntitySourceEntityPhone";
import MasterEntitySourceEntityCredential from "./MasterEntitySourceEntityCredential";
import { DefinitionList } from "@twii/common/lib/component/DefinitionList";
import { css } from "office-ui-fabric-react/lib/Utilities";
import MasterEntitySourceEntityEmail from "./MasterEntitySourceEntityEmail";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import MasterEntitySourceEntityDateOfBirth from "./MasterEntitySourceEntityDateOfBirth";
import { getClassNames } from "./EntityAttributes.classNames";
import { getStyles, IEntityAttributesStyles } from "./EntityAttributes.styles";
import MasterEntitySourceEntityGender from "./MasterEntitySourceEntityGender";

enum EntityAttributesType {
    primary,
    secondary
}

interface IEntityAttributesProps {
    entity: IEntityModel;
    type?: EntityAttributesType;
    position?: number;
    onSearch?: (value : ISearchField) => void;
    styles?: IEntityAttributesStyles;
    className?: string;
}

const DefaultEntityAttributesProps: IEntityAttributesProps = {
    entity: null,
    type: EntityAttributesType.primary,
    position: null,
    onSearch: null
}

class EntityAttributes extends React.Component<IEntityAttributesProps, any> {
    public static defaultProps = DefaultEntityAttributesProps;
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        let positionDescription;
        let names;
        let addresses;
        let phones;
        let credentials;
        let dob;
        let gender;
        let emails;

        if (this.props.position) {
            positionDescription = <DefinitionList>({this.props.position})</DefinitionList>;
        }

        if (this.props.entity && this.props.entity.names && this.props.entity.names.length > 0) {
            const nameItems = this.props.entity.names.map(name => {
                return <MasterEntitySourceEntityName className={classNames.attributeValue} key={name.sourceSystemCd + name.sourceEntityNameId} name={name} onSearch={this.props.onSearch} />;
            });
            names = <DefinitionList className={classNames.attribute} name="Names">{nameItems}</DefinitionList>;
        }
        if (this.props.entity && this.props.entity.addresses && this.props.entity.addresses.length > 0) {
            const addressItems = this.props.entity.addresses.map(address => {
                return <MasterEntitySourceEntityAddress className={classNames.attributeValue} key={address.sourceSystemCd + address.sourceEntityAddressId} address={address} onSearch={this.props.onSearch} />;
            });
            addresses = <DefinitionList className={classNames.attribute} name="Addresses">{addressItems}</DefinitionList>;
        }
        if (this.props.entity && this.props.entity.phones && this.props.entity.phones.length > 0) {
            const phoneItems = this.props.entity.phones.map(phone => {
                return <MasterEntitySourceEntityPhone className={classNames.attributeValue} key={phone.sourceSystemCd + phone.sourceEntityPhoneId} phone={phone} onSearch={this.props.onSearch} />;
            });
            phones = <DefinitionList className={classNames.attribute} name="Phones">{phoneItems}</DefinitionList>;
        }
        if (this.props.entity && this.props.entity.emails && this.props.entity.emails.length > 0) {
            const emailItems = this.props.entity.emails.map(email => {
                return <MasterEntitySourceEntityEmail className={classNames.attributeValue} key={email.sourceSystemCd + email.sourceEntityPhoneId} email={email} onSearch={this.props.onSearch} />;
            });
            emails = <DefinitionList className={classNames.attribute} name="Emails">{emailItems}</DefinitionList>;
        }
        if (this.props.entity && this.props.entity.credentials && this.props.entity.credentials.length > 0) {
            const credentialItems = this.props.entity.credentials.map(credential => {
                return <MasterEntitySourceEntityCredential
                className={classNames.attributeValue}
                    key={credential.sourceSystemCd + credential.sourceEntityCredentialId}
                    credential={credential}
                    onSearch={this.props.onSearch} />
            });
            credentials = <DefinitionList className={classNames.attribute} name="Credentials">{credentialItems}</DefinitionList>;
        }
        if (this.props.entity && this.props.entity.datesOfBirth && this.props.entity.datesOfBirth.length > 0) {
            const dobItems = this.props.entity.datesOfBirth.map(dob => {
                return <MasterEntitySourceEntityDateOfBirth className={classNames.attributeValue} key={dob.getTime()} dob={dob} onSearch={this.props.onSearch} />
            });
            dob = <DefinitionList className={classNames.attribute} name="Date of Birth">{dobItems}</DefinitionList>
        }
        if (this.props.entity && this.props.entity.genders && this.props.entity.genders.length > 0) {
            const genderItems = this.props.entity.genders.map(gender => {
                return <MasterEntitySourceEntityGender className={classNames.attributeValue} key={gender} genderCd={gender} onSearch={this.props.onSearch} />
            });
            gender = <DefinitionList className={classNames.attribute} name="Gender">{genderItems}</DefinitionList>;
        }
        if (names || dob || gender || addresses || phones || credentials) {
            return (
                <div className={css(classNames.root, { "primary": this.props.type === EntityAttributesType.primary, "secondary": this.props.type === EntityAttributesType.secondary })}>
                    {positionDescription}
                    {names}
                    {dob}
                    {gender}
                    {addresses}
                    {phones}
                    {emails}
                    {credentials}
                </div>
            );
        }
        return null;
    }
}

export { EntityAttributes as default, EntityAttributes, IEntityAttributesProps, EntityAttributesType };