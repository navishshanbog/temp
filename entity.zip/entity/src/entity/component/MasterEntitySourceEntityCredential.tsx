import * as React from "react";
import IMasterEntitySourceEntityCredential from "../IMasterEntitySourceEntityCredential";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { SearchableValue } from "@twii/common/lib/search/component/SearchableValue";

interface IMasterEntityCredentialProps {
    credential: IMasterEntitySourceEntityCredential;
    onSearch?: (value : ISearchField) => void;
    className?: string;
}

class MasterEntitySourceEntityCredential extends React.Component<IMasterEntityCredentialProps, any> {
    render() {
        if(this.props.credential) {
            const searchString = this.props.credential.credentialValue;
            return (
                <SearchableValue className={this.props.className} name={this.props.credential.credentialTypeCd} searchString={searchString} onClick={this.props.onSearch}>
                    {this.props.credential.credentialValue} {`(${this.props.credential.credentialTypeCd})`}
                </SearchableValue>
            );
        }
        return null;
    }
}

export { MasterEntitySourceEntityCredential as default, MasterEntitySourceEntityCredential, IMasterEntityCredentialProps };