import * as React from "react";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { SearchableValue } from "@twii/common/lib/search/component/SearchableValue";
import * as DateUtils from "@twii/common/lib/DateUtils";

interface IMasterEntitySourceEntityDateOfBirthProps {
    dob?: Date;
    onSearch?: (value : ISearchField) => void;
    className?: string;
}

class MasterEntitySourceEntityDateOfBirth extends React.Component<IMasterEntitySourceEntityDateOfBirthProps, any> {
    render() {
        const searchString = this.props.dob ? DateUtils.dateToOutputText(this.props.dob) : undefined;
        return <SearchableValue className={this.props.className} name="dob" searchString={searchString} onClick={this.props.onSearch} />;
    }
}

export { MasterEntitySourceEntityDateOfBirth as default, MasterEntitySourceEntityDateOfBirth, IMasterEntitySourceEntityDateOfBirthProps };