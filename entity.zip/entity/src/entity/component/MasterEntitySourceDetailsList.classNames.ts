import { memoizeFunction } from "@uifabric/utilities";
import { IMasterEntitySourceDetailsListStyles } from "./MasterEntitySourceDetailsList.styles";
import { mergeStyleSets } from "@uifabric/styling";

interface IMasterEntitySourceDetailsListClassNames {
    root?: string;
}

const getClassNames = memoizeFunction((styles : IMasterEntitySourceDetailsListStyles, className?: string) : IMasterEntitySourceDetailsListClassNames => {
    return mergeStyleSets({
        root: ["master-entity-source-details-list", className, styles.root]
    });
});

export { IMasterEntitySourceDetailsListClassNames, getClassNames }