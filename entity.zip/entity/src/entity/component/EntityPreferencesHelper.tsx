import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { ISyncHandleModel } from "@twii/common/lib/ISyncHandleModel";
import { IEntityPreferences } from "../IEntityPrefences";


const onClickLinksPref = (e, item) => {
    const prefsHandle = item.prefsHandle;
    const value = prefsHandle.value;
    if(value) {
        const newValue = { isLinkOpenInANewWindow: !value.isLinkOpenInANewWindow };
        prefsHandle.setValue(newValue);
    }
};

const createEntityPreferencesMenuItem = (prefsHandle : ISyncHandleModel<IEntityPreferences>) : IContextualMenuItem => {
    const prefs = prefsHandle.value;
    const menuItems : IContextualMenuItem[] = [];
    if(prefs) {
        menuItems.push({
            key: "linksOpenInNewWindow",
            name: "Open links in new widget",
            canCheck: true,
            isChecked: prefs.isLinkOpenInANewWindow,
            prefsHandle: prefsHandle,
            onClick: onClickLinksPref
        }
    );
    }
    return {
        key: "entityPreferences",
        title: "Entity Preferences",
        iconProps: {
            iconName: "Settings"
        },
        disabled: prefsHandle.sync.syncing,
        subMenuProps: {
            items: menuItems
        }
    };
};

export { createEntityPreferencesMenuItem }