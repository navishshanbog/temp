import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { Output as DateOutputFormats } from "@twii/common/lib/DateFormats";
import * as moment from "moment";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import MasterEntitySearchResultSummary from "./MasterEntitySearchResultSummary";
import * as ColumnSortHelper from "@twii/common/lib/component/ColumnSortHelper";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import * as ActivityFilterMenuHelper from "@twii/common/lib/component/ActivityFilterMenuHelper";
import IMasterEntitySearchResultModel from "../IMasterEntitySearchResultModel";
import MasterEntitySearchResultDetailsList from "./MasterEntitySearchResultDetailsList";
import MasterEntitySearchResultItemColumns from "./MasterEntitySearchResultItemColumns";
import { saveAs } from "file-saver";
import IAppHost from "@twii/common/lib/IAppHost";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";

interface IMasterEntitySearchResultProps {
    host: IAppHost;
    searchResult: IMasterEntitySearchResultModel;
    onItemSelected?: (item: IMasterEntitySearchResultItem) => void;
    onOpenItems?: (items: IMasterEntitySearchResultItem[]) => void;
}

@observer
class MasterEntitySearchResultCommandBar extends React.Component<IMasterEntitySearchResultProps, any> {
    private _onDownloadCSVClick = () => {
        const blob = new Blob([ColumnTextHelper.getCSV(this.props.searchResult.items, MasterEntitySearchResultItemColumns)], { type: "text/csv" });
        saveAs(blob, "MasteredEntitySearchResult-" + moment(this.props.searchResult.sync.endDate).format(DateOutputFormats.filename) + ".csv");
    }
    private _onOpenClick = () => {
        const selectedItems = this.props.searchResult.selection.selectedItems;
        const visitedItems = this.props.searchResult.visitedItems.selectedItems;
        const itemsToSetVisited = (visitedItems && visitedItems.length > 0) ?
            visitedItems.concat(selectedItems.filter(selectedItem => visitedItems.find(visitedItem => visitedItem.mstrEntyId !== selectedItem.mstrEntyId))) :
            selectedItems

        this.props.onOpenItems(this.props.searchResult.selection.selectedItems);
        this.props.searchResult.visitedItems.setSelectedItems(itemsToSetVisited);
    }

    render() {
        const menuItems: IContextualMenuItem[] = [
            ActivityFilterMenuHelper.createActivityListFilterItem({
                list: this.props.searchResult,
                itemsTitle: "Search Results",
                viewOptions: {
                    fromFilterHidden: true,
                    toFilterHidden: true
                }
            })
        ];
        const farMenuItems: IContextualMenuItem[] = [];
        if (this.props.onOpenItems) {
            const selection = this.props.searchResult.selection;
            const openItem: IContextualMenuItem = {
                key: "open",
                name: `Combine${selection.selectionCount > 1 ? " " + selection.selectionCount + " " : " "}Entities`,
                iconProps: { iconName: "MergeDuplicate" },
                onClick: this._onOpenClick,
                disabled: selection.selectionCount < 2
            };
            farMenuItems.push(openItem);
        }
        const sortItem = ColumnSortHelper.createSortItemFromModel({
            columns: MasterEntitySearchResultItemColumns,
            sort: this.props.searchResult.sort
        });
        farMenuItems.push(sortItem);
        farMenuItems.push(
            {
                key: "download",
                name: "Download as CSV",
                iconProps: { iconName: "Download" },
                ariaLabel: "Download as CSV",
                onClick: this._onDownloadCSVClick
            }
        );

        return (
            <CommandBar className="master-entity-search-result-command-bar" items={menuItems} farItems={farMenuItems} />
        );
    }
}

@observer
class MasterEntitySearchResultList extends React.Component<IMasterEntitySearchResultProps, any> {
    private _onRenderMenu = () => {
        return <MasterEntitySearchResultCommandBar {...this.props} />;
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <MasterEntitySearchResultDetailsList searchResult={this.props.searchResult} onItemSelected={this.props.onItemSelected} />
            </AppView>
        );
    }
}

class MasterEntitySearchResultListContainer extends React.Component<IMasterEntitySearchResultProps, any> {
    private _onRenderDone = () => {
        return <MasterEntitySearchResultList {...this.props} />;
    }
    render() {
        return <Sync sync={this.props.searchResult.sync} onRenderDone={this._onRenderDone} syncLabel="Searching Entities..." />;
    }
}

@observer
class MasterEntitySearchResultContainer extends React.Component<IMasterEntitySearchResultProps, any> {
    private _onRenderMenu = () => {
        return <MasterEntitySearchResultSummary searchResult={this.props.searchResult} />;
    }
    render() {
        let content;
        if (this.props.searchResult.request) {
            content = (
                <AppView onRenderMenu={this._onRenderMenu}>
                    <MasterEntitySearchResultListContainer {...this.props} />
                </AppView>
            );
        } else {
            content = <MessageBar messageBarType={MessageBarType.warning}>You'll have to perform a search to see anything here</MessageBar>;
        }

        return (
            <div className="master-entity-search-result-container">
                {content}
            </div>
        );
    }
}

export { MasterEntitySearchResultContainer as default, MasterEntitySearchResultContainer, IMasterEntitySearchResultProps };