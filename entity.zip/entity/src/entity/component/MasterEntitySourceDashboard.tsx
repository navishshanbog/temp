import * as React from "react";
import { observer } from "mobx-react";
import IMasterEntityModel from "../IMasterEntityModel";
import { DashboardStorageServiceContext } from "../../common/DashboardStorageServiceContext";
import { byCode, IMasterEntitySourceConfigEntry, removePrefix } from "../MasterEntitySourceConfig";
import { DashboardContainer } from "@twii/dashboard/lib/component/Dashboard";
import { Dashboard } from "@twii/dashboard/lib/model/Dashboard";
import { Stack } from "@twii/dashboard/lib/model/Stack";
import { Window } from "@twii/dashboard/lib/model/Window";
import { IWindow } from "@twii/dashboard/lib/model/IWindow";
import { ComponentFactory } from "@twii/dashboard/lib/model/ComponentFactory";
import { IMasterEntitySearchRequest } from "../IMasterEntitySearchRequest";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { compare } from "@twii/common/lib/SortUtils";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { createActivityFilterItem, defaultRenderContent } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { createDashboardMenu, createDashboardLayoutActions } from "@twii/dashboard/lib/component/DashboardLayoutMenuHelper";
import { IStack } from "@twii/dashboard/lib/model/IStack";
import { AppView } from "@twii/common/lib/component/AppView";
import { IWindowManager } from "@twii/dashboard/lib/model/IWindowManager";
import { RouterContext } from "@twii/common/lib/RouterContext";
import { PathsContext } from "../../PathsContext";

// these are stack style overrides
const storageKey = "entity-source-dashboard";

const createWindowConfigFromEntry = (props : IMasterEntitySourceDashboardProps, entry : IMasterEntitySourceConfigEntry) => {
    return {
        type: "window",
        title: entry.title,
        path: PathsContext.value.entitySource(props.masterEntity.masterEntityId, entry.key),
        query: {
            sourceSystemCode: entry.key
        },
        params: {
            onSearch: props.onSearch
        }
    };
};

const getDefaultDashboardConfig = (props : IMasterEntitySourceDashboardProps) => {
    let windows : any[] = [];
    const entries : IMasterEntitySourceConfigEntry[] = [];
    props.masterEntity.sourceCodes.forEach(sourceSystemCode => {
        const e = byCode(sourceSystemCode);
        if(e) {
            entries.push(e);
        }
    });
    entries.sort((l, r) => compare(l.title, r.title));
    entries.forEach(e => {
        windows.push(createWindowConfigFromEntry(props, e));
    });
    const stack = {
        type: "stack",
        windows: windows,
        activeIndex: 0
    };

    if(props.selectSourceSystem) {
        const e = byCode(props.selectSourceSystem);
        const sourceSystemCode = e ? e.key : props.selectSourceSystem;
        const idx = stack.windows.findIndex(w => {
            const we = byCode(w.query.sourceSystemCode);
            return we && we.key === sourceSystemCode ? true : false;
        });
        if(idx >= 0) {
            stack.activeIndex = idx;
        }
        
    }
    return {
        type: "dashboard",
        margin: 0,
        component: stack,
        closeDisabled: true
    };
};

const getUpdatedDashboardConfig = (props : IMasterEntitySourceDashboardProps, existingConfig : any) : any => {
    // Here is the BS for loading the state of the source systems for an entity
    const sourceSystemCodes = props.masterEntity.sourceCodes;
    // create a temporary dashboard for doing our source system reconciliation based
    // on current positions
    const rdb = new Dashboard();
    rdb.router = RouterContext.value;
    rdb.componentFactory = ComponentFactory;
    rdb.setConfig(existingConfig);
    
    const windows : IWindow[] = rdb.findAll(c => {
        return c.type === "window";
    }) as IWindow[];
    
    const keepWindows = windows.filter(w => sourceSystemCodes.indexOf(w.query.sourceSystemCode) >= 0);
    const windowsForRemoval = windows.filter(w => sourceSystemCodes.indexOf(w.query.sourceSystemCode) < 0);
    
    windowsForRemoval.forEach(w => w.removeFromParent());

    const existingSourceCodes : string[] = [];
    keepWindows.forEach(w => {
        const sourceSystemCode = w.query.sourceSystemCode;
        const sourceSystemEntry = byCode(sourceSystemCode);
        existingSourceCodes.push(sourceSystemCode);
        w.config = {
            path: PathsContext.value.entitySource(props.masterEntity.masterEntityId, sourceSystemCode),
            query: { sourceSystemCode: sourceSystemCode },
            params: { onSearch: props.onSearch },
            title: sourceSystemEntry ? sourceSystemEntry.description : undefined,
        };
    });

    const entries : IMasterEntitySourceConfigEntry[] = [];
    sourceSystemCodes.forEach(sourceSystemCode => {
        const e = existingSourceCodes.indexOf(sourceSystemCode) < 0 ? byCode(sourceSystemCode) : undefined;
        if(e) {
            entries.push(e);
        }
    });
    let newWindows;
    if(entries.length > 0) {
        entries.sort((l, r) => compare(l.title, r.title));
        newWindows = entries.map(e => {
            const window = new Window();
            window.setConfig(createWindowConfigFromEntry(props, e));
            return window;
        });
    } else {
        newWindows = [];
    }

    // if we can find a stack, add the windows to that. Otherwise add to top manager
    let stack = rdb.findFirst(c => {
        return c.type === "stack";
    }) as IStack;
    if(stack) {
        newWindows.forEach(w => stack.add(w));
        if(!stack.active && stack.windowCount > 0) {
            stack.setActive(stack.windows[0]);
        }
    } else {
        const mgr = rdb.component as IWindowManager;
        if(mgr) {
            newWindows.forEach(w => mgr.add(w));
        } else {
            stack = new Stack();
            keepWindows.forEach(w => stack.add(w));
            newWindows.forEach(w => stack.add(w));
            rdb.setComponent(stack);
        }
    }

    // if we've got a source system code to select, grab that
    if(props.selectSourceSystem) {
        const e = byCode(props.selectSourceSystem);
        const sourceSystemCode = e ? e.key : props.selectSourceSystem;
        const sourceWindow = rdb.findFirst(c => {
            if(c.type === "window") {
                const w = c as IWindow;
                const we = byCode(w.query.sourceSystemCode);
                return we && we.key === sourceSystemCode ? true : false;
            }
            return false;
        }) as IWindow;
        if(sourceWindow) {
            sourceWindow.activate();
        }
    }

    return rdb.config;
};

const createEntitySourceLoader = (props : IMasterEntitySourceDashboardProps) => {
    return () => {
        return DashboardStorageServiceContext.value.getItem(storageKey).then(config => {
            let r;
            if(!config) {
                r = getDefaultDashboardConfig(props);
            } else {
                r = getUpdatedDashboardConfig(props, config);
            }
            return r;
        });
    };
};

const entitySourceSaver = (data) => {
    return DashboardStorageServiceContext.value.setItem(storageKey, data);
};

interface IMasterEntitySourceDashboardProps {
    masterEntity: IMasterEntityModel;
    selectSourceSystem?: string;
    host?: IAppHost;
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

@observer
class MasterEntitySourceDashboard extends React.Component<IMasterEntitySourceDashboardProps, any> {
    private _dashboard : Dashboard = new Dashboard();
    constructor(props : IMasterEntitySourceDashboardProps) {
        super(props);
        this._setupDashboard(props);
    }
    private _setupDashboard(props : IMasterEntitySourceDashboardProps) {
        this._dashboard.setCloseDisabled(true);
        this._dashboard.router = props.host && props.host.router ? props.host.router : RouterContext.value;
        this._dashboard.componentFactory = ComponentFactory;
        this._dashboard.loader = createEntitySourceLoader(props);
        this._dashboard.saver = entitySourceSaver;
    }
    private _onRenderFilterContent = (filter) => {
        if(filter.specified) {
            return <span>Activities matching: {defaultRenderContent(filter)}</span>
        } 
        return <span>All Activities</span>;
    }
    componentWillReceiveProps(nextProps) {
        this._dashboard.close();
        this._setupDashboard(nextProps);
        this._dashboard.load();
    }
    componentWillMount() {
        this._dashboard.load();
    }
    componentWillUnmount() {
        this._dashboard.close();
    }
    render() {
        const items : IContextualMenuItem[] = [
            createActivityFilterItem({ activityFilter: this.props.masterEntity.activityFilter, onRenderContent: this._onRenderFilterContent }),
        ];
        const actions = createDashboardLayoutActions(this._dashboard);
        if(actions && actions.length > 0) {
            actions.forEach(action => items.push(action));
        }
        const farItems : IContextualMenuItem[] = [];
        farItems.push(
            createDashboardMenu(this._dashboard)
        );
        return (
            <AppView commandBarProps={{ items: items, farItems: farItems }}>
                <DashboardContainer dashboard={this._dashboard} host={this.props.host} />
            </AppView>
        );
    }
}

export { MasterEntitySourceDashboard as default, MasterEntitySourceDashboard, IMasterEntitySourceDashboardProps }

