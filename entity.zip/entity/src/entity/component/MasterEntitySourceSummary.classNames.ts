import { memoizeFunction } from "@uifabric/utilities";
import { IMasterEntitySourceSummaryStyles } from "./MasterEntitySourceSummary.styles";
import { mergeStyleSets } from "@uifabric/styling";

interface IMasterEntitySourceSummaryClassNames {
    root?: string;
    source?: string;
    sourceCountContainer?: string;
    sourceCount?: string;
}

const getClassNames = memoizeFunction((styles : IMasterEntitySourceSummaryStyles, className?: string) => {
    return mergeStyleSets({
        root: ["master-entity-source-summary", className, styles.root],
        source: ["master-entity-source-summary-source", styles.source],
        sourceCountContainer: ["master-entity-source-summary-source-count-container", styles.sourceCountContainer],
        sourceCount: ["master-entity-source-summary-source-count", styles.sourceCount]
    })
});

export { IMasterEntitySourceSummaryClassNames, getClassNames }