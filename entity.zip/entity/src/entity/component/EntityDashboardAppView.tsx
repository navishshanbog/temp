import * as React from "react";
import { IEntityDashboardProps, EntityDashboard } from "./EntityDashboard";
import { IEntityAppViewProps, EntityAppView } from "../../common/component/EntityAppView";

interface IEntityDashboardAppViewProps extends IEntityDashboardProps, IEntityAppViewProps {}

class EntityDashboardAppView extends React.Component<IEntityDashboardAppViewProps, any> {
    render() {
        return (
            <EntityAppView {...this.props}>
                <EntityDashboard {...this.props} />
            </EntityAppView>
        );
    }
}

export { EntityDashboardAppView, IEntityDashboardAppViewProps }