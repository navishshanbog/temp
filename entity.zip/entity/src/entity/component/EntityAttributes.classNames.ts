import { memoizeFunction } from "@uifabric/utilities";
import { IEntityAttributesStyles } from "./EntityAttributes.styles";
import { mergeStyleSets } from "@uifabric/styling";

interface IEntityAttributesClassNames {
    root?: string;
    attribute?: string;
    attributeValue?: string;
}

const getClassNames = memoizeFunction((styles : IEntityAttributesStyles, className?: string) : IEntityAttributesClassNames => {
    return mergeStyleSets({
        root: ["entity-attributes", styles.root, className],
        attribute: ["entity-attributes-attribute", styles.attribute],
        attributeValue: ["entity-attributes-attribute-value", styles.attributeValue]
    })
});

export { IEntityAttributesClassNames, getClassNames }