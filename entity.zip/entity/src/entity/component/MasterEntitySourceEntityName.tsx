import * as React from "react";
import IMasterEntitySourceEntityName from "../IMasterEntitySourceEntityName";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { SearchableValue } from "@twii/common/lib/search/component/SearchableValue";

interface IMasterEntitySourceEntityNameProps {
    name: IMasterEntitySourceEntityName;
    onSearch?: (value : ISearchField) => void;
    titleSetter?: (title : string) => void;
    className?: string;
}

class MasterEntitySourceEntityName extends React.Component<IMasterEntitySourceEntityNameProps, any> {
    componentWillMount() {
        if(this.props.titleSetter) {
            this.props.titleSetter(this.props.name ? this.props.name.standardFullName || this.props.name.organisationName : "");
        }
    }
    render() {
        const searchString = this.props.name ? this.props.name.standardFullName || this.props.name.organisationName : undefined;
        return <SearchableValue className={this.props.className} name="name" searchString={searchString} onClick={this.props.onSearch} />;
    }
}

export { MasterEntitySourceEntityName as default, MasterEntitySourceEntityName, IMasterEntitySourceEntityNameProps };