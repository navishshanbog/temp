import * as React from "react";
import { IEntityAppProps } from "../../common/component/IEntityAppProps";
import { MasterEntityDashboard } from "./MasterEntityDashboard";
import { IMasterEntityModel } from "../IMasterEntityModel";
import { findByEntityId } from "../MasterEntityFinder";
import { EntityAppView } from "../../common/component/EntityAppView";
import { PathsContext } from "../../PathsContext";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { createMasterEntityNavigationMenuItem } from "./MasterEntityNavigation";
import ISyncHandleModel from "@twii/common/lib/ISyncHandleModel";
import { openValueSearch } from "../MasterEntitySearchActions";
import * as logoUrl from "../../common/component/Logo.png";

class EntityDetailsApp extends React.Component<IEntityAppProps, any> {
    get host() {
        return this.props.match.host;
    }
    get entityId() {
        return this.props.match.params.entityId;
    }
    get entitySupplier() : ISyncHandleModel<IMasterEntityModel> {
        return findByEntityId(this.entityId);
    }
    get userProfile() {
        return this.props.match.userProfile;
    }
    get isFromNewSearch() {
        return this.props.match.params._fromNewSearch ? true : false;
    }
    componentWillMount() {
        this.host.icon.url = logoUrl;
        this.host.title = "Entity Details";
        this.entitySupplier.load();
    }
    private _onClickEntity = (entity : IMasterEntityModel) => {
        this.host.load({ path: PathsContext.value.entity(entity.masterEntityId) });
    }
    private _onDashboardSearch = (value : ISearchField) => {
        openValueSearch(this.host, value, this.isFromNewSearch);
    }
    private _setTitle = (title : string) => {
        this.host.setTitle(title);
    }
    render() {
        const items : IContextualMenuItem[] = [];
        items.push(
            createMasterEntityNavigationMenuItem({
                host: this.host,
                entitySupplier: this.entitySupplier,
                onClickEntity: this._onClickEntity
            })
        );
        return (
            <EntityAppView host={this.host} commandBarProps={{ items: items }} hideTitle>
                <MasterEntityDashboard entityId={this.entityId} host={this.host} onSearch={this._onDashboardSearch} titleSetter={this._setTitle} />
            </EntityAppView>
        );
    }
}

export { EntityDetailsApp, EntityDetailsApp as default }