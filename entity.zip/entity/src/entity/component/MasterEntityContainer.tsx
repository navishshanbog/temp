import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import Error from "@twii/common/lib/component/Error";
import IMasterEntityModel from "../IMasterEntityModel";
import ISyncHandle from "@twii/common/lib/ISyncHandle";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";

interface IMasterEntityContainerProps {
    entitySupplier: ISyncSupplier<IMasterEntityModel> | ISyncHandle<IMasterEntityModel>;
    className?: string;
    onRenderEntity?: (masterEntity : IMasterEntityModel) => React.ReactNode;
    onRenderNotLoaded?: () => React.ReactNode;
}

class MasterEntityContainer extends React.Component<IMasterEntityContainerProps, any> {
    private _onRenderDone = () => {
        return this.props.onRenderEntity ? this.props.onRenderEntity(this.props.entitySupplier.value) : null;
    }
    private _onRenderError = (error : any) => {
        if(error.status === 404 || error.code === "NOT_FOUND") {
            return <MessageBar messageBarType={MessageBarType.warning}>{error.message}</MessageBar>;
        }
        return <Error error={error} />;
    }
    private _onRenderDefault = () => {
        return this.props.onRenderNotLoaded ?
            this.props.onRenderNotLoaded() : <MessageBar messageBarType={MessageBarType.warning}>Master Entity has not been loaded</MessageBar>;
    }
    componentWillMount() {
        this.props.entitySupplier.load();
    }
    render() {
        return <SyncContainer sync={this.props.entitySupplier.sync}
                              onRenderDone={this._onRenderDone}
                              onRenderError={this._onRenderError}
                              onRenderDefault={this._onRenderDefault} />;
    }
}

export { MasterEntityContainer as default, MasterEntityContainer, IMasterEntityContainerProps }