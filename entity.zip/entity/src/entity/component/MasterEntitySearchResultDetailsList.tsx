import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    DetailsRow,
    IDetailsRowProps,
    SelectionMode,
    IDetailsList
} from "office-ui-fabric-react/lib/DetailsList";
import { Link } from "office-ui-fabric-react/lib/Link";
import IMasterEntitySearchResultModel from "../IMasterEntitySearchResultModel";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import MasterEntitySearchResultItemColumns from "./MasterEntitySearchResultItemColumns";
import * as ColumnSortHelper from "@twii/common/lib/component/ColumnSortHelper";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import AppContext from "@twii/common/lib/AppContext";
import { css } from "@uifabric/utilities/lib/css";
import { SelectableDetailsList } from "@twii/common/lib/component/SelectableDetailsList";
import { PathsContext } from "../../PathsContext";
import MasterEntityVisitedHistoryStore from "../MasterEntityVisitedHistoryStore";

interface IMasterEntitySearchResultDetailsListProps {
    searchResult: IMasterEntitySearchResultModel;
    onItemSelected?: (item: IMasterEntitySearchResultItem) => void;
}

interface IMasterEntitySearchResultLinkProps extends IMasterEntitySearchResultDetailsListProps {
    item: IMasterEntitySearchResultItem;
}

@observer
class MasterEntitySearchResultLink extends React.Component<IMasterEntitySearchResultLinkProps, any> {
    private _onClick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.props.onItemSelected(this.props.item);
    }
    render() {
        const { item } = this.props;
        const visited = MasterEntityVisitedHistoryStore.items.some(i => String(i.value) === String(item.mstrEntyId));
        const url = AppContext.value.rootAppHost.getUrl({ path: PathsContext.value.entity(item.mstrEntyId) });
        return <Link className={css({ visited: visited })} href={url} onClick={this._onClick}>{item.stdFullNm}</Link>;
    }
}

@observer
class MasterEntitySearchResultDetailsList extends React.Component<IMasterEntitySearchResultDetailsListProps, any> {
    private _onColumnHeaderClick = (e: React.MouseEvent<HTMLElement>, column: IColumn) => {
        this.props.searchResult.sort.toggleSort(column.fieldName);
    }
    private _onShouldVirtualize = () => {
        return this.props.searchResult.itemsView.length > 200;
    }
    private _onRenderNameColumn = (item: IMasterEntitySearchResultItem, index: number, column: IColumn) => {
        return <MasterEntitySearchResultLink {...this.props} item={item} />;
    }
    render() {
        const itemsView = this.props.searchResult.itemsView;
        if (!itemsView || itemsView.length === 0) {
            return <MessageBar messageBarType={MessageBarType.warning}>There are no search results matching the specified filter</MessageBar>;
        }
        let columns = [].concat(MasterEntitySearchResultItemColumns);
        columns = ColumnSortHelper.applySort(columns, this.props.searchResult.sort);
        if (this.props.onItemSelected) {
            columns[0] = Object.assign({}, columns[0], { onRender: this._onRenderNameColumn });
        }

        return (
            <SelectableDetailsList className="master-entity-search-result-details-list"
                list={this.props.searchResult}
                columns={columns}
                selectionMode={SelectionMode.multiple}
                onItemInvoked={this.props.onItemSelected}
                onColumnHeaderClick={this._onColumnHeaderClick}
                layoutMode={DetailsListLayoutMode.fixedColumns}
                constrainMode={ConstrainMode.unconstrained}
                checkboxVisibility={CheckboxVisibility.always}
                onShouldVirtualize={this._onShouldVirtualize}
                selectAllAlwaysVisible
                fill />
        );
    }
}



export {
    MasterEntitySearchResultDetailsList as default,
    MasterEntitySearchResultDetailsList,
    IMasterEntitySearchResultDetailsListProps
};