import { DefaultFontStyles, IStyle, mergeStyleSets } from "@uifabric/styling";

interface IMasterEntitySearchRequestSummaryClassNames {
    root: any;
}

const root : IStyle = Object.assign({},
    DefaultFontStyles.small,
    {
        display: "flex",
        justifyContent: "flex-start",
        alignItems: "center",
        selectors: {
            ".definition-list": {
                paddingLeft: "8px",
                paddingRight: "8px"
            }
        }
    }
);

let classNames : IMasterEntitySearchRequestSummaryClassNames;

const getClassNames = () => {
    if(!classNames) {
        classNames = mergeStyleSets({
            root: root
        });
    }
    return classNames;
};

export { getClassNames, root, IMasterEntitySearchRequestSummaryClassNames }