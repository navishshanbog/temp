import * as React from "react";
import { IColumn } from "office-ui-fabric-react/lib/DetailsList";
import { IEntityActivity } from "../IEntityActivity";
import { ICompositeMasterEntityModel } from "../ICompositeMasterEntityModel";
import { EntityOwner } from "./EntityOwner";

const EntityActivityOwnerColumn : IColumn = {
    key: "ownerEntityId",
    name: "",
    fieldName: "ownerEntityId",
    minWidth: 20,
    maxWidth: 20,
    isResizable: false,
    onRender(item : IEntityActivity) {
        return (item.entity && item.entity.isComposite) ?
            <EntityOwner compositeEntity={item.entity as ICompositeMasterEntityModel}
                         entity={item.source.masterEntity}
                         setTitle={true} /> :
            null;
    }
};

export { EntityActivityOwnerColumn }