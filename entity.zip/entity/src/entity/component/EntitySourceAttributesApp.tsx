import * as React from "react";
import MasterEntityContainer from "./MasterEntityContainer";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { IEntityAppProps } from "../../common/component/IEntityAppProps";
import { EntityAppView } from "../../common/component/EntityAppView";
import { findByEntityId } from "../MasterEntityFinder";
import { composeSource } from "../MasterEntitySourceHelper";
import EntityAttributes, { EntityAttributesType } from "./EntityAttributes";
import { byCode } from "../MasterEntitySourceConfig";
import { EntitySourceAppBase } from "./EntitySourceAppBase";

class EntitySourceAttributesApp extends EntitySourceAppBase {
    componentWillMount() {
        const sourceSystemEntry = byCode(this.sourceSystemCode);
        const title = sourceSystemEntry ? sourceSystemEntry.title : this.sourceSystemCode;
        this.host.title = title;
        this.host.icon = sourceSystemEntry.icon ? sourceSystemEntry.icon() : undefined;
    }
    private _onRenderEntity = (entity) => {
        return <EntityAttributes entity={composeSource(entity, this.sourceSystemCode)} type={EntityAttributesType.secondary} onSearch={this.host.params.onSearch} />;
    }
    render() {
        return (
            <EntityAppView host={this.host} userProfile={this.userProfile} hideSettings={!this.host.root} hideHelp={!this.host.root} hideProtectedMarker>
                <MasterEntityContainer entitySupplier={findByEntityId(this.entityId)}
                                       onRenderEntity={this._onRenderEntity} />
            </EntityAppView>
        );
    }
}

export { EntitySourceAttributesApp as default, EntitySourceAttributesApp }