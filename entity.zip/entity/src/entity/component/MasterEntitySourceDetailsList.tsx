import * as React from "react";
import { observer } from "mobx-react";
import IMasterEntitySourceListModel from "../IMasterEntitySourceListModel";
import {
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    SelectionMode,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import { getViewPreferenceColumns } from "@twii/common/lib/component/ColumnHelper";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import * as ColumnSortHelper from "@twii/common/lib/component/ColumnSortHelper";
import DragStore from "../../common/DragStore";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import IEntitySourceItems from "../IEntitySourceItems";
import { EntityActivityOwnerColumn } from "./EntityActivityColumn";
import { IMasterEntitySourceDetailsListStyles, getStyles } from "./MasterEntitySourceDetailsList.styles";
import { getClassNames } from "./MasterEntitySourceDetailsList.classNames";
import { SelectableDetailsList, SelectionDisabledRowFields } from "@twii/common/lib/component/SelectableDetailsList";

interface IMasterEntitySourceDetailsListProps {
    list: IMasterEntitySourceListModel<any>;
    itemType?: string;
    columns: IColumn[];
    viewPreferences?: IViewPreferencesModel;
    typeLabel?: string;
    onItemInvoked?: (item : any, index : number, e : Event) => void;
    layoutMode?: DetailsListLayoutMode;
    constrainMode?: ConstrainMode;
    skipViewportMeasures?: boolean;
    dragDropDisabled?: boolean;
    selectionDisabled?: boolean;
    styles?: IMasterEntitySourceDetailsListStyles;
    className?: string;
}

interface IDetailsRowWrapperProps {
    list: IMasterEntitySourceListModel<any>;
    itemType?: string;
    onItemInvoked?: (item : any, index?: number, event?: any) => void;
    selectionDisabled?: boolean;
    dragDropDisabled?: boolean;
    rowProps?: IDetailsRowProps;
}

@observer
class DetailsRowWrapper extends React.Component<IDetailsRowWrapperProps, any> {
    private _onDragStart = (e : React.DragEvent<HTMLDivElement>) => {
        e.stopPropagation();
        const sourceItems : IEntitySourceItems = {
            type: this.props.itemType,
            items: this.props.list.selection.selectedItems
        }
        const r = {
            type: "entitySourceItems",
            value: sourceItems
        };
        const dataTransfer = JSON.stringify(r);
        try {
            e.dataTransfer.setData("application/json", dataTransfer);
        } catch(err) {}
        e.dataTransfer.setData("text", dataTransfer);
        DragStore.setValue(r);
    }
    private _onDoubleClick = (e : React.MouseEvent<HTMLDivElement>) => {
        this.props.onItemInvoked(this.props.rowProps.item, this.props.rowProps.itemIndex, e);
    }
    render() {
        const row = <DetailsRow {...this.props.rowProps} rowFieldsAs={SelectionDisabledRowFields} />;
        const selected = this.props.list.selection.selectedItems.indexOf(this.props.rowProps.item) >= 0;
        const draggable = selected && !this.props.dragDropDisabled;
        return (
            <div draggable={draggable}
                onDragStart={draggable ? this._onDragStart : undefined}
                onDoubleClick={this.props.onItemInvoked ? this._onDoubleClick : undefined}>
                {row}
            </div>
        );
    }
}

@observer
class MasterEntitySourceDetailsList extends React.Component<IMasterEntitySourceDetailsListProps, any> {
    private _onColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        this.props.list.sort.toggleSort(column.fieldName);
    }
    private _onRenderRow = (rowProps : IDetailsRowProps) => {
        return <DetailsRowWrapper list={this.props.list}
                                  itemType={this.props.itemType}
                                  rowProps={rowProps}
                                  onItemInvoked={this.props.onItemInvoked}
                                  selectionDisabled={this.props.selectionDisabled}
                                  dragDropDisabled={this.props.dragDropDisabled} />
    }
    private get _filteredColumns() {
        return getViewPreferenceColumns(this.props.columns, this.props.viewPreferences);
    }

    private _onShouldVirtualize = () => {
        return this.props.list.itemsView.length > 200;
    }

    render() {
        const itemsTitle = this.props.typeLabel || `${this.props.list.sourceSystemCode} items`;
        if(this.props.list.total === 0) {
            return <MessageBar messageBarType={MessageBarType.warning}>Unable to find any {itemsTitle}</MessageBar>;
        }

        const itemsView = this.props.list.itemsView;
        if(!itemsView || itemsView.length === 0) {
            return <MessageBar messageBarType={MessageBarType.warning}>Unable to find any matching {itemsTitle}</MessageBar>;
        }
        
        let columns = this._filteredColumns;
        columns = ColumnSortHelper.applySort(columns, this.props.list.sort);
        if(this.props.list.entity.isComposite) {
            columns = [EntityActivityOwnerColumn].concat(columns);
        }

        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);

        return (
            <SelectableDetailsList
                    list={this.props.list}
                    className={classNames.root}
                    columns={columns}
                    onColumnHeaderClick={this._onColumnHeaderClick}
                    layoutMode={this.props.layoutMode !== undefined ? this.props.layoutMode : DetailsListLayoutMode.fixedColumns}
                    constrainMode={this.props.constrainMode !== undefined ? this.props.constrainMode : ConstrainMode.unconstrained}
                    onItemInvoked={this.props.onItemInvoked}
                    checkboxVisibility={this.props.selectionDisabled ? CheckboxVisibility.hidden : CheckboxVisibility.always}
                    selectionMode={SelectionMode.multiple}
                    onShouldVirtualize={this._onShouldVirtualize}
                    skipViewportMeasures={this.props.skipViewportMeasures !== undefined ? this.props.skipViewportMeasures : true}
                    selectAllAlwaysVisible
                    onRenderRow={this._onRenderRow}
                    fill />
        );
    }
}

export { 
    MasterEntitySourceDetailsList as default,
    MasterEntitySourceDetailsList,
    IMasterEntitySourceDetailsListProps
}