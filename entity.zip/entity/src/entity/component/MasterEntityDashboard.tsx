import * as React from "react";
import { DashboardWrapper } from "@twii/dashboard/lib/component/DashboardWrapper";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { PathsContext } from "../../PathsContext";
import { ISearchField } from "@twii/common/lib/search/ISearchField";

const getDashboardConfig = (props : IMasterEntityDashboardProps) => {
    return {
        type: "dashboard",
        component: {
            type: "vsplit",
            minItemHeight: 0,
            offset: 0.2,
            top: {
                component: {
                    type: "window",
                    path: PathsContext.value.entitySummary(props.entityId),
                    params: {
                        onSearch: props.onSearch,
                        titleSetter: props.titleSetter
                    }
                }
            },
            bottom: {
                component: {
                    type: "window",
                    path: PathsContext.value.entitySources(props.entityId),
                    params: {
                        onSearch: props.onSearch
                    }
                }
            }
        }
    };
};

interface IMasterEntityDashboardProps {
    entityId: string;
    host?: IAppHost;
    onSearch?: (value : ISearchField) => void;
    titleSetter?: (title : string) => void;
}

class MasterEntityDashboard extends React.Component<IMasterEntityDashboardProps, any> {
    render() {
        const config = getDashboardConfig(this.props);
        return <DashboardWrapper host={this.props.host} config={config} />;
    }
}

export { MasterEntityDashboard as default, MasterEntityDashboard, IMasterEntityDashboardProps }