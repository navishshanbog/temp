import * as React from "react";
import MasterEntitySearchRequestEditor from "./MasterEntitySearchRequestEditor";
import MasterEntitySearchRequestModel from "../MasterEntitySearchRequestModel";
import * as Renderer from "react-test-renderer/shallow";

describe("MasterEntitySearchEditor", () => {
    test("render default", () => {
        const m = new MasterEntitySearchRequestModel();
        const r = new Renderer();
        r.render(<MasterEntitySearchRequestEditor searchRequest={m} />);
        // TODO: assertions
    });

    test("render all contracted", () => {
        const m = new MasterEntitySearchRequestModel();
        m.setEntityOn(false);
        m.setPersonOn(false);
        m.setAddressOn(false);
        m.setContactOn(false);
        m.setCredentialOn(false);
        const r = new Renderer();
        r.render(<MasterEntitySearchRequestEditor searchRequest={m} />);
        // TODO: assertions
    });
});