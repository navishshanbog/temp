import * as React from "react";
import { ICompositeMasterEntityModel } from "../ICompositeMasterEntityModel";
import { IMasterEntityModel } from "../IMasterEntityModel";
import { EntityIndexedColorManager } from "../EntityIndexedColorManager";
import { IndexedColorIcon } from "../../common/component/IndexedColorIcon";

interface IEntityOwnerProps {
    compositeEntity: ICompositeMasterEntityModel;
    entity: IMasterEntityModel;
    setTitle?: boolean;
}

class EntityOwner extends React.Component<IEntityOwnerProps, any> {
    render() {
        const e = this.props.entity;
        // find index of the entity and use to lookup color/legend
        const entityIdx = this.props.compositeEntity.entities.indexOf(e);
        return <IndexedColorIcon index={entityIdx} indexedColorManager={EntityIndexedColorManager} className="entity-owner-icon" title={this.props.setTitle ? `${e.nisName} (ID: ${e.masterEntityId})` : undefined} />;
    }
}

export { EntityOwner, IEntityOwnerProps }