import * as React from "react";
import { ICompositeMasterEntityModel } from "../ICompositeMasterEntityModel";
import { IMasterEntityModel } from "../IMasterEntityModel";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBarButton } from "office-ui-fabric-react/lib/Button";
import { IIconProps } from "office-ui-fabric-react/lib/Icon";
import { observer } from "mobx-react";
import { EntityIndexedColorManager } from "../EntityIndexedColorManager";
import { IAppHostBaseProps } from "@twii/common/lib/component/IAppHostBaseProps";
import { Sync } from "@twii/common/lib/component/Sync";
import { Spinner, SpinnerSize } from "office-ui-fabric-react/lib/Spinner";
import ISyncHandleModel from "@twii/common/lib/ISyncHandleModel";

const navEntityKey = "navCompositeMasterEntity";

const getEntityName = (e : IMasterEntityModel) : string => {
    if(e) {
        if(e.isPerson) {
            return e.nisName;
        }

        if(e.name) {
            return e.isOrganisation ? e.name.organisationName : e.name.standardFullName;
        }
    }
};

interface IMasterEntityNavigationProps extends IAppHostBaseProps {
    entity?: IMasterEntityModel;
    onClickEntity?: (entity : IMasterEntityModel) => void;
}

@observer
class MasterEntityNavigationCommandBarButton extends React.Component<IMasterEntityNavigationProps, any> {
    private _onClickEntity = (e, item : IContextualMenuItem) => {
        this.props.onClickEntity(item.entity as IMasterEntityModel);
    }
    get compositeEntity() : ICompositeMasterEntityModel {
        return this.props.host.getState(navEntityKey, () => {
            if(this.props.entity.isComposite) {
                return this.props.entity as ICompositeMasterEntityModel;
            }
        }, (e : ICompositeMasterEntityModel) => {
            return this.props.entity.isComposite && this.props.entity.masterEntityId !== e.masterEntityId;
        });
    }
    render() {
        const { entity } = this.props;
        const compositeEntity = this.compositeEntity;
        const menuItems : IContextualMenuItem[] = [];
        let iconProps : IIconProps;
        if(compositeEntity) {
            menuItems.push({
                key: compositeEntity.masterEntityId,
                name: "Combined Entity",
                iconProps: {
                    iconName: "MergeDuplicate"
                },
                entity: compositeEntity,
                onClick: this._onClickEntity,
                canCheck: true,
                isChecked: compositeEntity === entity
            });
            compositeEntity.entities.forEach(e => {
                menuItems.push({
                    key: e.masterEntityId,
                    name: getEntityName(e),
                    entity: e,
                    onClick: this._onClickEntity,
                    canCheck: true,
                    isChecked: e === entity,
                    iconProps: {
                        iconName: "CircleFill",
                        style: { color: EntityIndexedColorManager.getColor(compositeEntity.entities.indexOf(e)) }
                    }
                });
            });
            iconProps = {
                iconName: entity === compositeEntity ? "MergeDuplicate" : "CircleFill",
                    style: entity !== compositeEntity ? { color: EntityIndexedColorManager.getColor(compositeEntity.entities.indexOf(entity)) } : undefined
            };
        }
        return (
            <CommandBarButton menuProps={menuItems.length > 0 ? { items: menuItems } : undefined} iconProps={iconProps}>
                {this.props.entity === compositeEntity ? "Combined Entity" : getEntityName(this.props.entity)}
            </CommandBarButton>
        );
    }
}

interface IMasterEntityNavigationContainerProps extends IAppHostBaseProps {
    entitySupplier: ISyncHandleModel<IMasterEntityModel>;
    onClickEntity?: (entity : IMasterEntityModel) => void;
}

class MasterEntityNavigationContainer extends React.Component<IMasterEntityNavigationContainerProps, any> {
    private _onRenderDone = () => {
        return (
            <MasterEntityNavigationCommandBarButton host={this.props.host}
                                                    entity={this.props.entitySupplier.value}
                                                    onClickEntity={this.props.onClickEntity} />
        );
    }
    private _onRenderSyncIcon = () => {
        return <Spinner size={SpinnerSize.small} />;
    }
    private _onRenderSync = () => {
        return <CommandBarButton onRenderIcon={this._onRenderSyncIcon} title="Loading" />;
    }
    private _onRenderError = () => {
        return <CommandBarButton iconProps={{ iconName: "Error" }} title="An error occurred" />;
    }
    componentWillMount() {
        this.props.entitySupplier.load();
    }
    render() {
        return (
            <Sync sync={this.props.entitySupplier.sync}
                  onRenderDone={this._onRenderDone}
                  onRenderSync={this._onRenderSync}
                  onRenderError={this._onRenderError} />
        );
    }
}

const createMasterEntityNavigationMenuItem = (props : IMasterEntityNavigationContainerProps) : IContextualMenuItem => {
    return {
        key: "masterEntityNavigation",
        onRender: (item) => {
            return <MasterEntityNavigationContainer key={item.key} {...props} />;
        }
    }
};

export {
    IMasterEntityNavigationProps,
    MasterEntityNavigationCommandBarButton,
    IMasterEntityNavigationContainerProps,
    createMasterEntityNavigationMenuItem
}