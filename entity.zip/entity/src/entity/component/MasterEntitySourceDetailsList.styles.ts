import { IStyle, ITheme, getTheme, concatStyleSets } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface IMasterEntitySourceDetailsListStyles {
    root?: IStyle;
}

const defaultStyles = (theme : ITheme) : IMasterEntitySourceDetailsListStyles => {
    return {
        root: {
            selectors: {
                ".ms-DetailsRow": {
                    userSelect: "text"
                }
            }
        }
    };
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles : IMasterEntitySourceDetailsListStyles) : IMasterEntitySourceDetailsListStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export { IMasterEntitySourceDetailsListStyles, getStyles, defaultStyles, Defaults }