import * as React from "react";
import { DashboardWrapper } from "@twii/dashboard/lib/component/DashboardWrapper";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { RouterContext } from "@twii/common/lib/RouterContext";

interface IEntityDashboardProps {
    entityId: string;
    configSupplier: (entityId : string) => any;
    host: IAppHost;
}

class EntityDashboard extends React.Component<IEntityDashboardProps, any> {
    render() {
        return <DashboardWrapper host={this.props.host}
                                 config={this.props.configSupplier(this.props.entityId)}
                                 router={this.props.host.router || RouterContext.value} />;
    }
}

export { EntityDashboard, IEntityDashboardProps }