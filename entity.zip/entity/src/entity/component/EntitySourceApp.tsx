import * as React from "react";
import { IMasterEntitySourceContainerProps } from "./MasterEntitySourceContainer";
import { EntitySourceAppView } from "./EntitySourceAppView";
import { findByEntityId } from "../MasterEntityFinder";
import { EntitySourceAppBase } from "./EntitySourceAppBase";

class EntitySourceApp extends EntitySourceAppBase {
    protected _onRenderSource = (props : IMasterEntitySourceContainerProps) => {
        return null;
    }
    render() {
        return (
            <EntitySourceAppView entitySupplier={findByEntityId(this.entityId)}
                                 host={this.host}
                                 userProfile={this.userProfile}
                                 sourceSystemCode={this.sourceSystemCode}
                                 onRenderSource={this._onRenderSource}
                                 panelRequestSupplier={this.panelRequestSupplier} />
        );
    }
}

export { EntitySourceApp }