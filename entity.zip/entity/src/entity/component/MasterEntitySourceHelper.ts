import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import IMasterEntitySourceListModel from "../IMasterEntitySourceListModel";
import ClipboardStore from "../../common/ClipboardStore";


const entitySourceItemsType = "entitySourceItems";

interface ICreateCopyToClipboardItemOptions {
    sourceList: IMasterEntitySourceListModel<any>,
    itemType: string;
}

interface ICreateCopyToClipboardFieldOptions {
    fieldData?: any,
    itemType?: string;
    source?: any;
    parentItemType?: string;
    subEntityHeader?: string;
    masterEntityId?: string;
}

const copyToCliboardClickHandler = (e, item) => {
    ClipboardStore.setValue({
        type: entitySourceItemsType,
        value: {
            type: item.sourceItemType,
            items: item.sourceList.selection.selectedItems
        }
    });
};


const createCopyToClipboardItem = (opts : ICreateCopyToClipboardItemOptions) : IContextualMenuItem => {
    const sourceList = opts.sourceList;
    return {
        key: "copyToClipboard",
        name: "Copy",
        title: "Copy",
        iconProps: { iconName: "Copy" },
        disabled: sourceList.selection.selectionCount === 0,
        sourceList: sourceList,
        sourceItemType: opts.itemType,
        onClick: copyToCliboardClickHandler
    }
};

const copySubActivitiesToClipboard = (e, item) => {
    let customItems = [{
        items: item.fieldValues,  // subitems
        source: item.source,
        sourceSubItemType: item.sourceSubItemType,
        masterEntityId:item.masterEntityId,
        sourceSubItemHeader: item.sourceSubItemHeader
    }];
    ClipboardStore.setValue({
        type: entitySourceItemsType,
        value: {
            type: item.sourceItemType,
            items: customItems
        }
    });
}

export {
    createCopyToClipboardItem,
    copySubActivitiesToClipboard,
    ICreateCopyToClipboardItemOptions,
    entitySourceItemsType
}