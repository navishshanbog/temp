import IMasterEntityVisitedSearchItemsModel, { IVisitedItemsModel } from './IMasterEntityVisitedSearchItemsModel';
import * as moment from 'moment';
import { observable } from 'mobx';

class MasterEntityVisitedSearchItemsModel implements IMasterEntityVisitedSearchItemsModel {
    private visitedItemsList = "visitedItemsList";
    private autoClearAfter = 72;

    @observable items: IVisitedItemsModel[];

    constructor() {
        this.items = this.autoClear();
    };

    setInLocalStorage = (items: IVisitedItemsModel[]) => {
        localStorage.setItem(this.visitedItemsList, JSON.stringify(items));
    }

    getItems = (): IVisitedItemsModel[] => localStorage.getItem(this.visitedItemsList) ? JSON.parse(localStorage.getItem(this.visitedItemsList)) : [];

    setItems = (mstrEntityIds: string[]) => {
        const visitedItems: IVisitedItemsModel[] = mstrEntityIds.map(i => { return { mstrEntyId: i, timeStamp: moment().unix() } })
        this.setInLocalStorage(visitedItems);
        return this.items = this.getItems();
    };

    clearItems = () => {
        localStorage.removeItem(this.visitedItemsList);
        return this.items = this.getItems();
    };

    addItem = (mstrEntityId: string) => {
        let visitedItems = this.getItems();
        let itemVisited = visitedItems.find(i => i.mstrEntyId === mstrEntityId);
        if (itemVisited) {
            visitedItems.splice(visitedItems.indexOf(itemVisited), 1, { mstrEntyId: mstrEntityId, timeStamp: moment().unix() });
        } else {
            visitedItems.push({ mstrEntyId: mstrEntityId, timeStamp: moment().unix() });
        }
        this.setInLocalStorage(visitedItems);
        return this.items = this.getItems();

    };

    isItemSelected = (mstrEntityId: string): boolean => {
        return !!(this.getItems().find(i => i.mstrEntyId === mstrEntityId));
    }

    autoClear = () => {
        const items = this.getItems();
        if (items) {
            this.items = items.filter(i => moment.unix(i.timeStamp).diff(moment().subtract(this.autoClearAfter, 'hours')) > 0);
            this.setInLocalStorage(this.items);
        }
        return this.getItems();
    }
}

export { MasterEntityVisitedSearchItemsModel as default, MasterEntityVisitedSearchItemsModel }