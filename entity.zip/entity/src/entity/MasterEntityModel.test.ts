import MasterEntityModel from "./MasterEntityModel";
import MasterEntitySourceModel from "./MasterEntitySourceModel";
import IMasterEntitySourceEntity from "./IMasterEntitySourceEntity";
import * as DateUtils from "@twii/common/lib/util/Date";

describe("Master Entity Model", () => {
    test("test sources", () => {
        const e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: "BAGS",
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "N7107645|AUS|19880121|M"
                            },
                            meta: {
                                sex: "Male",
                                entityTypeCd: "IND",
                                birthDt: "1974-09-01"
                            },
                            names: [
                                {
                                    standardFullName: "Sunburn Slapper",
                                    firstName: "Sunburn",
                                    familyName: "Slapper"
                                }
                            ]
                        }
                    ]
                }
            ]
        });

        expect(e.sources.length).toBe(1);
        expect(e.gender).toBe("Male");
        expect(DateUtils.dateToDataText(e.dateOfBirth)).toBe("1974-09-01");
        expect(e.names.length).toBe(1);
        expect(e.names[0].standardFullName).toBe("Sunburn Slapper");
        expect(e.names[0].firstName).toBe("Sunburn");
        expect(e.names[0].familyName).toBe("Slapper");
    });
});