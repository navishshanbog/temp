import IMasterEntity from "./IMasterEntity";
import IMasterEntitySource from "./IMasterEntitySource";
import IMasterEntitySourceEntity from "./IMasterEntitySourceEntity";
import IMasterEntitySourceEntityAddress from "./IMasterEntitySourceEntityAddress";
import IMasterEntitySourceEntityName from "./IMasterEntitySourceEntityName";
import IMasterEntitySourceRef from "./IMasterEntitySourceRef";
import IMasterEntitySourceEntityMeta from "./IMasterEntitySourceEntityMeta";
import IMasterEntitySourceEntityCredential from "./IMasterEntitySourceEntityCredential";
import IMasterEntitySourceEntityPhone from "./IMasterEntitySourceEntityPhone";
import { Sequence } from "@twii/common/lib/Id";
import * as DateUtils from "@twii/common/lib/DateUtils";
import IMasterEntitySourceEntityEmail from "./IMasterEntitySourceEntityEmail";

const firstAndMiddleNames : string[] = ["SUNBURN", "KNEE", "JASON", "ROBERT", "XAVIER", "UMBERTO", "JUB", "DAVID", "SIMON", "JAMES", "LITTLE", "FATS", "RUSTY"];
const lastNames : string[] = ["SLAPPER", "INJURY", "MCGRATH", "SMITH", "WRIGHT", "JUB", "UNTERSMEGMA", "FLUGTAG", "PIGGY", "DOMINO", "APPLIANCE"];
const streetNumbers : string[] = ["23", "42", "1", "68", "13", "8"];
const streetTypes : string[] = ["STREET", "DRIVE", "ROAD", "WAY"];
const suburbs : string[] = ["SPRINGYIELD", "CHOPPERTOWN", "BOGANVILLE", "SHITNEY"];
const states : string[] = ["NSW", "ACT", "VIC", "SA", "WA", "QLD", "NT", "TAS"];
const postcodes : string[] = ["2480", "2477", "2622", "2000"];
const sourceSystemCodes : string[] = ["ABR", "ASIC", "EXAM", "IAT", "IATA", "BAGS", "ICS", "INTCP", "DGMS", "EROLL", "ETAS", "TRIPS", "PRISMS"];
const phoneAreaCodes : string[] = ["02", "03", "04", "05", "06", "07"];
const credentials = [{ type: "ABN", value: "32434234243" }];
const YEAR_MILLIS = 365 * 24 * 60 * 60 * 1000;

const maxNameCount = 3;
const maxAddressCount = 3;

const masterEntityIdSequence = new Sequence();
const sourceEntityIdSequence = new Sequence();
const sourceEntityAddressIdSequence = new Sequence();
const sourceEntityNameIdSequence = new Sequence();
const sourceEntityCredentialIdSequence = new Sequence();
const sourceRelatedKeyValueSequence = new Sequence();

const randomIndex = (length : number) => {
    return Math.floor(Math.random() * length);
};

const randomItem = (items : any[]) => {
    return items[randomIndex(items.length)];
};

const createAddress = (masterEntityId : string, sourceSystemCode : string, sourceEntityId : string) : IMasterEntitySourceEntityAddress => {
    const streetNumber = randomItem(streetNumbers);
    const streetName = randomItem(firstAndMiddleNames);
    const streetType = randomItem(streetTypes);
    const suburbIdx = randomIndex(suburbs.length);
    const state = randomItem(states);
    const suburb = suburbs[suburbIdx];
    const postcode = postcodes[suburbIdx];
    const address = `${streetNumber} ${streetName} ${streetType} ${suburb} ${postcode} AU`;
    const addressId = sourceEntityAddressIdSequence.next();
    return {
        masterEntityId: masterEntityId,
        sourceEntityId: sourceEntityId,
        sourceEntityAddressId: addressId,
        sourceSystemCd: sourceSystemCode,
        addressMatchKeyCd: "A01F",
        addressSiteLatitude: "-37.835380000000000",
        addressSiteLongitude: "144.879637000000000",
        streetLocalityPointLatitude: "-37.835405190000000",
        streetLocalityPointLongitude: "144.878303410000000",
        localityPointLatitude: "-37.843600550000000",
        localityPointLongitude: "144.880448570000000",
        usageTypeCd: "RES",
        standardAddressValue: address,
        lotId: "",
        unitTypeAbbreviation: "",
        unitId: "",
        levelTypeAbbreviation: "",
        levelId: "",
        roadFirstPartId: streetNumber,
        roadSecondPartId: "",
        roadName: streetName,
        roadTypeAbbreviation: streetType,
        roadSuffixAbbreviation: "",
        addressSiteName: "",
        localityName: suburb,
        stateCd: state,
        postalCd: postcode,
        countryCd: "AU",
        administrationArea: "",
        supraAdministrationArea: "",
        subAdministrationArea: "",
        postalDeliveryTypeAbbreviation: "",
        postalDeliveryId: "",
        deliveryPointId: "",
        unparsedAddress: "",
        identifiedContactValue: `<ADDRSLINE> ${streetNumber} ${streetName} ${streetType} <ADDRSAREA> ${suburb} ${state} ${postcode} AU`,
        usageTypeCdGeo: "RES",
        standardAddressValueGeo: address,
        lotIdGeo: "",
        unitTypeAbbreviationGeo: "",
        unitIdGeo: "",
        levelTypeAbbreviationGeo: "",
        levelIdGeo: "",
        roadFirstPartIdGeo: streetNumber,
        roadSecondPartIdGeo: "",
        roadNameGeo: streetName,
        roadTypeAbbreviationGeo: streetType,
        roadSuffixAbbreviationGeo: "",
        addressSiteNameGeo: "",
        localityNameGeo: suburb,
        stateCdGeo: state,
        postalCdGeo: postcode,
        countryCdGeo: "AU",
        postalDeliveryTypeAbbreviationGeo: "",
        postalDeliveryIdGeo: "",
        deliveryPointIdGeo: "",
        addressSitePID: addressId,
        addressDetailPID: `GA${state}${addressId}`,
        streetLocalityPID: `ST${state}${addressId}`,
        localityPID: `${state}${addressId}`,
        statePID: `${states.indexOf(state)}`,
        effectiveStartDt: DateUtils.dateToDataText(new Date())
    };
};

const createName = (masterEntityId : string, sourceSystemCode : string, sourceEntityId : string) : IMasterEntitySourceEntityName => {
    const nameId = sourceEntityNameIdSequence.next();
    const firstName = randomItem(firstAndMiddleNames);
    const middleName = randomItem(firstAndMiddleNames);
    const lastName = randomItem(lastNames);
    const fullName = `${firstName} ${middleName} ${lastName}`;
    return {
        masterEntityId: masterEntityId,
        sourceEntityId: sourceEntityId,
        sourceSystemCd: sourceSystemCode,
        sourceEntityNameId: nameId,
        usageTypeCd: "MAIN",
        standardFullName: fullName,
        organisationName: "",
        firstName: firstName,
        middleName: middleName,
        familyName: lastName,
        nameSuffix: "",
        nameGeneration: "",
        nameGenderCd: "M",
        nameEntityTypeCd: "IND",
        identifiedContactValue: ` <NAMETYPE> I <TITLEFIRSTNAME> ${firstName} ${middleName} <TITLEPRIMARYNAME> ${lastName} <ENDOFLINE> `,
        effectiveStartDt: DateUtils.dateToDataText(new Date())
    }
};

const createPhone = (masterEntityId : string, sourceSystemCode : string, sourceEntityId : string) : IMasterEntitySourceEntityPhone => {
    const areaCode = randomItem(phoneAreaCodes);
    let number = "";
    for(let i = 0; i < 8; i ++) {
        number += String(randomIndex(9));
    }
    return {
        masterEntityId: masterEntityId,
        sourceEntityId: sourceEntityId,
        sourceSystemCd: sourceSystemCode,
        phoneNumber: areaCode + number,
        areaCd: areaCode,
        phoneValue: areaCode + number
    }
}

const createCredential = (masterEntityId : string, sourceSystemCode : string, sourceEntityId : string) : IMasterEntitySourceEntityCredential => {
    const credId = sourceEntityCredentialIdSequence.next();
    const cred = randomItem(credentials);
    return {
        masterEntityId: masterEntityId,
        sourceEntityId: sourceEntityId,
        sourceSystemCd: sourceSystemCode,
        sourceEntityCredentialId: credId,
        credentialTypeCd: cred.type,
        credentialValue: cred.value,
    };
};

const createRef = (masterEntityId : string, sourceSystemCode : string, sourceEntityId : string) : IMasterEntitySourceRef => {
    return {
        masterEntityId: masterEntityId,
        sourceEntityId: sourceEntityId,
        sourceSystemCd: sourceSystemCode,
        masterSourceKeyValue: sourceEntityId,
        masteredIndicator: "Y",
        sourceRelatedKeyValue: sourceRelatedKeyValueSequence.next()
    };
};

const createMeta = (masterEntityId : string, sourceSystemCode : string, sourceEntityId : string) : IMasterEntitySourceEntityMeta => {
    const currentTimeMillis = new Date().getTime();
    const dob = new Date(currentTimeMillis - (20 * YEAR_MILLIS) - (Math.floor(Math.random() * 20) * YEAR_MILLIS));
    return {
        masterEntityId: masterEntityId,
        sourceEntityId: sourceEntityId,
        sourceSystemCd: sourceSystemCode,
        entityTypeCd: "IND",
        sex: "MALE",
        birthDt: DateUtils.dateToDataText(dob),
        birthCountryCd: "",
        effectiveStartDt: DateUtils.dateToDataText(new Date())
    };
};

const createSourceEntity = (masterEntityId: string, sourceSystemCode : string) : IMasterEntitySourceEntity => {
    const sourceEntityId = sourceEntityIdSequence.next();
    const r : IMasterEntitySourceEntity = {
        sourceSystemCode: sourceSystemCode,
        sourceEntityId: sourceEntityId
    };
    r.ref = createRef(masterEntityId, sourceSystemCode, sourceEntityId);
    r.meta = createMeta(masterEntityId, sourceSystemCode, sourceEntityId);
    let addressCount = Math.round(Math.random() * maxAddressCount);
    if(addressCount === 0) {
        addressCount = 1;
    }
    r.addresses = [];
    for(let i = 0; i < addressCount; i ++) {
        r.addresses.push(createAddress(masterEntityId, sourceSystemCode, sourceEntityId));
    }
    let nameCount = Math.round(Math.random() * maxNameCount);
    if(nameCount === 0) {
        nameCount = 1;
    }
    r.names = [];
    for(let i = 0; i < nameCount; i ++) {
        r.names.push(createName(masterEntityId, sourceSystemCode, sourceEntityId));
    }
    r.credentials = [createCredential(masterEntityId, sourceSystemCode, sourceEntityId)];
    r.phones = [createPhone(masterEntityId, sourceSystemCode, sourceEntityId)]
    
    return r;
};

const createMasterEntity = () : IMasterEntity => {
    const masterEntityId = masterEntityIdSequence.next();
    let effectiveSourceSystemCodes : string[] = [];
    sourceSystemCodes.forEach(s => {
        const r = Math.round(Math.random());
        if(r > 0) {
            effectiveSourceSystemCodes.push(s);
        }
    });
    if(effectiveSourceSystemCodes.length === 0) {
        effectiveSourceSystemCodes = [randomItem(sourceSystemCodes)];
    }

    const e : IMasterEntity = {
        masterEntityId: masterEntityId,
        sources: effectiveSourceSystemCodes.map(sourceSystemCode => {
            const src = {
                masterEntityId: masterEntityId,
                //sourceSystemCode: "ABR", // To get only ABR,
                sourceSystemCode: sourceSystemCode,
                sourceEntities: []
            };
            src.sourceEntities.push(createSourceEntity(masterEntityId, sourceSystemCode));
            return src;
        })
    }
    return e;
};

const Defaults = {
    entityCount: 2000
};

let _entities : IMasterEntity[];

const getEntities = () => {
    if(!_entities) {
        _entities = createEntities();
    }
    return _entities;
};

const createEntities = (entityCount : number = Defaults.entityCount) : IMasterEntity[] => {
    const r : IMasterEntity[] = [];
    for(let i = 0; i < entityCount; i ++) {
        r.push(createMasterEntity());
    }
    return r;
};

const getSourceEntityMainName = (sourceEntity : IMasterEntitySourceEntity) : IMasterEntitySourceEntityName => {
    if(sourceEntity) {
        return sourceEntity.names.find(n => n.usageTypeCd === "MAIN");
    }
}

const getSourceMainName = (source : IMasterEntitySource) : IMasterEntitySourceEntityName => {
    let r : IMasterEntitySourceEntityName;
    if(source) {
        source.sourceEntities.some(se => {
            r = getSourceEntityMainName(se);
            if(r) {
                return true;
            }
        });
    }
    return r;
};

const getMainName = (entity : IMasterEntity) => {
    let r : IMasterEntitySourceEntityName;
    if(entity && entity.sources) {
        entity.sources.some(src => {
            r = getSourceMainName(src);
            if(r) {
                return true;
            }
        });
    }
    return r;
};

const getMainStandardFullName = (entity : IMasterEntity) : string => {
    const r = getMainName(entity);
    return r ? r.standardFullName : undefined;
};

const getSourceEntityAddress = (sourceEntity : IMasterEntitySourceEntity) : IMasterEntitySourceEntityAddress => {
    if(sourceEntity && sourceEntity.addresses && sourceEntity.addresses.length > 0) {
        return sourceEntity.addresses[0];
    }
}

const getSourceAddress = (source : IMasterEntitySource) : IMasterEntitySourceEntityAddress => {
    let r : IMasterEntitySourceEntityAddress;
    if(source) {
        source.sourceEntities.some(se => {
            r = getSourceEntityAddress(se);
            if(r) {
                return true;
            }
        });
    }
    return r;
};

const getAddress = (entity : IMasterEntity) : IMasterEntitySourceEntityAddress => {
    let r : IMasterEntitySourceEntityAddress;
    if(entity) {
        entity.sources.some(src => {
            r = getSourceAddress(src);
            if(r) {
                return true;
            }
        });
    }
    return r;
};

const getStandardFullAddress = (entity : IMasterEntity) : string => {
    const r = getAddress(entity);
    return r ? r.standardAddressValue : undefined;
};

const getDateOfBirth = (entity : IMasterEntity) : string => {
    let r : string;
    if(entity && entity.sources && entity.sources.length > 0) {
        entity.sources.some(src => {
            const ses = src.sourceEntities;
            if(ses) {
                r = ses[0].meta.birthDt;
                return true;
            }
        });
    }
    return r;
};

const getSexCode = (entity : IMasterEntity) : string => {
    let r : string;
    if(entity && entity.sources && entity.sources.length > 0) {
        entity.sources.some(src => {
            const ses = src.sourceEntities;
            if(ses) {
                r = ses[0].meta.sex;
                return true;
            }
        });
    }
    return r;
};

const getSourceSystemCounts = (entity : IMasterEntity) : { [key : string] : number } => {
    const r = {};
    if(entity && entity.sources && entity.sources.length > 0) {
        entity.sources.forEach(src => {
            r[src.sourceSystemCode] = src.sourceEntities.length;
        });
    }
    return r;
};

const getRefs = (masterEntityId : string) : IMasterEntitySourceRef[] => {
    const e : IMasterEntity = getEntities().find(er => {
        return er.masterEntityId === masterEntityId;
    });
    const r = [];
    if(e) {
        e.sources.forEach(src => {
            src.sourceEntities.forEach(se => {
                r.push(se.ref);
            });
        });
    }
    return r;
};

const getMetas = (masterEntityId : string) : IMasterEntitySourceEntityMeta[] => {
    const e : IMasterEntity = getEntities().find(er => {
        return er.masterEntityId === masterEntityId;
    });
    const r = [];
    if(e) {
        e.sources.forEach(src => {
            src.sourceEntities.forEach(se => {
                r.push(se.meta);
            });
        });
    }
    return r;
};

const getNames = (masterEntityId : string) : IMasterEntitySourceEntityName[] => {
    const e : IMasterEntity = getEntities().find(er => {
        return er.masterEntityId === masterEntityId;
    });
    let r = [];
    if(e) {
        e.sources.forEach(src => {
            src.sourceEntities.forEach(se => {
                r = r.concat(se.names);
            });
        });
    }
    return r;
};

const getAddresses = (masterEntityId : string) : IMasterEntitySourceEntityAddress[] => {
    const e : IMasterEntity = getEntities().find(er => {
        return er.masterEntityId === masterEntityId;
    });
    let r = [];
    if(e) {
        e.sources.forEach(src => {
            src.sourceEntities.forEach(se => {
                r = r.concat(se.addresses);
            });
        });
    }
    return r;
};

const getCredentials = (masterEntityId : string) : IMasterEntitySourceEntityCredential[] => {
    const e : IMasterEntity = getEntities().find(er => {
        return er.masterEntityId === masterEntityId;
    });
    let r = [];
    if(e) {
        e.sources.forEach(src => {
            src.sourceEntities.forEach(se => {
                r = r.concat(se.credentials);
            });
        });
    }
    return r;
};

const getPhones = (masterEntityId : string) : IMasterEntitySourceEntityPhone[] => {
    const e : IMasterEntity = getEntities().find(er => {
        return er.masterEntityId === masterEntityId;
    });
    let r = [];
    if(e) {
        e.sources.forEach(src => {
            src.sourceEntities.forEach(se => {
                r = r.concat(se.phones);
            });
        });
    }
    return r;
};

const getEmails = (masterEntityId : string) : IMasterEntitySourceEntityEmail[] => {
    const e : IMasterEntity = getEntities().find(er => {
        return er.masterEntityId === masterEntityId;
    });
    let r = [];
    if(e) {
        e.sources.forEach(src => {
            src.sourceEntities.forEach(se => {
                r = r.concat(se.emails);
            });
        });
    }
    return r;
};

export {
    createEntities,
    getEntities,
    getMainName,
    getMainStandardFullName,
    getDateOfBirth,
    getSexCode,
    getAddress,
    getStandardFullAddress,
    getSourceSystemCounts,
    getRefs,
    getMetas,
    getNames,
    getAddresses,
    getCredentials,
    getPhones,
    getEmails,
    Defaults
}