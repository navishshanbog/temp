import { compare } from "@twii/common/lib/util/Sort";

const masterEntityIdSeparator : string = "-";

const getMasterEntityIds = (masterEntityId : string) : string[] => {
    const r = masterEntityId ? masterEntityId.split(masterEntityIdSeparator) : [];
    if(r.length > 1) {
        r.sort(compare);
    }
    return r;
};

export { masterEntityIdSeparator, getMasterEntityIds }