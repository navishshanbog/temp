import MasterEntitySearchRequestModel from "./MasterEntitySearchRequestModel";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import StorageServiceContext from "@twii/common/lib/StorageServiceContext";
import TransientStorageService from "@twii/common/lib/TransientStorageService";
import * as DateUtils from "@twii/common/lib/util/Date";

describe("MasterEntitySearchRequestModel", () => {
    test("name mutex", () => {
        const r = new MasterEntitySearchRequestModel();
        r.setFullName("Sunburn Slapper");
        expect(r.fullName).toBe("Sunburn Slapper");

        r.setFirstName("Sunburn");
        expect(r.firstName).toBe("Sunburn");
        expect(r.fullName).toBeFalsy();

        r.setMiddleName("Heavy");
        expect(r.middleName).toBe("Heavy");
        expect(r.fullName).toBeFalsy();

        r.setFamilyName("Slapper");
        expect(r.familyName).toBe("Slapper");
        expect(r.fullName).toBeFalsy();

        r.setFullName("Sunburn Light Slapper");
        expect(r.fullName).toBe("Sunburn Light Slapper");
        expect(r.firstName).toBeFalsy();
        expect(r.middleName).toBeFalsy();
        expect(r.familyName).toBeFalsy();
    });

    test("address mutex", () => {
        const r = new MasterEntitySearchRequestModel();
        const fullAddress = "1/10 Some Drive Somewhere VIC 3001";
        r.setFullAddress(fullAddress);
        expect(r.fullAddress).toBe(fullAddress);

        r.setUnitNumber("1");
        expect(r.unitNumber).toBe("1");
        expect(r.fullAddress).toBeFalsy();

        r.setFullAddress(fullAddress);
        expect(r.fullAddress).toBe(fullAddress);
        r.setStreetNumber("10");
        expect(r.streetNumber).toBe("10");
        expect(r.fullAddress).toBeFalsy();

        r.setFullAddress(fullAddress);
        expect(r.fullAddress).toBe(fullAddress);
        r.setStreetName("Some");
        expect(r.streetName).toBe("Some");
        expect(r.fullAddress).toBeFalsy();

        r.setFullAddress(fullAddress);
        expect(r.fullAddress).toBe(fullAddress);
        r.setStreetType("Drive");
        expect(r.streetType).toBe("Drive");
        expect(r.fullAddress).toBeFalsy();

        r.setFullAddress(fullAddress);
        expect(r.fullAddress).toBe(fullAddress);
        r.setLocality("Somewhere");
        expect(r.locality).toBe("Somewhere");
        expect(r.fullAddress).toBeFalsy();

        r.setFullAddress(fullAddress);
        expect(r.fullAddress).toBe(fullAddress);
        r.setState("VIC");
        expect(r.state).toBe("VIC");
        expect(r.fullAddress).toBeFalsy();

        r.setFullAddress(fullAddress);
        expect(r.fullAddress).toBe(fullAddress);
        r.setPostcode("3001");
        expect(r.postcode).toBe("3001");
        expect(r.fullAddress).toBeFalsy();
    });

    test("validation", () => {
        const r = new MasterEntitySearchRequestModel();
        expect(r.isValueSpecified).toBeFalsy();
        r.validate();
        expect(r.validationErrors.length > 0);

        r.clear();

        r.setPersonOn(true);
        r.setDob(DateUtils.momentFromDataText("wefwefw"));
        r.validate();
        expect(r.validationErrors.length).toBeGreaterThan(0);

        r.clear();

        r.setCredential("23423423423");
        r.setCredentialType("TD");
        r.validate();
        expect(r.validationErrors.length).toBe(0);

        r.clear();
        r.setDob(DateUtils.momentFromDataText("1962-01-01"));
        expect(r.validationErrors.length).toBe(0);
    });

    test("search", () => {
        StorageServiceContext.value = new TransientStorageService();

        let executedSearchRequest : IMasterEntitySearchRequest;
        const r = new MasterEntitySearchRequestModel();
        const requestHandler = (request) => {
            executedSearchRequest = request;
        };

        const fullName = "Sunburn Slapper";
        r.clear();
        // full name
        r.setFullName(fullName);
        r.submit(requestHandler);
       
        expect(executedSearchRequest).toBeTruthy();
        expect(executedSearchRequest.fullName).toBe(fullName);

        executedSearchRequest = undefined;
        r.clear();
        // person search
        r.setPersonOn(true);
        r.setFirstName("Sunburn");
        r.setMiddleName("Hard");
        r.setFamilyName("Slapper");

        r.submit(requestHandler);
        expect(executedSearchRequest.firstName).toBe("Sunburn");
        expect(executedSearchRequest.middleName).toBe("Hard");
        expect(executedSearchRequest.familyName).toBe("Slapper");

        // email
        r.clear();
        r.setContactOn(true);
        r.setEmail("woo@poo.com");
        r.submit(requestHandler);

        expect(executedSearchRequest.emailAddress).toBe("woo@poo.com");

        r.clear();
        r.setCredentialOn(true);
        r.setCredentialType("ABR");
        r.setCredential("323");
        r.submit(requestHandler);

        expect(executedSearchRequest.credentialType).toBe("ABR");
        expect(executedSearchRequest.credential).toBe("323");
    });

    test("load request", () => {
        let request : IMasterEntitySearchRequest = {
            fullName: "Sunburn Slapper"
        };

        const m = new MasterEntitySearchRequestModel();
        m.setRequest(request);
        expect(m.fullName).toBe("Sunburn Slapper");
        expect(m.isEntitySpecified).toBeTruthy();
        expect(m.entityOn).toBeTruthy();
        expect(m.isPersonSpecified).toBeFalsy();
        expect(m.personOn).toBeFalsy();
        expect(m.isAddressSpecified).toBeFalsy();
        expect(m.addressOn).toBeFalsy()
        expect(m.isContactSpecified).toBeFalsy();
        expect(m.contactOn).toBeFalsy();
        expect(m.isValueSpecified).toBeTruthy();

        request = {
            fullName: "Sunburn Slapper",
            dob: "1992-01-01"
        };

        m.setRequest(request);
        expect(m.fullName).toBe(request.fullName);
        expect(m.dob).toBeTruthy();
        expect(DateUtils.momentToDataText(m.dob)).toBe(request.dob);
        expect(m.isEntitySpecified).toBeTruthy();
        expect(m.entityOn).toBeTruthy();
        expect(m.isPersonSpecified).toBeTruthy();
        expect(m.personOn).toBeTruthy();
        expect(m.isAddressSpecified).toBeFalsy();
        expect(m.addressOn).toBeFalsy()
        expect(m.isContactSpecified).toBeFalsy();
        expect(m.contactOn).toBeFalsy();
        expect(m.isValueSpecified).toBeTruthy();

        request = {
            firstName: "Sunburn",
            middleName: "Harry",
            familyName: "Slapper"
        };

        m.setRequest(request);

        expect(m.firstName).toBe(request.firstName);
        expect(m.middleName).toBe(request.middleName);
        expect(m.familyName).toBe(request.familyName);
        expect(m.isEntitySpecified).toBeFalsy();
        expect(m.entityOn).toBeFalsy();
        expect(m.isPersonSpecified).toBeTruthy();
        expect(m.personOn).toBeTruthy();
        expect(m.isAddressSpecified).toBeFalsy();
        expect(m.isContactSpecified).toBeFalsy();
        expect(m.contactOn).toBeFalsy();
        expect(m.isValueSpecified).toBeTruthy();

        request = {
            fullAddress: "10 Some DRIVE Somewhere NSW 2000"
        };

        m.setRequest(request);

        expect(m.fullAddress).toBe(request.fullAddress);
        expect(m.isEntitySpecified).toBeFalsy();
        expect(m.entityOn).toBeFalsy();
        expect(m.isPersonSpecified).toBeFalsy();
        expect(m.personOn).toBeFalsy();
        expect(m.isAddressSpecified).toBeTruthy();
        expect(m.addressOn).toBeTruthy();
        expect(m.isContactSpecified).toBeFalsy();
        expect(m.contactOn).toBeFalsy();
        expect(m.isValueSpecified).toBeTruthy();

        request = {
            unitnNo: "1",
            streetNo: "10",
            streetName: "Some",
            streetType: "DRIVE",
            locality: "Somewhere",
            state: "NSW",
            postCode: "2000"
        };

        m.setRequest(request);
        expect(m.fullAddress).toBeFalsy();
        expect(m.unitNumber).toBe(request.unitnNo);
        expect(m.streetNumber).toBe(request.streetNo);
        expect(m.streetName).toBe(request.streetName);
        expect(m.streetType).toBe(request.streetType);
        expect(m.locality).toBe(request.locality);
        expect(m.state).toBe(request.state);
        expect(m.postcode).toBe(request.postCode);
        expect(m.isEntitySpecified).toBeFalsy();
        expect(m.entityOn).toBeFalsy();
        expect(m.isPersonSpecified).toBeFalsy();
        expect(m.personOn).toBeFalsy();
        expect(m.isAddressSpecified).toBeTruthy();
        expect(m.addressOn).toBeTruthy();
        expect(m.isContactSpecified).toBeFalsy();
        expect(m.contactOn).toBeFalsy();
        expect(m.isValueSpecified).toBeTruthy();

        request = {
            emailAddress: "some@ghit.com"
        };

        m.setRequest(request);
        expect(m.emailAddress).toBe(request.emailAddress);
        expect(m.phone).toBeFalsy();
        expect(m.isEntitySpecified).toBeFalsy();
        expect(m.entityOn).toBeFalsy();
        expect(m.isPersonSpecified).toBeFalsy();
        expect(m.personOn).toBeFalsy();
        expect(m.isAddressSpecified).toBeFalsy();
        expect(m.addressOn).toBeFalsy();
        expect(m.isContactSpecified).toBeTruthy();
        expect(m.contactOn).toBeTruthy();
        expect(m.isValueSpecified).toBeTruthy();

        request = {
            phoneNumber: "0288885555"
        };

        m.setRequest(request);
        expect(m.phone).toBe(request.phoneNumber);
        expect(m.emailAddress).toBeFalsy();
        expect(m.isEntitySpecified).toBeFalsy();
        expect(m.entityOn).toBeFalsy();
        expect(m.isPersonSpecified).toBeFalsy();
        expect(m.personOn).toBeFalsy();
        expect(m.isAddressSpecified).toBeFalsy();
        expect(m.addressOn).toBeFalsy();
        expect(m.isContactSpecified).toBeTruthy();
        expect(m.contactOn).toBeTruthy();
        expect(m.isValueSpecified).toBeTruthy();
    });
});