import * as React from "react";
import { observer } from "mobx-react";
import { Dropdown, IDropdownOption } from "office-ui-fabric-react/lib/Dropdown";
import { Dialog, DialogType, DialogFooter } from "office-ui-fabric-react/lib/Dialog";
import { PrimaryButton, DefaultButton } from "office-ui-fabric-react/lib/Button";
import IEntityProfileCreateDocumentModel from "../IEntityProfileCreateDocumentModel";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import EntityProfileTemplateList from "../EntityProfileTemplateList";

interface IEntityProfileCreateDocumentProps {
    model: IEntityProfileCreateDocumentModel;
}

@observer
class EntityProfileCreateDocument extends React.Component<IEntityProfileCreateDocumentProps, any> {
    private _onChange = (ev, option) => {
        const e = EntityProfileTemplateList.find(e => e.key === option.key);
        this.props.model.setSelectedTemplate(e);
    }
    render() {
        const options : IDropdownOption[] = [
            {
                key: "empty",
                text: ""
            }
        ];
        EntityProfileTemplateList.forEach(e => {
            options.push({
                key: e.key,
                text: e.name
            });
        });
        return (
            <div className="entity-profile-create-document">
                <Dropdown
                    label="Document Template"
                    ariaLabel="Document Template"
                    onChange={this._onChange}
                    options={options}
                    selectedKey={this.props.model.selectedTemplate ? this.props.model.selectedTemplate.key : undefined} />
            </div>
        );
    }
}

@observer
class EntityProfileCreateDocumentContainer extends React.Component<IEntityProfileCreateDocumentProps, any> {
    private _onCancelClick = () => {
        this.props.model.cancel();
    };
    private _onCreateDocumentClick = () => {
        this.props.model.createDocument();
    };
    private _renderContent = () => {
        let content;
        let footer;
        if(this.props.model.active) {
            content = <EntityProfileCreateDocument {...this.props} />;
            footer = (
                <DialogFooter>
                    <DefaultButton onClick={this._onCancelClick} text="Cancel" />
                    <PrimaryButton disabled={!this.props.model.selectedTemplate} onClick={this._onCreateDocumentClick} text="Create" />
                </DialogFooter>
            );
        }
        return (
            <div className="entity-profile-create-document-container">
                {content}
                {footer}
            </div>
        );
    };

    render() {
        return <SyncContainer sync={this.props.model.createDocumentSync}
                              onRenderDone={this._renderContent}
                              onRenderDefault={this._renderContent}
                              syncLabel="Creating document..." />
    }

}

@observer
class EntityProfileCreateDocumentDialog extends React.Component<IEntityProfileCreateDocumentProps, any> {
    private _onDismiss = () => {
        this.props.model.cancel();
    };
    render() {
        return (
            <Dialog
                hidden={!this.props.model.active}
                dialogContentProps={
                    {
                        type: DialogType.normal,
                        title: "Entity Profile - Create Document",
                        subText: "Create an Entity Profile Document based on a template"
                    }
                }
                onDismiss={this._onDismiss}>
                <EntityProfileCreateDocumentContainer {...this.props}/>
            </Dialog>
        );
    }
}

export { EntityProfileCreateDocumentDialog, IEntityProfileCreateDocumentProps }

