import * as React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";

class EntityProfileBanner extends React.Component<any, any> {
    render() {
        return <Icon iconName="DietPlanNotebook" />;
    }
}

export { EntityProfileBanner as default, EntityProfileBanner }