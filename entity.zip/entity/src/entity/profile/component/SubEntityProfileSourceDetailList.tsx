import * as React from "react";
import { observer } from "mobx-react";
import IEntityProfileSourceGroupModel from "../IEntityProfileSourceGroupModel";
import "./SubEntityProfileSourceDetailList.scss";
import {SubEntityProfileSourceData} from "./SubEntityProfileSourceData";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import Details from "@twii/common/lib/component/Details";

interface ISubProfileSourceGroupProps {
    group?: IEntityProfileSourceGroupModel;
}

@observer
class SubEntityProfileSourceDetailList extends React.Component<ISubProfileSourceGroupProps, any> {
    private _onOpenChange = (open : boolean) => {
        this.props.group.setOpen(open);
    }

    render() {
        let content = [<div key="key"></div>];
        if (this.props.group.hasSubTypes) {
            content = this.props.group.subEntities.map((subEntity: any, idx: number) => {
                return (
                    <Details key={idx} style={{ padding: 20 }}title={subEntity.items[0].sourceSubItemHeader} controlOnHeaderClick={true}
                             open={this.props.group.open}
                             onRemove={()=> {this.props.group.removeSubItem(subEntity, idx)}}
                             onOpenChange={this._onOpenChange}>
                        <SubEntityProfileSourceData subEntity={subEntity} parentType={this.props.group.source.entitySource.sourceSystemCode}/>
                    </Details>
                )
            });
        }
        return ( content  );
    }
}

export { SubEntityProfileSourceDetailList as default, SubEntityProfileSourceDetailList, ISubProfileSourceGroupProps }
