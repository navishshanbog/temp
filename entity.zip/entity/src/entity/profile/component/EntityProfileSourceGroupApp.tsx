import { EntityAppBase } from "../../../common/component/EntityAppBase";
import IEntityProfileSourceGroupModel from "../IEntityProfileSourceGroupModel";

class EntityProfileSourceGroupApp extends EntityAppBase {
    get group() : IEntityProfileSourceGroupModel {
        return this.props.match.params.group;
    }
}

export { EntityProfileSourceGroupApp }