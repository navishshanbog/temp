import * as React from "react";
import { observer } from "mobx-react";
import IEntitySourceItems from "../../IEntitySourceItems";
import { AppContainer } from "@twii/common/lib/component/App";
import SubEntityProfileViewRouter from "../SubEntityProfileViewRouter";

interface SubEntityProfileSourceDataProps {
    subEntity?: IEntitySourceItems;
    parentType?:string;
}

@observer
class SubEntityProfileSourceData extends React.Component<SubEntityProfileSourceDataProps, any> {
    render() {
        const subEntity = this.props.subEntity;
        const path = `/${this.props.parentType}/${subEntity.type}`;
        return (<AppContainer path={path} router={SubEntityProfileViewRouter} items={subEntity.items} />)
    }
}

export { SubEntityProfileSourceData as default, SubEntityProfileSourceData, SubEntityProfileSourceDataProps }