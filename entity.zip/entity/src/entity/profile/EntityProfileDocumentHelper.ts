import { saveAs } from "file-saver/FileSaver";
import IMasterEntityModel from "../IMasterEntityModel";
import IEntityProfileListModel from "./IEntityProfileListModel";
import IEntityProfileModel from "./IEntityProfileModel";
import IEntityProfileSourceGroupModel from "./IEntityProfileSourceGroupModel";
import IEntityProfileTemplateEntry from "./IEntityProfileTemplateEntry";
import NodeSerializerContext from "@twii/common/lib/xml/NodeSerializerContext";
import { DocxBuilder, IImageProps } from "../../ms/office/DocxBuilder";
import * as StringUtils from "@twii/common/lib/util/String";
import * as DateUtils from "@twii/common/lib/util/Date";
import { toNISFormat } from "../EntityNameUtils";
import EntityProfileDocumentRouter from "./EntityProfileDocumentRouter";
import { IColumn } from "office-ui-fabric-react/lib/DetailsList";
import { getRowText, getColumnText } from "@twii/common/lib/component/ColumnTextHelper";
import IDetailsAttributeConfig from "@twii/common/lib/IDetailsAttributeConfig";
import IEntityPhoto from "../../entityphotos/model/IEntityPhoto";
import * as PathUtils from "@twii/common/lib/util/Path";
import AppContext from "@twii/common/lib/AppContext";
import * as JSZip from "jszip";
import * as JSZipUtils from "jszip-utils";

const ZIP_DOC_PATH = "word/document.xml";
const ZIP_RESOURCE_PATH = "word/_rels/document.xml.rels";
const ZIP_CONTENT_TYPES_PATH = "[Content_Types].xml";
const SCALED_IMAGE_WIDTH = 1428750; // Twentieths of a point (dxa), the main unit in microsoft word.
const RESOURCE_ID_SEQ_START = 10000;

const DOC_REGEX = '([^]*)(<w:p[ >](?:(?!<\\/w:p>)[^])*{@(?:(?!<\\/w:p>)[^])*AndeReport(?:(?!<w:p[ >])[^])*}(?:(?!<w:p[ >])[^])*<\\/w:p>)([^]*)';
const CONTENT_TYPE_REGEX = '([^]*<Types[ >]*[^]*)(<\\/Types>[^]*)';
const RESOURCE_REL_REGEX = '([^]*<Relationships[ >]*[^]*)(<\/Relationships>[^]*)';

const CONTENT_TYPE_TO_EXT_MAP = {
    "image/jpeg": "jpeg",
    "image/png": "png",
    "image/gif": "gif"
};

const getExt = (contentType: string) => {
    let ext = CONTENT_TYPE_TO_EXT_MAP[contentType];
    if (!ext) {
        throw new Error('Unknown content type [' + contentType + ']');
    }
    return ext;
};
const getContentTypeDef = (contentType: string): string => {
    return `<Default Extension="${getExt(contentType)}" ContentType="${contentType}"/>`;
};

const getResourceRelXml = (rId: string, ext: string): string => {
    return `<Relationship Id="${rId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${rId}.${ext}"/>`;
};

const getTemplateBinaryContent = (path: string): Promise<any> => {
    return new Promise((resolve, reject) => {
        const templatePath = PathUtils.join(AppContext.value.config.basePath, path);
        JSZipUtils.getBinaryContent(templatePath, (err, data) => {
            if (err) {
                reject(err);
            }
            resolve(data);
        });
    });
};

const getAllNames = (entity: IMasterEntityModel): string => {
    return StringUtils.join(entity.names, nm => nm.standardFullName, " | ");
};

const getAllAddresses = (entity: IMasterEntityModel): string => {
    return StringUtils.join(entity.addresses, addr => addr.standardAddressValue, " | ");
};

const getAllPhones = (entity: IMasterEntityModel): string => {
    return StringUtils.join(entity.phones, ph => {
        let r = ph.countryCd ? "(" + ph.countryCd + ") " : "";
        r = ph.areaCd ? r + "- " + ph.areaCd + " " : "";
        r = ph.phoneNumber ? r + ph.phoneNumber : "";
        return r;
    }, " | ");
};

const getAllEmails = (entity: IMasterEntityModel): string => {
    return StringUtils.join(entity.emails, c => {
        return c.emailValue ? c.emailValue : "";
    }, " | ");
};

const getAllCredentials = (entity: IMasterEntityModel): string => {
    return StringUtils.join(entity.credentials, c => {
        let r = c.credentialValue ? c.credentialValue : "";
        r = c.credentialTypeCd ? r + "(" + c.credentialTypeCd + ")" : "";
        return r;
    }, " | ");
};

const getDateOfBirth = (entity: IMasterEntityModel): string => {
    return StringUtils.join(entity.datesOfBirth, dob => {
        return DateUtils.dateToOutputText(dob);
    }, " | ");
};

const getGender = (entity: IMasterEntityModel): string => {
    if (entity.genders && entity.genders.length > 0) {
        return entity.genders.join(" | ");
    }
};

const buildBiographic = (profile: IEntityProfileModel, doc: DocxBuilder) => {
    const entity = profile.entity;
    const title = entity.isPerson ? toNISFormat(entity) : entity.name ? entity.name.organisationName : undefined;
    if (StringUtils.isNotBlank(title)) {
        doc.p().r({ bold: true, size: "18" }).text(title).rEnd().pEnd();
    }
    const names = getAllNames(entity);
    const dob = getDateOfBirth(entity);
    const gender = getGender(entity);
    const addresses = getAllAddresses(entity);
    const phones = getAllPhones(entity);
    const emails = getAllEmails(entity);
    const credentials = getAllCredentials(entity);
    if (names) {
        doc.p().r({ bold: true, size: "14" }).text("Names: ").rEnd().r({ size: "14" }).text(names).rEnd().pEnd();
    }
    if (dob) {
        doc.p().r({ bold: true, size: "14" }).text("Date of Birth: ").rEnd().r({ size: "14" }).text(dob).rEnd().pEnd();
    }
    if (gender) {
        doc.p().r({ bold: true, size: "14" }).text("Gender: ").rEnd().r({ size: "14" }).text(gender).rEnd().pEnd();
    }
    if (addresses) {
        doc.p().r({ bold: true, size: "14" }).text("Addresses: ").rEnd().r({ size: "14" }).text(addresses).rEnd().pEnd();
    }
    if (phones) {
        doc.p().r({ bold: true, size: "14" }).text("Phones: ").rEnd().r({ size: "14" }).text(phones).rEnd().pEnd();
    }
    if (emails) {
        doc.p().r({ bold: true, size: "14" }).text("Emails: ").rEnd().r({ size: "14" }).text(emails).rEnd().pEnd();
    }
    if (credentials) {
        doc.p().r({ bold: true, size: "14" }).text("Credentials: ").rEnd().r({ size: "14" }).text(credentials).rEnd().pEnd();
    }
};

const buildProfileSourceGroup = (group: IEntityProfileSourceGroupModel, doc: DocxBuilder): Promise<any> => {
    const path = `/${group.source.entitySource.sourceSystemCode}/${group.type}`;
    return EntityProfileDocumentRouter.handleRequest({ path: path, params: { group: group, doc: doc } });
};

const buildComments = (comments: string, doc: DocxBuilder) => {
    if (StringUtils.isNotBlank(comments)) {
        doc.p({ justification: "start" }).r({ size: "14", color: "040405" }).text(comments).rEnd().pEnd();
    }
};


interface IImageMeta {
    travellerId: string,
    imageId: string,
    imageType: string,
    source: string,
    created: string
}

const buildImageSection = (profile: IEntityProfileModel, doc: DocxBuilder, imageProps?: IImageProps, imageMeta?: IImageMeta) => {
    doc.tbl();
    doc.tr().tc().p().r();
    // image
    if (imageProps) { doc.imageRef(imageProps) }

    doc.rEnd().pEnd().tcEnd();

    doc.tc().p({ justification: "left" }).r({ size: "12" });
    // image meta
    imageMeta.travellerId && doc.p().r({ bold: true, size: "14" }).text("IAT Traveller ID: ").rEnd().r({ size: "14" }).text(imageMeta.travellerId).rEnd().pEnd();
    imageMeta.imageId && doc.p().r({ bold: true, size: "14" }).text("Image ID: ").rEnd().r({ size: "14" }).text(imageMeta.imageId).rEnd().pEnd();
    imageMeta.imageType && doc.p().r({ bold: true, size: "14" }).text("Image Type: ").rEnd().r({ size: "14" }).text(imageMeta.imageType).rEnd().pEnd();
    imageMeta.created && doc.p().r({ bold: true, size: "14" }).text("Image Source: ").rEnd().r({ size: "14" }).text(imageMeta.source).rEnd().pEnd();
    imageMeta.created && doc.p().r({ bold: true, size: "14" }).text("Created Time (UTC): ").rEnd().r({ size: "14" }).text(imageMeta.created).rEnd().pEnd();

    doc.rEnd().pEnd().tcEnd();
    doc.trEnd().tblEnd();
}

const buildProfile = (profile: IEntityProfileModel, doc: DocxBuilder, imageProps?: IImageProps, imageMeta?: IImageMeta): Promise<any> => {

    // title
    doc.p({ justification: "start" }).r({ bold: true, size: "28", color: "005a9e" }).text("Entity Biographic Data").rEnd().pEnd();

    if (imageMeta) {
        buildImageSection(profile, doc, imageProps, imageMeta);
    }

    // biographic report
    buildBiographic(profile, doc);

    // primary comments
    buildComments(profile.comments, doc);

    // sources
    let sp: Promise<any>;
    profile.sources.forEach(source => {
        source.groups.forEach(g => {
            if (!sp) {
                sp = buildProfileSourceGroup(g, doc);
            } else {
                sp = sp.then(() => {
                    return buildProfileSourceGroup(g, doc);
                });
            }
        });
    });

    //Page break after each client
    sp.then(() => {
        doc.applyPageBreak();
    });

    return sp || Promise.resolve();
};

const getImageAspectRatio = (imageBase64: string, contentType: string): Promise<number> => {
    return new Promise((resolve, reject) => {
        let image = new Image();
        image.onload = () => {
            let aspectRatio = image.width / image.height;
            resolve(aspectRatio)
        };
        image.onerror = (err) => {
            reject(err);
        };
        image.src = `data:${contentType};base64,${imageBase64}`;
    })
};

const writeImage = (zip: JSZip, rId: string, imageBase64: string, contentType: string): Promise<string> => {
    return zip.file(ZIP_CONTENT_TYPES_PATH).async("string").then(xml => {
        let contentTypeDef = getContentTypeDef(contentType);
        let match = RegExp(contentTypeDef, 'ig').exec(xml);
        if (!match) {
            match = RegExp(CONTENT_TYPE_REGEX, 'ig').exec(xml);
            if (!match || match.length != 3) {
                return Promise.reject(`Cannot find pattern ${contentTypeDef} in content types file ${ZIP_CONTENT_TYPES_PATH}`);
            }
            zip.remove(ZIP_CONTENT_TYPES_PATH);
            zip.file(ZIP_CONTENT_TYPES_PATH, match[1] + contentTypeDef + match[2]);
        }
        return zip.file(ZIP_RESOURCE_PATH).async("string").then(xml => {
            let match = RegExp(RESOURCE_REL_REGEX, 'ig').exec(xml);
            if (!match || match.length != 3) {
                return Promise.reject(`Cannot find pattern ${RESOURCE_REL_REGEX} in resource file ${ZIP_RESOURCE_PATH}`);
            }
            let ext = getExt(contentType);
            zip.remove(ZIP_RESOURCE_PATH);
            zip.file(ZIP_RESOURCE_PATH, match[1] + getResourceRelXml(rId, ext) + match[2]);
            zip.file(`word/media/${rId}.${ext}`, imageBase64, { base64: true });
        });
    });
};

const writeData = (docXml: string, dataXml: string): string => {
    let r = docXml;
    let match = RegExp(DOC_REGEX, 'ig').exec(r);
    if (match) {
        r = match[1] + dataXml + match[3];
    }
    return r;
};

const createProfileListDocument = (profileList: IEntityProfileListModel, template: IEntityProfileTemplateEntry): Promise<any> => {
    return getTemplateBinaryContent(template.path).then(binary => {
        return new JSZip().loadAsync(binary).then(zip => {
            return zip.file(ZIP_DOC_PATH).async("string").then(docXml => {
                const doc = new DocxBuilder();
                doc.startDocument();
                let profilesPromise = Promise.resolve();
                let uIdSeq = RESOURCE_ID_SEQ_START;
                profileList.profiles.forEach(profile => {
                    profilesPromise = profilesPromise.then(() => {
                        return profile.entity.entityPhotos.getPhotos(profile.entity.masterEntityId);
                    }).then((photos: IEntityPhoto[]) => {
                        if (photos && photos.length > 0) {
                            let photo = photos[0];
                            return getImageAspectRatio(photo.IMAGE_DATA, photo.ENCODING).then((aspectRatio: number) => {
                                let uId = ++uIdSeq;
                                let rId = `rId${String(uId)}`;
                                let width = SCALED_IMAGE_WIDTH;
                                let height = Math.floor(width / aspectRatio);
                                let imageMeta: IImageMeta = {
                                    travellerId: photo.IAT_TRAVELLER_ID,
                                    imageId: photo.IMAGE_ID,
                                    imageType: photo.IMAGE_TYPE,
                                    source: `Smartgate - ${photo.IMAGE_SOURCE}`,
                                    created: DateUtils.dataTimestampToOutputText(photo.CREATED_DATETIME)
                                }
                                return writeImage(zip, rId, photo.IMAGE_DATA, photo.ENCODING).then(() => {
                                    let imageProps = { rId: rId, uId: uId, width: width, height: height };
                                    return buildProfile(profile, doc, imageProps, imageMeta);
                                });
                            });
                        } else {
                            return buildProfile(profile, doc);
                        }
                    }).catch(error => {
                        return buildProfile(profile, doc);
                    });
                });
                return profilesPromise.then(() => {
                    doc.endDocument();
                    let resultString = "";
                    const cl = doc.result.childNodes.length;
                    for (let i = 0; i < cl; i++) {
                        resultString += NodeSerializerContext.value.serializeNode(doc.result.childNodes.item(i));
                    }
                    let dataXml = writeData(docXml, resultString);
                    zip.remove(ZIP_DOC_PATH);
                    zip.file(ZIP_DOC_PATH, dataXml);
                    return zip.generateAsync({
                        type: "blob",
                        mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    });
                });
            });
        });
    });
};

const createDocument = (profileList: IEntityProfileListModel, template: IEntityProfileTemplateEntry): Promise<any> => {
    if (profileList.profiles.length > 0) {
        return createProfileListDocument(profileList, template).then(r => {
            saveAs(r, "results.docx");
        });
    }
    return Promise.reject({ message: "No Entity Profiles available" });
};

const buildSectionHeader = (title: string, doc: DocxBuilder) => {
    doc.p({ justification: "start" }).r({ bold: true, size: "20", color: "212121" }).text(title).rEnd().pEnd();
};

const buildSectionSubHeader = (title: string, doc: DocxBuilder) => {
    doc.p({ justification: "start" }).r({ bold: true, size: "14", color: "212121" }).text(title).rEnd().pEnd();
};

const cellShading = {
    val: "clear",
    color: "005a9e",
    fill: "005a9e"
};

const tableBorder = {
    val: "single",
    space: "0",
    size: "6",
    color: "black"
};

const buildTable = (items: any[], columns: IColumn[], doc: DocxBuilder) => {
    doc.tbl({
        borders: {
            top: tableBorder,
            start: tableBorder,
            bottom: tableBorder,
            end: tableBorder,
            insideH: tableBorder,
            insideV: tableBorder
        },
        style: "TableGrid",
        layout: "autofit",
        preferredWidth: { type: "pct", w: "100%" }
    }).tr();
    columns.forEach(c => {
        doc.tc({
            shading: cellShading
        }).p({ justification: "center" }).r({ bold: true, size: "12", color: "FFFFFF" }).text(c.name).rEnd().pEnd().tcEnd();
    });
    doc.trEnd();
    items.forEach(item => {
        doc.tr();
        const rt = getRowText(item, columns);
        rt.forEach(t => {
            doc.tc().p({ justification: "left" }).r({ size: "12" }).text(t || "").rEnd().pEnd().tcEnd();
        });
        doc.trEnd();
    });
    doc.tblEnd().p({ justification: "start" }).r({ size: "1", color: "212121" }).text(" ").rEnd().pEnd();
};

const buildSectionTable = (items: any[], columns: IColumn[], doc: DocxBuilder) => {
    if (items.length < 1) {
        return;
    }
    const sectionTableBorderBottom = {
        val: "single",
        space: "0",
        size: "1",
        color: "C1C1C1"
    };
    const sectionCellContentShading = {
        val: "clear",
        color: "474747",
        fill: "FFFFFF"
    };
    const sectionTableBorder = {
        val: "none",
        space: "0"
    };
    doc.tbl({
        borders: {
            top: sectionTableBorder,
            start: sectionTableBorder,
            bottom: sectionTableBorder,
            end: sectionTableBorder,
            insideH: sectionTableBorder,
            insideV: sectionTableBorder
        },
        style: "Plain Table 4",
        layout: "autofit",
        preferredWidth: { type: "pct", w: "100%" }
    }).tr();
    columns.forEach(c => {
        doc.tc({
            shading: sectionCellContentShading,
            borders: {
                top: sectionTableBorder,
                start: sectionTableBorder,
                bottom: sectionTableBorderBottom,
                end: sectionTableBorder
            }
        }).p({ justification: "left" }).r({ bold: false, size: "12", color: "000000" }).text(c.name).rEnd().pEnd().tcEnd();
    });
    doc.trEnd();
    items.forEach(item => {
        doc.tr();
        const rt = getRowText(item, columns);
        rt.forEach(t => {
            doc.tc().p({ justification: "left" }).r({ size: "12", color: "474747" }).text(t || "").rEnd().pEnd().tcEnd();
        });
        doc.trEnd();
    });
    doc.tblEnd().p({ justification: "start" }).r({ size: "1", color: "212121" }).text(" ").rEnd().pEnd();
};

const buildSectionList = (items: any[], columns: IColumn[], doc: DocxBuilder) => {
    const mapToIColumnModel = (item: IDetailsAttributeConfig<any>): IColumn => {
        return Object.assign({}, item, {
            fieldName: item.key,
            minWidth: 50
        });
    };

    const sectionTopTableBorder = {
        val: "single",
        space: "0",
        size: "1",
        color: "C1C1C1"
    };
    const sectionTableBorder = {
        val: "none",
        space: "0"
    };
    const tableParagraphProps = { justification: "left", before: "0 pt", after: "0 pt" };

    columns = columns.map(col => col.fieldName ? col : mapToIColumnModel(col));

    items.forEach((item, index) => {
        doc.tbl({
            borders: {
                top: sectionTopTableBorder,
                start: sectionTopTableBorder,
                bottom: sectionTopTableBorder,
                end: sectionTopTableBorder,
                insideH: sectionTableBorder,
                insideV: sectionTableBorder
            },
            layout: "autofit",
            preferredWidth: { type: "pct", w: "100%" },
        }).tr();
        let halfWayThough = Math.floor(columns.length / 2);
        halfWayThough = (columns.length % 2 === 1) ? halfWayThough + 1 : halfWayThough;
        let obj1 = columns.slice(0, halfWayThough);
        let obj2 = columns.slice(halfWayThough, columns.length);

        let grid = [obj1, obj2];
        var pIndex = -1;
        grid.forEach(gridcol => {
            doc.tc({
                margins: {
                    top: { w: "0" },
                    bottom: { w: "0" },
                    start: { w: "0" },
                    end: { w: "0" },
                }, hAlign: "left",
                preferredWidth: { type: "pct", w: "50%" }
            }).p(tableParagraphProps).r({
                bold: false,
                color: "000000",
                size: "12"
            });
            doc.tbl({
                borders: {
                    top: sectionTopTableBorder,
                    start: sectionTableBorder,
                    bottom: sectionTableBorder,
                    end: sectionTableBorder,
                    insideH: sectionTableBorder,
                    insideV: sectionTableBorder
                },
                layout: "fixed",
                preferredWidth: { type: "pct", w: "100%" }
            });
            gridcol.forEach(col => {
                pIndex = pIndex + 1;
                doc.tr();
                doc.tc({ preferredWidth: { type: "pct", w: "50%" } }).p(tableParagraphProps).r({
                    bold: true,
                    color: "000000",
                    size: "12"
                }).text(col.name).rEnd().pEnd().tcEnd().tc({ preferredWidth: { type: "pct", w: "50%" } }).p(tableParagraphProps).r({
                    bold: false,
                    color: "000000",
                    size: "12"
                }).text(getColumnText(item, col, pIndex).trim() === "" ? "-" : getColumnText(item, col, pIndex)).rEnd().pEnd().tcEnd();
                doc.trEnd();
            });


            doc.tblEnd();

            doc.rEnd().pEnd().tcEnd()
        });
        doc.trEnd().tblEnd();
    });
};

export {
    createDocument,
    buildSectionHeader,
    buildSectionSubHeader,
    buildTable,
    buildComments,
    buildSectionTable,
    buildSectionList
}