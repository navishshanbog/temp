import { Router } from "@twii/common/lib/Router";
import { reactRouter } from "@twii/common/lib/Routers";

const r = new Router();
r.use("/BAGS/activity", reactRouter(() => import("../../bags/component/EntityProfileBAGS")));
r.use("/ABR/activity", reactRouter(() => import("../../abr/component/EntityProfileABR")));
r.use("/DGMS/activity", reactRouter(() => import("../../dgms/component/EntityProfileDGMS")));

const examsActivityHandler = reactRouter(() => import("../../exams/component/EntityProfileEXAMS"));
r.use("/EXAM/activity", examsActivityHandler);
r.use("/EXAMS/activity", examsActivityHandler);

r.use("/IAT/movement", reactRouter(() => import("../../iat/component/EntityProfileIAT")));

const iataAgencyHandler = reactRouter(() => import("../../iata/component/EntityProfileIATA"));
r.use("/IATA/agency", iataAgencyHandler);

r.use("/INTCP/movement", reactRouter(() => import("../../intcp/component/EntityProfileINTCP")));
r.use("/INTCP/org", reactRouter(() => import("../../intcp/component/EntityProfileINTCP"), { exportKey: "EntityProfileINTCPOrgSummaryApp" }));

r.use("/ICS/activity/air", reactRouter(() => import("../../cargo/component/EntityProfileCargo"), { exportKey: "EntityProfileAirCargoApp"}));
r.use("/ICS/activity/sea", reactRouter(() => import("../../cargo/component/EntityProfileCargo"), { exportKey: "EntityProfileSeaCargoApp" }));

r.use("/ICSE/activity/visa/application", reactRouter(() => import("../../icse/component/EntityProfileVisaDealingsApp"), { exportKey: "EntityProfileVisaApplicationsApp" }));
r.use("/ICSE/activity/visa/cancellation", reactRouter(() => import("../../icse/component/EntityProfileVisaDealingsApp"), { exportKey: "EntityProfileVisaCancellationsApp" }));

r.use("/TRIPS/activity/visa", reactRouter(() => import("../../trips/component/EntityProfileTRIPSActivitiesApp"), { exportKey: "EntityProfileTRIPSVisasApp" }));
r.use("/TRIPS/activity/movement", reactRouter(() => import("../../trips/component/EntityProfileTRIPSActivitiesApp"), { exportKey: "EntityProfileTRIPSMovementsApp" }));

r.use("/EROLL/entity", reactRouter(() => import("../../eroll/component/EntityProfileEROLL")));

export { r as default, r as EntityProfileViewRouter }