import IMasterEntitySourceModel from "../IMasterEntitySourceModel";
import IEntityProfileModel from "./IEntityProfileModel";
import IEntityProfileSourceGroupModel from "./IEntityProfileSourceGroupModel";

interface IEntityProfileSourceModel  {
    profile: IEntityProfileModel;
    entitySource: IMasterEntitySourceModel;
    groups: IEntityProfileSourceGroupModel[];
    addItems(type : string, items: any[]) : void;
    removeGroup(items : IEntityProfileSourceGroupModel) : void;
}



export { IEntityProfileSourceModel as default, IEntityProfileSourceModel };