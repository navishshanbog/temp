import { observable, action, computed } from "mobx";
import IEntityProfileModel from "./IEntityProfileModel";
import IEntityProfileSourceModel from "./IEntityProfileSourceModel";
import IMasterEntityModel from "../IMasterEntityModel";
import IMasterEntitySourceModel from "../IMasterEntitySourceModel";
import EntityProfileSourceModel from "./EntityProfileSourceModel";
import IEntitySourceItems from "../IEntitySourceItems";

class EntityProfileModel implements IEntityProfileModel {
    @observable private _entity : IMasterEntityModel;
    @observable sources : IEntityProfileSourceModel[] = [];
    @observable comments : string;

    constructor(entity : IMasterEntityModel) {
        this._entity = entity;
    }

    @computed
    get entity() {
        return this._entity;
    }

    @action
    setComments(comments : string) {
        this.comments = comments;
    }
    
    @action
    addEntitySourceItems(e : IEntitySourceItems) : void {
        if(e.type && e.items) {
            e.items.forEach(item => {
                if(item.source) {
                    const source = item.source as IMasterEntitySourceModel;
                    let profileSource = this.sources.find(item => item.entitySource.sourceSystemCode === source.sourceSystemCode);
                    if(!profileSource) {
                        profileSource = new EntityProfileSourceModel(this, source);
                        this.sources.push(profileSource);
                    }
                    profileSource.addItems(e.type, [item]);
                }
            });
        }
    }

    @action
    removeAll() {
        this.sources = [];
    }

    @action
    clear() {
        this.removeAll();
    }
}

export { EntityProfileModel as default, EntityProfileModel }