import {observable, action, computed} from "mobx";
import IEntityProfileListModel from "./IEntityProfileListModel";
import IEntityProfileModel from "./IEntityProfileModel";
import IMasterEntitySourceModel from "../IMasterEntitySourceModel";
import EntityProfileModel from "./EntityProfileModel";
import IEntitySourceItems from "../IEntitySourceItems";


class EntityProfileListModel implements IEntityProfileListModel {
    @observable profiles: IEntityProfileModel[] = [];

    @action
    addEntitySourceItems(e : IEntitySourceItems) : void {
        if(e.type && e.items) {
            e.items.forEach(item => {
                if(item.source) {
                    const source = item.source as IMasterEntitySourceModel;
                    let profile = this.profiles.find(item => item.entity.masterEntityId === source.masterEntity.masterEntityId);
                    if(!profile) {
                        profile = new EntityProfileModel(source.masterEntity);
                        this.profiles.push(profile);
                    }
                    profile.addEntitySourceItems({ type: e.type, items: [item] });
                }
            });
        }
    }

    @action
    clear() {
        this.profiles = [];
    }
}

export { EntityProfileListModel as default, EntityProfileListModel }