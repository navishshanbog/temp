import * as React from "react";
import { Router } from "@twii/common/lib/Router";
import { reactRouter } from "@twii/common/lib/Routers";
const r = new Router();

const passportActivityHandler = reactRouter(() => import("../../iat/component/IATMovementProfilePassports"));
r.use("/IAT/passport", passportActivityHandler);

const visasActivityHandler = reactRouter(() => import("../../iat/component/IATMovementProfileVisas"));
r.use("/IAT/visa", visasActivityHandler);
r.use("/IAT/Visa", visasActivityHandler);

const iatAliasesActivityHandler = reactRouter(() => import("../../iat/component/IATMovementProfileAliases"));
r.use("/IAT/IATAliases", iatAliasesActivityHandler);

const iatMovementDetailsActivityHandler = reactRouter(() => import("../../iat/component/IATMovementProfileDetail"));
r.use("/IAT/movementDetails", iatMovementDetailsActivityHandler);

const seaCargoReportInfoActivityHandler = reactRouter(() => import("../../cargo/sea/component/SeaCargoActivityDetailProfileInfo"));
r.use("/ICS/sea/cargoReport", seaCargoReportInfoActivityHandler);

const airCargoReportInfoActivityHandler = reactRouter(() => import("../../cargo/air/component/AirCargoActivityDetailProfileInfo"));
r.use("/ICS/air/cargoReport", airCargoReportInfoActivityHandler);

const IATAAgencyDetailsHandler = reactRouter(() => import("../../iata/component/IATAAgencyProfileDetail"));
r.use("/IATA/IATAAgency", IATAAgencyDetailsHandler);

const abrDetailsHandler = reactRouter(() => import("../../abr/component/EntityProfileABRDetails"));
r.use("/ABR/detail", abrDetailsHandler);

const visaApplicationClientsHandler = reactRouter(() => import("../../icse/component/VisaApplicationProfileClients"));
r.use("/ICSE/clients", visaApplicationClientsHandler);

export { r as default, r as SubEntityProfileViewRouter }