import { observable, action, computed } from "mobx";
import IEntityProfileSourceModel from "./IEntityProfileSourceModel";
import IEntityProfileSourceGroupModel from "./IEntityProfileSourceGroupModel";
import * as isEqual from "lodash.isequal";
import IEntitySourceItems from "../IEntitySourceItems";

class EntityProfileSourceGroupModel implements IEntityProfileSourceGroupModel {
    @observable private _source : IEntityProfileSourceModel;
    @observable subEntities : IEntitySourceItems[] = [];
    @observable private _type : string;
    @observable items: any[] = [];
    @observable open : boolean = true;
    @observable comments : string;
    @observable hasSubTypes: boolean = false;


    constructor(source : IEntityProfileSourceModel, type : string) {
        this._source = source;
        this._type = type;
    }

    @computed
    get source() {
        return this._source;
    }

    @computed
    get type() {
        return this._type;
    }

    @action
    addItems(items : any[]) {
        if(items && items.length > 0) {
            items.forEach(n => {
                if(n.sourceSubItemType){
                    let subEntityProfile: IEntitySourceItems = {
                        type: n.sourceSubItemType,
                        items: [{
                            subItems: n.items,
                            sourceSubItemHeader: n.sourceSubItemHeader
                        }]
                    };
                    // const existing = this.subEntities.find(item => isEqual(item, subEntityProfile));
                    let existing = false;
                    this.subEntities.forEach(sEntity => {
                        sEntity.items.forEach(se => {
                            if(se.sourceSubItemHeader == n.sourceSubItemHeader) { existing = true; return; }
                        });
                    });
                    if (!existing) {
                        this.hasSubTypes = true;
                        this.subEntities.push(subEntityProfile);
                    }
                } else {
                    const existing = this.items.find(item => isEqual(item, n));
                    if (!existing) {
                        this.items.push(n);
                    }
                }
            });
        }
    }

    @action
    removeItem(item : any) {
        const idx = this.items.indexOf(item);
        if(idx >= 0) {
            this.items.splice(idx, 1);
        }
        if(this.items.length === 0 && !this.hasSubTypes) {
            this.remove();
        }
    }

    @action
    removeSubItem (item: any, index: number) {
        this.subEntities.splice(index, 1);
        if(this.subEntities.length <= 0) {
            this.hasSubTypes = false;
            if(this.items.length ===0 ) this.remove();
        }
    }

    @action
    remove() {
        this._source.removeGroup(this);
    }

    @action
    setOpen(open : boolean) : void {
        this.open = open;
    }

    @action
    setComments(comments : string) : void {
        this.comments = comments;
    }
}

export { EntityProfileSourceGroupModel as default, EntityProfileSourceGroupModel }