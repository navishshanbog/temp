import IMasterEntityModel from "../IMasterEntityModel";
import IEntityProfileSourceModel from "./IEntityProfileSourceModel";
import IEntitySourceItems from "../IEntitySourceItems";

interface IEntityProfile {
    entity: IMasterEntityModel;
    sources: IEntityProfileSourceModel[];
    comments: string;
    addEntitySourceItems(value : IEntitySourceItems) : void;
    setComments(comments : string) : void;
    removeAll();
    clear();
}

export { IEntityProfile as default, IEntityProfile }