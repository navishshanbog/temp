import IEntitySourceItems from "../IEntitySourceItems";
import IEntityProfileSourceModel from "./IEntityProfileSourceModel";

interface IEntitySourceProfileSourceGroupModel extends IIEntitySourceProfileSourceSubGroupProfile {
    source: IEntityProfileSourceModel;
    type: string;
    items: any[];
    open: boolean;
    comments: string;
    addItems(items: any[]) : void;
    removeItem(item : any) : void;
    remove() : void;
    setOpen(open : boolean) : void;
    setComments(comments : string) : void;
    removeSubItem(item: any, index: number): void;
}

interface IIEntitySourceProfileSourceSubGroupProfile {
    hasSubTypes?: boolean;
    subEntities?: IEntitySourceItems[];
}
export { IEntitySourceProfileSourceGroupModel as default, IEntitySourceProfileSourceGroupModel, IIEntitySourceProfileSourceSubGroupProfile }