import { action, IAction } from "mobx";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { IMasterEntitySearchRequest } from "./IMasterEntitySearchRequest";
import { IMasterEntitySearchResultItem } from "./IMasterEntitySearchResultItem";
import { MasterEntitySearchHistoryStore } from "./MasterEntitySearchHistoryStore";
import { IEntityPreferences } from "./IEntityPrefences";
import { IRequest } from "@twii/common/lib/IRequest";
import { MasterEntityVisitedHistoryStore } from "./MasterEntityVisitedHistoryStore";
import { ISearchField } from "@twii/common/lib/search/ISearchField";
import { openValueSearch as openValueSearchNEW } from "../search/EntitySearchActions";
import { createSearchRequest } from "./MasterEntitySearchHelper";
import { PreferencesSupplier } from "../common/model/PreferencesSupplier";
import { PathsContext } from "../PathsContext";

const loadSearch = action((host: IAppHost) => {
    host.load({ path: PathsContext.value.search() });
});

const openSearchLink = (host: IAppHost, request: IRequest, items?: IMasterEntitySearchResultItem) => {
    PreferencesSupplier.load().then(() => {
        const prefs: IEntityPreferences = PreferencesSupplier.value || { isLinkOpenInANewWindow: true };
        if (prefs.isLinkOpenInANewWindow) {
            host.open(Object.assign({}, request, { transient: true, makeActive: true })).then(host => {
                console.log(host);
            })
        } else {
            host.load(request).then(host => {
                console.log(host);
            });
        }
        request.path &&
            request.path.split("/").filter(i => i.indexOf("-") !== -1).forEach(i => {
                i.split("-").forEach(j => {
                    updateVisitedItemsList(host, j);
                })
            });
    });
};

const openNewSearch = action((host: IAppHost, request: IMasterEntitySearchRequest) => {
    MasterEntitySearchHistoryStore.addEntry(request);
    openSearchLink(host, { path: PathsContext.value.searchResult(), query: request });
    
});

const submitRequest = action((host: IAppHost, request: IMasterEntitySearchRequest) => {
    // clear any search results or details on the host
    clearSearchResult(host);
    MasterEntitySearchHistoryStore.addEntry(request);
    host.load({ path: PathsContext.value.searchResult(), query: request });
});

const loadSearchResult = action((host: IAppHost) => {
    host.load({ path: PathsContext.value.searchResult() });
});

const loadSearchResultItem = action((host: IAppHost, item: IMasterEntitySearchResultItem) => {
    host.setState({ compositeEntity: null });
    openSearchLink(host, { path: PathsContext.value.entity(item.mstrEntyId) });
    updateVisitedItemsList(host, item.mstrEntyId);
});

const loadSearchResultItems = action((host: IAppHost, items: IMasterEntitySearchResultItem[]) => {
    host.setState({ compositeEntity: null });
    const entityIds = items.map(item => String(item.mstrEntyId));
    const entityId = entityIds.join("-");
    openSearchLink(host, { path: PathsContext.value.entity(entityId) });
});

const openSearchResultItem = action((host: IAppHost, item: IMasterEntitySearchResultItem) => {
    host.setState({ entitySearchResultItem: item });
    loadSearchResultItem(host, item);
});

const openSearchResultItems = action((host: IAppHost, items: IMasterEntitySearchResultItem[]) => {
    if (items && items.length > 0) {
        if (items.length === 1) {
            openSearchResultItem(host, items[0]);
        } else {
            host.setState({ entitySearchResultItems: items, entitySearchResultItem: null });
            //Forcing results table refresh...
            loadSearchResultItems(host, items);
        }
    }
});

const clearSearchResult = action((host: IAppHost) => {
    host.setState({ entitySearchResult: null, entitySearchResultItem: null, entitySearchResultItems: null });
});

const updateVisitedItemsList = action((host: IAppHost, mstrEntyId: string) => {
    MasterEntityVisitedHistoryStore.addEntry(mstrEntyId);
});

const clearVisitedItemsList = action(() => {
    return MasterEntityVisitedHistoryStore.clearItems();
});

const isEntityVisited = action((mstrEntyId: string): boolean => {
    return MasterEntityVisitedHistoryStore.items.some(i => String(i.value) === String(mstrEntyId));
});

const openValueSearch = (host : IAppHost, value : ISearchField, useNew: boolean = false) => {
    if(useNew) {
        return openValueSearchNEW(host, value);
    }
    return openNewSearch(host, createSearchRequest(value));
};

export {
    loadSearch,
    submitRequest,
    openNewSearch,
    loadSearchResult,
    clearSearchResult,
    loadSearchResultItem,
    loadSearchResultItems,
    openSearchResultItem,
    openSearchResultItems,
    clearVisitedItemsList,
    isEntityVisited,
    openValueSearch
}

