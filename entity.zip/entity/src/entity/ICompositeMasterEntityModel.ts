import { IMasterEntityModel } from "./IMasterEntityModel";

// this whole entity hierarchy thing should probably become a bloody tree structure

interface ICompositeMasterEntityModel extends IMasterEntityModel {
    entities : IMasterEntityModel[];
}

export { ICompositeMasterEntityModel }