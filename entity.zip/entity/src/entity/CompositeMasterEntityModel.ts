import { observable, action, computed } from "mobx";
import { IMasterEntityModel } from "./IMasterEntityModel";
import { IMasterEntity } from "./IMasterEntity";
import { MasterEntityModel } from "./MasterEntityModel";
import { IMasterEntitySourceModel } from "./IMasterEntitySourceModel";
import { ICompositeMasterEntityModel } from "./ICompositeMasterEntityModel";
import { AbstractMasterEntityModel } from "./AbstractMasterEntityModel";
import { masterEntityIdSeparator } from "./MasterEntityHelper";
import { join } from "@twii/common/lib/util/String";

class CompositeMasterEntityModel extends AbstractMasterEntityModel<IMasterEntity[]> implements ICompositeMasterEntityModel {
    @observable private _entities : IMasterEntityModel[] = [];

    constructor(data?: IMasterEntity[]) {
        super();
        this.setData(data);
    }

    get isComposite() {
        return true;
    }

    @computed
    get nisName() {
        return join(this.entities, e => e.nisName, " | ");
    }

    @computed
    get entities() {
        return this._entities.slice(0);
    }

    @action
    setEntities(entities : IMasterEntityModel[]) {
        this._entities = [];
        if(entities) {
            entities.forEach(e => {
                this._entities.push(e);
            });
        }
    }

    @computed
    get masterEntityId() {
        return this.masterEntityIds.length > 0 ?  this.masterEntityIds.join(masterEntityIdSeparator) : undefined;
    }

    @computed
    get masterEntityIds() {
        const r : string[] = [];
        this._entities.forEach(e => {
            const id = e.masterEntityId;
            if(id) {
                if(r.indexOf(id) < 0) {
                    r.push(id);
                }
            }
        });
        return r;
    }

    @computed
    get data() : IMasterEntity[] {
        return this._entities.map(e => e.data);
    }
    set data(value) {
        this.setData(value);
    }

    @action
    setData(data : IMasterEntity[]) {
        this._entities = [];
        if(data) {
            data.forEach(d => {
                this._entities.push(new MasterEntityModel(d));
            });
        }
    }

    @computed
    get sources() {
        const sources : IMasterEntitySourceModel[] = [];
        this._entities.forEach(e => {
            e.sources.forEach(entitySource => {
                sources.push(entitySource);
            });
        });
        return sources;
    }
}

export { CompositeMasterEntityModel as default, CompositeMasterEntityModel }