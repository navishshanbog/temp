import { IActivityListModel } from "@twii/common/lib/model/IActivityListModel";
import { IMasterEntityModel } from "./IMasterEntityModel";
import { IMasterEntitySourceModel } from "./IMasterEntitySourceModel";

interface IMasterEntitySourceListModel<T> extends IActivityListModel<T> {
    sourceSystemCode : string;
    entity: IMasterEntityModel;
    sources: IMasterEntitySourceModel[];
}

export { IMasterEntitySourceListModel as default, IMasterEntitySourceListModel }