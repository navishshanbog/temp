import ElementBuilder from "@twii/common/lib/xml/ElementBuilder";

interface IBaseProps {
    bold?: boolean;
    italic?: boolean;
}

interface IParagraphProps extends IBaseProps {
    justification?: string;
    adjustRightInd?: boolean;
    autoSpaceDE?: boolean;
    autoSpaceDN?: boolean;
    after?: string;
    before?: string
    line?: string;
    lineRule?: string;
}
interface ITabProps {
    leader?: string;
    pos: string;
    val: string;
}

interface IRunProps extends IBaseProps {
    complexScriptBold?: boolean;
    bidirectionalOverride?: string;
    color?: string;
    size?: string;
}

interface ITyped {
    type?: string;
}

interface ITableWidth extends ITyped {
    w?: string;
}

interface ITableBorder {
    val?: string;
    size?: string;
    space?: string;
    color?: string;
    themeColor?: string;
}

interface ITableBorders {
    top?: ITableBorder;
    start?: ITableBorder;
    bottom?: ITableBorder;
    end?: ITableBorder;
    insideH?: ITableBorder;
    insideV?: ITableBorder;
}

interface ITableProps {
    preferredWidth?: ITableWidth;
    layout?: string;
    borders?: ITableBorders;
    look?: ITableLookProps;
    style?: string;
}

interface ITableRowHeight {
    val: string;
    hRule: string;
}

interface ITableRowProps {
    trHeight: ITableRowHeight;
    tableExceptions: ITableProps;
}

interface ITableCellBorders {
    top?: ITableBorder;
    start?: ITableBorder;
    bottom?: ITableBorder;
    end?: ITableBorder;
}

interface ITableCellMargins {
    top?: ITableWidth;
    start?: ITableWidth;
    bottom?: ITableWidth;
    end?: ITableWidth;
}

interface IShadingProps {
    val?: string;
    color?: string;
    fill?: string;
    themeColor?: string;
    themeFill?: string;
    themeFillShade?: string;
    themeFillTint?: string;
    themeShade?: string;
    themeTint?: string;
}

interface ITableCellProps {
    id?: string;
    preferredWidth?: ITableWidth;
    margins?: ITableCellMargins;
    textDirection?: string;
    shading?: IShadingProps;
    borders?: ITableCellBorders;
    fitText?: boolean;
    vMerge?: string;
    hMerge?: string;
    vAlign?: string;
    hAlign?: string;
}

interface ITableLookProps {
    firstColumn?: boolean;
    firstRow?: boolean;
    lastColumn?: boolean;
    lastRow?: boolean;
    noHBand?: boolean;
    noVBand?: boolean;
}

interface IImageProps {
    rId: string
    uId: number;
    width: number;
    height: number;
}

interface IContentHandler {
    (context: DocxBuilder): void;
}

const mainNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
const wpDrawingNamespace = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing";
const drawingNamespace = "http://schemas.openxmlformats.org/drawingml/2006/main";
const pictureNamespace = "http://schemas.openxmlformats.org/drawingml/2006/picture";
const relNamespace = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const dNamespace = "http://schemas.microsoft.com/office/drawing/2010/main";

class DocxBuilder {
    private _a = new ElementBuilder();
    private _startElement(name: string, prefix?: string, namespaceURI?: string) {
        this._a.startElement({ prefix: prefix || "w", namespaceURI: namespaceURI || mainNamespace, name: name });
    }
    private _startEndElement(name: string) {
        this._startElement(name);
        this._endElement();
    }
    private _attr(name: string, value: string) {
        if (value !== undefined) {
            this._a.attribute({ prefix: "w", namespaceURI: mainNamespace, name: name, value: value });
        }
    }
    private _valAttr(value: string) {
        this._attr("val", value);
    }
    private _valElement(name: string, value: string) {
        if (value !== undefined) {
            this._startElement(name);
            this._valAttr(value);
            this._endElement();
        }
    }
    private _toggleValElement(name: string, value?: boolean) {
        if (value !== undefined) {
            this._valElement(name, value ? "true" : "false");
        }
    }
    private _paragraphProps(props: IParagraphProps) {
        this._startElement("pPr");
        this._baseProps(props);
        this._valElement("jc", props.justification);
        this._toggleValElement("adjustRightInd", props.adjustRightInd);
        this._toggleValElement("autoSpaceDE", props.autoSpaceDE);
        this._toggleValElement("autoSpaceDN", props.autoSpaceDN);
        this._startElement("spacing");
        this._attr("line", props.line);
        this._attr("lineRule", props.lineRule);
        this._attr("before", props.before);
        this._attr("after", props.after);
        this._endElement();
        this._endElement();
        return this;
    }
    private _tabProps(props: ITabProps) {
        this._startElement("tab");
        this._valAttr(props.val);
        this._attr("pos", props.pos);
        this._attr("leader", props.leader || "none");
        this._endElement();
        return this;
    }
    startDocument() {
        this._startElement("document");
    }
    endDocument() {
        this._endElement();
    }
    startParagraph(props?: IParagraphProps) {
        this._startElement("p");
        if (props) {
            this._paragraphProps(props);
        }
        return this;
    }
    endParagraph() {
        this._endElement();
        return this;
    }
    pEnd() {
        return this.endParagraph();
    }
    paragraph(props?: IParagraphProps, contentHandler?: IContentHandler) {
        this.startParagraph(props);
        if (contentHandler) {
            contentHandler(this);
            this.endParagraph();
        }
        return this;
    }
    p(props?: IParagraphProps, contentHandler?: IContentHandler) {
        return this.paragraph(props, contentHandler);
    }
    _attrNs(name: string, value: string, prefix?: string, namespaceURI?: string) {
        if (value !== undefined) {
            this._a.attribute({ name: name, value: value, prefix: prefix, namespaceURI: namespaceURI });
        }
    }
    _attrs(props: any) {
        Object.keys(props).forEach(key => {
            this._attrNs(key, props[key]);
        })
    }
    _blipFill(props: IImageProps) {
        this._startElement("blipFill", "pic", pictureNamespace);
        this._startElement("blip", "a", drawingNamespace);
        this._attrNs("embed", props.rId, "r", relNamespace);
        this._startElement("extLst", "a", drawingNamespace);
        this._startElement("ext", "a", drawingNamespace);
        this._attrs({ uri: "{28A0092B-C50C-407E-A947-70E740481C1C}" });
        this._startElement("useLocalDpi", "a14", dNamespace);
        this._attrs({ val: "0" });
        this._endElement();
        this._endElement();
        this._endElement();
        this._endElement();
        this._startElement("srcRect", "a", drawingNamespace);
        this._endElement();
        this._startElement("stretch", "a", drawingNamespace);
        this._startElement("fillRect", "a", drawingNamespace);
        this._endElement();
        this._endElement();
        this._endElement();
    }
    _pictureRef(props: IImageProps) {
        this._startElement("pic", "pic", pictureNamespace);
        this._startElement("nvPicPr", "pic", pictureNamespace);
        this._startElement("cNvPr", "pic", pictureNamespace);
        this._attrs({ id: String(props.uId), name: "Picture", descr: "image" });
        this._endElement();
        this._startElement("cNvPicPr", "pic", pictureNamespace);
        this._startElement("picLocks", "a", drawingNamespace);
        this._attrs({ noChangeAspect: "1", noChangeArrowheads: "1" });
        this._endElement();
        this._endElement();
        this._endElement();
        this._blipFill(props);
        this._startElement("spPr", "pic", pictureNamespace);
        this._attrs({ bwMode: "auto" });
        this._startElement("xfrm", "a", drawingNamespace);
        this._startElement("off", "a", drawingNamespace);
        this._attrs({ x: "0", y: "0" });
        this._endElement();
        this._startElement("ext", "a", drawingNamespace);
        this._attrs({ cx: String(props.width), cy: String(props.height) });
        this._endElement();
        this._endElement();
        this._startElement("prstGeom", "a", drawingNamespace);
        this._attrs({ prst: "rect" });
        this._startElement("avLst", "a", drawingNamespace);
        this._endElement();
        this._endElement();
        this._startElement("noFill", "a", drawingNamespace);
        this._endElement();
        this._startElement("ln", "a", drawingNamespace);
        this._startElement("noFill", "a", drawingNamespace);
        this._endElement();
        this._endElement();
        this._endElement();
        this._endElement();
    }
    _graphicRef(props: IImageProps) {
        this._startElement("graphic", "a", drawingNamespace);
        this._startElement("graphicData", "a", drawingNamespace);
        this._attrs({ uri: pictureNamespace });
        this._pictureRef(props);
        this._endElement();
        this._endElement();
    }
    imageRef(props: IImageProps) {
        this._startElement("drawing");
        this._startElement("inline", "wp", wpDrawingNamespace);
        this._attrs({ distT: "0", distB: "0", distL: "0", distR: "0" });
        this._startElement("extent", "wp", wpDrawingNamespace);
        this._attrs({ cx: String(props.width), cy: String(props.height) });
        this._endElement();
        this._startElement("effectExtent", "wp", wpDrawingNamespace);
        this._attrs({ l: "0", t: "0", r: "0", b: "0" });
        this._endElement();
        this._startElement("docPr", "wp", wpDrawingNamespace);
        this._attrs({ id: String(props.uId), name: "Image", descr: "image" });
        this._endElement();
        this._startElement("cNvGraphicFramePr", "wp", wpDrawingNamespace);
        this._startElement("graphicFrameLocks", "a", drawingNamespace);
        this._attrs({ noChangeAspect: "1" });
        this._endElement();
        this._endElement();
        this._graphicRef(props);
        this._endElement();
        this._endElement();
        return this;
    }
    startTab(props?: ITabProps) {
        this._startElement("pPr");
        this._startElement("tabs");
        if (props) {
            this._tabProps(props);
        }
        this._endElement();
        this._endElement();
        return this;
    }
    endTab() {
        this._endElement();
        return this;
    }
    et() {
        return this.endTab();
    }
    tab(props?: ITabProps, contentHandler?: IContentHandler) {
        this.startTab(props);
        if (contentHandler) {
            contentHandler(this);
            this.endTab();
        }
        return this;
    }
    t(props?: ITabProps, contentHandler?: IContentHandler) {
        return this.tab(props, contentHandler);
    }

    shorttab() {
        this._startEndElement("tab");
        return this;
    }

    applyBreak() {
        this._startEndElement("br");
        return this;
    }

    applyPageBreak() {
        this._startElement("p");
        this._startElement("r");
        this._startElement("br");
        this._attr("type", "page");
        this._endElement();
        this._endElement();
        this._endElement();
        return this;
    }
    private _baseProps(props: IBaseProps) {
        this._toggleValElement("b", props.bold);
        this._toggleValElement("i", props.italic);
    }
    private _runProps(props: IRunProps) {
        this._startElement("rPr");
        this._baseProps(props);
        this._toggleValElement("bCs", props.complexScriptBold);
        if (props.bidirectionalOverride) {
            this._valElement("bdo", props.bidirectionalOverride);
        }
        if (props.color) {
            this._valElement("color", props.color);
        }
        if (props.size !== undefined) {
            this._valElement("sz", String(props.size));
        }
        this._endElement();
    }
    startRun(props?: IRunProps) {
        this._startElement("r");
        if (props) {
            this._runProps(props);
        }
        return this;
    }
    endRun() {
        this._endElement();
        return this;
    }
    rEnd() {
        return this.endRun();
    }
    run(props?: IRunProps, contentHandler?: IContentHandler) {
        this.startRun(props);
        if (contentHandler) {
            contentHandler(this);
            this.endRun();
        }
        return this;
    }
    r(props?: IRunProps, contentHandler?: IContentHandler) {
        return this.run(props, contentHandler);
    }
    text(value: string) {
        this._startElement("t");
        this._a.attribute({ prefix: "xml", name: "space", value: "preserve" });
        this._a.text(value);
        this._endElement();
        return this;
    }
    private _tableWidth(name: string, value: ITableWidth) {
        if (value && (value.type || value.w)) {
            this._startElement(name);
            this._attr("type", value.type);
            this._attr("w", value.w);
            this._endElement();
        }
    }
    private _typed(name: string, value: ITyped) {
        if (value && value.type) {
            this._startElement(name);
            this._attr("type", value.type);
            this._endElement();
        }
    }
    private _tableBorder(name: string, tableBorder: ITableBorder) {
        if (tableBorder) {
            this._startElement(name);
            this._valAttr(tableBorder.val);
            this._attr("sz", tableBorder.size);
            this._attr("space", tableBorder.space);
            this._attr("color", tableBorder.color);
            this._attr("themeColor", tableBorder.themeColor);
            this._endElement();
        }
    }
    private _tableBorders(tableBorders: ITableBorders) {
        if (tableBorders) {
            this._startElement("tblBorders");
            this._tableBorder("top", tableBorders.top);
            this._tableBorder("start", tableBorders.start);
            this._tableBorder("bottom", tableBorders.bottom);
            this._tableBorder("end", tableBorders.end);
            this._tableBorder("insideH", tableBorders.insideH);
            this._tableBorder("insideV", tableBorders.insideV);
            this._endElement();
        }
    }
    private _tableLayout(layout: string) {
        if (layout) {
            this._startElement("tblLayout");
            this._attr("type", layout);
            this._endElement();
        }
    }
    private _tableLook(props: ITableLookProps) {
        if (props) {
            this._startElement("tblLook");
            this._toggleValElement("firstColumn", props.firstColumn);
            this._toggleValElement("firstRow", props.firstRow);
            this._toggleValElement("lastColumn", props.lastColumn);
            this._toggleValElement("lastRow", props.lastRow);
            this._toggleValElement("noHBand", props.noHBand);
            this._toggleValElement("noVBand", props.noVBand);
            this._endElement();
        }
    }
    private _tableProps(name: string, props: ITableProps) {
        this._startElement(name);
        this._tableWidth("tblW", props.preferredWidth);
        this._tableLayout(props.layout);
        this._tableBorders(props.borders);
        this._tableLook(props.look);
        this._valElement("tblStyle", props.style);
        this._endElement();
    }
    startTable(props?: ITableProps) {
        this._startElement("tbl");
        if (props) {
            this._tableProps("tblPr", props);
        }
        return this;
    }
    table(props?: ITableProps, contentHandler?: IContentHandler) {
        this.startTable(props);
        if (contentHandler) {
            contentHandler(this);
            this.endTable();
        }
        return this;
    }
    tbl(props?: ITableProps, contentHandler?: IContentHandler) {
        return this.table(props, contentHandler);
    }
    private _tableRowHeight(props: ITableRowHeight) {
        if (props) {
            this._startElement("trHeight");
            this._valAttr(props.val);
            this._attr("hRule", props.hRule);
            this._endElement();
        }
    }
    private _tableRowProps(props: ITableRowProps) {
        this._startElement("trPr");
        this._tableRowHeight(props.trHeight);
        this._endElement();
    }
    startTableRow(props?: ITableRowProps) {
        this._startElement("tr");
        if (props) {
            this._tableRowProps(props);
        }
        if (props && props.tableExceptions) {
            this._tableProps("tblPrEx", props.tableExceptions);
        }
        return this;
    }
    tableRow(props?: ITableRowProps, contentHandler?: IContentHandler) {
        this.startTableRow(props);
        if (contentHandler) {
            contentHandler(this);
            this.endTableRow();
        }
        return this;
    }
    tr(props?: ITableRowProps, contentHandler?: IContentHandler) {
        return this.tableRow(props, contentHandler);
    }
    private _shadingProps(name: string, props: IShadingProps) {
        if (props) {
            this._startElement(name);
            this._valAttr(props.val);
            this._attr("color", props.color);
            this._attr("fill", props.fill);
            this._attr("themeColor", props.themeColor);
            this._attr("themeFill", props.themeFill);
            this._attr("themeFillShade", props.themeFillShade);
            this._attr("themeFillTint", props.themeFillTint);
            this._attr("themeShade", props.themeShade);
            this._attr("themeTint", props.themeTint);
            this._endElement();
        }
    }
    private _tableCellMargins(props: ITableCellMargins) {
        if (props) {
            this._startElement("tcMar");
            this._tableWidth("top", props.top);
            this._tableWidth("start", props.start);
            this._tableWidth("bottom", props.bottom);
            this._tableWidth("end", props.end);
            this._endElement();
        }
    }
    private _tableCellBorders(borders: ITableCellBorders) {
        if (borders) {
            this._startElement("tcBorders");
            this._tableBorder("top", borders.top);
            this._tableBorder("start", borders.start);
            this._tableBorder("bottom", borders.bottom);
            this._tableBorder("end", borders.end);
            this._endElement();
        }
    }
    private _tableCellProps(props: ITableCellProps) {
        this._startElement("tcPr");
        this._attr("id", props.id);
        this._tableWidth("tcW", props.preferredWidth);
        this._tableCellMargins(props.margins);
        this._valElement("textDirection", props.textDirection);
        this._shadingProps("shd", props.shading);
        this._toggleValElement("tcFitText", props.fitText);
        this._tableCellBorders(props.borders);
        this._valElement("vMerge", props.vMerge);
        this._valElement("hMerge", props.hMerge);
        this._valElement("vAlign", props.vAlign);
        this._valElement("hAlign", props.hAlign);
        this._endElement();
    }
    startTableCell(props?: ITableCellProps) {
        this._startElement("tc");
        if (props) {
            this._tableCellProps(props);
        }
        return this;
    }
    tableCell(props?: ITableCellProps, contentHandler?: IContentHandler) {
        this.startTableCell(props);
        if (contentHandler) {
            contentHandler(this);
            this.endTableCell();
        }
        return this;
    }
    tc(props?: ITableCellProps, contentHandler?: IContentHandler) {
        return this.tableCell(props, contentHandler);
    }
    endTableCell() {
        this._endElement();
        return this;
    }
    tcEnd() {
        return this.endTableCell();
    }
    endTableRow() {
        this._endElement();
        return this;
    }
    trEnd() {
        return this.endTableRow();
    }
    endTable() {
        this._endElement();
        return this;
    }
    tblEnd() {
        return this.endTable();
    }
    private _endElement() {
        this._a.endElement();
    }
    get result() {
        return this._a.result;
    }
}

export {
    DocxBuilder as default,
    DocxBuilder,
    ITyped,
    IParagraphProps,
    IContentHandler,
    IBaseProps,
    ITabProps,
    ITableProps,
    IRunProps,
    ITableRowProps,
    ITableCellProps,
    ITableWidth,
    ITableBorder,
    ITableBorders,
    ITableLookProps,
    ITableRowHeight,
    ITableCellMargins,
    IShadingProps,
    ITableCellBorders,
    IImageProps
}