import { IEntityActivity } from "../entity/IEntityActivity";
import { IVisaApplicationActivity } from "./IVisaApplicationActivity";

interface IEntityVisaApplicationActivity extends IEntityActivity, IVisaApplicationActivity {}

export { IEntityVisaApplicationActivity }