interface IVisaApplicationClient {
    applicationId?: number;
    icseClientId?: string;
    prmsnRequestClientId?: number;
    applicationType?: string;
    clientName?: string;
    clientDateOfBirth?: string;
    clientSexCode?: string;
    lastActivityDate?: string;
    clientApplicationRole?: string;
    roleAddedDate?: string;
    relationshipToMainApplicant?: string;
    milestoneEvent?: string;
    milestoneEventDate?: string;
    eventQualifier?: string;
    visaGrantNumber?: string;
    transactionReferenceNumber?: string;
    fileReference?: string;
    biometricValidationId?: string;
    office?: string;
    tripsPid?: number;
}

export { IVisaApplicationClient as default, IVisaApplicationClient };