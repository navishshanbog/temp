import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import { SyncSupplier } from "@twii/common/lib/model/SyncSupplier";
import VisaServiceContext from "../VisaServiceContext";
import { IVisaApplicationActivity } from "../IVisaApplicationActivity";
import { IVisaApplicationClient } from "../IVisaApplicationClient";

const findClientsByApplication = (application : IVisaApplicationActivity) : ISyncSupplier<IVisaApplicationClient[], IVisaApplicationActivity> => {
    const s = new SyncSupplier();
    s.parent = application;
    s.loader = (application : IVisaApplicationActivity) => {
        return VisaServiceContext.value.getApplicationClients({applicationId: String(application.applicationId)});
    };
    return s
};

export {
    findClientsByApplication
}