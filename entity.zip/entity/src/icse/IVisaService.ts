import IVisaApplicationActivity from "./IVisaApplicationActivity";
import IVisaCancellationActivity from "./IVisaCancellationActivity";
import IVisaApplicationClient from "./IVisaApplicationClient";

interface IVisaApplicationActivitiesGetRequest {
    icseClientId: string;
}

interface IVisaCancellationActivitiesGetRequest {
    icseClientId: string;
}

interface IVisaApplicationClientsGetRequest {
    applicationId: string;
}

interface IVisaService {
    getApplicationActivities(request: IVisaApplicationActivitiesGetRequest) : Promise<IVisaApplicationActivity[]>;
    getApplicationClients(request: IVisaApplicationClientsGetRequest) : Promise<IVisaApplicationClient[]>;
    getICSECancellationActivities(request: IVisaCancellationActivitiesGetRequest) : Promise<IVisaCancellationActivity[]>;
    getCANXCancellationActivities(request: IVisaCancellationActivitiesGetRequest) : Promise<IVisaCancellationActivity[]>;
}

export {
    IVisaApplicationActivitiesGetRequest,
    IVisaCancellationActivitiesGetRequest,
    IVisaApplicationClientsGetRequest,
    IVisaService
};