import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { copySubActivitiesToClipboard } from "../../entity/component/MasterEntitySourceHelper";
import * as ICSEConstants from "../ICSEConstants";


interface IVisaDealingSubActivityHelperProps {
    modelData?: any;
    data?:any;
    subEntityHeader?: string;
    subItemType?: string;
    name?: string;
    title?: string;
}


const createCopyForVisaDealings = (opts : IVisaDealingSubActivityHelperProps) : IContextualMenuItem => {
    let isCopyDisabled: boolean = false;
    return {
        key: "copySubActivityToClipboard",
        name: opts.name || "Copy",
        title: opts.title || "Copy",
        iconProps: { iconName: "Copy" },
        fieldValues: opts.data,
        source: opts.modelData.source? opts.modelData.source :
            opts.modelData.masterEntity.sources.find(item => item.sourceSystemCode == ICSEConstants.sourceSystemCode),
        sourceItemType: "activity/visa/application",
        sourceSubItemType: opts.subItemType,
        masterEntityId:opts.modelData.entity ? opts.modelData.entity.masterEntityId? opts.modelData.entity.masterEntityId : "" : opts.modelData.masterEntity.masterEntityId,
        sourceSubItemHeader: opts.subEntityHeader,
        disabled: isCopyDisabled,
        onClick: copySubActivitiesToClipboard
    }
};

export { IVisaDealingSubActivityHelperProps, createCopyForVisaDealings }