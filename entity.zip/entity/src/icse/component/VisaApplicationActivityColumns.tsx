import { IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import IVisaApplicationActivity from "../IVisaApplicationActivity";
import * as DateUtils from "@twii/common/lib/util/Date";

const ApplicationId : IColumn = {
    key: "applicationId",
    ariaLabel: "Application ID",
    name: "Application ID",
    fieldName: "applicationId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100
};

const getLodgementDateText = (item : IVisaApplicationActivity) => {
    return DateUtils.dataToOutputText(item.lodgementDate);
};

const LodgementDate : IColumn = {
    key: "lodgementDate",
    ariaLabel: "Lodgement Date",
    name: "Lodgement Date",
    fieldName: "lodgementDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 90,
    maxWidth: 90,
    data: {
        getText(item : IVisaApplicationActivity) {
            return getLodgementDateText(item);
        }
    },
    onRender: (item :  IVisaApplicationActivity) => {
        return getLodgementDateText(item);
    }
};

const ApplicationType : IColumn = {
    key: "applicationType",
    ariaLabel: "Application Type",
    name: "Application Type",
    fieldName: "applicationType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 200,
    maxWidth: 200
};

const NumberOfClientsInApplication : IColumn = {
    key: "numberOfClientsInApplication",
    ariaLabel: "No. of Clients",
    name: "No. of Clients",
    fieldName: "numberOfClientsInApplication",
    minWidth: 90,
    maxWidth: 90,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const getLastActivityDateText = (item : IVisaApplicationActivity) => {
    return DateUtils.dataToOutputText(item.lastActivityDate);
};

const LastActivityDate : IColumn = {
    key: "lastActivityDate",
    ariaLabel: "Last Activity Date",
    name: "Last Activity Date",
    fieldName: "lastActivityDate",
    minWidth: 100,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText(item : IVisaApplicationActivity) {
            return getLastActivityDateText(item);
        }
    },
    onRender: (item :  IVisaApplicationActivity) => {
        return getLastActivityDateText(item)
    }
};

const ClientApplicationRole : IColumn = {
    key: "clientApplicationRole",
    ariaLabel: "Client Application Role",
    name: "Client Application Role",
    fieldName: "clientApplicationRole",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const MilestoneEvent : IColumn = {
    key: "milestoneEvent",
    ariaLabel: "Milestone Event",
    name: "Milestone Event",
    fieldName: "milestoneEvent",
    minWidth: 120,
    maxWidth: 120,
    isResizable: true,
    isMultiline: true,
    columnActionsMode:ColumnActionsMode.clickable
};

const getMilestoneEventDateText = (item : IVisaApplicationActivity) => {
    return DateUtils.dataToOutputText(item.milestoneEventDate);
};

const MilestoneEventDate : IColumn = {
    key: "milestoneEventDate",
    ariaLabel: "Milestone Event Date",
    name: "Milestone Event Date",
    fieldName: "milestoneEventDate",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText(item : IVisaApplicationActivity) {
            return getMilestoneEventDateText(item);
        }
    },
    onRender: (item :  IVisaApplicationActivity) => {
        return getMilestoneEventDateText(item)
    }
};

const EventQualifier : IColumn = {
    key: "eventQualifier",
    ariaLabel: "Event Qualifier",
    name: "Event Qualifier",
    fieldName: "eventQualifier",
    minWidth: 120,
    maxWidth: 120,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const VisaGrantNumber : IColumn = {
    key: "visaGrantNumber",
    ariaLabel: "Visa Grant Number",
    name: "Visa Grant Number",
    fieldName: "visaGrantNumber",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const TransactionReferenceNumber : IColumn = {
    key: "transactionReferenceNumber",
    ariaLabel: "Transaction Reference Number",
    name: "Transaction Reference Number",
    fieldName: "transactionReferenceNumber",
    minWidth: 140,
    maxWidth: 140,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const FileReference : IColumn = {
    key: "fileReference",
    ariaLabel: "File Reference",
    name: "File Reference",
    fieldName: "fileReference",
    minWidth: 90,
    maxWidth: 90,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const ICSEClientId : IColumn = {
    key: "icseClientId",
    ariaLabel: "CID",
    name: "CID",
    fieldName: "icseClientId",
    minWidth: 90,
    maxWidth: 90,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
}; 

const TripsId : IColumn = {
    key: "tripsId",
    ariaLabel: "PID",
    name: "PID",
    fieldName: "tripsId",
    minWidth: 80,
    maxWidth: 80,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
}; 

const Office : IColumn = {
    key: "office",
    ariaLabel: "Office",
    name: "Office",
    fieldName: "office",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
}; 

const SourceSystemCode : IColumn = {
    key: "sourceSystemCode",
    ariaLabel: "Source System Code",
    name: "Source System Code",
    fieldName: "sourceSystemCode",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
}; 

const VisaApplicationActivityColumns : IColumn[] = [
    ApplicationId,
    ICSEClientId,
    TripsId,
    LodgementDate,
    ApplicationType,
    NumberOfClientsInApplication,
    ClientApplicationRole,
    LastActivityDate,
    MilestoneEvent,
    MilestoneEventDate,
    EventQualifier,
    VisaGrantNumber,
    TransactionReferenceNumber,
    FileReference,
    Office
];

export {
    VisaApplicationActivityColumns as default,
    VisaApplicationActivityColumns,
    ApplicationId,
    LodgementDate,
    ApplicationType,
    NumberOfClientsInApplication,
    LastActivityDate,
    ClientApplicationRole,
    MilestoneEvent,
    MilestoneEventDate,
    EventQualifier,
    VisaGrantNumber,
    TransactionReferenceNumber,
    FileReference,
    ICSEClientId,
    TripsId,
    Office,
    SourceSystemCode
}