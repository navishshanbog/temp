import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { DetailsList, DetailsListLayoutMode, ConstrainMode, CheckboxVisibility, SelectionMode, IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import * as DateUtils from "@twii/common/lib/util/Date";
import { IVisaApplicationClient } from "../IVisaApplicationClient";
import "./VisaApplicationClients.scss";
import SyncContainer from "@twii/common/lib/component/SyncContainer";
import { EntityAppBase } from "../../common/component/EntityAppBase";
import { EntityAppView } from "../../common/component/EntityAppView";
import { ISyncSupplier } from "@twii/common/lib/ISyncSupplier";
import {IVisaApplicationActivity} from "../IVisaApplicationActivity";
import { AppView } from "@twii/common/lib/component/AppView";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { createCopyForVisaDealings } from "./EntityVisaDealingsSubActivityHelper";
import { findClientsByApplication } from "../model/ICSEFinder";
import { genderToNISFormat, nisDOBFormat } from "../../entity/EntityNameUtils";
import * as moment from "moment";
import * as DateFormats from "@twii/common/lib//DateFormats";

const getClientFormattedNameText = (item : IVisaApplicationClient) => {
    const nameElements : string[] = [];
    if(item && item.clientName) {
        nameElements.push(item.clientName);
    }
    if(item && item.clientSexCode) {
        nameElements.push("(" + genderToNISFormat(item.clientSexCode) + ")");
    }
    if(item && item.clientDateOfBirth) {
        let dobMoment = moment(item.clientDateOfBirth, ['YYYY/MM/DD', DateFormats.Data.default]);
        if (dobMoment && dobMoment.isValid()) {
            nameElements.push(dobMoment.format(DateFormats.Output.nisFormat).toUpperCase());
        }
    }
    return nameElements.length > 0 ? nameElements.join(" ") : "";
};

const Columns: IColumn[] = [
    {
        key: "applicationType",
        ariaLabel: "Application Type",
        name: "Application Type",
        fieldName: "applicationType",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 130,
        maxWidth: 130,
        isMultiline: true
    },
    {
        key: "icseClientId",
        ariaLabel: "CID",
        name: "CID",
        fieldName: "icseClientId",
        minWidth: 80,
        maxWidth: 80,
        isResizable: true,
        columnActionsMode: ColumnActionsMode.clickable
    },
    {
        key: "tripsPid",
        ariaLabel: "PID",
        name: "PID",
        fieldName: "tripsPid",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 80,
        maxWidth: 80
    },
    {
        key: "client",
        ariaLabel: "Client",
        name: "Client",
        fieldName: "client",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 200,
        maxWidth: 200,
        isMultiline: true,
        onRender: (item: IVisaApplicationClient) => {
            return getClientFormattedNameText(item);
        },
        data: { getText: (item: IVisaApplicationClient) => getClientFormattedNameText(item) }
    },
    {
        key: "relationshipToMainApplicant",
        ariaLabel: "Relationship To Main Applicant",
        name: "Relationship To Main Applicant",
        fieldName: "relationshipToMainApplicant",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 130,
        maxWidth: 130,
        isMultiline: true
    },
    {
        key: "clientApplicationRole",
        ariaLabel: "Client Application Role",
        name: "Client Application Role",
        fieldName: "clientApplicationRole",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 120,
        maxWidth: 120,
        isMultiline: true
    },
    {
        key: "roleAddedDate",
        ariaLabel: "Role Added Date",
        name: "Role Added Date",
        fieldName: "roleAddedDate",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 90,
        maxWidth: 90,
        onRender: (item: IVisaApplicationClient) => {
            return DateUtils.dataToOutputText(item.roleAddedDate);
        },
        data: { getText: (item: IVisaApplicationClient) => DateUtils.dataToOutputText(item.roleAddedDate) }
    },
    {
        key: "lastActivityDate",
        ariaLabel: "Last Activity Date",
        name: "Last Activity Date",
        fieldName: "lastActivityDate",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 80,
        maxWidth: 80,
        onRender: (item: IVisaApplicationClient) => {
            return DateUtils.dataToOutputText(item.lastActivityDate);
        },
        data: { getText: (item: IVisaApplicationClient) => DateUtils.dataToOutputText(item.lastActivityDate) }
    },
    {
        key: "milestoneEvent",
        ariaLabel: "Milestone Event",
        name: "Milestone Event",
        fieldName: "milestoneEvent",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 130,
        maxWidth: 130,
        isMultiline: true
    },
    {
        key: "milestoneEventDate",
        ariaLabel: "Milestone Event Date",
        name: "Milestone Event Date",
        fieldName: "milestoneEventDate",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 80,
        maxWidth: 80,
        onRender: (item: IVisaApplicationClient) => {
            return DateUtils.dataToOutputText(item.milestoneEventDate);
        },
        data: { getText: (item: IVisaApplicationClient) => DateUtils.dataToOutputText(item.milestoneEventDate) }
    },
    {
        key: "eventQualifier",
        ariaLabel: "Event Qualifier",
        name: "Event Qualifier",
        fieldName: "eventQualifier",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 130,
        maxWidth: 130,
        isMultiline: true
    },
    {
        key: "office",
        ariaLabel: "Office",
        name: "Office",
        fieldName: "office",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 120,
        maxWidth: 120,
        isMultiline: true
    },
    {
        key: "transactionReferenceNumber",
        ariaLabel: "Transaction Reference Number",
        name: "Transaction Reference Number",
        fieldName: "transactionReferenceNumber",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 80,
        maxWidth: 80
    },
    {
        key: "fileReference",
        ariaLabel: "File Reference",
        name: "File Reference",
        fieldName: "fileReference",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 80,
        maxWidth: 80
    },
    {
        key: "visaGrantNumber",
        ariaLabel: "Visa Grant Number",
        name: "Visa Grant Number",
        fieldName: "visaGrantNumber",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 100,
        maxWidth: 100
    },
    {
        key: "biometricValidationId",
        ariaLabel: "Biometric Validation Id",
        name: "Biometric Validation Id",
        fieldName: "biometricValidationId",
        columnActionsMode: ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 80,
        maxWidth: 80
    }
];

interface IVisaApplicationClientsProps {
    list: IVisaApplicationClient[];
}

@observer
class VisaApplicationClients extends React.Component<IVisaApplicationClientsProps, any> {
    render() {
        let content;
        if (this.props.list.length > 0) {
            content = <DetailsList columns={Columns}
                        items={this.props.list}
                        selectionMode={SelectionMode.single}
                        layoutMode={DetailsListLayoutMode.fixedColumns}
                        constrainMode={ConstrainMode.unconstrained}
                        checkboxVisibility={CheckboxVisibility.hidden} />
        } else {
            content = <MessageBar messageBarType={MessageBarType.info}>Application does not have clients</MessageBar>;
        }
        return <div className="visa-application-clients">{content}</div>
    }
}

interface IVisaApplicationClientsContainerProps {
    model?: ISyncSupplier<IVisaApplicationClient[], IVisaApplicationActivity>;
}

class VisaApplicationClientsAppView extends React.Component<IVisaApplicationClientsContainerProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.model.parent) {
            items.push(
                createCopyForVisaDealings({
                    modelData: this.props.model.parent,
                    data: this.props.model.value,
                    subEntityHeader: `Associated Clients - Application ${this.props.model.parent.applicationId}`,
                    subItemType: "clients",
                    name: "Copy",
                    title: "Copy"
                })
            );
        }
        return (
            <AppView commandBarProps={{ items: items, farItems: [] }}>
                <VisaApplicationClients list={this.props.model.value} />
            </AppView>
        )
    }
}

class VisaApplicationClientsContainer extends React.Component<IVisaApplicationClientsContainerProps, any> {
    componentWillMount() {
        this.props.model.load();
    }
    private _onRenderDone = () => {
        return <VisaApplicationClientsAppView {...this.props} />;
    };
    render() {
        return <SyncContainer sync={this.props.model.sync} onRenderDone={this._onRenderDone} />;
    }
}

class VisaApplicationClientsApp extends EntityAppBase {
    get application() : IVisaApplicationActivity {
        if(this.props.match.application) {
            return this.props.match.application;
        }
        return this.props.match.params;
    }
    get model() : ISyncSupplier<IVisaApplicationClient[], IVisaApplicationActivity> {
        return findClientsByApplication(this.application);
    }
    componentWillMount() {
        this.host.title = `Associated Clients - Application ${this.application.applicationId}`;
    }
    render() {
        return (
            <EntityAppView host={this.host} hideHelp={!this.host.root} hideSettings={!this.host.root} hideProtectedMarker >
                <VisaApplicationClientsContainer model={this.model} />
            </EntityAppView>
        );
    }
}

export {
    VisaApplicationClientsApp as default,
    VisaApplicationClientsApp,
    IVisaApplicationClientsProps,
    VisaApplicationClients,
    Columns as VisaApplicationClientsColumns
};