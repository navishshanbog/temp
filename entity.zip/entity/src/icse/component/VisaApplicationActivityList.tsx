import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import VisaApplicationActivityDetailsList from "./VisaApplicationActivityDetailsList";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IVisaApplicationActivity from "../IVisaApplicationActivity";
import VisaApplicationActivityColumns from "./VisaApplicationActivityColumns";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { Sync } from "@twii/common/lib/component/Sync";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import VisaApplicationActivityViewPrefsStore from "../VisaApplicationActivityViewPrefsStore";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { AppView } from "@twii/common/lib/component/AppView";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { observer } from "mobx-react";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { getEntityActivityList } from "../VisaApplicationActivityHelper";
import { IEntityVisaApplicationActivity } from "../IEntityVisaApplicationActivity";
import { IPanelProps, PanelType } from "office-ui-fabric-react/lib/Panel";
import { PathsContext } from "../../PathsContext";

interface IVisaApplicationActivityListProps {
    list: IMasterEntitySourceListModel<IVisaApplicationActivity>;
    onItemInvoked?: (item : IVisaApplicationActivity, index?: number) => void;
}

@observer
class VisaApplicationActivityListCommandBar extends React.Component<IVisaApplicationActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "Visa Applications"}),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity/visa/application" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(VisaApplicationActivityViewPrefsStore, VisaApplicationActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

@observer
class VisaApplicationActivityList extends React.Component<IVisaApplicationActivityListProps, any> {
    private _onRenderMenu = () => {
        return <VisaApplicationActivityListCommandBar {...this.props} />
    };
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <VisaApplicationActivityDetailsList {...this.props} viewPreferences={VisaApplicationActivityViewPrefsStore}
                                                    onItemInvoked={this.props.onItemInvoked}/>
            </AppView>
        );
    }
}

class VisaApplicationActivityListContainer extends React.Component<IVisaApplicationActivityListProps, any> {
    private _onRenderDone = () => {
        return <VisaApplicationActivityList {...this.props} />;
    };
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Visa Applications ..." />;
    }
}

class VisaApplicationActivityListApp extends EntitySourceApp {
    private _onItemInvoked = (item : IEntityVisaApplicationActivity) => {
        const panelProps : IPanelProps = {
            type: PanelType.custom,
            customWidth: "800px"
        };
        this.panelRequestSupplier.value = {
            path: PathsContext.value.visaApplicationClients(String(item.applicationId)),
            application: item,
            panelProps: panelProps
        };
    };
    protected _onRenderSource = (props) => {
        return <VisaApplicationActivityListContainer list={getEntityActivityList(props.masterEntity)}
                                                     onItemInvoked={this._onItemInvoked}/>;
    };
    componentWillMount() {
        this.host.title = "Visa Applications";
    }
}

export {
    IVisaApplicationActivityListProps,
    VisaApplicationActivityListContainer,
    VisaApplicationActivityList,
    VisaApplicationActivityListApp,
    VisaApplicationActivityListApp as default
}