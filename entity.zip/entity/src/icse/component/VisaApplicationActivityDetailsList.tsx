import * as React from "react";
import IVisaApplicationActivity from "../IVisaApplicationActivity";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import VisaApplicationActivityColumns, { NumberOfClientsInApplication } from "./VisaApplicationActivityColumns";
import MasterEntitySourceDetailsList from "../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";
import { Link } from "office-ui-fabric-react/lib/Link";
import { IColumn } from "office-ui-fabric-react/lib/DetailsList";

interface IVisaApplicationActivityDetailsListProps {
    list: IMasterEntitySourceListModel<IVisaApplicationActivity>;
    viewPreferences?: IViewPreferencesModel;
    onItemInvoked?: (item : IVisaApplicationActivity, index : number) => void;
}

interface IVisaApplicationActivityDetailsListItemProps extends IVisaApplicationActivityDetailsListProps {
    item: IVisaApplicationActivity;
    itemIndex: number;
}

class ClientsLink extends React.Component<IVisaApplicationActivityDetailsListItemProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        e.preventDefault();
        this.props.onItemInvoked(this.props.item, this.props.itemIndex);
    };
    render() {
        let content;
        if (!isNaN(this.props.item.numberOfClientsInApplication) && this.props.item.numberOfClientsInApplication > 1) {
            return <Link onClick={this._onClick}>{String(this.props.item.numberOfClientsInApplication)}</Link>;
        } else {
            return String(this.props.item.numberOfClientsInApplication);
        }
    }
}

class VisaApplicationActivityDetailsList extends React.Component<IVisaApplicationActivityDetailsListProps, any> {
    private _onRenderNumberOfClients = (item : IVisaApplicationActivity, idx : number) => {
        return <ClientsLink {...this.props} item={item} itemIndex={idx} />;
    };
    render() {
        let columns : IColumn[];
        if(this.props.onItemInvoked) {
            columns = [].concat(VisaApplicationActivityColumns);
            const colIdx = columns.findIndex(c => c.key === NumberOfClientsInApplication.key);
            columns[colIdx] = Object.assign({}, columns[colIdx], {
                onRender: this._onRenderNumberOfClients
            });
        } else {
            columns = VisaApplicationActivityColumns;
        }
        return <MasterEntitySourceDetailsList
                    columns={columns}
                    list={this.props.list}
                    typeLabel="Visa Applications"
                    itemType="activity/visa/application"
                    viewPreferences={this.props.viewPreferences} />;
    }
}

export { IVisaApplicationActivityDetailsListProps, VisaApplicationActivityDetailsList as default, VisaApplicationActivityDetailsList }