import { IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import IVisaCancellationActivity from "../IVisaCancellationActivity";
import * as DateUtils from "@twii/common/lib/util/Date";

const ApplicationId : IColumn = {
    key: "applicationId",
    ariaLabel: "Application ID",
    name: "Application ID",
    fieldName: "applicationId",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 100,
    maxWidth: 100
};

const ICSEClientId : IColumn = {
    key: "clientId",
    ariaLabel: "CID",
    name: "CID",
    fieldName: "clientId",
    minWidth: 90,
    maxWidth: 90,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const TripsId : IColumn = {
    key: "tripsPid",
    ariaLabel: "PID",
    name: "PID",
    fieldName: "tripsPid",
    minWidth: 80,
    maxWidth: 80,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const ApplicationType : IColumn = {
    key: "applicationType",
    ariaLabel: "Application Type",
    name: "Application Type",
    fieldName: "applicationType",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 150,
    maxWidth: 150
};

const VisaGrantNumber : IColumn = {
    key: "visaGrantNumber",
    ariaLabel: "Visa Grant Number",
    name: "Visa Grant Number",
    fieldName: "visaGrantNumber",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const VisaClassSubClassCode : IColumn = {
    key: "visaClassSubClassCode",
    ariaLabel: "Visa Class Sub Class",
    name: "Visa Class Sub Class",
    fieldName: "visaClassSubClassCode",
    minWidth: 120,
    maxWidth: 120,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const ClientApplicationRole : IColumn = {
    key: "clientApplicationRole",
    ariaLabel: "Client Application Role",
    name: "Client Application Role",
    fieldName: "clientApplicationRole",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const Status : IColumn = {
    key: "milestoneEvent",
    ariaLabel: "Status",
    name: "Status",
    fieldName: "milestoneEvent",
    minWidth: 120,
    maxWidth: 120,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const getStatusDateText = (item : IVisaCancellationActivity) => {
    return DateUtils.dataToOutputText(item.milestoneEventDate);
};

const StatusDate : IColumn = {
    key: "milestoneEventDate",
    ariaLabel: "Status Date",
    name: "Status Date",
    fieldName: "milestoneEventDate",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 90,
    maxWidth: 90,
    data: {
        getText(item : IVisaCancellationActivity) {
            return getStatusDateText(item);
        }
    },
    onRender: (item :  IVisaCancellationActivity) => {
        return getStatusDateText(item);
    }
};

const CancellationOutcome : IColumn = {
    key: "cancellationOutcome",
    ariaLabel: "Cancellation Outcome",
    name: "Cancellation Outcome",
    fieldName: "cancellationOutcome",
    minWidth: 120,
    maxWidth: 120,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const Ground : IColumn = {
    key: "cancellationGround",
    ariaLabel: "Ground",
    name: "Ground",
    fieldName: "cancellationGround",
    minWidth: 120,
    maxWidth: 120,
    isResizable: true,
    isMultiline: true,
    columnActionsMode:ColumnActionsMode.clickable
};

const Power : IColumn = {
    key: "commencementPower",
    ariaLabel: "Power",
    name: "Power",
    fieldName: "commencementPower",
    minWidth: 120,
    maxWidth: 120,
    isResizable: true,
    isMultiline: true,
    columnActionsMode:ColumnActionsMode.clickable
};

const RecordingOfficer : IColumn = {
    key: "recordingOfficer",
    ariaLabel: "Recording Officer",
    name: "Recording Officer",
    fieldName: "recordingOfficer",
    minWidth: 120,
    maxWidth: 120,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const FileReference : IColumn = {
    key: "fileReference",
    ariaLabel: "File Reference",
    name: "File Reference",
    fieldName: "fileReference",
    minWidth: 90,
    maxWidth: 90,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const SourceSystemCode : IColumn = {
    key: "sourceSystemCode",
    ariaLabel: "Source System Code",
    name: "Source System Code",
    fieldName: "sourceSystemCode",
    minWidth: 130,
    maxWidth: 130,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
}; 

const VisaCancellationActivityColumns : IColumn[] = [
    ApplicationId,
    ICSEClientId,
    TripsId,
    ApplicationType,
    VisaGrantNumber,
    VisaClassSubClassCode,
    ClientApplicationRole,
    Status,
    StatusDate,
    CancellationOutcome,
    Ground,
    Power,
    FileReference,
    SourceSystemCode,
    RecordingOfficer
];

export {
    VisaCancellationActivityColumns as default,
    VisaCancellationActivityColumns,
    ApplicationId,
    ICSEClientId,
    TripsId,
    ApplicationType,
    VisaGrantNumber,
    VisaClassSubClassCode,
    ClientApplicationRole,
    Status,
    StatusDate,
    CancellationOutcome,
    Ground,
    Power,
    RecordingOfficer,
    FileReference,
    SourceSystemCode
}