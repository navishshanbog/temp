import EntitySourceDashboardApp from "../../entity/component/EntitySourceDashboardApp";
import { isMemberOfGroup } from "@twii/ozone/lib/user/UserHelper";
import { PathsContext } from "../../PathsContext";

class EntityVisaDealingsApp extends EntitySourceDashboardApp {
    protected _getDashboardConfig = () : any => {
        return {
            type: "dashboard",
            component: {
                type: "vsplit",
                offset: 0.5,
                top: {
                    component: {
                        type: "window",
                        path: `${PathsContext.value.entitySource(this.entityId, this.sourceSystemCode)}/visa/applications`,
                        params: {
                            onSearch: this.props.match.params.onSearch
                        }
                    }
                },
                bottom: {
                    component: {
                        type: "window",
                        path: `${PathsContext.value.entitySource(this.entityId, this.sourceSystemCode)}/visa/cancellations`,
                        params: {
                            onSearch: this.props.match.params.onSearch
                        }
                    }
                }
            }
        };
    };
}

export { EntityVisaDealingsApp as default, EntityVisaDealingsApp }