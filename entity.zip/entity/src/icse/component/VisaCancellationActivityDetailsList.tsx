import * as React from "react";
import IVisaCancellationActivity from "../IVisaCancellationActivity";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import VisaCancellationActivityColumns, { ApplicationId } from "./VisaCancellationActivityColumns";
import MasterEntitySourceDetailsList from "../../entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "@twii/common/lib/IViewPreferencesModel";

interface IVisaCancellationActivityDetailsListProps {
    list: IMasterEntitySourceListModel<IVisaCancellationActivity>;
    viewPreferences?: IViewPreferencesModel;
    onItemInvoked?: (item : IVisaCancellationActivity, index : number) => void;
}

class VisaCancellationActivityDetailsList extends React.Component<IVisaCancellationActivityDetailsListProps, any> {
    render() {
        return <MasterEntitySourceDetailsList
                    columns={VisaCancellationActivityColumns}
                    list={this.props.list}
                    typeLabel="Visa Cancellations"
                    itemType="activity/visa/cancellation"
                    viewPreferences={this.props.viewPreferences}
                    onItemInvoked={this.props.onItemInvoked} />;
    }
}

export { IVisaCancellationActivityDetailsListProps, VisaCancellationActivityDetailsList as default, VisaCancellationActivityDetailsList }