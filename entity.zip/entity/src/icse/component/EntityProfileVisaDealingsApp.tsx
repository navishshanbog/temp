import * as React from "react";
import IEntityProfileSourceGroupProps from "../../entity/profile/component/IEntityProfileSourceGroupProps";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import VisaApplicationActivityColumns from "./VisaApplicationActivityColumns";
import VisaCancellationActivityColumns from "./VisaCancellationActivityColumns";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import {
    buildSectionHeader, buildTable, buildComments
} from "../../entity/profile/EntityProfileDocumentHelper";
import SubEntityProfileSourceDetailList from "../../entity/profile/component/SubEntityProfileSourceDetailList";
import { buildSectionTable, buildSectionSubHeader } from "../../entity/profile/EntityProfileDocumentHelper";
import { equalsIgnoreCase } from "@twii/common/lib/util/String";
import { IEntitySourceItems } from "../../entity/IEntitySourceItems";
import { VisaApplicationClientsColumns } from "./VisaApplicationClients";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileVisaApplicationsApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="visa-application-activities" title="Visa Applications">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={VisaApplicationActivityColumns} />
                <SubEntityProfileSourceDetailList group={this.group} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const EntityProfileVisaApplicationsDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("Visa Applications", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, VisaApplicationActivityColumns, doc);
    if (group.hasSubTypes) {
        group.subEntities.map((subEntity: IEntitySourceItems) => {
            if (!(subEntity.items === null)) {
                buildSectionSubHeader(subEntity.items[0].sourceSubItemHeader, doc);
                if (equalsIgnoreCase(subEntity.type, "clients")) {
                    buildSectionTable(subEntity.items[0].subItems, VisaApplicationClientsColumns, doc);
                }
            }
        });
    }
    buildComments(group.comments, doc);
};

class EntityProfileVisaCancellationsApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="visa-cancellation-activities" title="Visa Cancellations">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={VisaCancellationActivityColumns} />
                <SubEntityProfileSourceDetailList group={this.group} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const EntityProfileVisaCancellationsDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("Visa Cancellations", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, VisaCancellationActivityColumns, doc);
    buildComments(group.comments, doc);
};

export { EntityProfileVisaApplicationsApp, EntityProfileVisaCancellationsApp, EntityProfileVisaApplicationsDocumentHandler, EntityProfileVisaCancellationsDocumentHandler }