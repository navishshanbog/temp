import * as React from "react";
import "./VisaApplicationClients.scss";
import { VisaApplicationClients } from "./VisaApplicationClients";
import { IAppProps } from "@twii/common/lib/component/IAppProps";

class VisaApplicationProfileClients extends React.Component<IAppProps, any> {
    render() {
        const items = this.props.match.items;
        let details;
        if(items && items.length > 0) {
            details = items[0].subItems;
        }
        return (
            <VisaApplicationClients list={details} />
        );
    }
}


export { VisaApplicationProfileClients as default, VisaApplicationProfileClients };