import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import VisaCancellationActivityDetailsList from "./VisaCancellationActivityDetailsList";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IVisaCancellationActivity from "../IVisaCancellationActivity";
import VisaCancellationActivityColumns from "./VisaCancellationActivityColumns";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { Sync } from "@twii/common/lib/component/Sync";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import VisaCancellationActivityViewPrefsStore from "../VisaCancellationActivityViewPrefsStore";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import { AppView } from "@twii/common/lib/component/AppView";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { observer } from "mobx-react";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { getEntityActivityList } from "../VisaCancellationActivityHelper";

interface IVisaCancellationActivityListProps {
    list: IMasterEntitySourceListModel<IVisaCancellationActivity>;
    onItemInvoked?: (item : IVisaCancellationActivity, index?: number) => void;
}

@observer
class VisaCancellationActivityListCommandBar extends React.Component<IVisaCancellationActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "Visa Cancellations"}),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity/visa/cancellation" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(VisaCancellationActivityViewPrefsStore, VisaCancellationActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class VisaCancellationActivityList extends React.Component<IVisaCancellationActivityListProps, any> {
    private _onRenderMenu = () => {
        return <VisaCancellationActivityListCommandBar {...this.props} />
    };
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <VisaCancellationActivityDetailsList {...this.props} viewPreferences={VisaCancellationActivityViewPrefsStore} onItemInvoked={this.props.onItemInvoked} />
            </AppView>
        );
    }
}

class VisaCancellationActivityListContainer extends React.Component<IVisaCancellationActivityListProps, any> {
    private _onRenderDone = () => {
        return <VisaCancellationActivityList {...this.props} />;
    };
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Visa Cancellations ..." />;
    }
}

class VisaCancellationActivityListApp extends EntitySourceApp {
    protected _onRenderSource = (props) => {
        return <VisaCancellationActivityListContainer list={getEntityActivityList(props.masterEntity)} />;
    };
    componentWillMount() {
        this.host.title = "Visa Cancellations";
    }
}

export {
    IVisaCancellationActivityListProps,
    VisaCancellationActivityListContainer,
    VisaCancellationActivityList,
    VisaCancellationActivityListApp,
    VisaCancellationActivityListApp as default
}