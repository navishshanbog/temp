import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const VisaApplicationActivityViewPrefsStore = new ViewPreferencesModel("visaApplicationActivity");

export { VisaApplicationActivityViewPrefsStore as default, VisaApplicationActivityViewPrefsStore }