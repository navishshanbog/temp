const sourceSystemCode = "ICSE";

export { sourceSystemCode }