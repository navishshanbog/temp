import Context from "@twii/common/lib/Context";
import { IVisaService } from "./IVisaService";
import { RestVisaService } from "./RestVisaService";

const VisaServiceContext = new Context<IVisaService>({
    value: new RestVisaService()
});

export { VisaServiceContext as default, VisaServiceContext };