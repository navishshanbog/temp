import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import { IEntityVisaCancellationActivity } from "./IEntityVisaCancellationActivity";
import { IVisaCancellationActivity } from "./IVisaCancellationActivity";
import ISort from "@twii/common/lib/ISortProps";
import VisaServiceContext from "./VisaServiceContext";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import { VisaCancellationActivityColumns, StatusDate } from "./component/VisaCancellationActivityColumns";
import * as StringUtils from "@twii/common/lib/util/String";
import * as SearchUtils from "@twii/common/lib/util/Search";
import * as moment from "moment";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as ICSEConstants from "./ICSEConstants";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import { IMasterEntityModel } from "../entity/IMasterEntityModel";
import { getForMasterEntity } from "../entity/MasterEntitySourceServiceUtils";
import IMasterEntitySourceModel from "../entity/IMasterEntitySourceModel";

const textFilterItemImpl = (item: IEntityVisaCancellationActivity, text : string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, VisaCancellationActivityColumns), text);
};

const textFilterItem = (item: IEntityVisaCancellationActivity, text : string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items : IEntityVisaCancellationActivity[], text : string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IEntityVisaCancellationActivity, from : moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.milestoneEventDate), from);
};

const toFilterItem = (item: IEntityVisaCancellationActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.milestoneEventDate), to);
};

const rangeFilterItem = (item: IEntityVisaCancellationActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items : IEntityVisaCancellationActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items; 
};

const filter = (items : IEntityVisaCancellationActivity[], props : IActivityFilterProps) => {
    return props ? rangeFilter(textFilter(items, props.filterText), props.filterFromDate, props.filterToDate) : items;
};

const toSortValue = (item: IEntityVisaCancellationActivity, field : string) => {
    if(item) {
        if(field === StatusDate.fieldName) {
            return DateUtils.dateFromDataText(item.milestoneEventDate);
        }
        return item[field];
    }
};

const compare = (a : IEntityVisaCancellationActivity, b : IEntityVisaCancellationActivity, sort: ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IEntityVisaCancellationActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a : IEntityVisaCancellationActivity, b : IEntityVisaCancellationActivity) => compare(a, b, sort)) : items;
};

const getActivitiesByClient = (icseClientId : string, source : IMasterEntitySourceModel, entity: IMasterEntityModel) : Promise<IEntityVisaCancellationActivity[]> => {
    const list : IEntityVisaCancellationActivity[] = [];
    const map = (r: IVisaCancellationActivity[]) : Promise<void> => {
        if (r) {
            r.map((i, index) => {
                i["key"] = i.applicationId + "_" + index;
                list.push(Object.assign({}, i, { source: source, entity: entity }));
            });
        }
        return Promise.resolve();
    };
    const icsePromise = VisaServiceContext.value.getICSECancellationActivities({ icseClientId: icseClientId }).then(map);
    const canxPromise = VisaServiceContext.value.getCANXCancellationActivities({ icseClientId: icseClientId }).then(map);
    return Promise.all([icsePromise, canxPromise])
        .then(() => list);
};

const getEntityActivities = (entity : IMasterEntityModel) : Promise<IEntityVisaCancellationActivity[]> => {
    return getForMasterEntity(entity, ICSEConstants.sourceSystemCode, getActivitiesByClient);
};

const getEntityActivityList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityVisaCancellationActivity> => {
    return entity.getState("visaCancellationActivityList", () => {
        const r = new MasterEntitySourceListModel(entity, ICSEConstants.sourceSystemCode, getEntityActivities);
        r.setFilterHandler(filter);
        r.setSortHandler(sort);
        r.load();
        return r;
    });
};

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getActivitiesByClient,
    getEntityActivities,
    getEntityActivityList
};