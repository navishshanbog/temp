interface IVisaApplicationActivity {
    applicationId?: number;
    lodgementDate?: string;
    applicationType?: string;
    numberOfClientsInApplication?: number;
    lastActivityDate?: string;
    clientApplicationRole?: string;
    milestoneEvent?: string;
    milestoneEventDate?: string;
    eventQualifier?: string;
    visaGrantNumber?: string;
    transactionReferenceNumber?: string;
    fileReference?: string;
    icseClientId?: string;
    tripsId?: number;
    office?: string;
    sourceSystemCode?: string;
}

export { IVisaApplicationActivity as default, IVisaApplicationActivity };