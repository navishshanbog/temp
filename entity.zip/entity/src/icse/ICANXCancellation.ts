interface ICANXCancellation {
    applicationId?: string;
    icseClientId?: string;
    tripsPid?: number;
    applicationType?: string;
    visaGrantNumber?: string;
    visaClassSubClassCode?: string;
    clientApplicationRole?: string;
    status?: string;
    statusDate?: string;
    cancellationOutcome?: string;
    cancellationOutcomeJustification?: string;
    cancellationGround?: string;
    commencementPower?: string;
    recordingOfficer?: string;
    sourceSystemCode?: string;
    canxId?: string;
    canxClientId?: number;
}

export { ICANXCancellation as default, ICANXCancellation }