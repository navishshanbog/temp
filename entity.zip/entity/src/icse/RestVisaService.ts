import axios from "axios";
import {
    IVisaService,
    IVisaApplicationActivitiesGetRequest,
    IVisaCancellationActivitiesGetRequest,
    IVisaApplicationClientsGetRequest
} from "./IVisaService";
import IVisaApplicationActivity from "./IVisaApplicationActivity";
import IVisaCancellationActivity from "./IVisaCancellationActivity";
import IVisaApplicationClient from "./IVisaApplicationClient";
import AbstractRestDataService from "../common/AbstractRestDataService";
import ICANXCancellation from "./ICANXCancellation";
import { ds404ToEmptyArrayHandler, Defaults } from "../common/service/AbstractRestDataService";

interface GetApplicationActivitiesRestResponse {
    ICSEVisaApplication?: IVisaApplicationActivity[];
}

interface GetApplicationClientsRestResponse {
    ICSEAssociatedVisaClient?: IVisaApplicationClient[];
}

interface GetICSECancellationActivitiesRestResponse {
    ICSECancellation?: IVisaCancellationActivity[];
}

interface GetCANXCancellationActivitiesRestResponse {
    CANXCancellation?: ICANXCancellation[];
}

const mapCANXCancellationToActivity = (c: ICANXCancellation): IVisaCancellationActivity => {
    return Object.assign({}, c, {
        clientId: c.icseClientId,
        milestoneEvent: c.status,
        milestoneEventDate: c.statusDate
    });
};

class RestVisaService extends AbstractRestDataService implements IVisaService {
    getApplicationActivities(request: IVisaApplicationActivitiesGetRequest) : Promise<IVisaApplicationActivity[]> {
        const url = `${this.config.baseUrl}/VisaServices/v1/resources/visa/icse/${encodeURIComponent(request.icseClientId)}/applications`;
        return axios.get(url, { headers: Defaults.requestHeaders }).then((value) => {
            const response = value.data as GetApplicationActivitiesRestResponse;
            return response.ICSEVisaApplication ? response.ICSEVisaApplication : [];
        }).catch(ds404ToEmptyArrayHandler);
    }
    getApplicationClients(request: IVisaApplicationClientsGetRequest) : Promise<IVisaApplicationClient[]> {
        const url = `${this.config.baseUrl}/VisaServices/v1/resources/visa/icse/${encodeURIComponent(request.applicationId)}/associated-visa-clients`;
        return axios.get(url, { headers: Defaults.requestHeaders }).then((value) => {
            const response = value.data as GetApplicationClientsRestResponse;
            return response.ICSEAssociatedVisaClient ? response.ICSEAssociatedVisaClient : [];
        }).catch(ds404ToEmptyArrayHandler);
    }
    getICSECancellationActivities(request: IVisaCancellationActivitiesGetRequest) : Promise<IVisaCancellationActivity[]> {
        const url = `${this.config.baseUrl}/VisaServices/v1/resources/visa/icse/${encodeURIComponent(request.icseClientId)}/cancellations`;
        return axios.get(url, { headers: Defaults.requestHeaders }).then((value) => {
            const response = value.data as GetICSECancellationActivitiesRestResponse;
            return response.ICSECancellation ? response.ICSECancellation : [];
        }).catch(ds404ToEmptyArrayHandler);
    }
    getCANXCancellationActivities(request: IVisaCancellationActivitiesGetRequest) : Promise<IVisaCancellationActivity[]> {
        const url = `${this.config.baseUrl}/VisaServices/v1/resources/visa/canx/${encodeURIComponent(request.icseClientId)}/cancellations`;
        return axios.get(url, { headers: Defaults.requestHeaders }).then((value) => {
            const response = value.data as GetCANXCancellationActivitiesRestResponse;
            return response.CANXCancellation ? response.CANXCancellation.map(mapCANXCancellationToActivity) : [];
        }).catch(ds404ToEmptyArrayHandler);
    }
}

export { RestVisaService };