import { IEntityActivity } from "../entity/IEntityActivity";
import { IVisaCancellationActivity } from "./IVisaCancellationActivity";

interface IEntityVisaCancellationActivity extends IEntityActivity, IVisaCancellationActivity {}

export { IEntityVisaCancellationActivity }