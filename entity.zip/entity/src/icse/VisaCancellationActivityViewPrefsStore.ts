import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const VisaCancellationActivityViewPrefsStore = new ViewPreferencesModel("visaCancellationActivity");

export { VisaCancellationActivityViewPrefsStore as default, VisaCancellationActivityViewPrefsStore }