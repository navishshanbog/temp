interface IVisaCancellationActivity {
    applicationId?: number;
    clientId?: string;
    tripsPid?: number;
    applicationType?: string;
    visaGrantNumber?: string;
    visaClassSubClassCode?: string;
    clientApplicationRole?: string;
    milestoneEvent?: string;
    milestoneEventDate?: string;
    cancellationOutcome?: string;
    cancellationOutcomeJustification?: string;
    cancellationGround?: string;
    commencementPower?: string;
    recordingOfficer?: string;
    fileReference?: string;
    sourceSystemCode?: string;
    canxId?: string;
    canxClientId?: string;
}

export { IVisaCancellationActivity as default, IVisaCancellationActivity };