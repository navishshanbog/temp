import ViewPreferencesModel from "@twii/common/lib/ViewPreferencesModel";

const EXAMSActivityViewPrefsStore = new ViewPreferencesModel("examsActivity");

export { EXAMSActivityViewPrefsStore as default, EXAMSActivityViewPrefsStore }