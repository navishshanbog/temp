import { action } from "mobx";
import IActivityFilterProps from "@twii/common/lib/IActivityFilterProps";
import { IEntityEXAMSActivity } from "./IEntityEXAMSActivity";
import IListModel from "@twii/common/lib/IListModel";
import IListResult from "@twii/common/lib/IListResult";
import ISort from "@twii/common/lib/ISortProps";
import * as StringUtils from "@twii/common/lib/util/String";
import * as SearchUtils from "@twii/common/lib/util/Search";
import * as SortUtils from "@twii/common/lib/util/Sort";
import * as moment from "moment";
import * as DateUtils from "@twii/common/lib/util/Date";
import * as ColumnTextHelper from "@twii/common/lib/component/ColumnTextHelper";
import { EXAMSActivityColumns, CurrentDate } from "./component/EXAMSActivityColumns";
import EXAMSServiceContext from "./EXAMSServiceContext";
import * as  EXAMSConstants from "./EXAMSConstants";
import { IEXAMSActivityGetRequest } from "./IEXAMSService";
import IMasterEntitySource from "../entity/IMasterEntitySource";
import IMasterEntitySourceModel from "../entity/IMasterEntitySourceModel";
import { Data as DateDataFormats } from "@twii/common/lib/DateFormats";
import IActivityListModel from "@twii/common/lib/IActivityListModel";
import MasterEntitySourceListModel from "../entity/MasterEntitySourceListModel";
import { getMasterEntityIds } from "../entity/MasterEntityHelper";
import IMasterEntityModel from "../entity/IMasterEntityModel";
import { getForMasterEntityWithSourceLoader } from "../entity/MasterEntitySourceServiceUtils";

const textFilterItemImpl = (item: IEntityEXAMSActivity, text: string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, EXAMSActivityColumns), text);
};

const textFilterItem = (item: IEntityEXAMSActivity, text: string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items: IEntityEXAMSActivity[], text: string) => {
    return items && StringUtils.isNotBlank(text) ?
        items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IEntityEXAMSActivity, from : moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.currentDate), from);
};

const toFilterItem = (item: IEntityEXAMSActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.currentDate), to);
};

const rangeFilterItem = (item: IEntityEXAMSActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items: IEntityEXAMSActivity[], from: moment.Moment, to: moment.Moment) => {
    return items ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items : IEntityEXAMSActivity[], props : IActivityFilterProps) => {
    return props ? rangeFilter(textFilter(items, props.filterText), props.filterFromDate, props.filterToDate) : items;
};

const toSortValue = (item : IEntityEXAMSActivity, field: string) => {
    if(item) {
        if(field === CurrentDate.fieldName) {
            return DateUtils.dateFromDataText(item.currentDate);
        }
        return item[field];
    }
};

const compare = (a : IEntityEXAMSActivity, b : IEntityEXAMSActivity, sort : ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IEntityEXAMSActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const getActivitiesByEntityId = (entityId : string) : Promise<IEntityEXAMSActivity[]> => {
    return EXAMSServiceContext.value.getEXAMSActivities({ masterEntityID: entityId });
};

const getSourceActivities = (source : IMasterEntitySourceModel, entity : IMasterEntityModel) : Promise<IEntityEXAMSActivity[]> => {
    return getActivitiesByEntityId(source.masterEntityId).then(r => {
        return r ? r.map((i, index) => {
            i["key"] = i.examinationIdentifier + "_" + index;
            return Object.assign({}, i, { source: source, entity: entity });
        }) : [];
    });
};

const getEntityActivities = (entity : IMasterEntityModel) : Promise<IEntityEXAMSActivity[]> => {
    return getForMasterEntityWithSourceLoader(entity, EXAMSConstants.sourceSystemCode, getSourceActivities);
};

const getEntityActivityList = (entity : IMasterEntityModel) : MasterEntitySourceListModel<IEntityEXAMSActivity> => {
    return entity.getState("examsActivityList", () => {
        const r = new MasterEntitySourceListModel(entity, EXAMSConstants.sourceSystemCode, getEntityActivities);
        r.setFilterHandler(filter);
        r.setSortHandler(sort);
        r.load();
        return r;
    });
};

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    compare,
    toSortValue,
    sort,
    getSourceActivities,
    getEntityActivityList
};