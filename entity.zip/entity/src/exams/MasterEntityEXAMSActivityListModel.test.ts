import MasterEntityModel from "../entity/MasterEntityModel";
import EXAMSServiceContext from "./EXAMSServiceContext";
import MockEXAMSService from "./MockEXAMSService";
import * as EXAMSConstants from "./EXAMSConstants";
import * as DateUtils from "@twii/common/lib/util/Date";
import { getEntityActivityList } from "./EXAMSActivityHelper";
import { toPromise } from "@twii/common/lib/SyncUtils";

describe("Master Entity EXAMS Activity List Model", () => {
    test("test set master entity", async () => {
        const e = new MasterEntityModel();
        e.setData({
            masterEntityId: "1",
            sources: [
                {
                    sourceSystemCode: EXAMSConstants.sourceSystemCode,
                    sourceEntities: [
                        {
                            ref: {
                                sourceRelatedKeyValue: "1"
                            }
                        }
                    ]
                }
            ]
        });

        const examsService = new MockEXAMSService();
        examsService.getEXAMSActivitiesResponse = [
            {
                "transportType":"AIR",
                "masterBillNumber":"4",
                "houseBillNumber":"4",
                "entityExaminationRoleType":"TestRole",
                "examinationIdentifier":"4",
                "billTyp":"4",
                "currentDate":"2006-01-04",
                "goodsDescription":"s4",
                "consigneeName":"s4",
                "consignorName":"s4",
                "consigneeAddress":"4 AirCargo Street, Canbera",
                "consignorAddress":"4 AirCargo Street, Canbera",
                "selectionCriteriaDescription":"s4",
                "examStatus":"Passed",
                "priorityType":"4",
                "examPort":"Canbera port",
                "examResultType":"e4",
                "toolsUsed": "test"
            },
            {
                "transportType":"AIR",
                "masterBillNumber":"5",
                "houseBillNumber":"5",
                "entityExaminationRoleType":"TestRole",
                "examinationIdentifier":"5",
                "billTyp":"5",
                "currentDate":"2006-01-05",
                "goodsDescription":"s5",
                "consigneeName":"s5",
                "consigneeAddress":"5 AirCargo Street, Canbera",
                "consignorName":"s5",
                "consignorAddress":"5 AirCargo Street, Canbera",
                "selectionCriteriaDescription":"s5",
                "examStatus":"Passed",
                "priorityType":"5",
                "examPort":"Canbera port",
                "examResultType":"e5",
                "toolsUsed": "test"
            }
        ];
        examsService.recordRequests = true;

        EXAMSServiceContext.value = examsService;

        expect(EXAMSServiceContext.value).toBe(examsService);
        
        const activityListModel = getEntityActivityList(e);
        expect(activityListModel.entity).toBe(e);

        await toPromise(activityListModel.sync);

        expect(examsService.getEXAMSActivitiesRequests.length).toBe(1);

        const r = examsService.getEXAMSActivitiesRequests[0];

        expect(r.masterEntityID).toBe("1");

        expect(activityListModel.items.length).toBe(examsService.getEXAMSActivitiesResponse.length);

        expect(activityListModel.itemsView.length).toBe(activityListModel.items.length);

        // apply a filter
        e.activityFilter.setFilterText("4 AirCargo Street");

        expect(activityListModel.itemsView.length).toBe(1);
        expect(activityListModel.itemsView[0].masterBillNumber).toBe("4");

        activityListModel.filter.setFilterText("noChance");

        expect(activityListModel.itemsView.length).toBe(0);

    });

});