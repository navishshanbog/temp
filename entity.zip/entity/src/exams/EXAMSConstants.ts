const sourceSystemCode = "EXAM";

export { sourceSystemCode };