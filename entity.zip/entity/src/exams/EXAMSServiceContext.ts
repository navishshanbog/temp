import Context from "@twii/common/lib/Context";
import IEXAMSService from "./IEXAMSService";
import RestEXAMSService from "./RestEXAMSService";

const EXAMSServiceContext = new Context<IEXAMSService>({
    value: new RestEXAMSService()
});

export { EXAMSServiceContext as default, EXAMSServiceContext };