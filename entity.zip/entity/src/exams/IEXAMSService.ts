import IEXAMSActivity from "./IEXAMSActivity";

interface IEXAMSActivityGetRequest {
    masterEntityID?: string;
    fromDate?: string;
    toDate?: string;
    examPort?: string;
    examResultType?: string;
    proxyUser?: string;
    maxNumberOfRecords?: number;
}

interface IEXAMSService {
    getEXAMSActivities(request : IEXAMSActivityGetRequest) : Promise<IEXAMSActivity[]>;
}

export {
    IEXAMSService as default,
    IEXAMSService,
    IEXAMSActivityGetRequest,
 };