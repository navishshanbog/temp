import { IEntityActivity } from "../entity/IEntityActivity";
import { IEXAMSActivity } from "./IEXAMSActivity";

interface IEntityEXAMSActivity extends IEntityActivity, IEXAMSActivity {}

export { IEntityEXAMSActivity }