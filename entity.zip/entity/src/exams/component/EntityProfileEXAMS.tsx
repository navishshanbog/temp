import * as React from "react";
import EntityProfileSourceGroupDetailsList from "../../entity/profile/component/EntityProfileSourceGroupDetailsList";
import EntityProfileSourceGroupDetails from "../../entity/profile/component/EntityProfileSourceGroupDetails";
import { IEntityProfileDocumentHandler } from "../../entity/profile/IEntityProfileDocumentHandler";
import { buildSectionHeader, buildTable, buildComments } from "../../entity/profile/EntityProfileDocumentHelper";
import EXAMSActivityColumns from "./EXAMSActivityColumns";
import { EntityProfileSourceGroupApp } from "../../entity/profile/component/EntityProfileSourceGroupApp";

class EntityProfileEXAMSApp extends EntityProfileSourceGroupApp {
    render() {
        return (
            <EntityProfileSourceGroupDetails group={this.group} className="exams-activities" title="EXAMS Activities">
                <EntityProfileSourceGroupDetailsList group={this.group} columns={EXAMSActivityColumns} />
            </EntityProfileSourceGroupDetails>
        );
    }
}

const EXAMSActivityDocumentHandler: IEntityProfileDocumentHandler = props => {
    const doc = props.doc;
    const group = props.group;

    buildSectionHeader("EXAMS Activities", doc);
    (group.items && group.items.length > 0) &&
        buildTable(group.items, EXAMSActivityColumns, doc);
    buildComments(group.comments, doc);
};

export { EntityProfileEXAMSApp as default, EntityProfileEXAMSApp, EXAMSActivityDocumentHandler }