import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import IMasterEntitySourceListModel from "../../entity/IMasterEntitySourceListModel";
import IEXAMSActivity from "../IEXAMSActivity";
import EXAMSActivityColumns from "./EXAMSActivityColumns";
import EXAMSActivityDetailsList from "./EXAMSActivityDetailsList";
import { createActivityListFilterItem } from "@twii/common/lib/component/ActivityFilterMenuHelper";
import { createCopyToClipboardItem } from "../../entity/component/MasterEntitySourceHelper";
import { createViewPreferencesMenuItem } from "@twii/common/lib/component/ViewPreferencesMenuItem";
import EXAMSActivityViewPrefsStore from "../EXAMSActivityViewPrefsStore";
import { AppView } from "@twii/common/lib/component/AppView";
import { Sync } from "@twii/common/lib/component/Sync";
import { EntitySourceApp } from "../../entity/component/EntitySourceApp";
import { getEntityActivityList } from "../EXAMSActivityHelper";

interface IEXAMSActivityListProps {
    list: IMasterEntitySourceListModel<IEXAMSActivity>;
}

@observer
class EXAMSActivityListCommandBar extends React.Component<IEXAMSActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "EXAM Activities" }),
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity" })
        ];
        const farItems : IContextualMenuItem[] = [
            createViewPreferencesMenuItem(EXAMSActivityViewPrefsStore, EXAMSActivityColumns)
        ];
        return <CommandBar items={items} farItems={farItems} />;
    }
}

class EXAMSActivityList extends React.Component<IEXAMSActivityListProps, any> {
    private _onRenderMenu = () => {
        return <EXAMSActivityListCommandBar {...this.props} />
    }
    render() {
        return (
            <AppView onRenderMenu={this._onRenderMenu}>
                <EXAMSActivityDetailsList {...this.props} viewPreferences={EXAMSActivityViewPrefsStore} />
            </AppView>
        )
    }
}

class EXAMSActivityListContainer extends React.Component<IEXAMSActivityListProps, any> {
    private _onRenderDone = () => {
        return <EXAMSActivityList {...this.props} />
    }
    componentWillMount() {
        this.props.list.load();
    }
    render() {
        return <Sync sync={this.props.list.sync} onRenderDone={this._onRenderDone} />;
    }
}

class EXAMSActivityListApp extends EntitySourceApp {
    protected _onRenderSource = (props) => {
        return <EXAMSActivityListContainer list={getEntityActivityList(props.masterEntity)} />
    }
}

export {
    EXAMSActivityList,
    EXAMSActivityListContainer,
    IEXAMSActivityListProps,
    EXAMSActivityListApp,
    EXAMSActivityListApp as default
}