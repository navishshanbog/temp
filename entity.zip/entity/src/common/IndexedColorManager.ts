import * as randomColor from "randomcolor";
import { getTheme } from "@uifabric/styling";

let _initialColors : string[];

const getInitialColors = () : string[] => {
    if(!_initialColors) {
        const theme = getTheme();
        _initialColors = [];
        _initialColors.push(theme.palette.red);
        _initialColors.push(theme.palette.blue);
        _initialColors.push(theme.palette.green);
        _initialColors.push(theme.palette.yellow);
        _initialColors.push(theme.palette.magenta);
        _initialColors.push(theme.palette.orange);
        _initialColors.push(theme.palette.teal);
        _initialColors.push(theme.palette.redDark);
        _initialColors.push(theme.palette.blueDark);
        _initialColors.push(theme.palette.greenDark);
        _initialColors.push(theme.palette.yellowLight);
        _initialColors.push(theme.palette.magentaDark);
        _initialColors.push(theme.palette.orangeLight);
    }
    return _initialColors;
}

class IndexedColorManager {
    private _colors : { [key : number] : string } = {};
    getColor(index : number) : string {
        const ic = getInitialColors();
        if(index < ic.length) {
            return ic[index];
        }
        let color = this._colors[index];
        if(!color) {
            color = randomColor({ luminosity: "bright" });
            this._colors[index] = color;
        }
        return color;
    }
}

export { IndexedColorManager }