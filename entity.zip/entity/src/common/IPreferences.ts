import { IEntityPreferences } from "../entity/IEntityPrefences";

export { IEntityPreferences as IPreferences, IEntityPreferences as default }