import { IPreferences } from "../IPreferences";
import { EntitySearchResultViewType } from "../../search/EntitySearchResultViewType";
import { EntitySearchResultDataType } from "../../search/EntitySearchResultDataType";

interface IPreferencesModel extends IPreferences {
    data : IPreferences;
    setData(data : IPreferences) : void;
    setIsLinkOpenInANewWindow(isLinkOpenInANewWindow : boolean) : void;
    setShowPhotosInSearchResult(setShowPhotosInSearchResult : boolean) : void;
    setGroupSearchResultsByMaster(groupSearchResultsByMaster : boolean) : void;
    setSystemsToExcludeFromSearch(systemsToExcludeFromSearch : string[]) : void;
    setSearchResultViewType(searchResultViewType : EntitySearchResultViewType) : void;
    setSearchResultDataType(searchResultDataType : EntitySearchResultDataType) : void;
    setSearchResultColumnOrder(searchResultColumnOrder : string[]) : void;
}

export { IPreferencesModel }