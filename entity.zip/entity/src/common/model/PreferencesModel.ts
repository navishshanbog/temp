import { IPreferencesModel } from "./IPreferencesModel";
import { IPreferences } from "../IPreferences";
import { observable, computed, action } from "mobx";
import { EntitySearchResultViewType } from "../../search/EntitySearchResultViewType";
import { EntitySearchResultDataType } from "../../search/EntitySearchResultDataType";

class PreferencesModel implements IPreferencesModel {
    @observable private _isLinkOpenInANewWindow : boolean;
    @observable private _showPhotosInSearchResult : boolean;
    @observable private _groupSearchResultsByMaster : boolean = true;
    @observable private _systemsToExcludeFromSearch : string[] = [];
    @observable private _searchResultViewType : EntitySearchResultViewType;
    @observable private _searchResultDataType : EntitySearchResultDataType;
    @observable private _searchResultColumnOrder : string[] = [];

    constructor(data?: IPreferences) {
        this.setData(data);
    }

    @computed
    get isLinkOpenInANewWindow() {
        return this._isLinkOpenInANewWindow !== undefined ? this._isLinkOpenInANewWindow : true;
    }
    set isLinkOpenInANewWindow(value) {
        this.setIsLinkOpenInANewWindow(value);
    }
    @action
    setIsLinkOpenInANewWindow(isLinkOpenInANewWindow : boolean) {
        this._isLinkOpenInANewWindow = isLinkOpenInANewWindow;
    }

    @computed
    get groupSearchResultsByMaster() {
        return true;//this._groupSearchResultsByMaster !== undefined ? this._groupSearchResultsByMaster : true;
    }
    set groupSearchResultsByMaster(value) {
        this.setGroupSearchResultsByMaster(value);
    }
    @action
    setGroupSearchResultsByMaster(groupSearchResultsByMaster : boolean) {
        this._groupSearchResultsByMaster = groupSearchResultsByMaster;
    }

    @computed
    get showPhotosInSearchResult() {
        return this._showPhotosInSearchResult !== undefined ? this._showPhotosInSearchResult : false;
    }
    set showPhotosInSearchResult(value) {
        this.setShowPhotosInSearchResult(value);
    }
    @action
    setShowPhotosInSearchResult(showPhotosInSearchResult : boolean) {
        this._showPhotosInSearchResult = showPhotosInSearchResult;
    }

    @computed
    get searchResultViewType() {
        return this._searchResultViewType || EntitySearchResultViewType.TABLE;
    }
    set searchResultViewType(value) {
        this.setSearchResultViewType(value);
    }
    @action
    setSearchResultViewType(searchResultViewType : EntitySearchResultViewType) {
        this._searchResultViewType = searchResultViewType;
    }

    @computed
    get searchResultDataType() {
        return this._searchResultDataType || EntitySearchResultDataType.original;
    }
    set searchResultDataType(value) {
        this.setSearchResultDataType(value);
    }
    @action
    setSearchResultDataType(searchResultDataType : EntitySearchResultDataType) {
        this._searchResultDataType = searchResultDataType;
    }

    @computed
    get searchResultColumnOrder() {
        return this._searchResultColumnOrder.slice(0);
    }
    set searchResultColumnOrder(value) {
        this.setSearchResultColumnOrder(value);
    }
    @action
    setSearchResultColumnOrder(searchResultColumnOrder : string[]) {
        this._searchResultColumnOrder = [];
        if(searchResultColumnOrder) {
            searchResultColumnOrder.forEach(v => {
                this._searchResultColumnOrder.push(v);
            });
        }
    }

    @computed
    get systemsToExcludeFromSearch() {
        return this._systemsToExcludeFromSearch.slice(0);
    }
    set systemsToExcludeFromSearch(value) {
        this.setSystemsToExcludeFromSearch(value);
    }
    @action
    setSystemsToExcludeFromSearch(systemsToExcludeFromSearch : string[]) {
        this._systemsToExcludeFromSearch = [];
        if(systemsToExcludeFromSearch) {
            systemsToExcludeFromSearch.forEach(v => {
                this._systemsToExcludeFromSearch.push(v);
            });
        }
    }
    @computed
    get data() {
        return {
            isLinkOpenInANewWindow: this._isLinkOpenInANewWindow,
            showPhotosInSearchResult: this._showPhotosInSearchResult,
            groupSearchResultsByMaster: true,//this._groupSearchResultsByMaster,
            systemsToExcludeFromSearch: this._systemsToExcludeFromSearch.slice(0),
            searchResultViewType: this._searchResultViewType,
            searchResultDataType: this._searchResultDataType,
            searchResultColumnOrder: this._searchResultColumnOrder.slice(0)
        };
    }
    set data(value) {
        this.setData(value);
    }
    @action
    setData(data : IPreferences) {
        this.setIsLinkOpenInANewWindow(data ? data.isLinkOpenInANewWindow : undefined);
        this.setShowPhotosInSearchResult(data ? data.showPhotosInSearchResult : undefined);
        this.setGroupSearchResultsByMaster(true);
        this.setSystemsToExcludeFromSearch(data ? data.systemsToExcludeFromSearch : undefined);
        this.setSearchResultViewType(data ? data.searchResultViewType : undefined);
        this.setSearchResultDataType(data ? data.searchResultDataType : undefined);
        this.setSearchResultColumnOrder(data ? data.searchResultColumnOrder : undefined);
    }
}

export { PreferencesModel }