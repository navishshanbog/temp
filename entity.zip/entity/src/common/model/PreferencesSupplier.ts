import { AutoSaveSyncSupplier } from "@twii/common/lib/model/AutoSaveSyncSupplier";
import { StorageServiceContext } from "@twii/common/lib/StorageServiceContext";
import { IPreferencesModel } from "./IPreferencesModel";
import { PreferencesModel } from "./PreferencesModel";

const prefsKey = "entity-search-prefs";

const PreferencesSupplier = new AutoSaveSyncSupplier<IPreferencesModel>();
// we'll leave the defaults to the model
PreferencesSupplier.defaultValue = new PreferencesModel();
PreferencesSupplier.loader = () => {
    return StorageServiceContext.value.getItem(prefsKey).then(r => {
        return new PreferencesModel(r);
    });
};
PreferencesSupplier.saver = (value : IPreferencesModel) => {
    return StorageServiceContext.value.setItem(prefsKey, value.data);
};

export { PreferencesSupplier }