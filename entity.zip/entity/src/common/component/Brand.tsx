import * as React from "react";
import * as logoUrl from "./Logo.png";
import { Image } from "office-ui-fabric-react/lib/Image";
import { IBrandClassNames, getClassNames } from "./Brand.classNames";
import { getStyles, IBrandStyles } from "./Brand.styles";

interface IBrandProps {
    onClick?: (e : React.MouseEvent<HTMLButtonElement>) => void;
    styles?: IBrandStyles;
    className?: string;
}

class Brand extends React.Component<IBrandProps, any> {
    private _classNames : IBrandClassNames;
    private _renderLogo() : React.ReactNode {
        return (
            <div className={this._classNames.logo} aria-hidden={true}>
                <Image src={String(logoUrl)} alt="Entity Search" />
            </div>
        );
    }
    private _renderTitle() : React.ReactNode {
        return (
            <div className={this._classNames.title}>
                Entity Search
            </div>
        )
    }
    render() {
        this._classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <button type="button" className={this._classNames.root} onClick={this.props.onClick} title="Entity Search">
                {this._renderLogo()}
                {this._renderTitle()}
            </button>
        );
    }
}

export { IBrandProps, Brand }