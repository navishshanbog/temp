import * as React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { IndexedColorManager } from "../IndexedColorManager";

interface IIndexedColorIconProps {
    index: number;
    indexedColorManager: IndexedColorManager;
    title?: string;
    className?: string;
}

class IndexedColorIcon extends React.Component<IIndexedColorIconProps, any> {
    render() {
        const color = this.props.indexedColorManager.getColor(this.props.index);
        return <Icon className={this.props.className} style={{ color: color }} iconName="CircleFill" title={this.props.title} />;
    }
}

export { IndexedColorIcon, IIndexedColorIconProps }