import * as React from "react";
import { ISettingsStyles, getStyles } from "./Settings.styles";
import { getClassNames } from "./Settings.classNames";
import { OpenLinkInNewWindowToggle, ShowPhotosInSearchResultToggle } from "./Preferences";
import { PreferencesSupplier } from "../model/PreferencesSupplier";
import { ClearHistoryButton } from "@twii/common/lib/component/History";
import { MasterEntitySearchHistoryStore } from "../../entity/MasterEntitySearchHistoryStore";
import { SearchRequestHistoryStore } from "../../search/model/SearchRequestHistoryStore";
import MasterEntityVisitedHistoryStore from "../../entity/MasterEntityVisitedHistoryStore";
import { Spinner, SpinnerSize } from "office-ui-fabric-react/lib/Spinner";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { observer } from "mobx-react";

interface ISettingsProps {
    styles?: ISettingsStyles;
    className?: string;
}

@observer
class ClearRecentSearchesButton extends React.Component<any, any> {
    componentWillMount() {
        MasterEntitySearchHistoryStore.load();
        SearchRequestHistoryStore.load();
    }
    private _onClick = () => {
        MasterEntitySearchHistoryStore.clear();
        SearchRequestHistoryStore.clear();
    }
    private _onRenderSync = () => {
        return <Spinner size={SpinnerSize.small} />;
    }
    render() {
        const syncing = MasterEntitySearchHistoryStore.sync.syncing || SearchRequestHistoryStore.sync.syncing;
        const disabled = syncing || (MasterEntitySearchHistoryStore.items.length === 0 && SearchRequestHistoryStore.items.length === 0);
        const iconProps = !syncing ? { iconName: "Clear" } : undefined;
        const onRenderIcon = syncing ? this._onRenderSync : undefined;
        return (
            <PrimaryButton {...this.props.buttonProps}
                            disabled={disabled}
                            onClick={this._onClick}
                            iconProps={iconProps}
                            onRenderIcon={onRenderIcon}>
                Clear Recent Searches
            </PrimaryButton>
        );
    }
}

const createSettingsItem = () : IContextualMenuItem => {
    const items : IContextualMenuItem[] = [
        {
            key: "openLinkInNewWindow",
            onRender(item) {
                return (
                    <div data-is-focusable={true} key={item.key} style={{ minWidth: 280, display: "flex", justifyContent: "center", alignItems: "center" }}>
                        <OpenLinkInNewWindowToggle />
                    </div>
                );
            }
        },
        {
            key: "sep1",
            name: "-"
        },
        {
            key: "clearRecentSearches",
            onRender(item) {
                return (
                    <div key={item.key} style={{ minWidth: 200, padding: 8, display: "flex", justifyContent: "center" }}>
                        <ClearRecentSearchesButton />
                    </div>
                )
            }
        },
        {
            key: "sep2",
            name: "-"
        },
        {
            key: "clearRecentEntities",
            onRender(item) {
                return (
                    <div key={item.key} style={{ minWidth: 200, padding: 8, display: "flex", justifyContent: "center" }}>
                        <ClearHistoryButton history={MasterEntityVisitedHistoryStore}>
                            Clear Recent Entities
                        </ClearHistoryButton>
                    </div>
                );
            }
        }
    ];
    return {
        key: "entitySettings",
        title: "Settings",
        iconProps: {
            iconName: "Settings"
        },
        subMenuProps: {
            items: items
        }
    }
};


class Settings extends React.Component<ISettingsProps, any> {
    render() {
        const classNames = getClassNames(getStyles(null, this.props.styles), this.props.className);
        return (
            <div className={classNames.root}>
                <div className={classNames.content}>
                    <div className={classNames.section}>
                        <h3 className={classNames.sectionTitle}>Preferences</h3>
                        <div className={classNames.sectionBody}>
                            <div>
                                <OpenLinkInNewWindowToggle />
                            </div>
                            <div>
                                <ShowPhotosInSearchResultToggle />
                            </div>
                        </div>
                    </div>
                    <div className={classNames.section}>
                        <h3 className={classNames.sectionTitle}>Recent Searches</h3>
                        <div className={classNames.sectionBody}>
                            <ClearRecentSearchesButton />
                        </div>
                    </div>
                    <div className={classNames.section}>
                        <h3 className={classNames.sectionTitle}>Recent Entities</h3>
                        <div className={classNames.sectionBody}>
                            <ClearHistoryButton history={MasterEntityVisitedHistoryStore}>
                                Clear Recent Entities
                            </ClearHistoryButton>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export {
    Settings,
    ISettingsProps,
    createSettingsItem
}