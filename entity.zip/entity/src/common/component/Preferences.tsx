import * as React from "react";
import { BoundToggle } from "@twii/common/lib/component/BoundToggle";
import { PreferencesSupplier } from "../model/PreferencesSupplier";

class OpenLinkInNewWindowToggle extends React.Component<any, any> {
    render() {
        return (
            <BoundToggle label="Open Links in a new Window"
                         binding={{ target: PreferencesSupplier.value, key: "isLinkOpenInANewWindow" }}
                         styles={
                            { 
                               root: {
                                   display: "flex",
                                   alignItems: "center",
                                   paddingTop: 8
                               },
                               label: {
                                   paddingRight: 8
                               }
                           }
                       } />
        );
    }
}

interface IShowPhotosInSearchResultToggleProps {
    label?: string;
}

class ShowPhotosInSearchResultToggle extends React.Component<IShowPhotosInSearchResultToggleProps, any> {
    render() {
        return (
            <BoundToggle label={this.props.label || "Show Images in Search Result"}
                         binding={{ target: PreferencesSupplier.value, key: "showPhotosInSearchResult" }}
                         styles={
                            { 
                                root: {
                                    display: "flex",
                                    alignItems: "center",
                                    paddingTop: 8
                                },
                                label: {
                                    paddingRight: 8,
                                    paddingLeft: 8
                                }
                            }
                         } />
        );
    }
}

const showPhotosInSearchResultMenuItem = (props : IShowPhotosInSearchResultToggleProps, key : string = "showPhotosInSearchResult") => {
    return {
        key: key,
        onRender(item) {
            return <ShowPhotosInSearchResultToggle key={item.key} {...props} />
        }
    }
};

interface IGroupSearchResultsByMasterToggleProps {
    label?: string;
    onChanged? : (checked : boolean) => void;
}

class GroupSearchResultsByMasterToggle extends React.Component<IGroupSearchResultsByMasterToggleProps, any> {
    render() {
        return (
            <BoundToggle label={this.props.label || "Group Results"}
                         binding={{ target: PreferencesSupplier.value, key: "groupSearchResultsByMaster" }}
                         onChanged={this.props.onChanged}
                         styles={
                             {
                                 root: {
                                     display: "flex",
                                     alignItems: "center",
                                     paddingTop: 8
                                 },
                                 label: {
                                     paddingRight: 8,
                                     paddingLeft: 8
                                 }
                             }
                         } />
        );
    }
}

const groupSearchResultsByMasterMenuItem = (props : IGroupSearchResultsByMasterToggleProps, key : string = "groupSearchResultsByMaster") => {
    return {
        key: key,
        onRender(item) {
            return <GroupSearchResultsByMasterToggle key={item.key} {...props} />
        }
    }
};

export {
    OpenLinkInNewWindowToggle,
    ShowPhotosInSearchResultToggle,
    showPhotosInSearchResultMenuItem,
    IGroupSearchResultsByMasterToggleProps,
    GroupSearchResultsByMasterToggle,
    groupSearchResultsByMasterMenuItem
}