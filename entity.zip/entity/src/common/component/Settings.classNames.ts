import { memoizeFunction } from "@uifabric/utilities";
import { ISettingsStyles } from "./Settings.styles";
import { mergeStyleSets } from "@uifabric/styling";

interface ISettingsClassNames {
    root?: string;
    content?: string;
    section?: string;
    sectionTitle?: string;
    sectionBody?: string;
}

const getClassNames = memoizeFunction((styles : ISettingsStyles, className?: string) : ISettingsClassNames => {
    return mergeStyleSets({
        root: ["entity-settings", styles.root, className],
        content: ["entity-settings-content", styles.content],
        section: ["entity-settings-section", styles.section],
        sectionTitle: ["entity-settings-section-title", styles.sectionTitle],
        sectionBody: ["entity-settings-section-body", styles.sectionBody]
    });
});

export { ISettingsClassNames, getClassNames }