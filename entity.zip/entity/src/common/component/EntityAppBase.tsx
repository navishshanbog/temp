import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { IUserProfile } from "@twii/ozone/lib/user/IUserProfile";
import { IMutableSupplier } from "@twii/common/lib/IMutableSupplier";
import { IRequest } from "@twii/common/lib/IRequest";
import { getRequestSupplier } from "@twii/common/lib/AppPanelUtils";

class EntityAppBase extends React.Component<IAppProps, any> {
    get host() : IAppHost {
        return this.props.match.host;
    }
    get userProfile() : IUserProfile {
        return this.props.match.userProfile;
    }
    get panelRequestSupplier() : IMutableSupplier<IRequest> {
        return getRequestSupplier(this.host);
    }
    render() {
        return null;
    }
}

export { EntityAppBase }