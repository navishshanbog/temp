import { IAppProps } from "@twii/common/lib/component/IAppProps";

interface IEntityAppProps extends IAppProps {}

export { IEntityAppProps }