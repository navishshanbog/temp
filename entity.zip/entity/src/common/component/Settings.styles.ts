import { IStyle, ITheme, getTheme, concatStyleSets, FontWeights } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface ISettingsStyles {
    root?: IStyle;
    content?: IStyle;
    section?: IStyle;
    sectionTitle?: IStyle;
    sectionBody?: IStyle;
}

const defaultStyles = (theme : ITheme) : ISettingsStyles => {
    return {
        root: { display: "flex", justifyContent: "center" },
        content: { width: "60%" },
        section: {
            
        },
        sectionTitle: {
            margin: 8,
            fontWeight: FontWeights.semibold
        },
        sectionBody: {
            margin: 8
        }
    };
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles?: ISettingsStyles) : ISettingsStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export {
    ISettingsStyles,
    defaultStyles,
    Defaults,
    getStyles
}