import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { IUserProfile } from "@twii/ozone/lib/user/IUserProfile";
import { Settings } from "./Settings";
import { HostAppView } from "@twii/common/lib/component/HostAppView";
import { getTheme } from "@uifabric/styling";

class SettingsApp extends React.Component<IAppProps, any> {
    get host() : IAppHost {
        return this.props.match.host;
    }
    get userProfile() : IUserProfile {
        return this.props.match.userProfile;
    }
    componentWillMount() {
        this.host.title = "Entity Search Settings";
    }
    render() {
        return (
            <HostAppView host={this.host} styles={{ root: { backgroundColor: getTheme().palette.neutralLighter } }}>
                <Settings />
            </HostAppView>
        );
    }
}

export { SettingsApp, SettingsApp as default }