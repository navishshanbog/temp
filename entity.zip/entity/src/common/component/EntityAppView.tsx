import * as React from "react";
import { HostAppView, IHostAppViewProps } from "@twii/common/lib/component/HostAppView";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { ICommandBarProps } from "office-ui-fabric-react/lib/CommandBar";
import { IUserProfile } from "@twii/ozone/lib/user/IUserProfile";
import { createUserProfileMenu } from "@twii/ozone/lib/user/component/UserProfileMenuHelper";
import { PathsContext } from "../../PathsContext";
import { IMutableSupplier } from "@twii/common/lib/IMutableSupplier";
import { IRequest } from "@twii/common/lib/IRequest";
import { getRequestSupplier } from "@twii/common/lib/AppPanelUtils";
import { PanelType, IPanelProps } from "office-ui-fabric-react/lib/Panel";
import { AppPanelContainer } from "@twii/common/lib/component/AppPanel";
import { createSettingsItem } from "./Settings";
import "./EntityAppView.scss";

interface IEntityAppViewProps extends IHostAppViewProps {
    userProfile?: IUserProfile;
    hideSettings?: boolean;
    hideHelp?: boolean;
    hideProtectedMarker?: boolean;
    panelRequestSupplier?: IMutableSupplier<IRequest>;
    panelProps?: IPanelProps;
}

class EntityAppView extends React.Component<IEntityAppViewProps, any> {
    private _onClickHelp = () => {
        if(this.panelRequestSupplier.value) {
            this.panelRequestSupplier.clearValue();
        } else {
            this.panelRequestSupplier.setValue({ path: PathsContext.value.help(), panelProps: { type: PanelType.medium }});
        }
    }
    get panelRequestSupplier() : IMutableSupplier<IRequest> {
        return this.props.panelRequestSupplier || getRequestSupplier(this.props.host);
    }
    render() {
        const commandBarProps : ICommandBarProps = Object.assign({}, this.props.commandBarProps);
        let items : IContextualMenuItem[] = [];
        if(commandBarProps.items) {
            items = items.concat(commandBarProps.items);
        }
        if(!this.props.hideProtectedMarker) {
            items.push(
                {
                    key: "protectedMarker",
                    onRender() {
                        return (
                            <div className="entity-app-view-app-header-security">
                                PROTECTED
                            </div>
                        );
                    }
                }
            );
        }

        let farItems : IContextualMenuItem[] = [];
        
        if(!this.props.hideHelp) {
            farItems.push({
                key: "entityHelp",
                title: "Entity Search Help",
                iconProps: {
                    iconName: "Help"
                },
                onClick: this._onClickHelp
            });
        }
        if(!this.props.hideSettings) {
            farItems.push(
                createSettingsItem()
            );
        }
        // if we're in the root context, then show user details (which currently come from ozone services)
        if(this.props.host.root && this.props.userProfile) {
            farItems.push(createUserProfileMenu(this.props.userProfile));
        }

        if(commandBarProps.farItems) {
            farItems = commandBarProps.farItems.concat(farItems);
        }
        commandBarProps.items = items;
        commandBarProps.farItems = farItems;
        return (
            <HostAppView {...this.props} commandBarProps={commandBarProps}>
                <AppPanelContainer requestSupplier={this.panelRequestSupplier} router={this.props.host.router} panelProps={this.props.panelProps} />
                {this.props.children}
            </HostAppView>
        );
    }
}

export { EntityAppView, IEntityAppViewProps }