import * as React from "react";
import { Link } from "office-ui-fabric-react/lib/Link";
import { AppContext } from "@twii/common/lib/AppContext";
import { IAppProps } from "@twii/common/lib/component/IAppProps";

class Help extends React.Component<any, any> {
    render() {
        return (
            <div>
                <div className="default-help">
                    <p>
                        Entity Search provides a view of person and organisation information from several separate data sources.
                        For detailed instructions on using Entity Search, please refer to the user guide available at ADD2017/2455581.
                        For more information, please contact the <Link href={`mailto:CIEICP@homeaffairs.gov.au?subject=Analyst Desktop${!AppContext.value.config.production ? " (Non Production)" : ""}`}>Intelligence Business Capability</Link> team.
                    </p>
                </div>
            </div>
        );
    }
}

class HelpApp extends React.Component<IAppProps, any> {
    componentWillMount() {
        this.props.match.host.title = "Entity Search Help";
    }
    render() {
        return <Help />;
    }
}


export { HelpApp, HelpApp as default, Help }