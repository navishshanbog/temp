import HandleModel from "@twii/common/lib/HandleModel";
import ITypedValue from "@twii/common/lib/ITypedValue";

const ClipboardStore = new HandleModel<ITypedValue>();

export { ClipboardStore as default, ClipboardStore }