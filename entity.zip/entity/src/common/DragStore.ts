import HandleModel from "@twii/common/lib/HandleModel";
import ITypedValue from "@twii/common/lib/ITypedValue";

const DragStore = new HandleModel<ITypedValue>();

export { DragStore as default, DragStore }