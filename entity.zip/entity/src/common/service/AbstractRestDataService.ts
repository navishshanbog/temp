import * as DefaultHttpErrorHandler from "@twii/common/lib/HttpErrorHandler";

const defaultRequestErrorHandler = (error : any) => {
    if(error.response && error.response.status === 504) {
        throw {
            message: "Request Timed Out",
            description: "The server is currently not responding. If the problem persists, please contact CIEICP@homeaffairs.gov.au with a description of the problem."
        };
    }
    throw error;
};

const ds404ToEmptyArrayHandler = (error): any => {
    if (error.response && error.response.status === 404) {
        return [];
    }
    DefaultHttpErrorHandler.handleAxiosError(error);
};


const Defaults = {
    baseUrl: "/DataServices",
    NoResultErrorCode: "0101",
    onRequestError: defaultRequestErrorHandler,
    requestHeaders: {
        'X-Clientapp-Id': 'AnalystDesktop-EntitySearchPortal'
    }
};

abstract class AbstractRestDataService {
    private _baseUrl : string;
    get baseUrl() {
        return this._baseUrl || Defaults.baseUrl;
    }
    set baseUrl(value) {
        this._baseUrl = value;
    }
    protected assertObject(data: any) : any {
        if (data && typeof(data) !== 'object') {
            throw new Error(`UNEXPECTED_RESPONSE_TYPE: Expected response to be an object, but got ${typeof(data)}. Data - ${data}`);
        }
        return data;
    }
    protected handleDataServiceError(errors : any, emptyResult: any = []) : any {
        if(errors && errors.code !== Defaults.NoResultErrorCode) {
            throw errors;
        }
        return emptyResult;
    }
    protected _handleRequestError = (error : any) : any => {
       return Defaults.onRequestError(error);
    }
}

export { AbstractRestDataService, defaultRequestErrorHandler, Defaults, ds404ToEmptyArrayHandler };