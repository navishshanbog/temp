interface IServiceResponseStatus {
    ReturnCode?: string;
    ReturnMessage?: string;
}

export { IServiceResponseStatus }