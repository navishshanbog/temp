import { Router } from "@twii/common/lib/Router";
import { exactPath } from "@twii/common/lib/Routers";
import { reactRouter } from "@twii/common/lib/Routers";
import { launchHandler } from "./listing/ListingLaunch";

const r = new Router();
r.use("/bookmarks", reactRouter(() => import("./listing/component/ListingBookmarksApp")));
r.use("/store", reactRouter(() => import("./listing/component/ListingStoreFrontApp")));
r.use("/listings", reactRouter(() => import("./listing/component/ListingListApp")));
r.use("/listings/user", reactRouter(() => import("./listing/component/UserListingsApp")));
r.use("/listings/add", reactRouter(() => import("./listing/component/ListingAddApp")));
r.use("/listings/:listingId", reactRouter(() => import("./listing/component/ListingApp")));
r.use("/listings/:listingId/launch", exactPath(launchHandler));
r.use("/listings/:listingId/edit", reactRouter(() => import("./listing/component/ListingEditApp")));

export { r as Router, r as default }