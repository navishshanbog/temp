interface ITag {
    id?: number;
    name?: string;
}

export { ITag }