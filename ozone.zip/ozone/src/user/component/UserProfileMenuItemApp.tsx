import * as React from "react";
import { OzoneAppBase } from "../../common/component/OzoneAppBase";
import { createUserProfileMenu } from "./UserProfileMenuHelper";
import { IconButton } from "office-ui-fabric-react/lib/Button";

/**
 * This is for legacy stuff
 */
class UserProfileMenuItemApp extends OzoneAppBase {
    private _onRenderHiddenMenuIcon = () => {
        return null;
    }
    protected get hideMenuIcon() {
        return this.host.params.hideMenuIcon ? true : false;
    }
    render() {
        const item = createUserProfileMenu(this.userProfile);
        return (
            <IconButton className="app-menu-button user-profile-menu-item"
                        iconProps={item.iconProps}
                        ariaLabel={item.ariaLabel}
                        menuProps={item.subMenuProps}
                        onRenderMenuIcon={this.hideMenuIcon ? this._onRenderHiddenMenuIcon : undefined} />
        );
    }
}

export { UserProfileMenuItemApp, UserProfileMenuItemApp as default }