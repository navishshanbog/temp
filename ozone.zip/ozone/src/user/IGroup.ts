interface IGroup {
    name?: string;
}

export { IGroup }