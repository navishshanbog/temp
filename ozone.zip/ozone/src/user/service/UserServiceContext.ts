import { Context } from "@twii/common/lib/Context";
import { IUserService } from "./IUserService";

const UserServiceContext = new Context<IUserService>();

export { UserServiceContext }