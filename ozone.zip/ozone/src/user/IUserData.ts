interface IUserData {
    username?: string;
    key?: string;
    entity?: string;
    content_type?: string;
    version?: string;
}

export { IUserData }