interface ICategory {
    id?: number;
    title?: string;
    description?: string;
}

export { ICategory }