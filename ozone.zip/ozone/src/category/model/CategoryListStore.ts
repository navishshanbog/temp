import { CategoryListModel } from "./CategoryListModel";

const CategoryListStore = new CategoryListModel();

export { CategoryListStore }