interface IListingFeedback {
    id: number;
    feedback: number;
}

export { IListingFeedback }