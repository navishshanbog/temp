import { ListModel } from "@twii/common/lib/model/ListModel";
import { IListingType } from "../IListingType";
import { IListingService } from "../service/IListingService";
import { ListingServiceContext } from "../service/ListingServiceContext";

class ListingTypeListModel extends ListModel<IListingType> {
    private _service : IListingService;
    get service() {
        return this._service || ListingServiceContext.value;
    }
    set service(value) {
        this._service = value;
    }

    protected _loadImpl() {
        return this.service.getListingTypes();
    }
}

export { ListingTypeListModel }