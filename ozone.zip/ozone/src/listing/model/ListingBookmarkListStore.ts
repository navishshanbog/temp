import { ListingBookmarkListModel } from "./ListingBookmarkListModel";

const ListingBookmarkListStore = new ListingBookmarkListModel();

export { ListingBookmarkListStore }