import { IListing } from "../IListing";
import { ListingApprovalStatus } from "../ListingApprovalStatus";
import { IImage } from "../../media/IImage";
import { IListingLinkModel } from "./IListingLinkModel";
import { ISync } from "@twii/common/lib/ISync";
import { IError } from "@twii/common/lib/IError";
import { IStateManager } from "@twii/common/lib/IStateManager";
import { ICategory } from "../../category/ICategory";
import { IListingType } from "../IListingType";

interface IListingModel extends IListing, IStateManager {
    validationErrors: IError[];
    valid: boolean;
    loadSync : ISync;
    saveSync : ISync;
    state : any;
    doc_urls : IListingLinkModel[];
    data : IListing;
    canSubmit : boolean;
    setUniqueName(uniqueName : string) : void;
    setTitle(title : string) : void;
    setDescription(description : string) : void;
    setShortDescription(shortDescription : string) : void;
    setEnabled(enabled : boolean) : void;
    setFeatured(featured : boolean) : void;
    setPrivate(prv : boolean) : void;
    setLaunchUrl(url : string) : void;
    setSecurityMarking(securityMarking : string) : void;
    setVersionName(version : string) : void;
    setApprovalStatus(status : ListingApprovalStatus) : void;
    setSmallIcon(smallIcon : IImage) : void;
    setLargeIcon(largeIcon : IImage) : void;
    setBannerIcon(bannerIcon : IImage) : void;
    setLargeBannerIcon(largeBannerIcon : IImage) : void;
    setCategories(categories : ICategory[]) : void;
    addCategory(category : ICategory) : void;
    removeCategory(category : ICategory) : void;
    setListingType(listingType : IListingType) : void;
    submitForApproval() : Promise<any>;
    approve() : Promise<any>;
    reject() : Promise<any>;
    save() : Promise<any>;
    delete() : Promise<any>;
    reset() : void;
    addLink() : void;
    removeLink(link : IListingLinkModel) : void;
    enable() : Promise<any>;
    disable() : Promise<any>;
    savedEnabled(enabled : boolean) : Promise<any>;
    saveFeatured(featured : boolean) : Promise<any>;
    saveIframeCompatible(iframeCompatible : boolean) : Promise<any>;
    setIframeCompatible(iframeCompatible : boolean) : void;
    setData(data : IListing) : void;
    upload(file : File) : Promise<any>;
    refresh() : Promise<any>;
    load() : Promise<any>;
}

export { IListingModel }