import { ListingTypeListModel } from "./ListingTypeListModel";

const ListingTypeListStore = new ListingTypeListModel();

export { ListingTypeListStore }