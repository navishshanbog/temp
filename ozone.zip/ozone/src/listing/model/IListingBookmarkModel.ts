import { IListingBookmark } from "../IListingBookmark";
import { ISync } from "@twii/common/lib/ISync";
import { IListingBookmarkListModel } from "./IListingBookmarkListModel";

interface IListingBookmarkModel extends IListingBookmark {
    bookmarks : IListingBookmarkListModel;
    launchSync: ISync;
    data: IListingBookmark;
    setData(data : IListingBookmark) : void;
    launch() : Promise<any>;
    remove() : void;
}

export { IListingBookmarkModel }