import ListingListModel from "./ListingListModel";

const ListingListStore = new ListingListModel();

export { ListingListStore }