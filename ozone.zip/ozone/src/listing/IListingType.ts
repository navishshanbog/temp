interface IListingType {
    title?: string;
    description?: string;
}

export { IListingType }