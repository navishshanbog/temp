import { ITheme, IStyle,  } from "@uifabric/styling";
import { IStyleFunctionOrObject } from "@uifabric/utilities";
import { IListingModel } from "../model/IListingModel";

export interface IListingUploadProps {
    listing: IListingModel;
    className?: string;
    styles?: IStyleFunctionOrObject<IListingUploadStyleProps, IListingUploadStyles>;
    theme?: ITheme;
    onAfterUpload?: (props : IListingUploadProps) => void;
}

export interface IListingUploadStyleProps {
    className?: string;
    theme?: ITheme;
}

export interface IListingUploadStyles {
    root?: IStyle;
    content?: IStyle;
}