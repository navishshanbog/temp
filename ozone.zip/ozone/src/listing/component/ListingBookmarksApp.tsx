import * as React from "react";
import { ListingBookmarksContainer } from "./ListingBookmarks";
import { ListingBookmarkListStore } from "../model/ListingBookmarkListStore";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { AppLink } from "@twii/common/lib/component/AppLink";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { IUserProfile } from "../../user/IUserProfile";
import { UserAdminContext } from "../../user/UserAdminContext";
import { OzoneAppView } from "../../common/component/OzoneAppView";
import { ListingViewConfig } from "./ListingViewConfig";
import { PathsContext } from "../../PathsContext";
import { IListingBookmark } from "../IListingBookmark";
import { IMutableSync } from "@twii/common/lib/IMutableSync";
import { Sync } from "@twii/common/lib/model/Sync";
import { launch } from "../ListingLaunch";
import { ListingLaunchDialog } from "./ListingLaunchDialog";
import { IListing } from "../IListing";

class ListingBookmarksApp extends React.Component<IAppProps, any> {
    get host() : IAppHost {
        return this.props.match.host;
    }
    get userProfile() : IUserProfile {
        return this.props.match.userProfile;
    }
    get launchSync() : IMutableSync<IListing> {
        return this.host.getState("listingLaunchSync", () => {
            return new Sync();
        });
    }
    private _onLaunchBookmark = (bookmark : IListingBookmark) => {
        this.launchSync.syncStart({ id: bookmark.listing });
        launch({ host: this.host, userProfile: this.userProfile, listingId: bookmark.listing.id }).then(app => {
            this.launchSync.syncEnd();
        }).catch(err => {
            this.launchSync.syncError(err);  
        });
    }
    componentWillMount() {
        this.host.setTitle("Bookmarks");
    }
    private _onLoadStore = () => {
        this.host.load({ path: PathsContext.value.store() });
    }
    private _onLoadAllListings = () => {
        this.host.load({ path: PathsContext.value.listings() });
    }
    private _onRenderNoBookmarks = () => {
        return (
            <div style={{ padding: 8 }}>
                <MessageBar  messageBarType={MessageBarType.info}>
                    You haven't bookmarked anything. <AppLink host={this.host} request={{ path: PathsContext.value.store() }} onClick={this._onLoadStore}>Take a look in the {ListingViewConfig.storeLabel}</AppLink>.
                </MessageBar>
            </div>
        );
    }
    render() {
        const farItems : IContextualMenuItem[] = [
            {
                key: "store",
                name: `${ListingViewConfig.storeLabel}`,
                iconProps: {
                    iconName: "Shop"
                },
                onClick: this._onLoadStore
            }
        ];
        if(UserAdminContext.value(this.userProfile)) {
            farItems.push({
                key: "listings",
                name: `All ${ListingViewConfig.labelPlural}`,
                iconProps: {
                    iconName: "ViewList"
                },
                onClick: this._onLoadAllListings
            });
        }
        
        return (
            <OzoneAppView host={this.host} userProfile={this.userProfile} commandBarProps={{ items: [], farItems: farItems }}>
                <ListingLaunchDialog sync={this.launchSync} />
                <ListingBookmarksContainer bookmarkList={ListingBookmarkListStore} onLaunch={this._onLaunchBookmark} onRenderNoBookmarks={this._onRenderNoBookmarks} />
            </OzoneAppView>
        );
    }
}

export {
    ListingBookmarksApp,
    ListingBookmarksApp as default
}