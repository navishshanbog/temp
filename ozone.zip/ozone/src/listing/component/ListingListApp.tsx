import * as React from "react";
import { ListingListModel } from "../model/ListingListModel";
import { IListing } from "../IListing";
import { ListingListPage } from "./ListingListPage";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { OzoneAppView } from "../../common/component/OzoneAppView";
import { ListingViewConfig } from "./ListingViewConfig";
import { PathsContext } from "../../PathsContext";
import { IMutableSync } from "@twii/common/lib/IMutableSync";
import { Sync } from "@twii/common/lib/model/Sync";
import { launch } from "../ListingLaunch";
import { ListingLaunchDialog } from "./ListingLaunchDialog";
import { OzoneAppBase } from "../../common/component/OzoneAppBase";
import { syncRefreshItem } from "@twii/common/lib/component/SyncRefreshAction";

class ListingListApp extends OzoneAppBase {
    private _onSelectItem = (item : IListing) => {
        this.host.load({ path: PathsContext.value.listingDetails(item.id) });
    }
    private _onAdd = () => {
        this.host.load({ path: PathsContext.value.listingAdd() });
    }
    private _onRefresh = () =>{
        this.listings.refresh();
    }
    get launchSync() : IMutableSync<IListing> {
        return this.host.getState("appLaunchSync", () => {
            return new Sync();
        });
    }
    private _onLaunchApp = (listing : IListing) => {
        this.launchSync.syncStart({ id: listing });
        launch({ host: this.host, userProfile: this.userProfile, listingId: listing.id, noReplace: true }).then(app => {
            this.launchSync.syncEnd();
        }).catch(err => {
            this.launchSync.syncError(err);  
        });
    }
    get listings() {
        return this.host.getState("allListings", () => {
            return new ListingListModel();
        });
    }
    componentWillMount() {
        this.host.title = `All ${ListingViewConfig.labelPlural}`;
        // we deliberately refresh here
        this.listings.load();
    }
    render() {
        const items : IContextualMenuItem[] = [];
        items.push(
            {
                key: "add",
                name: `Add ${ListingViewConfig.label}`,
                title: `Add a new ${ListingViewConfig.label}`,
                iconProps: {
                    iconName: "Add"
                },
                onClick: this._onAdd
            }
        );
        const farItems : IContextualMenuItem[] = [
            syncRefreshItem({ sync: this.listings.sync, onClick: this._onRefresh })
        ];
        return (
            <OzoneAppView host={this.host} userProfile={this.userProfile} commandBarProps={{ items: items, farItems: farItems }}>
                <ListingLaunchDialog sync={this.launchSync} />
                <ListingListPage compact wrapping
                                 listings={this.listings}
                                 onSelectItem={this._onSelectItem}
                                 onLaunch={this._onLaunchApp} />
            </OzoneAppView>
        );
    }
}

export {
    ListingListApp,
    ListingListApp as default
}
