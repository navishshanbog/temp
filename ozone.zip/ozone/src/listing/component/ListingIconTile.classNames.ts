import { mergeStyleSets } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";
import { IListingIconTileStyles } from "./ListingIconTile.styles";

interface IListingIconTileClassNames {
    root?: string;
    top?: string;
    actions?: string;
    content?: string;
    title?: string;
}

const getClassNames = memoizeFunction((styles : IListingIconTileStyles, className?: string) : IListingIconTileClassNames => {
    return mergeStyleSets({
        root: ["listing-icon-tile", styles.root, className],
        top: ["listing-icon-tile-top", styles.top],
        actions: ["listing-icon-title-actions", styles.actions],
        content: ["listing-icon-tile-content", styles.content],
        title: ["listing-icon-tile-title", styles.title]
    })
});

export {
    IListingIconTileClassNames,
    getClassNames
}