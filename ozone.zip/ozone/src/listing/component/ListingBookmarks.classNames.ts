import { mergeStyleSets } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";
import { IListingBookmarkStyles } from "./ListingBookmarks.styles";

interface IListingBookmarkClassNames {
    root?: string;
}

const getClassNames = memoizeFunction((styles : IListingBookmarkStyles, className?: string) : IListingBookmarkClassNames => {
    return mergeStyleSets({
        root: ["listing-bookmarks", styles.root, className]
    })
});

export { IListingBookmarkClassNames, getClassNames }