import * as React from "react";
import { IAppHostBaseProps } from "@twii/common/lib/component/IAppHostBaseProps";
import { IListing } from "../../listing/IListing";
import { AppFrame } from "@twii/common/lib/component/AppFrame";

interface IListingAppFrameProps extends IAppHostBaseProps {
    listing: IListing;
}

class ListingAppFrame extends React.Component<IListingAppFrameProps, any> {
    render() {
        return (
            <AppFrame host={this.props.host}
                      src={this.props.listing.launch_url} />
        );
    }
}

export {
    IListingAppFrameProps,
    ListingAppFrame
}