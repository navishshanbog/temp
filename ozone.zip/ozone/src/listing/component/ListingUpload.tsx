import * as React from "react";
import { IListingUploadProps, IListingUploadStyleProps, IListingUploadStyles } from "./ListingUpload.types";
import { getStyles } from "./ListingUpload.styles";
import { classNamesFunction, styled } from "@uifabric/utilities";
import { observer } from "mobx-react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Link } from "office-ui-fabric-react/lib/Link";
import { Spinner, SpinnerSize } from "office-ui-fabric-react/lib/Spinner";

const getClassNames = classNamesFunction<IListingUploadStyleProps, IListingUploadStyles>();

@observer
class ListingUploadBase extends React.Component<IListingUploadProps, any> {
    private _fileInputRef : HTMLInputElement;
    private _upload(file : File) {
        const up = this.props.listing.upload(file);
        if(this.props.onAfterUpload) {
            up.then(() => {
                this.props.onAfterUpload(this.props);
            });
        }
    }
    private _onInputChange = (e) => {
        const fileList = this._fileInputRef.files;
        if(fileList.length > 0) {
            // upload the file via the model
            this._upload(fileList.item(0));
        }
    }
    private _onFileInputRef = (ref : HTMLInputElement) => {
        this._fileInputRef = ref;
    }
    private _onDragOver = (e : React.DragEvent<HTMLElement>) => {
        e.stopPropagation();
        e.preventDefault();
    }
    private _onDrop = (e : React.DragEvent<HTMLElement>) => {
        e.stopPropagation();
        e.preventDefault();
        if(e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            const file = e.dataTransfer.files.item(0);
            this._upload(file);
        }
    }
    private _onClickSelectPackage = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        try {
            this._fileInputRef.click();
        } catch(e) {}
    }
    render() {
        const { listing, styles, className, theme } = this.props;
        const classNames = getClassNames(styles, {
            className: className,
            theme: theme
        });
        return (
            <div className={classNames.root} onDragOver={this._onDragOver} onDrop={this._onDrop}>
                <input type="file"
                       accept=".zip, .tar.gz, .tgz"
                       onChange={this._onInputChange}
                       ref={this._onFileInputRef}
                       value=""
                       hidden={true}
                       style={{ display: "none" }}
                       disabled={listing.saveSync.syncing} />
                {listing.saveSync.syncing && (
                    <div className={classNames.content}>
                        <Spinner size={SpinnerSize.small} /> {listing.saveSync.type === "upload" ? " Uploading Package..." : " Saving Listing..."}
                    </div>
                )}
                {!listing.saveSync.syncing && (
                    <div className={classNames.content}>
                        <Icon iconName="CloudUpload" /> Drop a package here or <Link onClick={this._onClickSelectPackage}>select a package</Link>
                    </div>
                )}
            </div>
        );
    }
}

export const ListingUpload : React.StatelessComponent<IListingUploadProps> = styled<IListingUploadProps, IListingUploadStyleProps, IListingUploadStyles>(
    ListingUploadBase,
    getStyles,
    undefined,
    {
        scope: "ListingUpload"
    }
)