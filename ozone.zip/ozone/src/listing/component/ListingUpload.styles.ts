import { getTheme } from "@uifabric/styling";
import { IListingUploadStyleProps, IListingUploadStyles } from "./ListingUpload.types";

export const getStyles = (props : IListingUploadStyleProps) : IListingUploadStyles => {
    let { className, theme } = props;
    if(!theme) {
        theme = getTheme();
    }
    return {
        root: [
            "package-upload-input",
            {
                position: "relative",
                height: 100,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: theme.palette.neutralLight,
                borderRadius: 4,
                selectors: {
                    "&.package-drag-over": {
                        selectors: {
                            "$content": {
                                backgroundColor: theme.palette.themeLight
                            }
                        }
                    }
                }
            },
            className
        ],
        content: [
            "package-upload-input-content",
            {
                position: "absolute",
                top: 8,
                right: 8,
                bottom: 8,
                left: 8,
                border: `1px dashed ${theme.palette.neutralTertiary}`,
                borderRadius: 4,
                backgroundColor: theme.palette.white,
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                whiteSpace: "pre-wrap"
            }
        ]
    }
};