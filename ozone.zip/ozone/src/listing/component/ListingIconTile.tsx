import * as React from "react";
import { IListing } from "../IListing";
import { IListingIconTileStyles, getStyles } from "./ListingIconTile.styles";
import { getClassNames, IListingIconTileClassNames } from "./ListingIconTile.classNames";
import { Persona, PersonaSize } from "office-ui-fabric-react/lib/Persona";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import { getTheme } from "@uifabric/styling";

enum ListingIconSize {
    small = 16,
    large = 32
}

interface IListingIconTileProps {
    listing: IListing;
    onClick?: (listing : IListing, e : React.MouseEvent<HTMLElement>) => void;
    onClickInfo?: (listing : IListing, e : React.MouseEvent<HTMLButtonElement>) => void;
    iconSize?: ListingIconSize,
    styles?: IListingIconTileStyles;
    className?: string;
}

class ListingIconTileIcon extends React.Component<IListingIconTileProps, any> {
    render() {
        const { listing, iconSize } = this.props;
        let iconUrl : string;
        let iconImageSize : ListingIconSize = iconSize || ListingIconSize.large;
        if(iconImageSize === ListingIconSize.small) {
            iconUrl = listing.small_icon ? listing.small_icon.url : undefined;
        } else {
            iconUrl = listing.large_icon ? listing.large_icon.url : undefined;
        }
        const personaSize = iconImageSize === ListingIconSize.small ? PersonaSize.size16 : undefined;
        return (
            <Persona size={personaSize} hidePersonaDetails imageUrl={iconUrl} text={listing.title} />
        );
    }
}

class ListingInfoButton extends React.Component<IListingIconTileProps, any> {
    private _onClick = (e : React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();
        this.props.onClickInfo(this.props.listing, e);
    }
    render() {
        if(this.props.onClickInfo) {
            return <IconButton title={`Open details for ${this.props.listing.title}`}
                                iconProps={{ iconName: "Info"}}
                                styles={{
                                    root: {
                                        color: getTheme().palette.blue
                                    }
                                }}
                                onClick={this._onClick} />
        }
        return null;
    }
}

class ListingIconTile extends React.Component<IListingIconTileProps, any> {
    private _classNames : IListingIconTileClassNames;
    private _onClick = (e : React.MouseEvent<HTMLElement>) => {
        this.props.onClick(this.props.listing, e);
    }
    private _onRenderActions = () => {
        return (
            <div className={this._classNames.actions}>
                <ListingInfoButton {...this.props} />
            </div>
        )
    }
    private _onRenderTop = () => {
        return (
            <div className={this._classNames.top}>
                <ListingIconTileIcon {...this.props} />
                {this._onRenderActions()}
            </div>
        );
    }
    private _onRenderContent = () => {
        return (
            <div className={this._classNames.content}>
                <div className={this._classNames.title}>{this.props.listing.title}</div>
            </div>
        )
    }
    render() {
        const { listing, styles, className, onClick } = this.props;
        this._classNames = getClassNames(getStyles(null, styles), className);
        return (
            <div role="button" title={onClick ? `Launch ${listing.title}` : listing.title} className={this._classNames.root} onClick={onClick ? this._onClick : undefined}>
                {this._onRenderTop()}
                {this._onRenderContent()}
            </div>
        );
    }
}

export {
    IListingIconTileProps,
    ListingIconTile,
    ListingIconTileIcon,
    ListingIconSize }