import * as React from "react";
import { IAppHostBaseProps } from "@twii/common/lib/component/IAppHostBaseProps";
import { IListing } from "../IListing";
import { ScriptFrame } from "../../common/component/ScriptFrame";
import { IRequest } from "@twii/common/lib/IRequest";
import { PathsContext } from "../../PathsContext";
import { IUserProfile } from "../../user/IUserProfile";

interface IListingScriptFrameProps extends IAppHostBaseProps {
    listing: IListing;
    defaultRequest?: IRequest;
    userProfile?: IUserProfile;
}

class ListingScriptFrame extends React.Component<IListingScriptFrameProps, any> {
    private _launchApp = (request) => {
        return this.props.host.open({
            path: PathsContext.value.listingLaunch(this.props.listing.id),
            transient: request.transient,
            makeActive: request.makeActive,
            params: {
                defaultRequest: request
            }
        });
    }
    render() {
        return (
            <ScriptFrame host={this.props.host}
                        src={this.props.listing.launch_url}
                        launcher={this._launchApp}
                        defaultRequest={this.props.defaultRequest}
                        userProfile={this.props.userProfile} />
        );
    }
}

export {
    IListingScriptFrameProps,
    ListingScriptFrame
}