import * as React from "react";
import { ListingReviewListContainer } from "./ListingReviewList";
import { IListingModel } from "../model/IListingModel";
import { getReviews } from "../model/ListingReviewHelper";
import { IAppHostBaseProps } from "@twii/common/lib/component/IAppHostBaseProps";
import { OzoneAppView } from "../../common/component/OzoneAppView";
import { ListingAppBase } from "./ListingAppBase";
import { ListingContainer } from "./Listing";

interface IListingReviewListAppProps extends IAppHostBaseProps {
    listingId: number;
}

class ListingReviewListApp extends ListingAppBase {
    private _onRenderListing = () => {
        return <ListingReviewListContainer reviewList={getReviews(this.listing)} />;
    }
    protected _setTitleFromListing() {
        this.host.title = `Reviews for ${this.listing.title}`;
    }
    render() {
        return (
            <OzoneAppView host={this.host}>
                <ListingContainer listing={this.listing} onRenderListing={this._onRenderListing} />
            </OzoneAppView>
        );
    }
}

export { IListingReviewListAppProps, ListingReviewListApp }
