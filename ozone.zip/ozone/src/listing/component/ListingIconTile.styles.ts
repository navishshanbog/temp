import { IStyle, ITheme, getTheme, concatStyleSets, FontSizes } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface IListingIconTileStyles {
    root?: IStyle;
    top?: IStyle;
    actions?: IStyle;
    content?: IStyle;
    title?: IStyle;
}

const defaultStyles = (theme : ITheme) : IListingIconTileStyles => {
    return {
        root: {
            justifyContent: "center",
            padding: 0,
            background: "transparent",
            outline: "none",
            borderRadius: 4,
            cursor: "pointer",
            width: 130,
            maxWidth: 130,
            minWidth: 130,
            backgroundColor: theme.palette.white,
            boxShadow: "0 0 10px rgba(0, 0, 0, 0.05)",
            transition: "box-shadow 0.5s",
            border: `1px solid ${theme.palette.neutralQuaternary}`,
            selectors: {
                "&:hover": {
                    boxShadow: "0 5px 30px rgba(0, 0, 0, 0.15)",
                    selectors: {
                        "$top": {
                            backgroundColor: theme.palette.neutralQuaternaryAlt
                        }
                    }
                }
            }
        },
        top: {
            position: "relative",
            height: 80,
            minHeight: 80,
            maxHeight: 80,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: theme.palette.neutralLight
        },
        actions: {
            position: "absolute",
            top: 0,
            right: 0,
            height: 28,
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end"
        },
        content: {
            height: 36,
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        },
        title: {
            fontSize: FontSizes.small,
            width: 120,
            textOverflow: "ellipsis",
            overflow: "hidden",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexWrap: "wrap",
            textAlign: "center"
        }
    };
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles?: IListingIconTileStyles) : IListingIconTileStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export {
    IListingIconTileStyles,
    defaultStyles,
    Defaults,
    getStyles
}