import * as React from "react";
import { ListingContainer, ListingDeleteDialog } from "./Listing";
import { ListingDeleteStore } from "../model/ListingDeleteStore";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { OzoneAppView } from "../../common/component/OzoneAppView";
import { ICategory } from "../../category/ICategory";
import { PathsContext } from "../../PathsContext";
import { IMutableSync } from "@twii/common/lib/IMutableSync";
import { IListing } from "../IListing";
import { Sync } from "@twii/common/lib/model/Sync";
import { launch } from "../ListingLaunch";
import { ListingLaunchDialog } from "./ListingLaunchDialog";
import { listingEditMenuItem, listingWorkflowSubmitMenuItem, listingApproveMenuItem, listingRejectMenuItem, listingDeleteMenuItem } from "./ListingAction";
import { syncRefreshItem } from "@twii/common/lib/component/SyncRefreshAction";
import { ListingAppBase } from "./ListingAppBase";

class ListingApp extends ListingAppBase {
    private _onEdit = () => {
        this.host.load({ path: PathsContext.value.listingEdit(this.listing.id) });
    }
    private _onDelete = () => {
        ListingDeleteStore.setValue(this.listing);
    }
    get launchSync() : IMutableSync<IListing> {
        return this.host.getState("appLaunchSync", () => {
            return new Sync();
        });
    }
    private _onLaunchApp = (listing : IListing) => {
        this.launchSync.syncStart({ id: listing });
        launch({ host: this.host, userProfile: this.userProfile, listingId: listing.id, noReplace: true }).then(app => {
            this.launchSync.syncEnd();
        }).catch(err => {
            this.launchSync.syncError(err);  
        });
    }
    private _onSubmit = () => {
        this.listing.submitForApproval();
    }
    private _onApprove = () => {
        this.listing.approve();
    }
    private _onReject = () => {
        this.listing.reject();
    }
    private _onRefresh = () => {
        this.listing.refresh();
    }
    private _onSelectCategory = (category : ICategory) => {
        console.log("-- On Select Category: " + JSON.stringify(category));
    }
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.isAdmin || this.isOwner) {
            items.push(
                listingEditMenuItem({ listing: this.listing, onClick: this._onEdit }),
                listingWorkflowSubmitMenuItem({ listing: this.listing, onClick: this._onSubmit })
            );
            if(this.isAdmin) {
                items.push(
                    listingApproveMenuItem({ listing: this.listing, onClick: this._onApprove }),
                    listingRejectMenuItem({ listing: this.listing, onClick: this._onReject }),
                    listingDeleteMenuItem({ listing: this.listing, onClick: this._onDelete })
                );
            }
        }
        const farItems : IContextualMenuItem[] = [
            syncRefreshItem({ sync: this.listing.loadSync, onClick: this._onRefresh })
        ];
        return (
            <OzoneAppView host={this.host} userProfile={this.userProfile} commandBarProps={{ items: items, farItems: farItems }}>
                <ListingLaunchDialog sync={this.launchSync} />
                <ListingDeleteDialog listingSupplier={ListingDeleteStore} />
                <ListingContainer listing={this.listing}
                                  onEdit={this._onEdit}
                                  onDelete={this._onDelete}
                                  onLaunch={this._onLaunchApp}
                                  onSelectCategory={this._onSelectCategory} />
            </OzoneAppView>
        );
    }
}

export {
    ListingApp,
    ListingApp as default
}

