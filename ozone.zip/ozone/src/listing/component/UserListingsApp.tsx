import * as React from "react";
import { OzoneAppBase } from "../../common/component/OzoneAppBase";
import { ListingViewConfig } from "./ListingViewConfig";
import { PathsContext } from "../../PathsContext";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { UserAdminContext } from "../../user/UserAdminContext";
import { OzoneAppView } from "../../common/component/OzoneAppView";
import { UserListingsContainer } from "./UserListings";
import { IListingListModel } from "../model/IListingListModel";
import { IListing } from "../IListing";
import { IMutableSync } from "@twii/common/lib/IMutableSync";
import { Sync } from "@twii/common/lib/model/Sync";
import { launch } from "../ListingLaunch";
import { ListingLaunchDialog } from "./ListingLaunchDialog";
import { ListingListStore } from "../model/ListingListStore";
import { IAppViewStyles } from "@twii/common/lib/component/AppView.styles";
import { syncRefreshItem } from "@twii/common/lib/component/SyncRefreshAction";

class UserListingsApp extends OzoneAppBase {
    protected get iconName() : string {
        return "Backlog";
    }
    componentWillMount() {
        this.host.setTitle(`My ${ListingViewConfig.labelPlural}`);
        this.host.icon.name = this.iconName;
    }
    private _onLoadStore = () => {
        this.host.load({ path: PathsContext.value.store() });
    }
    private _onLoadAllListings = () => {
        this.host.load({ path: PathsContext.value.listings() });
    }
    get listingList() : IListingListModel {
        return ListingListStore;
    }
    get launchSync() : IMutableSync<IListing> {
        return this.host.getState("appLaunchSync", () => {
            return new Sync();
        });
    }
    protected get appViewStyles() : IAppViewStyles {
        return {};
    }
    protected get showLinks() : boolean {
        return true;
    }
    private _onLaunchApp = (listing : IListing) => {
        this.launchSync.syncStart({ id: listing });
        launch({ host: this.host, userProfile: this.userProfile, listingId: listing.id }).then(app => {
            this.launchSync.syncEnd();
        }).catch(err => {
            this.launchSync.syncError(err);  
        });
    }
    private _onRefreshList = () => {
        this.listingList.refresh();
    }
    private _onClickInfo = (listing : IListing) => {
        this.host.load({ path: PathsContext.value.listingDetails(listing.id) });
    }
    render() {
        const farItems : IContextualMenuItem[] = [];
        if(this.showLinks) {
            farItems.push(
                {
                    key: "store",
                    name: `${ListingViewConfig.storeLabel}`,
                    iconProps: {
                        iconName: "Shop"
                    },
                    onClick: this._onLoadStore
                }
            );
        }
        if(this.showLinks && UserAdminContext.value(this.userProfile)) {
            farItems.push({
                key: "listings",
                name: `All ${ListingViewConfig.labelPlural}`,
                iconProps: {
                    iconName: "ViewList"
                },
                onClick: this._onLoadAllListings
            });
        }
        farItems.push(
            syncRefreshItem({
                sync: this.listingList.sync,
                onClick: this._onRefreshList,
                title: `Refresh ${ListingViewConfig.labelPlural}`
            })
        );
        return (
            <OzoneAppView host={this.host} userProfile={this.userProfile} commandBarProps={{ items: [], farItems: farItems }} styles={this.appViewStyles}>
                <ListingLaunchDialog sync={this.launchSync} />
                <UserListingsContainer userProfile={this.userProfile}
                                       listingList={this.listingList}
                                       onLaunchApp={this._onLaunchApp}
                                       onClickInfo={this._onClickInfo} />
            </OzoneAppView>
        );
    }
}

export { UserListingsApp, UserListingsApp as default }