import { IStyle, ITheme, getTheme, concatStyleSets } from "@uifabric/styling";
import { memoizeFunction } from "@uifabric/utilities";

interface IListingBookmarkStyles {
    root?: IStyle;
}

const defaultStyles = (theme : ITheme) : IListingBookmarkStyles => {
    return {
        root: {
            display: "flex",
            flexWrap: "wrap"
        }
    };
};

const Defaults = {
    styles: defaultStyles
};

const getStyles = memoizeFunction((theme : ITheme, customStyles?: IListingBookmarkStyles) : IListingBookmarkStyles => {
    if(!theme) {
        theme = getTheme();
    }
    return concatStyleSets(Defaults.styles(theme), customStyles);
});

export { getStyles, Defaults, defaultStyles, IListingBookmarkStyles }