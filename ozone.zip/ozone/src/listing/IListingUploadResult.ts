import { IListing } from "./IListing";

interface IPackageSource {
    contentType?: string;
    name?: string;
    size?: number;
}

interface IPackage {
    info?: any;
    base_url?: string;
    resource_path?: string;
}

interface IListingUploadResult {
    source?: IPackageSource;
    package?: IPackage;
    listing_props?: IListing;
    listing?: IListing;
}

export {
    IListingUploadResult
}