interface IListingLink {
    name?: string;
    url?: string;
}

export { IListingLink }