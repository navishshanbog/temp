import * as React from "react";
import { IAppProps } from "@twii/common/lib/component/IAppProps";
import { IAppHost } from "@twii/common/lib/IAppHost";
import { IUserProfile } from "../../user/IUserProfile";
import { UserAdminContext } from "../../user/UserAdminContext";

class OzoneAppBase extends React.Component<IAppProps, any> {
    get host() : IAppHost {
        return this.props.match.host;
    }
    get userProfile() : IUserProfile {
        return this.props.match.userProfile;
    }
    get isAdmin() : boolean {
        return UserAdminContext.value(this.userProfile);
    }
    render() {
        return null;
    }
}

export { OzoneAppBase }