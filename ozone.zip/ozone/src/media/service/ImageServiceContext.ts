import { Context } from "@twii/common/lib/Context";
import { IImageService } from "./IImageService";

const ImageServiceContext = new Context<IImageService>();

export { ImageServiceContext }