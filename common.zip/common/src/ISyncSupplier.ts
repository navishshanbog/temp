import { IMutableSupplier } from "./IMutableSupplier";
import { ISync } from "./ISync";

interface ISyncSupplier<T = any, P = any> extends IMutableSupplier<T> {
    sync: ISync;
    parent : P;
    setParent(parent : P) : void;
    load() : Promise<void>;
    refresh() : Promise<void>;
}

export { ISyncSupplier }