import { Context } from "./Context";
import { IAppHost } from "./IAppHost";
import AppContext from "./AppContext";

const HostContext = new Context<IAppHost>({
    factory() {
        return AppContext.value.rootAppHost
    }
});

export { HostContext }