import { HistoryModel } from "./model/HistoryModel";
export { HistoryModel, HistoryModel as default }