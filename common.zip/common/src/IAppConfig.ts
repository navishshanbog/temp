interface IAppConfig {
    production?: boolean;
    configName?: string;
    basePath?: string;
    fabricFontBasePath?: string;
    fabricIconBasePath?: string;
    buildVersion: string;
    buildDate: Date;
}

export { IAppConfig as default, IAppConfig }