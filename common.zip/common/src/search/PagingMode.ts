enum PagingMode {
    offset = "offset",
    cursor = "cursor"
}

export { PagingMode }