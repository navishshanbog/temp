enum SearchSchemaFieldType {
    divider = "divider",
    date = "date",
    string = "string",
    number = "number",
    boolean = "boolean",
    header= "header"
}

interface ISearchSchemaFieldConfig {
}

interface ISearchSchemaStringFieldConfig extends ISearchSchemaFieldConfig {
    supportsBeginsWith: boolean;
    supportsEndsWith: boolean;
}

interface ISearchSchemaField {
    key: string;
    type?: SearchSchemaFieldType,
    config?: ISearchSchemaFieldConfig,
    name?: string;
    searchFields?: string[];
    fields?: string[];
    aliases?: string[];
    hidden?: boolean;
    toSearchString?: (value : string) => string;
    fieldDomain?: string;
    iconName?: string;
}

interface ISearchSchema {
    fields: ISearchSchemaField[]
}

export {
    SearchSchemaFieldType,
    ISearchSchemaFieldConfig,
    ISearchSchemaStringFieldConfig,
    ISearchSchemaField,
    ISearchSchema
}