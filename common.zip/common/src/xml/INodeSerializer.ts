interface INodeSerializer {
    serializeNode(node : Node) : string;
}

export { INodeSerializer as default, INodeSerializer }