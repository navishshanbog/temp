import { ILoggingService } from "./ILoggingService";

const ConsoleLoggingService : ILoggingService = console;

export { ConsoleLoggingService }