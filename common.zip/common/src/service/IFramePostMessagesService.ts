import {IAppHost} from "../IAppHost";
import {Observable, fromEvent} from "rxjs";
import {Subscription} from "rxjs/Rx";
import {
    IIFramePostMessagesBroadcasterMessage,
    IIFramePostMessagesBroadcasterResponse
} from "./IFramePostMessagesBroadcaster";

enum ValidIFramePostMessagesCommands {
    open = "open",
    load = "load"
}

interface IIFramePostMessagesServiceMessage extends IIFramePostMessagesBroadcasterMessage {
    uniqueId: string;
    hostId: string;
}

interface IIFramePostMessagesService {
    destroy: () => void;
}

class IFramePostMessagesService implements IIFramePostMessagesService {
    _postMessagesListener: Observable<Event> = fromEvent(window, "message");
    _postMessagesListenerSubscription: Subscription;
    private _appHost: IAppHost;
    private _validateMessageData = (data: IIFramePostMessagesServiceMessage): boolean => {
        return data && data.uniqueId && data.hostId && data.command && data.hostId === this._appHost.id;
    };

    private _postMessage(message: IIFramePostMessagesBroadcasterResponse) {
        const iframe: HTMLIFrameElement = document.getElementsByName(message.frameId)[0] as HTMLIFrameElement;
        iframe.contentWindow.postMessage(message, "*");
    }

    constructor(host: IAppHost) {
        this._appHost = host;
        this._postMessagesListenerSubscription = this._postMessagesListener.subscribe((e: MessageEvent) => {
            const data: IIFramePostMessagesServiceMessage = e.data;

            if (this._validateMessageData(data)) {
                if (data.command === ValidIFramePostMessagesCommands.load) {
                    if (data.path && data.params) {
                        this._appHost.load({
                            path: data.path,
                            params: data.params
                        }).then(() => {
                            this._postMessage({
                                frameId: data.hostId,
                                uniqueId: data.uniqueId,
                                data: "Done"
                            });
                        })
                    }

                }

                if (data.command === ValidIFramePostMessagesCommands.open) {
                    if (data.path && data.params) {
                        this._appHost.open({
                            path: data.path,
                            params: data.params
                        }).then(() => {
                            this._postMessage({
                                frameId: data.hostId,
                                uniqueId: data.uniqueId,
                                data: "Done"
                            });
                        })
                    }
                }
            }
        })
    }

    destroy = () => {
        this._postMessagesListenerSubscription.unsubscribe();
    }

}

export {
    IFramePostMessagesService as default,
    IFramePostMessagesService,
    IIFramePostMessagesService,
    IIFramePostMessagesServiceMessage,
    ValidIFramePostMessagesCommands
}