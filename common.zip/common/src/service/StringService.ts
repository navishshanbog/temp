import * as StringUtils from "../StringUtils";
import { IStringService } from "./IStringService";

const StringService : IStringService = StringUtils;

export { StringService }