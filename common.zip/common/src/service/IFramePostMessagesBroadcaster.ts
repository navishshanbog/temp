import {Observable, fromEvent, Subject, Subscription} from "rxjs";
import {IIFramePostMessagesServiceMessage, ValidIFramePostMessagesCommands} from "./IFramePostMessagesService";
import {isNumber} from "../util/Lang";

interface IIFramePostMessagesBroadcasterMessage {
    command: ValidIFramePostMessagesCommands;
    path?: string;
    params?: any;
}

interface IIFramePostMessagesBroadcaster {
    send: (message: IIFramePostMessagesBroadcasterMessage) => Promise<IIFramePostMessagesBroadcasterResponse>;
}

interface IIFramePostMessagesBroadcasterResponse {
    uniqueId: string;
    frameId: string;
    data: any;
}

class IFramePostMessagesBroadcaster implements IIFramePostMessagesBroadcaster {
    _postMessagesListener: Observable<Event> = fromEvent(window, "message");
    _postMessagesListenerSubscription: Subscription;
    _postMessagesResponseSubject: Subject<IIFramePostMessagesBroadcasterResponse> = new Subject<IIFramePostMessagesBroadcasterResponse>();

    private readonly _appId: string;
    private _timeoutMS: number = 10000;

    private _validateMessageData = (data: IIFramePostMessagesBroadcasterResponse): boolean => {
        return data && data.uniqueId && data.frameId && data.frameId === this._appId;
    };

    constructor(iframeName: string, responseTimeoutMS?: number) {
        this._appId = iframeName;
        this._timeoutMS = isNumber(responseTimeoutMS) ? responseTimeoutMS : this._timeoutMS;

        this._postMessagesListenerSubscription = this._postMessagesListener.subscribe((e: MessageEvent) => {
            const data: IIFramePostMessagesBroadcasterResponse = e.data;

            if (this._validateMessageData(data)) {
                this._postMessagesResponseSubject.next(data);
            }
        })
    }

    private _postMessage = (message: IIFramePostMessagesServiceMessage) => {
        if (window) {
            window.parent.postMessage(message, "*");
        }
    };

    send = (message: IIFramePostMessagesBroadcasterMessage) => {
        const uniqueId = `${this._appId}_${Math.random()}`;
        const msg: IIFramePostMessagesServiceMessage = {
            uniqueId: uniqueId,
            hostId: this._appId,
            command: message.command,
            params: message.params,
            path: message.path
        };

        this._postMessage(msg);

        return new Promise<IIFramePostMessagesBroadcasterResponse>((resolve, reject) => {

            const subscription = this._postMessagesResponseSubject.subscribe(res => {
                handlePromise(res);
            });

            const handlePromise = (res: IIFramePostMessagesBroadcasterResponse) => {
                if (res.uniqueId === uniqueId) {
                    resolve(res);
                    subscription.unsubscribe();
                }
            };

            setTimeout(() => {
                reject("Timeout");
                subscription.unsubscribe();
            }, this._timeoutMS);
        })
    };

    destroy = () => {
        this._postMessagesListenerSubscription.unsubscribe();
    }
}

export {
    IFramePostMessagesBroadcaster as default,
    IFramePostMessagesBroadcaster,
    IIFramePostMessagesBroadcaster,
    IIFramePostMessagesBroadcasterResponse,
    IIFramePostMessagesBroadcasterMessage
}