interface ISupplier<T> {
    readonly value: T;
}

export { ISupplier }