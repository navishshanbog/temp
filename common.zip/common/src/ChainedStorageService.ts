import { ChainedStorageService } from "./service/ChainedStorageService";
export { ChainedStorageService, ChainedStorageService as default }