interface IList<T = any> {
    items: T[];
}

export { IList, IList as default }