import IAppHost from "./IAppHost";

interface IAppletProps {
    host: IAppHost;
}

export { IAppletProps as default, IAppletProps }