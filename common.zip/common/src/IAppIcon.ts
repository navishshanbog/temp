interface IAppIcon {
    url?: string;
    text?: string;
    name?: string;
    component?: any;
}

export { IAppIcon }