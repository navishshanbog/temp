import { IStorageService } from "./service/IStorageService";

export { IStorageService as default, IStorageService };