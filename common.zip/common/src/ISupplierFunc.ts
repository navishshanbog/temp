interface ISupplierFunc<T> {
    () : T;
}

export { ISupplierFunc }