import { IRequest } from "../IRequest";

interface IAppProps {
    match: IRequest;
}

export { IAppProps }