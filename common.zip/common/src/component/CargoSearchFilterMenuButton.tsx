import * as React from "react";
import { observer } from "mobx-react";
import IActivityFilterModel from "../IActivityFilterModel";
import { SearchBox } from "office-ui-fabric-react/lib/SearchBox";
import { IContextualMenuItem, ContextualMenuItemType, IContextualMenuProps } from "office-ui-fabric-react/lib/ContextualMenu";
import { IIconProps } from "office-ui-fabric-react/lib/Icon";
import MomentField from "./MomentField";
import { css } from "@uifabric/utilities/lib/css";
import { IActivityFilterMenuButtonStyles, getStyles } from "./ActivityFilterMenuButton.styles";
import { getClassNames } from "./ActivityFilterMenuButton.classNames";

interface IActivityFilterViewOptions {
    textFilterHidden?: boolean;
    fromFilterHidden?: boolean;
    toFilterHidden?: boolean;
}

interface IActivityFilterProps {
    activityFilter: IActivityFilterModel;
    viewOptions?: IActivityFilterViewOptions;
    iconProps?: IIconProps;
    onRenderContent: (activityFilter : IActivityFilterModel) => React.ReactNode | string;
    styles?: IActivityFilterMenuButtonStyles;
    className?: string;
}

@observer
class CargoSearchFilterMenuButton extends React.Component<IActivityFilterProps, any> {
    private _onFilterTextChange = (text) => {
        this.props.activityFilter.setFilterText(text);
    };
    private _onRenderFilterTextItem = (item) => {
        return <SearchBox disableAnimation onChange={this._onFilterTextChange} value={this.props.activityFilter.filterText} key={item.key} placeholder="Text Filter" className="activity-filter-menu-input-item" />
    }
   
    render() {
       let items : IContextualMenuItem[] = [];
       
        if(!this.props.viewOptions || !this.props.viewOptions.textFilterHidden) {
            items.push({
                key: "textFilter",
                onRender: this._onRenderFilterTextItem
            });
        }
       
        return (
           <SearchBox disableAnimation onChange={this._onFilterTextChange} value={this.props.activityFilter.filterText} placeholder="Text Filter" className="activity-filter-menu-input-item" />
        );
    }
}

export { CargoSearchFilterMenuButton as default, CargoSearchFilterMenuButton, IActivityFilterProps, IActivityFilterViewOptions }
