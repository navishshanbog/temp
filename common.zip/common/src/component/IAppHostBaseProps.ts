import { IAppHost } from "../IAppHost";

interface IAppHostBaseProps {
    host: IAppHost;
}

export { IAppHostBaseProps }