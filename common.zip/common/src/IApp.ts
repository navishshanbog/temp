import { IAppConfig } from "./IAppConfig";
import { IRouter } from "roota/lib/IRouter";
import { IAppHost } from "./IAppHost";

interface IApp {
    config: IAppConfig;
    router: IRouter;
    rootAppHost: IAppHost;
}

export { IApp as default, IApp }